import{importTableSpec2,inspectTableSpec2,exportTableSpec2}from"./explorer.js";export{exportTableSpec2 as exportTableSpec,importTableSpec2 as importTableSpec,inspectTableSpec2 as inspectTableSpec};
