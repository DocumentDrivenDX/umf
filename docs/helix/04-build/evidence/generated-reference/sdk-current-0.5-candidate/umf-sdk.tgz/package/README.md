# UMF SDK

This single SDK contains the browser ESM, TypeScript declarations and schemas, including umf.actions. Import createUmfRegistry from the public entrypoint for built-in action declaration support. No separate actions installation is needed. Vocabulary versions remain explicit; executors, credentials and database runtimes are selected separately. This archive does not install a hosted executor or broaden adapter qualification.
