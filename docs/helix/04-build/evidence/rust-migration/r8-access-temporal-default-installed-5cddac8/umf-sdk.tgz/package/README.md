# UMF SDK

The package root uses the synchronous Rust V4 Python-client generator. The TypeScript implementation remains available from `@umf/core/reference`. This package is private pending broader R7/R8 qualification.
