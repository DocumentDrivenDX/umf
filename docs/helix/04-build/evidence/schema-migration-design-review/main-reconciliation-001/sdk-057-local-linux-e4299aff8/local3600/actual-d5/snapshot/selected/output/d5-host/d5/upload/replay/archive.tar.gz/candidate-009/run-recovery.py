import hashlib,json,pathlib,subprocess,sys
base=pathlib.Path('/private/tmp/umf-g02-independent-009')
results=[]
for scenario in ('fenced-resume','backfill-commit-lost','existing-target-commit-lost','no-default'):
 report=base/(scenario+'.json');assert not report.exists()
 if scenario=='no-default':
  command=[sys.executable,'-I',str(base/'no-default-runner.py'),'--dsn','dbname=postgres','--fixture',str(base/'no-default-fixture.json'),'--report',str(report)]
 else:
  command=[sys.executable,'-I',str(base/'fault-runner.py'),'--dsn','dbname=postgres','--fixture',str(base/'fault-fixture.json'),'--manifest',str(base/'owner-artifacts.json'),'--scenario',scenario,'--report',str(report)]
 with (base/(scenario+'.log')).open('w') as log:
  run=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 assert run.returncode==0,(scenario,(base/(scenario+'.log')).read_text()[-3500:])
 data=json.loads(report.read_text());results.append({'scenario':scenario,'checks':len(data['checks']),'reportSha256':hashlib.sha256(report.read_bytes()).hexdigest()})
 print(json.dumps(results[-1]),flush=True)
(base/'recovery-summary.json').write_text(json.dumps(results,indent=2)+'\n')
