import pathlib,hashlib,json,os,sys,subprocess
out=pathlib.Path(__file__).resolve().parent;root=out/'source';before=json.loads((root/'cases-before.json').read_text());after=json.loads((root/'cases-after.json').read_text());delta=json.loads((root/'inventory-delta.json').read_text());planpath=root/'docs/helix/03-test/security/cases.json';planpath.parent.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();records=[];all_sources={};native_calls=[];original_run=subprocess.run
# Prefixes are cut immediately after the unchanged exact set assertion. A hard
# process sentinel additionally prohibits executing any child/native command.
def forbidden(*args,**kwargs):native_calls.append(str(args));raise RuntimeError('No subprocess allowed in inventory review')
subprocess.run=forbidden
os.chdir(root);sys.argv=['independent-prefix'];sys.dont_write_bytecode=True;os.environ['UMF_SECURITY_RUN_ID']='c3e6b0cd-7c0b-4111-b350-88685f0ae408'
for d in delta['cases']:
 c=next(c for c in after['cases']if c['id']==d['id']);p=root/c['testSource'];raw=p.read_text();lines=raw.splitlines(True);stop=next(i for i,l in enumerate(lines)if 'if not spike:assert set(sources)=='in l)+1;prefix=''.join(lines[:stop]);assert sha(p.read_bytes())==d['testSourceSha256'];os.environ['UMF_SECURITY_CASE_ID']=c['id']
 variants=[('before',before,False),('after',after,True)]
 for added in d['added']:
  q=json.loads(json.dumps(after));entry=next(e for e in q['cases']if e['id']==c['id']);entry['implementationSources'].remove(added);variants.append(('omit:'+added,q,False))
 q=json.loads(json.dumps(after));entry=next(e for e in q['cases']if e['id']==c['id']);entry['implementationSources'].append('inventory-delta.json');variants.append(('extra-unrelated-input',q,False))
 for label,plan,wanted in variants:
  planpath.write_text(json.dumps(plan));env={'__name__':'__inventory_prefix__','__file__':str(p)};error=None
  try:exec(compile(prefix,str(p),'exec'),env);passed=True
  except AssertionError:passed=False;error='AssertionError'
  assert passed==wanted,(c['id'],label,error);assert not native_calls
  actual=env['sources'];assert sorted(actual)==d['actual'];all_sources.update(actual)
  records.append({'case':c['id'],'control':label,'expectedAssertionPass':wanted,'actualAssertionPass':passed,'passed':True,'prefixFinalLine':stop,'prefixSha256':sha(prefix.encode()),'actualInventoryCount':len(actual),'nativeCommands':0})
planpath.write_bytes((root/'cases-after.json').read_bytes());assert not native_calls
report={'scope':'Original unchanged Python prefixes through exact source-set assertion; all subprocess/native execution prohibited. No native acceptance.','controls':records,'total':len(records),'nativeCommands':native_calls,'sourceDigests':dict(sorted(all_sources.items())),'sourceCount':len(all_sources)}
(out/'prefix-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'controls':len(records),'sourceCount':len(all_sources),'nativeCommands':len(native_calls)}))
