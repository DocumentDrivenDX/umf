import pathlib,json,hashlib,subprocess,tarfile,io
out=pathlib.Path(__file__).resolve().parent;r=out/'source';repo='/Users/erik/.codex/worktrees/security-main-integration/umf';base=subprocess.check_output(['git','-C',repo,'rev-parse','0b2bf0c1^{commit}'],text=True).strip();checks=json.loads((out/'prefix-controls.json').read_text());paths=list(checks['sourceDigests']);data=subprocess.check_output(['git','-C',repo,'archive',base,*paths]);t=tarfile.open(fileobj=io.BytesIO(data));mismatches=[]
for p,h in checks['sourceDigests'].items():
 frozen=(r/p).read_bytes();assert hashlib.sha256(frozen).hexdigest()==h
 git=t.extractfile(p).read()
 if git!=frozen:mismatches.append(p)
assert not mismatches
before=subprocess.check_output(['git','-C',repo,'show',base+':docs/helix/03-test/security/cases.json']);assert before==(r/'cases-before.json').read_bytes()
gov=out/'governance';gov.mkdir(exist_ok=True)
for p in ['AGENTS.md','.helix.yml','docs/helix/README.md']:
 b=subprocess.check_output(['git','-C',repo,'show',base+':'+p]);q=gov/p;q.parent.mkdir(exist_ok=True,parents=True);q.write_bytes(b)
report={'baseCommit':base,'sourceCount':len(paths),'all127SourcesExactGitBase':True,'mismatches':mismatches,'sourceDigests':checks['sourceDigests'],'beforePlanSha256':hashlib.sha256(before).hexdigest(),'afterPlanSha256':hashlib.sha256((r/'cases-after.json').read_bytes()).hexdigest(),'packetSha256':hashlib.sha256(pathlib.Path('/private/tmp/umf-security-inventory-review-20261016.zip').read_bytes()).hexdigest()}
(out/'source-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='sourceDigests'},indent=2))
