import pathlib,zipfile,json,hashlib,collections
out=pathlib.Path(__file__).resolve().parent;hist=out/'history';hist.mkdir(exist_ok=True);reports={}
for kind,name,expected in [('fifth','umf-fifth-failed-gate-20261016.zip','51e49dba6d73b231c7eb196998f9e14cd57935a8872d020a89ef7e4ff3ebbd5c'),('fourth','umf-fourth-tested-cohort-before-fifth-20261016.zip','7bc169f78cf527f486d46f914b14054030753b1fd69f3589b166dde836d8311d')]:
 p=pathlib.Path('/private/tmp')/name;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==expected;z=zipfile.ZipFile(p);d=hist/kind;d.mkdir(exist_ok=True);pins={}
 for n in z.namelist():
  assert not pathlib.PurePosixPath(n).is_absolute()and'..'not in pathlib.PurePosixPath(n).parts
  raw=z.read(n);pins[n]=hashlib.sha256(raw).hexdigest()
  # Retain authoritative gate receipt, original plan, scope/log/witness/map;
  # original case payloads remain inside the pinned immutable ZIP.
  if n.endswith(('acceptance.json','cases.json','scope.json','execution.log','retention.json','fourth-run-witness.json')):
   q=d/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 j=json.loads(z.read('docs/helix/04-build/evidence/security/acceptance.json'));assert j['status']=='failed'and j['requiredCases']==158 and j['allocatedAcceptanceCriteria']==34 and j['planDigest']==j['finalPlanDigest']=='0e56c5d63ed4b11053822ddf4211141ac4d125b35109d07ab96b56cb74b82b80';assert z.read('docs/helix/03-test/security/cases.json')==(out/'source/cases-before.json').read_bytes();failures=[e for e in j['execution']if e['exitCode']!=0 or e['timedOut']or e['outputExceeded']];successes=[e for e in j['execution']if e not in failures]
 r={'path':str(p),'sha256':expected,'memberPins':pins,'status':j['status'],'requiredCases':158,'allocatedCriteria':34,'executions':len(j['execution']),'successfulExecutions':len(successes),'failedExecutions':[e['id']for e in failures],'unimplementedErrors':sum('binding not implemented'in e for e in j['errors'])}
 if kind=='fifth':
  assert len(successes)==40 and set(e['id']for e in failures)=={'pg-raw.P02','pg-raw.P04','pg-raw.P05','pg-raw.P07','pg-raw.P08'}and r['unimplementedErrors']==113
  for e in failures:assert e['exitCode']==1 and not e['timedOut']and not e['outputExceeded']and 'assert set(sources)==set('in e['stderr']and 'AssertionError'in e['stderr']
  r['failureDiagnostics']=failures;r['failurePhase']='Unchanged exact source-set assertion, before native command execution'
 else:
  retention=json.loads(z.read('retention.json'));files=retention['files'];print('retention shape',type(files).__name__)
  if isinstance(files,dict):
   for n,h in files.items():assert pins[n]==h
  else:
   for e in files:assert pins[e['path']]==e['sha256']
  r['retentionManifestVerified']=len(files)
 reports[kind]=r
(out/'history-audit.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps({k:{f:v for f,v in r.items()if f not in ['memberPins','failureDiagnostics']}for k,r in reports.items()},indent=2))
