import pathlib,json,hashlib
r=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def pin(p):p=pathlib.Path(p);return {'path':str(p),'sha256':sha(p)}
s=json.loads((r/'source-audit.json').read_text());d=json.loads((r/'source/inventory-delta.json').read_text());p=json.loads((r/'prefix-controls.json').read_text());i=json.loads((r/'import-controls.json').read_text());h=json.loads((r/'history-audit.json').read_text());c=json.loads((r/'plan-review/report.json').read_text())
assert p['total']==31 and p['sourceCount']==127 and not p['nativeCommands'];assert all(x['passed']for x in p['controls']);assert all(not x['missingFromProposedInventory']for x in i['reports'])
report={
 'review':'Independent Astra Ultra review of UMF security gate inventory-only amendment',
 'date':'2026-10-16',
 'verdict':'No actionable finding. The expanded plan exactly matches the unchanged runner source inventory for the frozen input graph; no test assertion, case allocation or native acceptance is weakened.',
 'remainingFindings':[],
 'scope':{'packet':pin('/private/tmp/umf-security-inventory-review-20261016.zip'),'baseCommit':s['baseCommit'],'beforePlan':pin(r/'source/cases-before.json'),'afterPlan':pin(r/'source/cases-after.json'),'originalSelectedSourceCount':127,'allSelectedSourceBytesMatchGitBase':True,'repositoryEdits':False,'nativeExecution':False,'sixthGateResultClaimed':False},
 'verifiedChange':{'onlyFieldChanged':'implementationSources','caseAdditions':{x['id']:x['added']for x in d['cases']},'addedEntries':16,'uniqueAddedPaths':sorted(set(p for x in d['cases']for p in x['added'])),'removals':[],'duplicatesIntroduced':False,'existingInventoryOrderPreserved':True,'caseCount':158,'allocatedCriteriaCount':34,'unmodifiedCases':153,'unchanged':['Every case ID/backend/requirement/criterion allocation','All commands, testSource/oracleSource, evidence paths, timeoutMs, required flags, assertion bindings and case status metadata','Top-level version/scope/runnerContract','All five Python runner sources, TypeScript implementation and schemas in the127-source snapshot','Both exact-set comparison sides and the existing assertion behavior']},
 'independentValidation':{
  'sourceAudit':pin(r/'source-audit.json'),
  'originalRunnerPrefixes':{'controls':31,'report':pin(r/'prefix-controls.json'),'script':pin(r/'prefix-controls.py'),'oldPlan':{'exactSetAssertionFailures':5,'nativeCommands':0},'newPlan':{'exactSetAssertionPasses':5,'nativeCommands':0},'negativeControls':{'omittingEachOf16AddedEntries':16,'addingAnExtraneousDeclaredInput':5},'method':'Execute original unmodified runner text only through its exact source-set assertion in an extracted packet copy, with subprocess.run prohibited. Matching source digests and actual closure sets are retained. No native/fixture commands run.'},
  'independentImportParser':{'report':pin(r/'import-controls.json'),'script':pin(r/'import-controls.ts'),'parser':'Bun.Transpiler scanImports, Bun1.4.2','method':'Traverse executable static imports/reexports/dynamic imports/require calls using a parser, union conservative original/type-only import edges, resolve each source within frozen root, and independently compare against proposed inventory. Retain an explicit entry-to-added-file dependency chain for all16 entries. The remaining declared inputs are runner/oracle/SQL and package/lock files.','missingSourceInputs':[],'closureCounts':{x['id']:x['closureCount']for x in i['reports']},'runtimeExternalPackages':['ajv/dist/2020','yaml'],'externalDependencyQualification':'Package/lock pins and the existing separate runtime dependency capture remain unchanged; this inventory-only review does not rerun or requalify installed external dependency bytes.'},
  'structuralAndAssertionControls':{'controls':98,'report':pin(r/'plan-review/report.json'),'scope':'Separate independent structural diff, Git runner identity and isolated exact-set assertion controls; no native execution.'}
 },
 'historicalEvidence':{
  'audit':pin(r/'history-audit.json'),
  'fifthFailedGate':{'archive':pin('/private/tmp/umf-fifth-failed-gate-20261016.zip'),'status':'failed','requiredCases':158,'allocatedCriteria':34,'implementedPasses':40,'implementedFailures':['pg-raw.P02','pg-raw.P04','pg-raw.P05','pg-raw.P07','pg-raw.P08'],'unimplementedRequired':113,'phase':'All five failures are exit1 AssertionError at the unchanged exact source-set assertion, not timeouts/output limits/native query failures. The independent old-plan prefix replay reproduces that condition.','preservation':'Original acceptance JSON, plan, execution log and scope extracted verbatim under history/fifth; original archive and all member hashes retained. No original result rewritten.'},
  'fourthHistoricalCohort':{'archive':pin('/private/tmp/umf-fourth-tested-cohort-before-fifth-20261016.zip'),'status':'failed overall because113 required cases remain unimplemented','implementedPasses':45,'implementedFailures':0,'retentionManifestFilesVerified':23,'qualification':'Historical tested-source cohort remains historical; it is not represented as fresh execution against the newly expanded inventory or current source.'}
 },
 'conclusions':[
  'The four distinct new file paths are already in the true transitive source graph at Git0b2bf0c1; the16 additions distribute those dependencies across exactly the five affected case inventories.',
  'The amendment repairs stale declarative source lists without relaxing the exact equality check. Missing or extraneous declarations still fail before native execution.',
  'The bit128 schema is required in P02/P04/P05/P08 but not P07; key-tuple-v4 schema is required only in P04/P08. This asymmetry matches the independent import graph rather than a blanket inventory addition.',
  'All127 selected source bytes, including every runner, equal the named Git base. This packet proposes no compiler/core/runner behavior change.',
  'No required case, acceptance allocation or assertion is removed or promoted. The running sixth gate remains separate evidence and is not needed to establish this inventory-only conclusion.'
 ],
 'limitations':['No database/native campaign was independently rerun. This review approves only the exact inventory amendment and its preserved fail-closed comparison.','A passing source-inventory assertion is input custody evidence, not a proof of native security behavior, runner honesty, complete runtime provenance, absence of ABA source changes or overall backend acceptance.','The original158 required cases and34 allocated criteria remain in force; the historical113 unimplemented bindings remain unresolved by this amendment.']
}
(r/'review.json').write_text(json.dumps(report,indent=2)+'\n')
files={str(p.relative_to(r)):sha(p)for p in sorted(r.rglob('*'))if p.is_file()and p.relative_to(r).parts[0]not in ['source','plan-review']and p.name!='review-evidence-manifest.json'}
(r/'review-evidence-manifest.json').write_text(json.dumps({'files':files},indent=2)+'\n');print(json.dumps({'report':str(r/'review.json'),'sha256':sha(r/'review.json'),'remainingFindings':[]},indent=2))
