import {readFileSync,existsSync,statSync,writeFileSync} from 'node:fs';import {resolve,relative,dirname}from'node:path';import{createHash}from'node:crypto';
const dir='/private/tmp/umf-security-inventory-astra-20261016',root=dir+'/source',delta=JSON.parse(readFileSync(root+'/inventory-delta.json','utf8'));
const entries={'pg-raw.P02':'tests/security/native/pg18-catalog-compile.ts','pg-raw.P04':'tests/security/native/pg18-mask-write-declarations.ts','pg-raw.P05':'tests/security/native/pg18-carrier-compile.ts','pg-raw.P07':'tests/security/native/pg18-native-archive-cli.ts','pg-raw.P08':'tests/security/native/pg18-stored-token-declarations.ts'};
const parser=new Bun.Transpiler({loader:'ts'}),reports=[];
for(const c of delta.cases){const seen=new Set<string>(),edges:any[]=[],externals:any[]=[],witnesses:any={};
 function visit(p:string,chain:string[]){if(seen.has(p))return;seen.add(p);if(!p.startsWith(root+'/'))throw Error('escaped-root');const rel=relative(root,p);if(c.added.includes(rel))witnesses[rel]=chain;if(!/\.(ts|js)$/.test(p))return;const src=readFileSync(p,'utf8');
  // Parser covers executable static, re-export, dynamic import and require. The
  // original retained regex adds conservative type-only edges separately.
  const parsed=parser.scanImports(src),typed=[...src.matchAll(/(?:from\s*|import\s*)['"](\.[^'"]+)['"]/g)].map(m=>({kind:'original-retained-or-type',path:m[1]}));
  for(const spec of [...parsed,...typed]){if(!spec.path.startsWith('.')){if(!externals.some(x=>x.path===spec.path))externals.push(spec);continue;}const b=resolve(dirname(p),spec.path),q=[b,b+'.ts',b+'.json',b+'/index.ts'].find(p=>existsSync(p)&&statSync(p).isFile());if(!q)throw Error('unresolved '+spec.path+' from '+p);edges.push({from:rel,to:relative(root,q),kind:spec.kind});visit(q,[...chain,relative(root,q)]);}
 }
 visit(root+'/'+entries[c.id],[entries[c.id]]);
 const paths=[...seen].map(p=>relative(root,p)).sort(),missing=paths.filter(p=>!c.actual.includes(p));if(missing.length)throw Error('missing inventory '+JSON.stringify(missing));
 const metadata=c.actual.filter(p=>!paths.includes(p));for(const a of c.added)if(!witnesses[a])throw Error('no closure witness '+a);
 reports.push({id:c.id,entry:entries[c.id],parsedAndRetainedClosure:paths,closureCount:paths.length,nonImportRunnerSqlOracleAndPackageInputs:metadata,edges,externalPackageImports:externals,additionWitnesses:witnesses,missingFromProposedInventory:missing});
}
writeFileSync(dir+'/import-controls.json',JSON.stringify({scope:'Independent Bun parser executable-import graph plus original conservative/type-only import edges. Files read only; no project modules or native commands executed.',bun:Bun.version,reports},null,2)+'\n');console.log(JSON.stringify(reports.map(r=>({id:r.id,count:r.closureCount,missing:r.missingFromProposedInventory,witnesses:r.additionWitnesses}))));
