"""Read-only source/evidence review for the single P04 outer-budget change."""
import collections
import copy
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
BASE = Path('/private/tmp/umf-security-current-gate-20261015')
OUT = Path('/private/tmp/umf-security-gate-refresh-astra-20261015')
PLAN = 'docs/helix/03-test/security/cases.json'
sha = lambda b: hashlib.sha256(b).hexdigest()
canonical = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
old_bytes = subprocess.check_output(['git', 'show', 'HEAD:' + PLAN], cwd=ROOT)
new_bytes = (ROOT / PLAN).read_bytes()
old, new = json.loads(old_bytes), json.loads(new_bytes)
old_rows, new_rows = ({c['id']: c for c in p['cases']} for p in [old, new])
expected = copy.deepcopy(old)
next(c for c in expected['cases'] if c['id'] == 'pg-raw.P04')['timeoutMs'] = 120000
assert new == expected
assert old_rows['pg-raw.P04']['timeoutMs'] == 60000
assert new_rows['pg-raw.P04']['timeoutMs'] == 120000
assert len(new['cases']) == len(new_rows) == 158 and all(c['required'] is True for c in new['cases'])
criteria = sorted({ac for c in new['cases'] for ac in c['covers']})
assert len(criteria) == 34
assert sum(c['status'] == 'implemented' for c in new['cases']) == 45
assert new_rows['pg-raw.P03'] == old_rows['pg-raw.P03']
assert new_rows['pg-raw.L03'] == old_rows['pg-raw.L03']

evidence_names = [
    'first-full-gate/cases.json',
    'first-full-gate/docs/helix/04-build/evidence/security/acceptance.json',
    'first-full-gate/sha256.json',
    'first-full-gate/README.md',
    'run.log',
    'p04-isolated-component.json',
    'p04-isolated-execution.json',
    'p04-isolated.stdout',
    'p04-isolated.stderr',
    'formal-restored-runtime.json',
    'formal-restored-runtime.stderr',
    'historical-runtime-import-diagnostic.json',
]
evidence_bytes = {name: (BASE / name).read_bytes() for name in evidence_names}
assert evidence_bytes['first-full-gate/cases.json'] == old_bytes
first = json.loads(evidence_bytes[evidence_names[1]])
p04 = json.loads(evidence_bytes['p04-isolated-component.json'])
execution = json.loads(evidence_bytes['p04-isolated-execution.json'])
formal = json.loads(evidence_bytes['formal-restored-runtime.json'])
import_diagnostic = json.loads(evidence_bytes['historical-runtime-import-diagnostic.json'])
executions = {c['id']: c for c in first['execution']}
assert first['status'] == 'failed' and first['requiredCases'] == 158 and first['allocatedAcceptanceCriteria'] == 34
assert first['planDigest'] == first['finalPlanDigest'] == sha(old_bytes)
assert len(executions) == 45 and sum(c['accepted'] is True for c in executions.values()) == 43
assert {c['id'] for c in executions.values() if not c['accepted']} == {'S12', 'pg-raw.P04'}
assert executions['pg-raw.P04']['timedOut'] is True
assert executions['pg-raw.P04']['outputExceeded'] is False
assert executions['pg-raw.P04']['stdout'] == executions['pg-raw.P04']['stderr'] == ''
assert executions['S12']['exitCode'] == 1 and executions['S12']['timedOut'] is False
assert 'Fresh solver replay failed' in executions['S12']['stderr']
assert len(first['errors']) == 115
assert import_diagnostic['exitCode'] == 1 and "ModuleNotFoundError: No module named 'z3'" in import_diagnostic['stderr']
assert 'Post-failure reproduction' in import_diagnostic['scope']

def exact(left, right):
    assert type(left) is type(right)
    if isinstance(left, dict):
        assert left.keys() == right.keys()
        for key in left:
            exact(left[key], right[key])
    elif isinstance(left, list):
        assert len(left) == len(right)
        for a, b in zip(left, right):
            exact(a, b)
    else:
        assert left == right

for receipt, count in [(p04, 806), (formal, 84)]:
    assert len(receipt['observations']) == len({o['assertionId'] for o in receipt['observations']}) == count
    for observation in receipt['observations']:
        exact(observation['expected'], observation['observed'])
    assert receipt['sourceDigests'] == executions[receipt['id']]['fingerprints']
    for path, digest in receipt['sourceDigests'].items():
        assert sha((ROOT / path).read_bytes()) == digest
assert p04['status'] == 'component-passed' and p04['acceptanceReceipt'] is False and p04['casePromoted'] is None
assert len(p04['sourceDigests']) == 100
assert p04['nativeInventory']['cleanup'] == {'containerAbsent': True, 'volumesAbsent': True}
inventory = copy.deepcopy(p04['nativeInventory'])
inventory_digest = inventory.pop('digest')
assert sha(canonical(inventory)) == inventory_digest
assert execution['exitCode'] == 0 and execution['timedOut'] is False
assert 60 < p04['elapsedSeconds'] < execution['elapsedSeconds'] < 120
assert formal['status'] == 'passed' and formal['versions']['z3'] == '4.15.4'
assert len(formal['sourceDigests']) == 5
assert len(p04['runtimeSourceDigests']) == 772
for path, digest in p04['runtimeSourceDigests'].items():
    assert sha(Path(path).read_bytes()) == digest
for path, digest in first['gateSourceDigests'].items():
    assert first['finalGateSourceDigests'][path] == digest == sha((ROOT / path).read_bytes())
manifest = json.loads(evidence_bytes['first-full-gate/sha256.json'])
for path, digest in manifest.items():
    assert sha((BASE / 'first-full-gate' / path).read_bytes()) == digest

sources = {**p04['sourceDigests'], **formal['sourceDigests'], **first['gateSourceDigests']}
for path, digest in sources.items():
    target = OUT / 'reviewed-sources' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / path).read_bytes())
    assert sha(target.read_bytes()) == digest
for path, data in evidence_bytes.items():
    target = OUT / 'reviewed-evidence' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
(OUT / 'cases-before.json').write_bytes(old_bytes)
(OUT / 'cases-reviewed.json').write_bytes(new_bytes)
diff = subprocess.check_output(['git', 'diff', 'HEAD', '--', PLAN], cwd=ROOT)
(OUT / 'plan.diff').write_bytes(diff)
report = {
    'status': 'completed',
    'conclusion': 'No actionable findings in the single P04 outer test-budget adjustment. The retained isolated run justifies increasing the finite harness timeout without weakening an assertion or native policy limit.',
    'reviewer': 'Independent subagent requested for Astra Ultra review',
    'date': '2026-10-15',
    'scope': 'cases.json pg-raw.P04 timeoutMs 60000 to 120000 only; source and diagnostic evidence review, no native campaign replay.',
    'head': head,
    'planPath': str(ROOT / PLAN),
    'beforePlanSha256': sha(old_bytes),
    'reviewedPlanSha256': sha(new_bytes),
    'diffSha256': sha(diff),
    'planDelta': {'case': 'pg-raw.P04', 'field': 'timeoutMs', 'before': 60000, 'after': 120000, 'allOtherParsedValuesUnchanged': True},
    'preserved': {
        'requiredCases': 158,
        'uniqueCaseIds': 158,
        'allocatedAcceptanceCriteria': 34,
        'implementedCases': 45,
        'unimplementedRequiredCases': 113,
        'orderedCaseIdsSha256': sha(canonical([c['id'] for c in new['cases']])),
        'criteriaSha256': sha(canonical(criteria)),
        'assertionIdsCommandsOraclesSourceBindingsBackendLimitsUnchanged': True,
        'P03Unchanged': True,
        'L03Unchanged': True,
        'gateAndRunnerSourcesUnchanged': True,
        'finiteOuterDeadlineBelowRunnerMaximum600000Ms': True,
        'timeoutNonzeroMissingReceiptOutputAndSourceDriftStillRefuse': True,
    },
    'firstFullGate': {
        'status': 'failed', 'implementedExecuted': 45, 'accepted': 43,
        'unimplementedRequiredFailures': 113, 'totalMissingOrFailed': 115,
        'P04': {'timedOut': True, 'outputExceeded': False, 'stdoutBytes': 0, 'stderrBytes': 0},
        'S12': {'exitCode': 1, 'originalDiagnostic': 'Fresh solver replay failed',
                'rootCauseAssessment': 'Missing Z3 is a supported inference from the separate post-failure import diagnostic in the historical explicitly selected interpreter and the successful restored-runtime replay. The original formal runner suppresses its child stderr; no original ModuleNotFoundError output is claimed.'},
        'archiveManifestEntriesVerified': len(manifest),
        'archiveChronology': 'first-full-gate/README.md explicitly identifies its formal.json companion as independently regenerated after failed S12, not output from that failed invocation.',
    },
    'isolatedP04': {
        'status': 'component-passed', 'acceptanceReceipt': False, 'casePromoted': None,
        'runId': p04['runId'], 'matchingUniqueObservations': 806,
        'wallSeconds': execution['elapsedSeconds'], 'receiptElapsedSeconds': p04['elapsedSeconds'],
        'elapsedBoundary': 'The component timer begins after preliminary dependency discovery and is captured before cleanup; the external elapsed time includes those costs.',
        'sourceDigestsVerified': 100, 'sourceDigestsEqualFirstFullGate': True,
        'runtimeDigestsVerified': 772, 'nativeInventoryDigestVerified': True,
        'cleanup': p04['nativeInventory']['cleanup'],
    },
    'standaloneS12Recovery': {
        'status': formal['status'], 'runId': formal['runId'], 'matchingUniqueObservations': 84,
        'sourceDigestsVerified': 5, 'sourceDigestsEqualFirstFullGate': True,
        'versions': formal['versions'], 'scope': formal['scope'],
    },
    'sourceDigests': sources,
    'evidenceDigests': {str(BASE / path): sha(data) for path, data in evidence_bytes.items()},
    'findings': [], 'remainingFindings': [],
    'acceptanceCasesPromoted': [],
    'nativeCampaignIndependentlyReplayed': False,
    'limitations': [
        'The isolated component and standalone formal replay do not replace a fresh complete governed gate at the new plan digest.',
        'The first full gate remains failed; this report does not reclassify its P04 timeout or S12 failure as passes.',
        'The 120-second harness allowance is empirical headroom, not a performance guarantee or a policy timing claim.',
        'No P03, L03, graph/Delta, broad implementation or full-backend acceptance is promoted.',
        'This reviewer performed source, checksum and receipt validation only; no expensive native campaign or solver replay was repeated.',
    ],
    'undo': 'Restore only pg-raw.P04.timeoutMs to 60000. Keep historical failure and separate diagnostic evidence.',
}
assert (ROOT / PLAN).read_bytes() == new_bytes
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'findings': 0, 'planSha256': report['reviewedPlanSha256'], 'P04Observations': 806, 'S12Observations': 84, 'sourceDigests': len(sources), 'runtimeDigests': 772}))
