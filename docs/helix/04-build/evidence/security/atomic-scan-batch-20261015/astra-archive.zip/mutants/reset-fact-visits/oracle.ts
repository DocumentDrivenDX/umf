import base from './base-fixture.json';
import {compileCandidateCatalogProgram as compile} from '/private/tmp/atomic-logical-scan-astra-20261015/mutants/reset-fact-visits/src/extensions/security/catalog-program-candidate';
import {evaluateCandidateCatalogScan as scan,evaluateCandidateCatalogScanBatch as batch,evaluateCandidateCatalogCollection as collection} from '/private/tmp/atomic-logical-scan-astra-20261015/mutants/reset-fact-visits/src/extensions/security/catalog-runtime-candidate';
const cp=(x:any)=>structuredClone(x), ref=(elementId:string,moduleId='entities')=>({documentId:'review-domain',moduleId,elementId});
const A=ref('Asset'),AM=ref('amount'),AK=ref('asset-key'),R={documentId:'review-domain',moduleId:'entities',relationshipId:'DirectLink'};
const frozen=(v:any):boolean=>v===null||typeof v!=='object'||Object.isFrozen(v)&&Object.values(v).every(frozen);
const same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b);
const fact=(f:any,name:string)=>f.cut.facts.find((x:any)=>x.type.elementId===name), cov=(f:any,name='Asset')=>f.cut.coverage.find((x:any)=>x.type.elementId===name);
const field=(f:any,name='amount')=>f.closure.documents[0].document.modules[0].elements.find((x:any)=>x.id===name);
const cell=(field:any,value:any)=>({field,disposition:'original',value});
const eq=(v:any)=>({op:'eq',left:{kind:'resource',field:AM},right:{kind:'constant',field:ref('dto-number','domains'),value:v}});
function add(f:any,key:string,value:any){const a=cp(fact(f,'Asset'));a.key=[{string:key}];a.fields=[{field:AK,value:{string:key}},{field:AM,value}];a.absent=[];f.cut.facts.push(a);return a;}
function fixture(){const f:any=cp(base);f.owner.disclosure={readAction:'read'};f.ontology.actionPurposes=[{action:'read',purposes:['read']}];f.policy.rules[0].disclosure[0].disposition={kind:'original'};fact(f,'Asset').fields[1].value={integerToken:'1'};add(f,'a2',{integerToken:'2'});add(f,'a3',{integerToken:'1'});f.selection={type:A,fields:[AK,AM]};return f;}
function membership(f:any,graph=false,opaque=false){
 const ep=(endpoint:string)=>({kind:'variable',name:'g',endpoint});
 f.policy.rules[0].condition={op:'exists',association:graph?R:ref('Link'),as:'g',where:{op:'and',args:[{op:'eq',left:ep('person'),right:{kind:'subject',identity:true}},{op:'eq',left:ep('asset'),right:{kind:'resource',identity:true}}]}};
 if(graph){f.closure.documents[0].document.modules[0].relationships=[{id:'DirectLink',name:'DirectLink',directed:true,sourceMultiplicity:{min:0,max:1},targetMultiplicity:{min:0,max:2},targetLifecycle:'independent',source:[{module:'entities',element:'Person'}],target:[{module:'entities',element:'Asset',key:'pk'}],...(!opaque?{associationRecord:{module:'entities',element:'Link'}}:{})}];f.ontology.associations=[{kind:'core-relationship',relationship:R,witness:opaque?{kind:'opaque-existential'}:{kind:'record-key',type:ref('Link'),keyId:'pk'},endpoints:[{role:'person',side:'source',target:ref('Person'),keyId:'pk'},{role:'asset',side:'target',target:A,keyId:'pk'}]}];f.cut.graphs=[{relationship:R,witness:opaque?{kind:'opaque-existential',id:'w1'}:{kind:'record-key',type:ref('Link'),key:[{string:'l1'}]},endpoints:[{role:'person',key:[{string:'p1'}]},{role:'asset',key:[{string:'a1'}]}]}];f.cut.graphCoverage=[{relationship:R,complete:true,roles:['person','asset'],fields:[]}];}
}
function dropAmount(f:any,absent=false){for(const a of f.cut.facts.filter((x:any)=>x.type.elementId==='Asset')){a.fields=a.fields.filter((p:any)=>p.field.elementId!=='amount');if(absent)a.absent=[AM];}if(!absent)cov(f).fields=cov(f).fields.filter((r:any)=>r.elementId!=='amount');}
function empty(f:any){f.cut.facts=f.cut.facts.filter((x:any)=>x.type.elementId!=='Asset');}
const refused={status:'refused',complete:false,authority:false,rows:[],valueProfiles:[]};
function exec(f:any){return scan(compile(f.policy,f.catalog??null,f.closure,f.ontology),f.owner,f.cut,f.selection);}
const noBatch={status:'refused',complete:false,authority:false,scans:[]};
const req=(name='s0',fields=[AK,AM],type=A)=>({scan:name,type,fields});
const full=[['a1','1'],['a2','2'],['a3','1']].map(([k,n])=>[cell(AK,{string:k}),cell(AM,{integerToken:n})]);
export function runOracle(){const rows:any[]=[];
 const test=(id:string,fn:()=>boolean)=>{let passed=false,error=null;try{passed=fn();}catch(e){error=String(e);}rows.push({id,passed,error});};
 const observe=(label:string,edit:(f:any,r:any[])=>void,expected:any)=>test(label,()=>{const f=fixture(),r:any[]=[req(),req('s1')];edit(f,r);const h=compile(f.policy,f.catalog??null,f.closure,f.ontology),before=JSON.stringify({f,r}),result=batch(h,f.owner,f.cut,r);return same(result,expected)&&frozen(result)&&JSON.stringify({f,r})===before;});
 const output=(scans:any[])=>({status:'rendered',complete:false,authority:false,scans:scans.map(([scan,rows])=>({scan,rows,valueProfiles:[]}))});
 observe('two-occurrences-complete-population',()=>{},output([['s0',full],['s1',full]]));
 observe('occurrence-and-field-order',(_,r)=>{r.splice(0,2,req('t9',[AM,AK]),req('s2',[]));},output([['t9',full.map(x=>[x[1],x[0]])],['s2',[[],[],[]]]]));
 observe('separate-type-no-grant-is-empty',(_,r)=>r[1]=req('t0',[ref('person-key')],ref('Person')),output([['s0',full],['t0',[]]]));
 observe('deny-filter-per-occurrence',f=>f.policy.rules[0].condition=eq({integerToken:'1'}),output([['s0',[full[0],full[2]]],['s1',[full[0],full[2]]]]));
 observe('all-denied-retains-occurrences',f=>f.policy.rules=[],output([['s0',[]],['s1',[]]]));
 observe('custom-owner-read-action',f=>{f.owner.disclosure.readAction='view';f.ontology.actions=['view'];f.ontology.actionPurposes=[{action:'view',purposes:['read']}];f.policy.rules[0].actions=['view'];},output([['s0',full],['s1',full]]));
 for(const [label,graph,opaque]of [['flat',false,false],['record-graph',true,false],['opaque-graph',true,true]]as [string,boolean,boolean][]){
  observe(label+'-membership',f=>membership(f,graph,opaque),output([['s0',[full[0]]],['s1',[full[0]]]]));
  observe(label+'-field-free', (f,r)=>{membership(f,graph,opaque);r[0].fields=[];r[1].fields=[];},output([['s0',[[]]],['s1',[[]]]]));
  observe(label+'-coverage-refusal',f=>{membership(f,graph,opaque);if(graph)f.cut.graphCoverage=[];else cov(f,'Link').complete=false;},noBatch);
 }
 observe('null-values', (f,r)=>{for(const a of f.cut.facts.filter((x:any)=>x.type.elementId==='Asset'))a.fields[1].value=null;r.forEach(x=>x.fields=[AM]);},output([['s0',Array.from({length:3},()=>[cell(AM,null)])],['s1',Array.from({length:3},()=>[cell(AM,null)])]]));
 observe('known-absence', (f,r)=>{dropAmount(f,true);r.forEach(x=>x.fields=[AM]);},output([['s0',Array.from({length:3},()=>[{field:AM,disposition:'absent'}])],['s1',Array.from({length:3},()=>[{field:AM,disposition:'absent'}])]]));
 observe('withheld-no-input', (f,r)=>{dropAmount(f);f.policy.rules[0].disclosure[0].disposition={kind:'withheld'};r.forEach(x=>x.fields=[AM]);},output([['s0',Array.from({length:3},()=>[{field:AM,disposition:'withheld'}])],['s1',Array.from({length:3},()=>[{field:AM,disposition:'withheld'}])]]));
 observe('late-protected-disclosure-clears-prefix',(f,r)=>{delete f.policy.rules[0].disclosure;r[0].fields=[];r[1].fields=[AM];},noBatch);
 observe('late-field-conflict-clears-prefix',(f,r)=>{f.policy.rules[0].disclosure[0].disposition={kind:'transformed',transform:'constant',version:'0.1.0',field:ref('dto-text','domains'),value:{string:'one'}};const q=cp(f.policy.rules[0]);q.id='conflict';q.disclosure[0].disposition.value={string:'two'};f.policy.rules.push(q);r[0].fields=[];r[1].fields=[AM];},noBatch);
 for(const [label,edit]of [
 ['late-unknown-target',(f:any,r:any[])=>r[1].type=ref('Missing')],['late-foreign-field',(f:any,r:any[])=>r[1].fields=[ref('person-label')]],['late-duplicate-field',(f:any,r:any[])=>r[1].fields=[AM,AM]],['late-native-member',(f:any,r:any[])=>r[1].native={}],['late-action',(f:any,r:any[])=>r[1].action='read'],['late-subset',(f:any,r:any[])=>r[1].resources=[]],['duplicate-occurrence',(f:any,r:any[])=>r[1].scan=r[0].scan],['invalid-occurrence',(f:any,r:any[])=>r[1].scan='s-1'],['empty-occurrence',(f:any,r:any[])=>r[1].scan=''],['empty-batch',(f:any,r:any[])=>r.length=0],['over-256',(f:any,r:any[])=>r.splice(0,r.length,...Array.from({length:257},(_,i)=>req('s'+i,[])))],
 ['missing-read-owner',(f:any)=>delete f.owner.disclosure],['wrong-purpose',(f:any)=>f.ontology.actionPurposes[0].purposes=['field']],['stale-cut',(f:any)=>f.cut.expectedGeneration='other'],['stale-policy',(f:any)=>f.cut.policy.revision='other'],['unselected-malformed',(f:any)=>fact(f,'Person').fields[1].value={integerToken:'1'}],['no-coverage',(f:any)=>cov(f).complete=false],['fractional-maxfacts',(f:any)=>f.cut.maxFacts=99.5],['string-maxfacts',(f:any)=>f.cut.maxFacts='100'],['fractional-maxsteps',(f:any)=>f.cut.maxSteps=999.5],['string-maxsteps',(f:any)=>f.cut.maxSteps='10000'],['tiny-step-budget',(f:any)=>f.cut.maxSteps=1],
 ]as [string,(f:any,r:any[])=>void][])observe(label,edit,noBatch);
 observe('aggregate-fact-visits-inclusive',f=>f.cut.maxFacts=f.cut.facts.length+f.cut.graphs.length+6,output([['s0',full],['s1',full]]));
 observe('aggregate-fact-visits-one-below',f=>f.cut.maxFacts=f.cut.facts.length+f.cut.graphs.length+5,noBatch);
 observe('graph-visits-inclusive',f=>{membership(f,true,false);f.cut.maxFacts=f.cut.facts.length+f.cut.graphs.length+6;},output([['s0',[full[0]]],['s1',[full[0]]]]));
 observe('graph-witness-charged-once',f=>{membership(f,true,false);f.cut.maxFacts=f.cut.facts.length+6;},noBatch);
 test('single-passes-batch-cumulative-facts-refuses',()=>{const f=fixture(),h=compile(f.policy,null,f.closure,f.ontology);f.cut.maxFacts=f.cut.facts.length+f.cut.graphs.length+3;return scan(h,f.owner,f.cut,f.selection).status==='rendered'&&same(batch(h,f.owner,f.cut,[req(),req('s1')]),noBatch);});
 test('shared-work-single-positive-batch-negative',()=>{const f=fixture(),h=compile(f.policy,null,f.closure,f.ontology);let lo=1,hi=1000000;while(lo<hi){const m=Math.floor((lo+hi)/2);f.cut.maxSteps=m;if(scan(h,f.owner,f.cut,f.selection).status==='rendered')hi=m;else lo=m+1;}f.cut.maxSteps=lo;return scan(h,f.owner,f.cut,f.selection).status==='rendered'&&same(batch(h,f.owner,f.cut,[req(),req('s1')]),noBatch);});
 test('shared-literal-single-positive-batch-negative',()=>{const f=fixture(),replace=(x:any):void=>{if(x&&typeof x==='object')for(const key of Object.keys(x)){if(x[key]==='p1')x[key]='p'.repeat(512);else replace(x[key]);}};replace(f.cut);f.cut.maxSteps=1000000;f.cut.maxFacts=10000;const h=compile(f.policy,null,f.closure,f.ontology);return scan(h,f.owner,f.cut,f.selection).status==='rendered'&&same(batch(h,f.owner,f.cut,Array.from({length:64},(_,i)=>req('s'+i))),noBatch);});
 test('shared-text-single-positive-batch-negative',()=>{const f=fixture();f.owner.revision='r'.repeat(200000);f.cut.owner.revision=f.owner.revision;f.cut.maxSteps=1000000;f.cut.maxFacts=10000;const h=compile(f.policy,null,f.closure,f.ontology);return scan(h,f.owner,f.cut,f.selection).status==='rendered'&&same(batch(h,f.owner,f.cut,Array.from({length:10},(_,i)=>req('s'+i))),noBatch);});
 observe('empty-population-preserves-labels',empty,output([['s0',[]],['s1',[]]]));
 observe('empty-population-preflight',f=>{empty(f);cov(f).fields=[];},noBatch);
 for(const place of ['requests','cut','owner'])test(place+'-accessor-no-call',()=>{const f=fixture(),h=compile(f.policy,null,f.closure,f.ontology),requests=[req(),req('s1')];let n=0;Object.defineProperty(place==='requests'?requests[1]:place==='cut'?f.cut:f.owner,place==='requests'?'fields':place==='cut'?'facts':'disclosure',{enumerable:true,get(){n++;return[];}});return same(batch(h,f.owner,f.cut,requests),noBatch)&&n===0;});
 test('forged-handle',()=>{const f=fixture();return same(batch({},f.owner,f.cut,[req()]),noBatch);});
 test('copied-handle',()=>{const f=fixture();return same(batch(cp(compile(f.policy,null,f.closure,f.ontology)),f.owner,f.cut,[req()]),noBatch);});
 test('input-mutation-cannot-change-output',()=>{const f=fixture(),h=compile(f.policy,null,f.closure,f.ontology),requests=[req(),req('s1')],r=batch(h,f.owner,f.cut,requests);f.cut.facts.length=0;requests[0].fields.length=0;return same(r,output([['s0',full],['s1',full]]))&&frozen(r);});
 return rows;
}
