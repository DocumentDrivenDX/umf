from pathlib import Path
import subprocess,shutil,hashlib,json,difflib
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent;rel='src/extensions/security/catalog-runtime-candidate.ts';original=(root/rel).read_text();baseline=hashlib.sha256(original.encode()).hexdigest()
variants=[
 ('original',None,None,[]),
 ('catch-and-release-prefix',"const result=run(handle,owner,cut,{type:request.type,fields:request.fields},true,ledger,true) as CandidateCatalogCollectionResult;","let result;try{result=run(handle,owner,cut,{type:request.type,fields:request.fields},true,ledger,true) as CandidateCatalogCollectionResult;}catch{return freeze({status:'rendered',complete:false,authority:false,scans});}",['late-protected-disclosure-clears-prefix','late-field-conflict-clears-prefix','late-unknown-target']),
 ('reset-whole-operation-ledger','true,ledger,true) as CandidateCatalogCollectionResult','true,undefined,true) as CandidateCatalogCollectionResult',['shared-work-single-positive-batch-negative','shared-literal-single-positive-batch-negative','shared-text-single-positive-batch-negative']),
 ('reset-fact-visits',"for(const request of requests){shape(request,['scan','type','fields']);","for(const request of requests){visits=0;shape(request,['scan','type','fields']);",['aggregate-fact-visits-one-below','single-passes-batch-cumulative-facts-refuses']),
 ('omit-graph-witness-charge',"if(cut.facts.length+cut.graphs.length+visits>cut.maxFacts)","if(cut.facts.length+visits>cut.maxFacts)",['graph-witness-charged-once']),
 ('allow-duplicate-occurrence',"||names.has(request.scan)","",['duplicate-occurrence']),
 ('reset-literal-ledger',"const result=run(handle,owner,cut,{type:request.type,fields:request.fields},true,ledger,true)","(ledger as any).literal=new CandidateSecurityOperationBudget(cut.maxSteps).literal;const result=run(handle,owner,cut,{type:request.type,fields:request.fields},true,ledger,true)",['shared-literal-single-positive-batch-negative']),
 ('reset-snapshot-text-ledger',"const result=run(handle,owner,cut,{type:request.type,fields:request.fields},true,ledger,true)","(ledger as any).text=0;const result=run(handle,owner,cut,{type:request.type,fields:request.fields},true,ledger,true)",['shared-text-single-positive-batch-negative']),
]
rows=[]
for name,old,new,expected in variants:
 d=out/'mutants'/name;d.mkdir(parents=True,exist_ok=True);shutil.copytree(root/'src',d/'src',dirs_exist_ok=True)
 for folder in ['spec','native','node_modules']:
  if not (d/folder).exists():(d/folder).symlink_to(root/folder,target_is_directory=True)
 src=original
 if old is not None:
  assert src.count(old)==1,(name,src.count(old));src=src.replace(old,new);(d/rel).write_text(src);(d/'change.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),src.splitlines(True),fromfile=rel,tofile=rel)))
 shutil.copyfile(out/'base-fixture.json',d/'base-fixture.json');(d/'oracle.ts').write_text((out/'oracle.ts').read_text().replace(str(root),str(d)));shutil.copyfile(out/'run.ts',d/'run.ts')
 r=subprocess.run(['/opt/homebrew/bin/bun',str(d/'run.ts')],cwd=d,capture_output=True,text=True,timeout=30);(d/'run.log').write_text(r.stdout+r.stderr);assert (d/'results.json').exists(),(name,r.stderr)
 observations=json.loads((d/'results.json').read_text())['rows'];failed=[r['id']for r in observations if not r['passed']];assert len(observations)==58 and all(r['error'] is None for r in observations),(name,'setup/unexpected error');detected=(r.returncode==0 and not failed)if name=='original' else(r.returncode==1 and set(expected).issubset(failed));rows.append(dict(name=name,exitCode=r.returncode,expectedFailedRows=expected,failedRows=failed,detected=detected,sourceSha256=hashlib.sha256(src.encode()).hexdigest(),baselineSha256=baseline));(out/'mutation-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True);assert detected,(name,failed,expected)
assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==baseline
