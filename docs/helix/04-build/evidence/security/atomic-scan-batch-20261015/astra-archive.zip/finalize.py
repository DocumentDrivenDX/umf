from pathlib import Path
import json,hashlib,datetime,zipfile,subprocess,shutil
p=Path(__file__).parent;root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda b:hashlib.sha256(b).hexdigest();j=lambda f:json.loads((p/f).read_text())
pins=j('source-pins-final.json');host=j('readsets/receipt.json')
for f,h in host['selectedSourceDigests'].items():
 assert sha((root/f).read_bytes())==h
 if f not in pins:
  pins[f]=h;dest=p/'captured-sources'/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/f,dest)
(p/'source-pins-final.json').write_text(json.dumps(pins,indent=2)+'\n');assert all(sha((root/f).read_bytes())==h for f,h in pins.items())
r=j('results.json');b=j('browser-results.json');m=j('mutation-results.json');proof=j('formal-final/receipt.json');assert r['total']==r['passed']==58 and b['parity'] and b['hostGlobalsAbsent'] and not b['externalRequests'] and not b['pageErrors'];assert len(m)==8 and all(x['detected']for x in m);assert len(proof['checks'])==10 and host['controls']==280
for f,h in proof['selectedSourceDigests'].items():assert sha((root/f).read_bytes())==h
for name in ['final-weft-provenance.json','final-weft-owner-receipt.json']:
 f=root/'docs/helix/04-build/evidence/security/current-logical-scan-20261015'/name;target=p/'parent-provenance'/name;target.parent.mkdir(exist_ok=True);shutil.copyfile(f,target)
review={
 'review':'atomic-complete-logical-scan-batch','recordedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'verdict':'No open blocker in reviewed atomic logical batch and fixed host correspondence scope.',
 'acceptanceReceipt':False,'acceptanceCasesPromoted':[],'productionEditsByReviewer':False,'nativeJobsStarted':False,
 'source':{'root':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'runtimeSha256':pins['src/extensions/security/catalog-runtime-candidate.ts'],'selectedPins':len(pins),'pins':'source-pins-final.json','scope':'Final selected repository snapshots; not hermetic runtime/build closure. Runtime SHA matches baseline and all mutation preimages; actual host replay verifies its selected sources before/after.'},
 'independentEvidence':{
  'oracle':{'source':'oracle.ts','fixture':'base-fixture.json','origin':'Independent Person/Asset/Link source fixture, not repository runtime helpers; hand-authored outputs and refusals.','bunControls':58,'chromiumControls':58,'versions':b['versions'],'exactParity':True,'hostGlobalsAbsent':True,'externalRequests':0,'pageErrors':[],'results':['results.json','browser-results.json']},
  'mutations':{'cleanBaselinePassed':True,'meaningfulDetected':7,'variants':[x['name']for x in m if x['name']!='original'],'result':'mutation-results.json','scope':'Private actual-source copies; exact intended failing rows required and unexpected errors rejected.'},
  'calibratedParentCorpus':{'baselineControls':56,'textOnlyResetFailedExactly':['shared-snapshot-text-budget'],'result':'parent-text-control-sensitivity.json'},
  'formal':{'queries':10,'unsat':6,'sat':4,'freshContextReplay':True,'source':'captured-sources/tools/security/prove-atomic-scan-batch.py','results':'formal-final/receipt.json','scope':'Conditional unbounded prefix/cost model assumes complete ordered enumeration, faithful outcomes/costs, source preflight and delayed release. No TS traversal/cost, compiler or native refinement.'},
  'actualHostBridge':{'controls':280,'reports':18,'producer':'/private/tmp/weft-lineage02-current-binaries/application_lineage','producerSha256':'a78a3c04b69cf669f1f7ee9dfc91f4a1b1e495692684a16012f418ce1084862e','independentSourceReportAudits':18,'independentExactWholeBatchAudits':18,'results':['readsets/receipt.json','readsets-independent-audit.json','independent-batch-readset-outputs.json'],'provenance':'Parent supplies committed owner correspondence for Weft75b7c24. This review independently invoked/hash-checked actual binary, but did not rebuild compiler or reverify every Git blob.'}
 },
 'semanticReview':[
 'Exact bounded detached request packet admits no caller action/resource-subset/permission flags. Unique ordered occurrence names remain separate; output is deeply frozen and detached.',
 'One CandidateSecurityOperationBudget shares cumulative work, literal and snapshot-text ledgers across all runs. Inventory facts/graph witnesses count once plus all target visits before rendering. Repeated copying/validation is additionally charged, without total preallocation/heap/CPU claims.',
 'Each scan reuses original full-population/read-purpose/disposition semantics. Denial filters; late source/field/protected-disclosure/unresolved/conflict/budget failure clears all output. Pending rows never leave before final success.',
 'Field-free scans retain row-read duties; empty populations retain preflight. Flat, Record-witness and opaque graph membership retain existing semantics.',
 'Host batch expected rows come from the independent fixed scenario table; complete report/source correspondence precedes request assembly. Stored properties and unsupported SUM remain separate from read batches.'
 ],
 'limits':[
 'Supplied request arrays do not establish compiler issuance/completeness; omitted scans and relationship-observation duties remain adapter/compiler obligations.',
 'No query-use mode/action grant, aggregate evaluation, native SQL, caller/source authentication, current authority, release custody, P03/B08 or executable whole-query admission.',
 'Successful results keep complete:false and authority:false; supplied complete logical facts remain an external premise.',
 'No new root export. Existing single-scan/action/collection semantics are reused.',
 'Parent terminal gate and broader regression/browser/Python bridge results are attributed separately, not counted as independent execution.'
 ],
 'calibrationHistory':[
 {'control':'result-status-only prefix break','result':'survived redundant branch weakening','meaning':'run throws for late failures before reaching result-status branch. Actual catch-and-return-prefix weakening is detected. No production defect.','evidence':['initial-mutation-results.json','initial-mutations.log','mutants/release-successful-prefix/change.patch']},
 {'control':'40k revision with64 scans','result':'text-only reset masked by shared literal refusal','meaning':'Independent final test uses200k/10scans; separate800k/2scans also kills only text reset. Parent calibrated56-control corpus independently checked. No production defect.','evidence':['oracle-before-text-isolation.ts','mutation-results-before-text-isolation.json','mutations-before-text-isolation.log','two-scan-text-sensitivity.json','parent-text-control-sensitivity.json']},
 {'control':'initial Chromium sandbox launch','result':'loopback EADDRINUSE setup failure','meaning':'Retained separately; authorized local-only Chromium replay passed. No failed-setup controls counted.','evidence':['browser-sandbox-startup-failure.log','browser-final.log']}
 ],
 'parentReportedTerminalGate':{'executedAccepted':45,'requiredUnbound':113,'requiredCases':158,'caseDefinitionsByteIdenticalTo':'160c88c4','withinRunPlanAndSourcesExact':True,'rootRegressionTests':342,'rootRegressionExpectations':3987,'rootBrowserControls':56,'scope':'Parent reported terminal results after independent review completed; not independently executed by this reviewer. No acceptance case promotion.'},
 'remainingFindings':[]
}
(p/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(p/'review.md').write_text('No open blocker in the atomic logical batch scope.58 independent Bun/Chromium controls pass with exact parity; seven meaningful actual-source weakenings detected;10 conditional formulas replay6UNSAT/4SAT. Actual finalized Weft/host bridge passes280 checks plus18 independently audited source reports and18 whole-batch outputs.\n\nInitial redundant-branch survivor and masked text-budget control remain retained. Corrected controls prove sensitivity; neither indicates a production bug. Compiler/cut completeness and native/whole-query authority remain external/open.\n')
files=[]
for f in p.rglob('*'):
 if not f.is_file()or f.is_symlink()or f.name in ['archive.zip','archive-summary.json','archive-manifest.json']:continue
 rel=f.relative_to(p)
 if 'mutants' in rel.parts and len(rel.parts)>2:
  sub=Path(*rel.parts[2:])
  if sub.parts[0]in ['spec','native','node_modules']:continue
  if sub.parts[0]=='src'and str(sub)!='src/extensions/security/catalog-runtime-candidate.ts':continue
 files.append(f)
files.sort();manifest={str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())}for f in files};(p/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(p/'archive-manifest.json');archive=p/'archive.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in files:z.write(f,str(f.relative_to(p)))
summary=dict(review=str(p/'review.json'),reviewSha256=sha((p/'review.json').read_bytes()),archive=str(archive),archiveSha256=sha(archive.read_bytes()),archiveBytes=archive.stat().st_size,files=len(files),selectedPins=len(pins));(p/'archive-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
