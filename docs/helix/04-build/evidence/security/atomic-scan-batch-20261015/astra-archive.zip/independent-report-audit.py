"""Fixed six-scenario metadata oracle. Expectations are authored separately from bridge/producer."""
import pathlib,json,hashlib,sys,copy
base=pathlib.Path(__file__).resolve().parent;directory=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2])
fixture=json.loads((base/'initial-sources/umf/tests/security/protection/current-query-source.json').read_text());scenarios=json.loads((base/'initial-sources/umf/tests/security/protection/current-query-read-scenarios.json').read_text());rev=fixture['closure']['pins'][0]['revision']
ref=lambda n:dict(documentId='domain',moduleId='m',elementId=n)
ident=lambda n:dict(documentId='domain',revision=rev,module='m',element=n)
types={'token':dict(family='string',facets={},nullable=False),'resourceId':dict(family='string',facets={},nullable=False),'salary':dict(family='integer',facets={'integerWidth':{'bits':64,'signed':True}},nullable=False)}
cases={
 'projection-read':(['s0'],[('s0','outputs/0/expression','token','projection')]),
 'hidden-read-false-zero':(['s0'],[('s0','outputs/0/expression','resourceId','projection'),('s0','filters/1/left','token','predicate'),('s0','order/0','token','order')]),
 'distinct-selfjoin-false-zero':(['s0','s1'],[('s0','joins/0/on/0/left','token','join'),('s1','joins/0/on/0/right','token','join'),('s0','filters/1/left','token','predicate'),('s1','outputs/0/argument','token','aggregate')]),
 'field-free-false-zero':(['s0'],[]),
 'distinct-required':(['s0'],[('s0','outputs/0/argument','token','aggregate')]),
 'sum-unsupported':(['s0'],[('s0','outputs/0/argument','salary','aggregate')]),
}
sha=lambda s:hashlib.sha256(s.encode()).hexdigest();rows=[]
for variant in ['r1-undisclosed','r2-allowed','r2-revoked']:
 for name,(scans,fields) in cases.items():
  stem=variant+'-'+name;request_raw=(directory/(stem+'.request.json')).read_text();request=json.loads(request_raw);r=json.loads((directory/(stem+'.report.json')).read_text())
  reqfields=[];uses=[]
  for scan,path,field,role in fields:
   reqfields.append(dict(path=path,scan=scan,target=ref('Resource'),recordIdentity=ident('Resource'),field=ref(field),fieldIdentity=ident(field),role=role,descriptor=dict(availability='required',identity=ident(field),kind='scalar',type=types[field]),sourceStatus='derived'))
   if role=='projection':continue
   operation='sum' if field=='salary' else 'countDistinct' if role=='aggregate' else 'order' if role=='order' else 'equal'
   use=dict(path=path,scan=scan,type=ref('Resource'),field=ref(field),fieldIdentity=ident(field),logicalType=types[field],operator=role,operation=operation,required=None if operation=='sum' else ['order' if role=='order' else 'equality'],propertyStatus='unsupported' if operation=='sum' else 'derived')
   if role=='aggregate':use['outputType']=dict(family='integer',facets={},nullable=operation=='sum')
   uses.append(use)
  expected=dict(scans=[dict(path='source' if i==0 else 'joins/0/right',scan=s,target=ref('Resource'),recordIdentity=ident('Resource'),kind='rowRead')for i,s in enumerate(scans)],fields=reqfields,relationships=[],unsupportedSources=[dict(path='outputs/0/argument',kind='numericAggregateProperties')] if name=='sum-unsupported' else [])
  opaque=[dict(role=s['role'],identity=s['identity'],mediaType=s['mediaType'],sha256=s['sha256'],status='uninterpreted') for s in request['opaqueSources']]
  source_ok=json.loads(request['modules'][0]['documentJson'])==fixture['closure']['documents'][0]['document'] and request['modules'][0]['pin']['sha256']==sha(request['modules'][0]['documentJson'])
  bodies={s['role']:json.loads(s['utf8']) for s in request['opaqueSources']}
  expected_owner=copy.deepcopy(fixture['owner']);expected_owner['revision']='named-scan-owner-r1';expected_owner['disclosure']={'readAction':'read'}
  source_ok=source_ok and bodies['policy']==(fixture['policy'] if variant=='r1-undisclosed' else scenarios['policy']) and bodies['owner']==expected_owner and bodies['catalog']==fixture['catalog'] and bodies['ontology']==fixture['ontology']
  expected_cut=copy.deepcopy(scenarios['cut']);expected_cut['owner']['revision']='named-scan-owner-r1';expected_cut['policy']['revision']=bodies['policy']['revision']
  if variant=='r2-revoked':
   expected_cut['generation']=expected_cut['expectedGeneration']='logical-revoked-cut-r1'
   next(f for f in next(f for f in expected_cut['facts'] if f['type']['elementId']=='Assignment')['fields'] if f['field']['elementId']=='active')['value']={'boolean':False}
  source_ok=source_ok and bodies['logical-cut']==expected_cut and all(s['sha256']==sha(s['utf8']) for s in request['opaqueSources'])
  checks=dict(sourcePacket=source_ok,exactReadRequirements=r['readRequirements']==expected,exactUses=r['uses']==uses,exactOpaqueMetadata=r['unresolvedSources']==opaque,modelPins=r['modelPins']==[request['modules'][0]['pin']],sourceRetention=r['sourceRequestJson']==request_raw and r['sourceRequestSha256']==sha(request_raw),authority=r['authority'] is False and r['securityReady'] is False)
  rows.append(dict(id=stem,passed=all(checks.values()),checks=checks))
result=dict(observations=rows,status='passed' if all(r['passed']for r in rows) else 'failed',scope='Independent exact expected metadata/source-packet comparison for fixed six scenarios and three policy/fact variants; no query execution or native authority.')
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(passed=sum(r['passed']for r in rows),total=len(rows),failed=[r for r in rows if not r['passed']])));sys.exit(0 if result['status']=='passed' else 1)
