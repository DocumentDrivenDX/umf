import {chromium} from '/Users/erik/.codex/worktrees/security-main-integration/umf/node_modules/playwright/index.mjs';
import {createHash} from 'node:crypto';
const out=import.meta.dir;
const build=await Bun.build({entrypoints:[out+'/oracle.ts'],target:'browser',format:'esm'});
if(!build.success||build.outputs.length!==1)throw Error('Browser build refused');
const js=await build.outputs[0]!.text();if(js.length>16000000)throw Error('Bundle bound');
const server=Bun.serve({hostname:'127.0.0.1',port:0,fetch:r=>new URL(r.url).pathname==='/oracle.js'?new Response(js,{headers:{'content-type':'text/javascript'}}):new Response('<!doctype html><title>Independent atomic scan batch review</title>')});let browser;
try{browser=await chromium.launch({headless:true});const page=await browser.newPage();const pageErrors:string[]=[];let externalRequests=0;page.on('pageerror',e=>pageErrors.push(String(e)));const origin=`http://127.0.0.1:${server.port}`;
await page.route('**/*',r=>new URL(r.request().url()).origin===origin?r.continue():(externalRequests++,r.abort()));await page.goto(origin);
const actual=await page.evaluate(async()=>{const p='/oracle.js',m=await import(p);return{rows:m.runOracle(),hostGlobalsAbsent:['Bun','process','Buffer','Deno'].every(k=>!(k in globalThis))};});const bun=await Bun.file(out+'/results.json').json();
const result={versions:{bun:Bun.version,chromium:browser.version()},...actual,externalRequests,pageErrors,parity:JSON.stringify(actual.rows)===JSON.stringify(bun.rows),bundleSha256:createHash('sha256').update(js).digest('hex'),scope:'Private atomic batch of complete scans of supplied logical population; completeness is a host premise, not a compiler/native credential.'};await Bun.write(out+'/browser-results.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,rows:actual.rows.length,failed:actual.rows.filter((r:any)=>!r.passed)}));if(actual.rows.some((r:any)=>!r.passed)||!result.parity||externalRequests||pageErrors.length||!actual.hostGlobalsAbsent)process.exitCode=1;
}finally{await browser?.close();server.stop(true);}
