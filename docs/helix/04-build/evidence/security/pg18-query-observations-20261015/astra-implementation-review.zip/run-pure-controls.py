from pathlib import Path
import ast,json,subprocess,hashlib,re,types
BASE=Path(__file__).parent;ROOT=BASE/'final-source';source=(ROOT/'tests/security/native/pg18-query-observations.py').read_text();prefix=source[:source.index("compiled=reports['projection'];")]
d=BASE/'final-preflight-controls';d.mkdir(exist_ok=True)
variants=[('positive-original','',None),('omitted-all-reports',"reports['reports']=[]",'exact-conditional-report-inventory'),('duplicate-first-report',"reports['reports']=[reports['reports'][0]]*10",'exact-conditional-report-inventory'),('reordered-reports',"reports['reports'].reverse()",'exact-conditional-report-inventory'),('extra-report',"reports['reports'].append(reports['reports'][0])",'exact-conditional-report-inventory'),('report-native-authority',"reports['authority']=True",'no-native-query-authority'),('conditional-authority',"reports['reports'][0]['report']['authority']=True",'conditional-not-native'),('prohibited-variant-installed',"reports['prohibitedVariantsInstalled']=True",'prohibited-variants-not-installed'),('token-kind-encrypt',"stored['catalog']['transforms'][0]['kind']='encrypt'",'exact-selected-tokenize-declaration'),('token-random',"stored['catalog']['transforms'][0]['determinism']='random'",'exact-selected-tokenize-declaration'),('token-wrong-input-domain',"stored['catalog']['transforms'][0]['inputDomain']['elementId']='foreign'",'exact-selected-tokenize-declaration'),('token-owner-canonical',"stored['owner']['storage']=[dict(x,storageEffect='canonical') for x in stored['owner']['storage']]",'exact-stored-owner-binding'),('token-catalog-pin',"stored['catalog']['revision']='foreign'",'exact-selected-catalog'),('policy-catalog-pin',"stored['policy']['protection']['revision']='foreign'",'exact-protection-catalog-pin'),('policy-ontology-pin',"stored['policy']['ontology']['revision']='foreign'",'exact-policy-ontology-pin'),('core-closure-pin',"stored['closure']['pins'][0]['revision']='foreign'",'exact-core-closure-pins'),('core-token-domain',"[x.update(scalarType='integer') for x in stored['closure']['documents'][0]['document']['modules'][0]['elements'] if x['id']=='token']",'exact-core-domain:token'),('obligations-verified',"[x.update(status='verified') for x in stored['declaration']['obligations']]",'all-tokenize-obligations-unverified'),('missing-obligation',"stored['declaration']['obligations'].pop()",'all-tokenize-obligations-present')]
rows=[]
for name,mutation,witness in variants:
 code=prefix
 if mutation:
  if mutation.startswith('reports'):code=code.replace("check('read-projection-only'",mutation+"\ncheck('read-projection-only'",1)
  else:code=code.replace("stored=declarations();check(","stored=declarations();"+mutation+";check(",1)
 code+="\nprint(json.dumps(dict(preflightPassed=True,observations=len(observations))))\n";ast.parse(code)
 p=d/(name+'.py');p.write_text(code);r=subprocess.run(['python3',str(p),'--output',str(d/'unused.json')],cwd=ROOT,capture_output=True,text=True,timeout=20);log=r.stdout+r.stderr;(d/(name+'.log')).write_text(log)
 passed=r.returncode==0 if witness is None else r.returncode!=0 and 'AssertionError:' in log and witness in log
 rows.append(dict(id=name,exitCode=r.returncode,expectedFailureLabel=witness,passed=passed,scriptSha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(d/'results.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(r['passed'] for r in rows);print('preflight',len(rows),'passed',flush=True)
# Run exact original refusal classifier against synthetic subprocess results.
tree=ast.parse(source);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='denied');ctx={'re':re};exec(compile(ast.Module(body=[node],type_ignores=[]),'<original-denied>','exec'),ctx)
refusals=[('valid',3,'','ERROR:  42501: permission denied\n',True),('zero-exit',0,'','ERROR:  42501: permission denied\n',False),('connect-exit',2,'','ERROR:  42501: permission denied\n',False),('output-row',3,'[]\n','ERROR:  42501: permission denied\n',False),('output-space',3,' ','ERROR:  42501: permission denied\n',False),('wrong-code',3,'','ERROR:  55000: broken\n',False),('missing-error',3,'','NOTICE:  42501: ignored\n',False),('duplicate-errors',3,'','ERROR:  42501: denied\nERROR:  42501: denied\n',False),('fatal',3,'','ERROR:  42501: denied\nFATAL:  08006: connection lost\n',False),('panic',3,'','PANIC: broken\nERROR:  42501: denied\n',False)]
rs=[]
for name,code,stdout,stderr,expected in refusals:
 ctx['sql']=lambda *args,c=code,o=stdout,e=stderr:types.SimpleNamespace(returncode=c,stdout=o,stderr=e)
 try:ctx['denied']('SELECT 1;','actor');actual=True
 except AssertionError:actual=False
 rs.append(dict(id=name,expectedAccept=expected,actualAccept=actual,passed=expected==actual))
(BASE/'refusal-controls.json').write_text(json.dumps(rs,indent=2)+'\n');assert all(r['passed'] for r in rs);print('refusal',len(rs),'passed',flush=True)
# Execute original finally block with exact fake inventory/ownership outcomes, never Docker.
cleanup=next(n.finalbody for n in tree.body if isinstance(n,ast.Try) and n.finalbody)
cleanup_code=compile(ast.Module(body=cleanup,type_ignores=[]),'<original-cleanup>','exec');req=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='require')
cs=[]
for scenario,expected in [('owned',True),('already-removed',True),('lost-container-live-volume',False),('container-inventory-error',False),('volume-inventory-error',False),('foreign-label',False),('shared-volume',False),('remove-error',False),('container-remains',False),('volume-remains',False)]:
 state={'present':scenario not in ['already-removed','lost-container-live-volume'],'volume':scenario!='already-removed','rm':False};calls=[]
 def command(args):
  calls.append(args);rc=0;out='';err=''
  if args[:3]==['docker','container','ls']:
   if scenario=='container-inventory-error':rc=1;err='daemon denied'
   elif '--filter' in args:out='abcdef123456\n'+('fedcba654321\n' if scenario=='shared-volume' else '')
   elif state['present']:out='abcdef123456 owned-name\n' if '{{.ID}} {{.Names}}' in args else 'owned-name\n'
  elif args[:2]==['docker','inspect']:
   out=json.dumps([{'Id':'abcdef1234567890','Config':{'Labels':{'umf.security.run':'foreign' if scenario=='foreign-label' else 'nonce'}},'Mounts':[{'Type':'volume','Name':'owned-volume'}]}])
  elif args[:2]==['docker','rm']:
   state['rm']=True
   if scenario=='remove-error':rc=1;err='remove denied'
   else:state['present']=scenario=='container-remains';state['volume']=scenario=='volume-remains'
  elif args[:3]==['docker','volume','ls']:
   if scenario=='volume-inventory-error':rc=1;err='volume daemon denied'
   elif state['volume']:out='owned-volume\n'
  else:raise AssertionError(args)
  return types.SimpleNamespace(returncode=rc,stdout=out,stderr=err)
 env={'creation_attempted':True,'name':'owned-name','run_id':'nonce','receipt':{'nativeInventory':{}},'volumes':['owned-volume'],'command':command,'json':json};exec(compile(ast.Module(body=[req],type_ignores=[]),'<original-require>','exec'),env)
 try:exec(cleanup_code,env);actual=True;error=None
 except (RuntimeError,AssertionError) as e:actual=False;error=type(e).__name__
 cs.append(dict(id=scenario,expectedSuccess=expected,actualSuccess=actual,error=error,removeAttempted=state['rm'],passed=expected==actual and (scenario not in ['foreign-label','shared-volume'] or not state['rm'])))
(BASE/'cleanup-controls.json').write_text(json.dumps(cs,indent=2)+'\n');assert all(r['passed'] for r in cs);print('cleanup',len(cs),'passed',flush=True)
