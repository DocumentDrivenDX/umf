from pathlib import Path
import ast,json,subprocess,time,shutil,os,signal,hashlib,difflib
BASE=Path(__file__).parent;SOURCE=BASE/'final-source';RUNNER=Path('tests/security/native/pg18-query-observations.py')
original=(SOURCE/RUNNER).read_text()
variants=[
 ('final-original',None,None,None),
 ('membership-always-true','USING(security_raw.allowed(id));','USING(true);','baseline:umf_sec_alice:generalize:order'),
 ('aggregate-without-distinct','count(DISTINCT ','count(','baseline:umf_sec_alice:generalize:aggregate'),
 ('join-without-value-comparison',"+expression(kind,'a')+' OPERATOR(pg_catalog.=) '+expression(kind,'b')+","+'TRUE'+",'baseline:umf_sec_bob:generalize:join'),
 ('generalize-lexical-order',"if operator=='order':return", "if operator=='order' and kind=='generalize':v='('+v+')::pg_catalog.text COLLATE pg_catalog.\"C\"'\n if operator=='order':return",'baseline:umf_sec_bob:generalize:order'),
 ('weakened-control-no-raw-threshold',"WHERE (p.bag->>'salary')::numeric >=200;",'WHERE true;','weakened-barrier-infers-hidden-change'),
 ('public-mask-exports-raw-input',"SELECT r.id,'restricted'::text AS salary_display FROM security_raw.resource r;", "SELECT r.id,(SELECT p.bag->>'salary' FROM security_raw.resource_private_carrier p WHERE p.resource_id=r.id) AS salary_display FROM security_raw.resource r;",'same-publication-after-hidden-change'),
]
def docker(args):
 p=subprocess.run(['docker',*args],capture_output=True,text=True,timeout=10)
 if p.returncode:raise RuntimeError(p.stderr)
 return p.stdout.splitlines()
results=json.loads((BASE/'native-controls.json').read_text())
for row in results:
 if row['id']=='membership-always-true':
  row['expectedFailureLabel']='baseline:umf_sec_alice:generalize:order'
  row['witnessObserved']=row['expectedFailureLabel'] in (BASE/(row['id']+'.log')).read_text()
  row['passedControl']=row['exitCode']!=0 and not row['timeout'] and row['witnessObserved'] and not row['newOwnedContainers'] and not row['newVolumes']
(BASE/'native-controls.json').write_text(json.dumps(results,indent=2)+'\n')
for name,old,new,witness in variants:
 if any(row['id']==name for row in results):continue
 path=SOURCE if old is None else BASE/'mutants'/name
 if old is not None:
  assert original.count(old)==1,(name,original.count(old))
  shutil.copytree(SOURCE,path,symlinks=True)
  text=original.replace(old,new)
  ast.parse(text)
  (path/RUNNER).write_text(text)
  d=BASE/'mutant-patches';d.mkdir(exist_ok=True)
  (d/(name+'.diff')).write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile=str(RUNNER),tofile=str(RUNNER))))
 log=BASE/(name+'.log');receipt=BASE/(name+'.json')
 before_volumes=set(docker(['volume','ls','--format','{{.Name}}']))
 before_names=set(docker(['container','ls','-a','--format','{{.Names}}']))
 start=time.monotonic();timed_out=False
 with log.open('w') as stream:
  process=subprocess.Popen(['python3',str(path/RUNNER),'--output',str(receipt)],cwd=path,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=process.wait(timeout=60)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(process.pid,signal.SIGTERM)
   try:code=process.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait()
 elapsed=time.monotonic()-start
 after_names=set(docker(['container','ls','-a','--format','{{.Names}}']));after_volumes=set(docker(['volume','ls','--format','{{.Name}}']))
 names=[n for n in after_names-before_names if n.startswith('umf-sec-pg18-query-observe-')]
 row={'id':name,'exitCode':code,'seconds':round(elapsed,3),'timeout':timed_out,'sourceSha256':hashlib.sha256((path/RUNNER).read_bytes()).hexdigest(),'expectedFailureLabel':witness,'witnessObserved':None if witness is None else witness in log.read_text(),'newOwnedContainers':names,'newVolumes':sorted(after_volumes-before_volumes)}
 if receipt.exists():
  r=json.loads(receipt.read_text());row.update(observations=len(r['observations']),status=r['status'],cleanup=r['nativeInventory']['cleanup'],sourceCount=len(r['sourceDigests']),runtimeSourceCount=len(r['nativeInventory']['runtimeDependencies']['sourceDigests']))
 row['passedControl']=code==0 and not timed_out and not names and not row['newVolumes'] if witness is None else code!=0 and not timed_out and row['witnessObserved'] and not names and not row['newVolumes']
 results.append(row);(BASE/'native-controls.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if not row['passedControl']:break
