"""Disclosed operator observation only; no P03 admission. @covers US-056-AC6
Fixed raw membership eligibility; not a general policy or lifecycle compiler.
"""
import copy,hashlib,importlib.util,json,os,re,secrets,signal,subprocess,sys,time,uuid
from pathlib import Path
ROOT=Path.cwd();CASE='pg18-disclosed-query-observation/0.1';IMAGE='postgres@sha256:74935e72241653ca55e0414067e6d8763aceb8a810eb51b452253ec3dcfc4336'
if len(sys.argv)!=3 or sys.argv[1]!='--output':raise ValueError('Explicit observation output required; no governed case mode')
run_id=str(uuid.uuid4());output=Path(sys.argv[2])
sys.dont_write_bytecode=True
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,ROOT/path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
oracle=module('query_oracle','tests/security/native/pg18-query-observations-oracle.py')
projection_oracle=module('projection_oracle','tests/security/native/pg18-catalog-oracle.py')
stored_oracle=module('stored_oracle','tests/security/native/pg18-stored-token-oracle.py')
sha=lambda b:hashlib.sha256(b).hexdigest()
# Retain the repository import closure (type-only imports overpin harmlessly).
def closure_sources(path,seen):
 path=path.resolve()
 if path in seen:return
 if not path.is_relative_to(ROOT.resolve()) or not path.is_file():raise ValueError('Original repository source required')
 seen.add(path)
 if path.suffix not in ['.ts','.js']:return
 for rel in re.findall(r'(?:from\s*|import\s*)[\'"](\.[^\'"]+)[\'"]',path.read_text()):
  base=path.parent/rel;candidates=[base,Path(str(base)+'.ts'),Path(str(base)+'.json'),base/'index.ts'];found=next((p for p in candidates if p.is_file()),None)
  if found is None:raise ValueError('Unresolved original source import')
  closure_sources(found,seen)
paths=set();closure_sources(ROOT/'tests/security/native/pg18-stored-token-declarations.ts',paths);closure_sources(ROOT/'tests/security/native/pg18-query-observations.ts',paths)
paths.update(ROOT/p for p in ['tests/security/native/pg18-query-observations.py','tests/security/native/pg18-query-observations-oracle.py','tests/security/native/pg18-catalog-oracle.py','tests/security/native/pg18-stored-token-oracle.py','tests/security/native/pg18-stored-token.sql','tools/security/pg-mask-query.py','tests/security/native/pg-raw-membership.sql','bun.lock','package.json'])
sources={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(paths)}

def command(args,**kw):return subprocess.run(args,text=True,capture_output=True,timeout=kw.pop('timeout',10),**kw)
def require(result):
 if result.returncode:raise RuntimeError(result.stderr[:3000])
 return result.stdout.strip()
def declarations():return json.loads(require(command(['/opt/homebrew/bin/bun','tests/security/native/pg18-stored-token-declarations.ts'])))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
observations=[]
def check(label,expected,actual):
 if canonical(expected)!=canonical(actual):raise AssertionError(dict(label=label,expected=expected,observed=actual))
 observations.append(dict(assertionId=CASE+':'+label,expected=json.loads(canonical(expected)),observed=json.loads(canonical(actual))))
# Pin actual Bun/Ajv dependency bytes, not only their declared lock versions.
dependency_script="const seen=new Set();const out=[];function collect(name,from){const path=Bun.resolveSync(name+'/package.json',from);if(seen.has(path))return;seen.add(path);const p=JSON.parse(require('fs').readFileSync(path,'utf8'));out.push({name:p.name,version:p.version,path});for(const n of Object.keys(p.dependencies??{}))collect(n,require('path').dirname(path));}collect('ajv',process.cwd()+'/src/validation');console.log(JSON.stringify(out));"
packages=json.loads(require(command(['/opt/homebrew/bin/bun','-e',dependency_script])))
runtime_paths={Path('/opt/homebrew/bin/bun').resolve(),Path(sys.executable).resolve()}
for package in packages:
 runtime_paths.update(p for p in Path(package['path']).parent.rglob('*') if p.is_file() and 'node_modules' not in p.relative_to(Path(package['path']).parent).parts)
runtime_sources={str(p):sha(p.read_bytes()) for p in sorted(runtime_paths)}
fixture=projection_oracle.fixture()
reports=json.loads(require(command(['/opt/homebrew/bin/bun','tests/security/native/pg18-query-observations.ts'],input=json.dumps(fixture))))
check('read-projection-only','compiled',reports['projection']['status']);check('original-catalog-preserved',fixture['catalog'],reports['projection']['catalog']);check('no-native-query-authority',False,reports['authority']);check('prohibited-variants-not-installed',False,reports['prohibitedVariantsInstalled'])
check('exact-conditional-report-inventory',[[name,operator] for name in ['integer_bucket','hash'] for operator in oracle.OPERATORS],[[row['name'],row['operator']] for row in reports['reports']])
for row in reports['reports']:
 check('conditional:'+row['name']+':'+row['operator'],'refused' if row['operator']=='order' else 'compatible-properties',row['report']['status'])
 check('prohibited-source-variant:'+row['name']+':'+row['operator'],'prohibited',row['prohibitedVariant']['status'])
 check('conditional-not-native:'+row['name']+':'+row['operator'],[False,False],[row['report']['complete'],row['report']['authority']])
stored=declarations();stored['catalog']['revision']='foreign';check('stored-query-modes-omitted',{},stored['catalog']['transforms'][0]['queryUse']);check('token-equality-acknowledged',['equality'],stored['catalog']['transforms'][0]['disclosureProfile'])
original=stored;declared=original['declaration']
check('exact-selected-catalog',dict(vocabulary='umf.security.protection',version='0.1.0',id='stored',revision='1'),{k:original['catalog'][k] for k in ['vocabulary','version','id','revision']})
check('exact-selected-tokenize-declaration',[stored_oracle.TRANSFORM],original['catalog']['transforms'])
check('exact-stored-owner-binding',[stored_oracle.STORAGE],[x for x in original['owner']['storage'] if x['field']==stored_oracle.ref('token')])
elements=original['closure']['documents'][0]['document']['modules'][0]['elements']
for selected in ['clear','token']:check('exact-core-domain:'+selected,stored_oracle.domain(selected),next(x for x in elements if x['id']==selected))
check('exact-protection-catalog-pin',dict(id='stored',revision='1'),original['policy']['protection'])
check('exact-core-closure-pins',[dict(documentId='domain',revision='schema-1')],original['closure']['pins'])
check('exact-core-document-context',dict(id='domain',revision='schema-1',version='0.8.0',module='m'),dict(id=original['closure']['documents'][0]['document']['id'],revision=original['closure']['documents'][0]['revision'],version=original['closure']['documents'][0]['document']['umf'],module=original['closure']['documents'][0]['document']['modules'][0]['id']))
check('exact-policy-ontology-pin',dict(documentId='domain',revision='runtime-v2'),original['policy']['ontology'])
check('exact-ontology-context',dict(documentId='domain',revision='runtime-v2'),{k:original['ontology'][k] for k in ['documentId','revision']})
check('declared-not-enforced',dict(status='declared-obligations',complete=False,authority=False),{k:declared[k] for k in ['status','complete','authority']})
check('all-tokenize-obligations-present',stored_oracle.OBLIGATIONS,[o['kind'] for o in declared['obligations']])
check('all-tokenize-obligations-unverified',['unverified']*len(stored_oracle.OBLIGATIONS),[o['status'] for o in declared['obligations']])
check('source-propagation-declarations',{k:stored_oracle.PROPAGATION[k] for k in ['history','snapshots','exports','feeds','caches']},original['catalog']['transforms'][0]['custody']['propagation'])

print(json.dumps(dict(preflightPassed=True,observations=len(observations))))
