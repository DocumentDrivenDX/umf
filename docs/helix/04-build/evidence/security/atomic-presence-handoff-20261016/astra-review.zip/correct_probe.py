from pathlib import Path
import shutil
r=Path('.');p=r/'reconstructed/independent.ts'
for a,b in [('reconstructed/independent.ts','second-independent.ts'),('independent-controls.json','second-independent-controls.json'),('independent-controls.log','second-independent-failure.log')]:shutil.copyfile(r/a,r/b)
s=p.read_text().replace("if(key==='r4')r.absent=[ref('token')];", "if(key==='r4'&&state!=='transformed-null')r.absent=[ref('token')];")
s=s.replace("[[transformed],[transformed],[transformed],[{disposition:'absent'}]]", "[[transformed],[transformed],[transformed],[transformed]]")
s=s.replace("const bad=structuredClone(p);", "if(state==='transformed-null'){const missing=structuredClone(p);const mf=missing.cut.facts.find((x:any)=>x.type.elementId==='Resource'&&x.key[0].string==='r4');mf.fields=mf.fields.filter((x:any)=>x.field.elementId!=='token');mf.absent=[ref('token')];refused('transformed-null:known-absent-late-input-atomic',run(missing));mf.absent=[];refused('transformed-null:unreported-late-input-atomic',run(missing));}const bad=structuredClone(p);")
p.write_text(s)
