from pathlib import Path
import json,hashlib,subprocess,shutil,collections
R=Path(__file__).parent;F=R/'frozen';owner=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda b:hashlib.sha256(b).hexdigest();x=json.loads((F/'inputs.json').read_text());receipt=json.loads((F/'receipt.json').read_text());base=json.loads((F/'manifest.json').read_text())['baseCommit'];d=R/'governance';d.mkdir(exist_ok=True)
for name,path in [('CONTRACT-062-security-semantics.md','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md'),('STP-056-before.md','docs/helix/03-test/test-plans/STP-056-security-bindings.md')]:
 (d/name).write_bytes(subprocess.check_output(['git','show',f'{base}:{path}'],cwd=owner))
(d/'README-supplement.md').write_bytes((owner/'docs/helix/04-build/evidence/security/atomic-presence-handoff-20261016/README.md').read_bytes())
(d/'implementation-plan-tail-supplement.md').write_text('\n'.join((owner/'docs/helix/04-build/implementation-plan.md').read_text().splitlines()[-100:])+'\n')
checks=[]
def ck(i,a,e):checks.append({'id':i,'passed':a==e,'actual':a,'expected':e})
for p,h in x['sourcePins'].items():ck('post-controls-source:'+p,sha((R/'reconstructed'/p).read_bytes()),h)
for p,h in json.loads((F/'manifest.json').read_text())['files'].items():ck('frozen-member:'+p,sha((F/p).read_bytes()),h)
ck('original-archive',sha(Path('/private/tmp/umf-atomic-presence-handoff-review-20261016.zip').read_bytes()),'123be2df9ef80b9a1a25904ea6b886924ac8d63b52de88b4c5a6b34fdc020acb')
for p in ['inputs.json','receipt.json']:ck('byte-identical-replay:'+p,sha((R/'replay'/p).read_bytes()),sha((F/p).read_bytes()))
stat=collections.Counter(p['result']['status'] for p in x['packets']);ck('rendered',stat['rendered'],41);ck('refused',stat['refused'],25)
(R/'final-custody.json').write_text(json.dumps({'status':'passed' if all(c['passed'] for c in checks) else 'failed','count':len(checks),'checks':checks},indent=2)+'\n');assert all(c['passed'] for c in checks)
report={
 'version':'independent-component-review/1','reviewer':'Astra Ultra','status':'passed-with-scope-qualifications','remainingFindings':[],
 'subject':'Actual atomic disclosure producer presence handoff on explicit optional Resource.Token source',
 'baseCommit':base,
 'frozenInputs':{'archive':'/private/tmp/umf-atomic-presence-handoff-review-20261016.zip','archiveSha256':'123be2df9ef80b9a1a25904ea6b886924ac8d63b52de88b4c5a6b34fdc020acb','inputsSha256':sha((F/'inputs.json').read_bytes()),'receiptSha256':sha((F/'receipt.json').read_bytes()),'generatorSha256':x['sourcePins']['tools/security/query-presence-disclosure-oracle.ts'],'kernelSha256':x['sourcePins']['src/extensions/security/catalog-runtime-candidate.ts'],'governedTestPlanSha256':sha((F/'overlay/docs/helix/03-test/test-plans/STP-056-security-bindings.md').read_bytes()),'selectedSourceCount':len(x['sourcePins'])},
 'conclusion':'No actionable defect found in this frozen handoff component. The actual originally issued private WithinOperation producer, public V2 inspector and JSON/YAML codecs reproduce every supplied packet and receipt byte. Independent checks corroborate source/occurrence/storage/value and row correspondence. This is conditional logical component evidence, not native or full security acceptance.',
 'independentlyExecuted':[
  {'check':'Exact frozen generator replay','result':'passed','scenarios':66,'controls':546,'rendered':41,'refused':25,'command':'bun tools/security/query-presence-disclosure-oracle.ts /private/tmp/umf-atomic-presence-handoff-astra-20261016/replay','cwd':str(R/'reconstructed'),'evidence':['replay.log','replay/inputs.json','replay/receipt.json'],'byteIdenticalInputAndReceipt':True},
  {'check':'Independent source and relational membership audit','result':'passed','controls':1467,'evidence':['audit.py','audit.json','audit.log'],'details':'Checks raw source UTF-8/hash/parsed content, unique content per role/id/revision, unchanged original membership/ontology/domains/vault definition, valid foreign identities, independent nested Ownership/Assignment eligibility, exact rule truth, source correlations, canonical source and selected occurrences, inspector qualifications, and refusal outputs.'},
  {'check':'Actual mixed and empty supplied populations','result':'passed','controls':59,'evidence':['reconstructed/independent.ts','independent-controls.json','independent-controls.log'],'details':'Five resources in non-key order, four permitted and one denied; duplicate String values remain a bag. Original null/String/absent and withheld, present-input null-out, reversed fact order, exact census versus permitted rows and source occurrences, JSON/YAML codecs, malformed denied-row and duplicate-resource atomic refusals, late missing/unreported transformed-input atomic refusals, three complete empty populations and stale empty-cut refusal.'},
  {'check':'Independent parsed runtime import closure','result':'passed','runtimeImportEdges':296,'missingPins':0,'evidence':['reconstructed/closure-audit.ts','closure-audit.json','closure-audit.log'],'details':'Bun.Transpiler.scan parsed every captured TypeScript source. All relative runtime edges resolve to captured source pins. Type-only imports may be stripped by this parser; frozen source capture also includes its regex-selected type imports.'},
  {'check':'Final source and archive custody','result':'passed','controls':len(checks),'evidence':['custody.json','final-custody.json'],'details':'102 captured sources unchanged after reviewer executions; original archive and all nine named manifest members match; replay bytes exact. All captured repository inputs other than the new generator agree with exact base Git objects; installed Ajv metadata is external.'}
 ],
 'sourceAssessment':[
  'The new host tool calls the actual private atomic producer with a compiler-issued catalog program and one operation budget. It does not emulate the producer or invoke a public per-cell evaluator.',
  'The original salary-only policy remains byte-equivalent in the undisclosed controls. Original, withheld and presentation-null Token policies use distinct authored revisions; the original required membership rule and closure are unchanged.',
  'The optional String Token domain and stored-transformed vault carrier remain exact. Original Token is not prestorage cleartext; presentation-null consumes present Token-domain input via the actual pure null-out definition and performs no vault operation.',
  'Source/owner/ontology/catalog raw JSON bytes and hashes correlate with the source objects and result pins. Canonical provenance is rule 0/disclosure 1, with selectedOccurrence only for the actual transform. V2 columns retain the stored carrier and rows preserve permitted-resource order.',
  'Denied resources remain only in the private census and produce no permitted rows. Denied/missing/foreign membership facts, coverage and generation controls use their stated semantics; foreign endpoints are actual complete facts, not dangling references.',
  'The governed STP addition and separately retained README correctly limit this to supplied logical facts and private output. Source identity hashes, read purpose and complete supplied census do not authenticate actor, source or current cut.'
 ],
 'investigatedNonFindings':[
  {'id':'REVIEWER-ABSENT-TRANSFORM-EXPECTATION','resolution':'The first mixed-population reviewer expectation incorrectly allowed an absent input to pass through a selected null-out recipe. CONTRACT-062 requires a present validated catalog recipe input, even for null-out; frozen runtime preflights all selected inputs before cells. Refusal is correct. Corrected positive uses present inputs; separate known-absent and unreported late-input controls both atomically refuse.','retained':['first-independent.ts','first-independent-failure.log','second-independent.ts','second-independent-controls.json','second-independent-failure.log','correct_probe.py']}
 ],
 'historicalEvidence':{'authorFirstAttempt':'Original first-source.ts and first-failure.log are retained unchanged. The failure was the expected empty disclosureProfile property absent from the canonical V2 transformed cell; no complete failed packet exists. Final-source changes also distinguish policy revisions, preserve the undisclosed original catalog, and retain raw source/inspection/codec bytes. No retroactive passing claim is made for that attempt.','intermediateR2':'README records a separately retained earlier successful packet; reviewer did not independently replay or qualify it.','types':'Owner tools TypeScript success log is retained. This reviewer did not rerun typechecking; actual Bun source execution and source audit are independently reproduced.'},
 'limitations':[
  'The supplied 66 author scenarios each contain one Resource. Reviewer mixed and empty controls add finite examples, not an arbitrary population proof.',
  'No native database, SQL compiler, typed carrier lowering, materialization, operator authorization, current-cut authentication, actor authentication, guarded release or backend admission was exercised or approved.',
  'Every logical result and public inspector verdict remains complete:false and authority:false. The private denied-resource census must not be exposed as ordinary-reader output or public diagnostics.',
  'Custody is endpoint comparison. Package metadata/lock and selected repository import closure are captured, but Bun and external package implementations are not a hermetic executable closure.',
  'No new browser campaign was required for this host-only generator; the underlying atomic product source is unchanged from the separately reviewed component. No new acceptance case or criterion promotion is implied; P03/B08/B07 and broader native obligations remain open.'
 ],
 'repositoryMutation':'None. Only reconstructed sources and reviewer harnesses under this review directory were executed; no owner product source or frozen packet was changed.',
 'evidenceManifest':'manifest.json'
}
(R/'review.json').write_text(json.dumps(report,indent=2)+'\n')
files={}
for p in R.rglob('*'):
 if not p.is_file() or p==R/'manifest.json' or 'node_modules' in p.parts:continue
 files[str(p.relative_to(R))]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
# Every frozen selected source including the external Ajv metadata is pinned in inputs/custody. External package implementations remain explicitly outside the evidence manifest.
(R/'manifest.json').write_text(json.dumps({'version':'review-evidence-manifest/1','files':dict(sorted(files.items())),'selectedSourcePins':x['sourcePins'],'exclusions':['reconstructed/node_modules package implementation bytes: external non-hermetic runtime closure'],'reviewSha256':sha((R/'review.json').read_bytes())},indent=2)+'\n')
print(json.dumps({'status':report['status'],'reviewSha256':sha((R/'review.json').read_bytes()),'manifestSha256':sha((R/'manifest.json').read_bytes()),'finalCustodyChecks':len(checks),'manifestFiles':len(files),'findings':len(report['remainingFindings'])}))
