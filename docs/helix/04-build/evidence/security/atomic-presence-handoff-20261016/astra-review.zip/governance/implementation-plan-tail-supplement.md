LIMIT remain compiler inputs, not executed SQL. Oldr3 source/bundle/registrations
remain frozen; native adoption needs an explicit new source/consumer cohort.
No native case promotion:45/158 accepted,113 unimplemented; original132 IDs/hash
37308740 preserved. pg-raw.B10 retains diagnostic leakage/no full registered
runner; Delta B04/B10 have no native runner and ordinary identity/deployment
qualification remains missing. This transport implements no diagnostic provider.
See [versioned source and evidence](evidence/security/projection-query-child-v2-20261015/README.md).


### Typed reporting reads — 2026-10-15

Restored the typed SDK foundation from archived `39bf/umf` snapshot `8c9d0fb6`, then implemented the FR-53 Praxis reporting amendment: three-edge declared to-one joins, generated cross-record projections, reviewed SQL aggregates, native caller-role execution, joined keyset continuations and per-call typed timeouts. Weft core owns source/SQL admission; its PostgreSQL backend owns native lowering. WR-B7 and WR-A14 are the located interface work references from `20bc/umf`. [Execution evidence](evidence/typed-reporting/README.md) records source pins, actual installed-wheel tests and limits. [Usage](guides/typed-reporting.md) shows build and runtime calls. This scoped milestone does not close broader SDK targets, native aggregate DSL or Lakebase service qualification.

### Raw retirement-first ordering component — 2026-10-15

For US-057-AC2/5/7, the existing PG17.9 publisher routine now has an independent retirement-first native schedule. Forty matching observations cover commit/refusal, rollback/refusal and an unsafe claim-omission control that returns rows after terminal retirement. Exact native lock barriers precede release; the original routine is restored and the owned fixture removed. This closes a component test gap, not L03 or backend acceptance. The psycopg harness does not qualify the public decoder, host issuer, complete writer closure or final transport. [Source, native receipt and review evidence](evidence/security/retirement-first-20261015/README.md) retain the scope and failed exploratory attempt.45/158 cases remain accepted; all158 remain required.

The accompanying broader evidence audit fails101/221 checks on existing source/cross-repository drift;31 of the45 retained accepted cases are source-current. The failing current report is preserved, not represented as full qualification. Resolving that drift remains required by the original goal.

Independent Astra Ultra review found no remaining component finding after two cleanup corrections. Its ten fault-injection controls and original reports are retained verbatim in the packet. This is source/receipt inspection and modeled cleanup testing, not an independent replay of the native concurrency campaign.

### Current gate replay and P04 test budget — 2026-10-15

The complete158-required-case replay executes45 implementations:43 pass, S12 fails its selected solver environment and P04 exceeds the60-second outer harness limit. A restored pinnedZ3 replay passes84 observations; the unchanged isolated P04 passes806 in65.1 seconds. Only P04's outer budget increases to120 seconds; assertions and native limits are unchanged. Astra Ultra review finds no actionable issue. The first failed run and qualified diagnostics are [retained](evidence/security/gate-refresh-20261015/README.md). A second full run is underway; no corrected full-gate result or case promotion is asserted at this commit. All113 missing implementations and full34-criterion completion remain required.

### Experimental128-bit and UUID implementation — 2026-10-16

CONTRACT-076 / SD-005 now have core0.9 value codecs, literals, copied Field/schema
property authoring, inspection/selection, tuple-v2/operation-v4 encoding and
collision-preserving migration. Binding3 adds explicit carrier codecs and bounded
one-Field schema proposals. Native PG17.9, SQL Server2022, Avro/fastavro and
PyArrow paths recover the exercised library-produced values; captured TableSpec
model validation covers the string fallback. The [execution record](evidence/uuid-implementation.md)
retains current source/test evidence, native warnings, failed attempts and corrections.

Full ideal admission and five-binding delivery are not promoted. Native binding3
indexes/relationships, general nullable-pair/write/atomicity qualification and
consumer runtime adoption remain separate. Earlier global acceptance receipts
are not refreshed by this scoped work; storage optimality is not benchmarked.

### Typed SDK public schema-load and non-temporal instance E2E — 2026-10-15

The actual public schema loader and CLI now feed emitted packages imported against a source-verified installed runtime. Scalar, nested-container and alternate-Key cases pass83 creation/codec checks on each of Python3.11.17 and3.14.8; both installed runtime suites pass95tests. A red control exposed same-shaped foreign Key DTO acceptance during raw graph copying; nominal identity is now checked before reconstruction. Explicit selectedKey, distinct alternate DTOs, thin shared-runtime codecs/projection decode, value-free decode errors, final/unhashable metadata, explicit update keywords, stage-two privilege preservation and public compatibility reports are exercised.

The932-test Bun replay/3170assertions, pinned mypy2.4.0/Pyright1.1.414/ty0.0.88 positive and exact-negative corpora, actual two-wheel scale-fix/drift proof and15-case Chromium153 parity pass. One concurrent CLI timeout and harness corrections remain retained. Owner-approved initial exact-only and explicitly hypothetical no-null policy qualifications do not alter core semantics. [Execution and continuation](evidence/typed-persistence/non-temporal-20261015/execution.json) distinguishes this scoped delivery from full B-TP-003/SDK acceptance. Full action/source, complete DSL/catalog and native/engine gates remain open; temporal qualification is HELD.


### Typed SDK concurrent reporting integration and real E2E replay — 2026-10-15

The combined source preserves typed to-one joins, nullable cross-record projections and reviewed PostgreSQL reads alongside explicit Key selection and shared-runtime codecs. Merge review added red/green guards for Join import and projection descriptor collisions. The final frozen SDK source b6e59db0 passes935Bun tests/3186assertions across15files; both installed Python3.11.17/3.14.8 suites pass95tests and83 public schema-load/creation/codec E2E checks each. All three pinned checkers pass positives and reject the19 selected reporting/query misuse cases; separate model negatives retain exact line/rule checks. General15-case and joined3-case Chromium parity pass.

The exact frozen Weft raw-read wheel and fresh SDK wheel execute14 compiler/native read tests with no skips on an isolated PostgreSQL18.6 cluster, including generated capture/catalog/caller reads and nullable joined thin-codec controls; the owned server is stopped. [Final integration evidence](evidence/typed-persistence/non-temporal-20261015/integration/integration.json) records source/SDK/compiler hashes and supersedes pre-merge claims only for the tested subset. Full SDK/B-TP-003 acceptance remains OPEN; temporal qualification remains HELD. Unrelated dirty UUID work on local main is preserved; publication uses the verified integration branch to fast-forward repository main.

### Typed action ABI, catalog freshness and PostgreSQL snapshot exports — 2026-10-16

Source-bound ActionRef now carries the exact original document/core/action pointer/digest and initial tx/1 invocation identity. Generated synchronous Actions/ReplayingActions endpoints validate raw model graphs, omit MISSING inputs, distinguish replay capability and retain complete original authorized outcomes/request/transport and host recovery custody. Action protocol fixtures exercise invocation, validation, failures and replay without implicit retry; they do not qualify native/Truss writes. Endpoint keyword/case-fold collisions refuse before emission.

Reviewed catalogs now bind to participating generated stage-one digest/runtime ABI and refuse stale/mixed generations before touching a connection. PostgreSQL18 bounded exports execute existing Weft keyset pages in one repeatable-read/read-only transaction; an independent concurrent writer, max_rows, early-close cleanup and host transaction refusal are exercised natively. [Exact execution and limits](evidence/typed-persistence/action-catalog-20261016/README.md) retain installed-wheel, public schema-to-instance, static, browser and native receipts. Full B-TP-003/SDK acceptance remains OPEN: complete stage-two catalog publication, native action/bulk/search lowering and engine/managed backend gates are not implemented or qualified by this packet. Temporal qualification stays HELD.

### UUID implementation main integration — 2026-10-16

Implementation commit `25a38767` integrates with the fourteen newer remote-main commits. The execution-log conflict retains both workstreams. On the combined source, both TypeScript configurations pass and the seven UUID/128-bit test files pass27 tests with6849 assertions; `git diff --check` is clean. This integration check does not refresh the earlier native or browser receipts or claim a full-repository replay.

### Weft bounded String prerequisite and current core gate — 2026-10-16

Bounded required Unicode String compilation and actual issued-object Python/WASM bridges are committed directly to Weft main 8e0f4cb, with no SDK bump or implicit feature activation. Frozen/committed source campaigns pass 348 core, 20 Databricks and 119 PostgreSQL compiler-library tests plus both 26-command bridge campaigns; Astra Ultra finds no actionable issue over 1,593 independent controls. [Cross-repository source/artifact custody and qualification](evidence/security/bounded-current-string-compiler-20261016/README.md) retain exact tested revisions, original failures and the separate actual original-Token logical-state probe. No database, native current-cut/caller custody or guarded-release acceptance follows from this compiler component.

Current UMF core/UUID changes invalidated 30 prior case fingerprints. The fifth complete gate passed 40 cases but five native runners refused an outdated exact source inventory before SQL. A reviewed amendment adds 16 genuinely imported paths, removes none and changes no assertion, identity, required flag, command, deadline or allocation. The sixth full replay passes all 45 implementations with fresh selected source fingerprints; all 113 missing required implementations still fail. All 158 cases/34 criteria, including original P03/L03/B10 and every graph case, remain in scope. [Original failed cohort, additive inventory review and corrected gate](evidence/security/gate-refresh-20261015/README.md) preserve the complete history and broader failing audit.

### Native presence and disclosure carrier prerequisite — 2026-10-16

A PostgreSQL18.6 owned tmpfs fixture passes43 observations over four actual issued SQL queries and actual Rust checker calls. Complete fixture capture rejects hidden NULLs even for FALSE/LIMIT0. An explicit carrier preserves five declared DisclosureV2 outcomes and exact domain/transform provenance; scalar NULL loses these distinctions. A separately revised queryable optional Token model validates absence/null/String, while the current required-only producer refuses it before application SQL. Sixteen retained Z3 checks establish bounded abstract carrier properties and erasure counterexamples, not policy or implementation correctness.

[Exact source, handoff, failures and cleanup qualification](evidence/security/native-query-presence-20261016/README.md) distinguish supplied cells and excluded-admin physical observations from authenticated owner selection, complete current-cut custody, actual transforms and guarded release. Weft owns a separately versioned protocol; existing profiles remain closed. Astra Ultra review is clean after fixing a missing generator source closure with a separate fresh replay;114 independent component observations and exact evidence are retained. Native database execution remains supplied evidence, not an independent Astra native replay. No case promoted:45 implemented passing/158 required,113 missing. Full original P03 operators/actors/bypass controls and all graph cases remain required.

### Explicit optional-cell policy selection — 2026-10-16

Forty-four actual candidate logical-scan scenarios pass on the explicit optional Resource model. A separately authored Token disclosure preserves String/null/absence under the existing project-membership requirement; the original salary-only policy, unreported presence, incomplete coverage and stale generation refuse. Inactive assignment, foreign subject/staff/project links and complete missing Ownership/Assignment populations yield no eligible rows. All outcomes retain complete=false/authority=false. [Exact source and supplied policy/cut packets](evidence/security/queryable-presence-policy-20261016/README.md) distinguish these logical decisions from authenticated native custody, actual compiler .4 composition and operator/transform execution. Independent Astra Ultra review is clean: exact44-scenario replay,44-packet semantic/custody audit and30 additional actual logical controls pass. No required backend case is promoted.

### Canonical logical disclosure-selection provenance — 2026-10-16

A private separately versioned read-disclosure scan now retains exact winning source occurrences directly inside the original kernel, including all compatible transform contributors and the first canonical selected occurrence. Old action/render/rule-scan shapes remain unchanged.42Bun/Chromium controls and both TypeScript configurations pass. The broader security suite passes318tests/4982assertions after fixing three independently reproduced pre-existing0.9-version negative expectations; separate existing browser/type harnesses pass133 metadata cases across the old and newer inspection profiles. The44-scenario optional policy oracle passes again on the changed kernel.

[Exact source, initial failures, baseline reconstruction and current gate](evidence/security/disclosure-selection-20261016/README.md) retain all replaced receipt preimages. The full unchanged158-case/34-criterion gate passes45implementations with fresh fingerprints and still fails113missing required implementations; the broader221-check audit still fails87checks. Independent Astra Ultra review is clean, with3,082 checks each in Bun and Chromium plus16 edge controls and exact source/receipt custody verification; the original report and manifest-pinned artifacts are retained. Selection evidence does not authenticate caller/source/current cut, execute or certify transform values, admit DisclosureV2 wire adaptation, compose compiler .4 or grant native/operator/release authority. No backend case is promoted.


### Conditional disclosure occurrence algebra — 2026-10-16

[Exact formulas, original weak controls and strengthened analysis](evidence/security/disclosure-selection-formal-20261016/README.md) supplement US-056-AC6/AC10. The revised33-query campaign has14 UNSAT properties and19 SAT premise/counterexample controls, including actual inactive-update contributor/selection invariance. Faithful source flattening and eligibility are premises; TypeScript refinement, chooser construction, retained-output completeness and native authority remain unproved. Independent Astra Ultra final review is clean: all33 formulas replay,14 premise pairs are nonvacuous and three independent source mutations fail without a receipt; original findings and exact review inputs are retained. No required case is promoted and the full158-case goal remains open.


### Atomic canonical V2 disclosure production — 2026-10-16

CONTRACT-062/TD-056/STP-056 compose the original fold's exact winning source occurrences, issued pure recipe execution and original0.2 transport in one private supplied-cut operation. 181 Bun/Chromium controls and 319 security tests / 5163 assertions pass, with both final TypeScript configurations independently passing. Astra Ultra final source review is clean after fixing a shared parameter/Cell budget mismatch and an inherited source-inventory gap. Exact counterexamples and immutable intermediate reviews remain retained.

[Original failures, frozen sources, additive inventories and replay history](evidence/security/atomic-disclosure-batch-20261016/README.md) retain all receipt preimages. The first replay passes 44 implementations and P04 refuses before SQL on missing imports; the second passes 45 with selected-file freshness. Independent review then finds 25 inherited S24/S25 import omissions. Additive amendments add six then 52 actual dependency entries without changing cases, assertions, commands, allocations or deadlines. A fail-closed conservative closure guard passes 58 independent controls; the third replay passes all 45 implementations. After a type-only annotation with byte-identical emitted JavaScript, the fourth exact-source replay passes all 45 implementations with 570 unique pins / 2236 fresh fingerprint occurrences. All 113 errors are missing implementations; the final broader audit remains 221 checks / 87 failures. All 158 required cases / 34 criteria remain required; no backend case is promoted. Private census data cannot be public diagnostics; native source/caller/current-cut, query operators, compiler .4 composition and guarded release remain required.

### Actual atomic producer presence handoff — 2026-10-16

[Exact supplied cuts, source snapshots, failures and producer output](evidence/security/atomic-presence-handoff-20261016/README.md) retain 66 scenarios / 546 passing Bun controls and a passing tools TypeScript check. The actual WithinOperation fold and pure null-out recipe retain exact private census/resources, stored Token carrier, distinct original/null/absent/withheld/transformed-null V2 cells, original public inspector verdicts and codec bytes. Separately authored Token policies use distinct content revisions; the original salary-only policy remains a negative. Independent source review is pending. Weft's separately reviewed borrowed context is now verified on main 1c1a7dba; typed native lowering remains a separate prototype. This handoff removes supplied-cell construction from the next integration input without authenticating the supplied logical facts or promoting any of the full 158 required cases.
