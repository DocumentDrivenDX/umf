from pathlib import Path
import json,hashlib,datetime,subprocess,zipfile
out=Path(__file__).parent;root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');prior=Path('/private/tmp/pg18-catalog-p02-astra-20261015');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
priorpins=json.loads((out/'prior-packet-pins.json').read_text());assert sha(prior/'review.json')==priorpins['review'] and sha(prior.with_suffix('.zip'))==priorpins['archive']
current=json.loads((out/'final-original.json').read_bytes());assert len(current['observations'])==93 and sum(t['cells'] for t in current['nativeInventory']['transport'])==260;assert current['nativeInventory']['cleanup']=={'containerAbsent':True,'volumesAbsent':True};assert all(sha(root/p)==h for p,h in current['sourceDigests'].items())
old=json.loads((prior/'review.json').read_bytes());changed=[p for p,h in current['sourceDigests'].items()if old['finalSourcePins'][p]!=h];assert sorted(changed)==['tests/security/native/pg18-catalog-oracle.py','tests/security/native/pg18-catalog-projection.py']
results=json.loads((out/'final-run-results.json').read_bytes());assert results[0]['exit']==0 and all(r['correctFailure'] for r in results[1:]);pair=json.loads((out/'alias-pair-coverage.json').read_bytes());assert pair['dependentPairs']==pair['distinguishedPairs']==42
case=next(c for c in json.loads((root/'docs/helix/03-test/security/cases.json').read_bytes())['cases']if c['id']=='pg-raw.P02');assert all(case[k]==old['requirement'][k]for k in old['requirement'])
md='''P02 distinct-carrier delta review: no remaining actionable blocker.

Only the authored Python oracle and native runner changed from the prior reviewed packet. The compiler and remaining selected implementation dependencies are byte-identical. No authoritative files were edited by this review, and the original review/archive hashes remain unchanged.

Independent current PostgreSQL18.6 execution passed 93 observations and260 typed Cells in11.080s, within the original60s limit. All33 repository source digests match current files;539 selected runtime dependency hashes were checked before/after. Original fixture cleanup verified container and anonymous-volume absence; a separate successful Docker inventory found no remaining P02 containers.

The historical four-round fixture passed89 observations but failed to distinguish fixed-redact reading input_hash: that actual compiler mutant survived. This is retained as a sensitivity gap, not successful correspondence evidence. The value-sensitive partial->hash mutant already failed the distinct-field Alice assertion.

The final fifth round assigns distinct null signatures across readable Resource IDs. Both actual compiler mutations now fail their exact intended native value assertions: partial->hash at distinct-field-carriers/Alice (9.215s), fixed->hash at mixed-null-carriers/Alice (10.349s). Source snapshots, patches, logs and the historical survivor receipt are retained separately.

Finite analysis of the authored oracle distinguishes all42 value-dependent same-family carrier-alias pairs. The12 constant/null-out pairs correctly remain source-value independent. This analysis is not42 separate native mutation executions; two actual native alias executions are retained.

The original P02 assertion, covers, required flag, native layer and60s timeout are unchanged. This supplemental review clears the fixed five-round native subset for governed binding/full-gate execution; it does not itself promote acceptance. All prior limits remain: private native transport and fixed membership eligibility, no general .2 permission compiler, P03/P04/P05, current authority/lifecycle, other backend or production admission claim.
'''
(out/'review.md').write_text(md)
review={'status':'no-open-actionable-findings-in-P02-delta','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'priorPacket':{'review':str(prior/'review.json'),'reviewSha256':priorpins['review'],'archive':str(prior.with_suffix('.zip')),'archiveSha256':priorpins['archive'],'unchanged':True},'changedSourcePaths':changed,'requirement':old['requirement'],'currentSourcePins':current['sourceDigests'],'currentNative':{'observations':93,'typedCells':260,'seconds':11.080,'repositoryPins':33,'runtimePins':len(current['nativeInventory']['runtimeDependencies']['sourceDigests']),'cleanup':current['nativeInventory']['cleanup']},'historicalWitness':{'sourcePins':'source-pins.json','originalObservations':89,'fixedAliasSurvived':True,'artifact':'fixed-alias.json','qualification':'Historical evidence of insufficient null-sensitive fixture discrimination, not current success.'},'currentNativeMutations':[{'name':r['name'],'seconds':r['seconds'],'failure':r['expectedFailure'],'detected':r['correctFailure']}for r in results[1:]],'finiteOracleSensitivity':{'valueDependentPairs':42,'distinguishedPairs':42,'intrinsicallyInputIndependentPairs':12,'nativeExecutions':2,'scope':pair['scope']},'scope':'Five-round fixed PostgreSQL18.6 P02 source-correspondence fixture and oracle delta. Prior source/provider/security boundaries preserved.','authoritativeEdits':False,'acceptancePromotions':[]}
important=['final-original.json','final-run-results.json','run-results.json','alias-pair-coverage.json','post-run-inventory.json','source-pins.json','final-source-pins.json','review.md'];review['artifactPins']={p:sha(out/p)for p in important};(out/'review.json').write_text(json.dumps(review,indent=2)+'\n')
selected=[p for p in out.iterdir()if p.is_file()and p.suffix in ['.py','.json','.log','.patch','.md']and p.name!='manifest.json']
for folder,pinsfile in [('source','source-pins.json'),('final-source','final-source-pins.json')]:
 for rel in json.loads((out/pinsfile).read_text()):selected.append(out/folder/rel)
selected=sorted(set(selected));(out/'manifest.json').write_text(json.dumps({str(p.relative_to(out)):sha(p)for p in selected},indent=2)+'\n');selected.append(out/'manifest.json')
archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in selected:z.write(p,str(p.relative_to(out)))
print(json.dumps({'review':str(out/'review.json'),'reviewSha256':sha(out/'review.json'),'archive':str(archive),'archiveSha256':sha(archive),'archiveBytes':archive.stat().st_size,'files':len(selected)}))
