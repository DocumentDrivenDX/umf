from pathlib import Path
import subprocess,time,json,shutil,difflib,hashlib
out=Path(__file__).parent;source=out/'final-source';results=[]
variants=[('final-original',None,None),('final-partial-alias','input_partial','typed-byte-exact:distinct-field-carriers:umf_sec_alice'),('final-fixed-alias','input_fixed','typed-byte-exact:mixed-null-carriers:umf_sec_alice')]
for name,carrier,expected_failure in variants:
 work=source if name=='final-original' else out/name
 if name!='final-original':
  shutil.copytree(source,work,symlinks=True);p=work/'tools/security/protection-pg18-catalog.ts';text=p.read_text();old="source:{alias:'r',column:binding.column}";new="source:{alias:'r',column:binding.column==='"+carrier+"'?'input_hash':binding.column}";assert text.count(old)==1;mutant=text.replace(old,new);p.write_text(mutant);(out/(name+'.patch')).write_text(''.join(difflib.unified_diff(text.splitlines(True),mutant.splitlines(True),fromfile='original-compiler',tofile=name)))
 start=time.monotonic();r=subprocess.run(['python3','tests/security/native/pg18-catalog-projection.py','--output',str(out/(name+'.json'))],cwd=work,capture_output=True,text=True,timeout=60);elapsed=round(time.monotonic()-start,3)
 (out/(name+'.log')).write_text(r.stdout+r.stderr)
 results.append({'name':name,'seconds':elapsed,'exit':r.returncode,'status':'passed'if r.returncode==0 else 'failed','expectedFailure':expected_failure,'correctFailure':r.returncode!=0 and expected_failure in r.stderr if expected_failure else None,'stdout':r.stdout,'stderrTail':r.stderr[-2500:]});(out/'final-run-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results[-1]),flush=True)
 assert r.returncode==0 if name=='final-original' else (r.returncode!=0 and expected_failure in r.stderr if expected_failure else True)
