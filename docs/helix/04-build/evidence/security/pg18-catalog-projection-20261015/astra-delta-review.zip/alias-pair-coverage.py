from pathlib import Path
import importlib.util,sys,json,copy,hashlib
sys.dont_write_bytecode=True
out=Path(__file__).parent;p=out/'final-source/tests/security/native/pg18-catalog-oracle.py';s=importlib.util.spec_from_file_location('oracle',p);o=importlib.util.module_from_spec(s);s.loader.exec_module(o)
rows=[]
for name,kind,function,params,family in o.RECIPES:
 for other,_,_,_,otherfamily in o.RECIPES:
  if name==other or family!=otherfamily:continue
  witness=None
  for round_name,source_rows in o.rounds():
   for row in source_rows:
    if not any(row['id']in ids for ids in o.ACTORS.values()):continue
    original=o.expected_value(row,name,kind,function,params,family);changed=copy.deepcopy(row);changed.setdefault('fields',{})[name]=o.scalar(row,family,other);wrong=o.expected_value(changed,name,kind,function,params,family)
    if original!=wrong:witness={'round':round_name,'resource':row['id'],'original':original,'wrongAlias':wrong};break
   if witness:break
  independent=name in ['constant','null_out'];assert (witness is None)==independent,(name,other,witness)
  rows.append({'target':name,'wrongCarrier':other,'family':family,'sourceValueIndependent':independent,'distinguished':witness is not None,'witness':witness})
result={'sourceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'dependentPairs':sum(not r['sourceValueIndependent']for r in rows),'distinguishedPairs':sum(r['distinguished']for r in rows),'intrinsicallyIndependentPairs':sum(r['sourceValueIndependent']for r in rows),'scope':'Finite sensitivity analysis of authored Python oracle/fixture only, not independent SQL execution of every alias. The two actual native alias mutations are retained separately.','rows':rows};(out/'alias-pair-coverage.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='rows'}))
