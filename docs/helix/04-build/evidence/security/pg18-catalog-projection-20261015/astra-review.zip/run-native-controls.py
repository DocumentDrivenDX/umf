import pathlib,json,shutil,subprocess,time,hashlib
out=pathlib.Path(__file__).parent;snapshot=out/'snapshot';summary=[]
variants=[('original',None,None,None),('owner-rls-disabled','tests/security/native/pg18-catalog-projection.py',' ALTER TABLE security_projection.resource FORCE ROW LEVEL SECURITY;','', 'typed-byte-exact:baseline:umf_sec_alice'),('barrier-disabled','tools/security/protection-pg18-catalog.ts','WITH (security_barrier=true)','WITH (security_barrier=false)','owner-barrier-view'),('ordinary-base-grant','tests/security/native/pg18-catalog-projection.py',"+'; RESET ROLE;'", "+'; GRANT SELECT ON security_projection.resource TO umf_sec_alice; RESET ROLE;'",'no-base-or-column-route:umf_sec_alice')]
for entry in variants:
 name,path,old,new=entry[:4];dest=out/'native-sandboxes'/name;shutil.copytree(snapshot,dest,symlinks=True)
 if path:
  p=dest/path;s=p.read_text();assert s.count(old)==1,(name,s.count(old));p.write_text(s.replace(old,new));(out/(name+'-changed-source.txt')).write_text(p.read_text())
 start=time.monotonic();r=subprocess.run(['python3','tests/security/native/pg18-catalog-projection.py','--output',str(out/(name+'-native.json'))],cwd=dest,capture_output=True,text=True,timeout=60);seconds=time.monotonic()-start
 (out/(name+'-native.log')).write_text(r.stdout+r.stderr)
 passed=r.returncode==0 if name=='original' else r.returncode!=0 and entry[4] in r.stderr and 'AssertionError:' in r.stderr
 summary.append(dict(name=name,seconds=round(seconds,3),exit=r.returncode,expectedFailure=None if name=='original' else entry[4],pass_=passed,stdout=r.stdout,stderrTail=r.stderr[-1500:]))
 (out/'native-controls.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary[-1]),flush=True)
 assert passed,name
# Independent inventory check only for names created by retained sandbox runs.
r=subprocess.run(['docker','container','ls','-a','--format','{{.Names}}'],capture_output=True,text=True,timeout=10);assert r.returncode==0
left=[n for n in r.stdout.splitlines() if n.startswith('umf-sec-pg18-p02-')];(out/'native-controls-inventory.json').write_text(json.dumps({'commandSucceeded':True,'remainingP02Names':left},indent=2)+'\n')
