from pathlib import Path
import json,subprocess,hashlib,difflib
out=Path(__file__).parent;source=out/'snapshot/tools/security/protection-pg18-catalog.ts';text=source.read_text();rows=[]
def line(s,needle):
 found=[v for v in s.splitlines(True) if needle in v];assert len(found)==1,(needle,len(found));return found[0]
revisions=["if(typeof entry.revision!=='string'||!entry.revision.length||entry.revision.length>4096)fail('Exact nonempty core revision required');","if(typeof pin.documentId!=='string'||!pin.documentId.length||typeof pin.revision!=='string'||!pin.revision.length||pin.revision.length>4096)fail('Exact nonempty document/revision pin required');"]
variants=[
 ('revision-types',[(x,'')for x in revisions],['core-revision-null','core-revision-0','core-revision-true','core-revision-""']),
 ('range-validation',[(line(text,'for(const property of t.disclosureProfile)'),'')],['range-property-missing-domain','range-property-wrong-literal']),
 ('bucket-output-proof',[("if(bucket(from.min)<to.min||bucket(from.max)>to.max)fail('Whole native input domain exceeds bucket output domain');",'')],['bucket-small-output']),
 ('string-output-proof',[(line(text,"if(to.family==='string'&&recipe.operation"),'')],['partial-output-too-short','fixed-output-too-short','fixed-output-min-too-long','prefix-output-too-short','regex-output-expansion','hash-output-too-short']),
 ('metadata-representability',[("pgMetadata(metadata);",'')],['native-metadata-id-"\\u0000"','native-metadata-revision-"\\u0000"','native-metadata-id-"\\ud800"','native-metadata-revision-"\\ud800"','native-metadata-text-bound']),
 ('core-pin-revision',[("d.revision===pin.revision",'true')],['stale-core-pin-"d0"']),
]
for name,changes,expected in variants:
 mutated=text
 for before,after in changes:assert mutated.count(before)==1,(name,before);mutated=mutated.replace(before,after)
 p=source.with_name('compiler-mutant-'+name+'.ts');p.write_text(mutated);script=(out/'controls-final.ts').read_text().replace(str(source.with_suffix('')),str(p.with_suffix('')));run=out/('pure-mutant-'+name+'.ts');run.write_text(script);output=out/('pure-mutant-'+name+'.json');r=subprocess.run(['/opt/homebrew/bin/bun',str(run),str(output)],capture_output=True,text=True,timeout=20)
 (out/('pure-mutant-'+name+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,(name,r.stderr)
 result=json.loads(output.read_text());failed=[x['name']for x in result['failed']];assert failed==expected,(name,expected,failed);assert result['rows'][0]['pass'],name
 patch=''.join(difflib.unified_diff(text.splitlines(True),mutated.splitlines(True),fromfile='original',tofile=name));(out/('pure-mutant-'+name+'.patch')).write_text(patch)
 rows.append(dict(name=name,originalSha256=hashlib.sha256(text.encode()).hexdigest(),mutantSha256=hashlib.sha256(mutated.encode()).hexdigest(),expectedFailures=expected,observedFailures=failed,positiveStillPasses=True,status='detected'))
(out/'pure-mutations.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'mutants':len(rows),'status':'all-exact-failures'}))
