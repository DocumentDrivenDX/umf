import ast,json,pathlib,re,subprocess
out=pathlib.Path(__file__).parent
root=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
paths={'historical':out/'snapshot/tests/security/native/pg18-catalog-projection.py','current':root/'tests/security/native/pg18-catalog-projection.py'}
rows=[]
for variant,path in paths.items():
 tree=ast.parse(path.read_text());env={'re':re};fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='refuse');exec(compile(ast.Module(body=[fn],type_ignores=[]),str(path),'exec'),env)
 good=subprocess.CompletedProcess([],3,'','ERROR:  42501: permission denied\nLOCATION:  aclcheck_error, aclchk.c:1\n')
 tests=[('valid-exact-refusal',good,True)]
 for code in [0,1,2,4]:tests.append(('wrong-exit-'+str(code),subprocess.CompletedProcess([],code,'',good.stderr),False))
 for stdout in ['row\n','\n',' ','{}']:tests.append(('nonempty-output-'+repr(stdout),subprocess.CompletedProcess([],3,stdout,good.stderr),False))
 for name,stderr in [('wrong-state',good.stderr.replace('42501','23514')),('duplicate-primary',good.stderr+good.stderr),('fatal',good.stderr+'FATAL:  57P01: stopping\n'),('panic',good.stderr+'PANIC:  XX000: failure\n'),('missing-primary','permission denied'),('malformed-state','ERROR: 42501x: denied\n')]:tests.append((name,subprocess.CompletedProcess([],3,'',stderr),False))
 for name,result,expected in tests:
  env['sql']=lambda *a,r=result:r
  try:ret=env['refuse']('SELECT secret;','ordinary');accepted=ret==dict(status='refused',scope='statement',sqlstate='42501',rows=[])
  except AssertionError:accepted=False
  rows.append(dict(variant=variant,name=name,pass_=accepted==expected))
 # Execute the actual initial-volume capture expression (if present), then the
 # actual cleanup AST, with a container absent but its observed volume still live.
 block=next(n for n in tree.body if isinstance(n,ast.Try) and n.finalbody)
 volume='owned-anonymous-v';name='umf-sec-pg18-p02-review';run='review-owned-run';calls=[]
 def command(args,**kw):
  calls.append(args)
  if args[1:3]==['container','ls']:return subprocess.CompletedProcess(args,0,'','')
  if args[1:3]==['volume','ls']:return subprocess.CompletedProcess(args,0,volume+'\n','')
  raise AssertionError('Unexpected mocked cleanup command: '+repr(args))
 def require(r):
  if r.returncode:raise RuntimeError(r.stderr)
  return r.stdout.strip()
 e={'creation_attempted':True,'name':name,'run_id':run,'volumes':[],'info':{'Mounts':[{'Type':'volume','Name':volume}]},'receipt':{'nativeInventory':{}},'command':command,'require':require,'json':json}
 for n in block.body:
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='volumes' for t in n.targets):exec(compile(ast.Module(body=[n],type_ignores=[]),str(path),'exec'),e)
 try:exec(compile(ast.Module(body=block.finalbody,type_ignores=[]),str(path),'exec'),e);accepted=True
 except (AssertionError,RuntimeError):accepted=False
 rows.append(dict(variant=variant,name='container-disappeared-owned-volume-remains',pass_=accepted==(variant=='historical'),acceptedCleanup=accepted,observedCapturedVolumes=e['volumes'],cleanup=e.get('cleanup'),scope='Controlled successful initial inspect and successful final inventories; isolated original cleanup AST, not Docker fault injection'))
(out/'fault-controls.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'controls':len(rows),'passed':sum(r['pass_'] for r in rows),'failed':[r for r in rows if not r['pass_']]}))
