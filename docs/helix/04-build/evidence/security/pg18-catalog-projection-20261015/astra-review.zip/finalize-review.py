from pathlib import Path
import json,hashlib,zipfile,datetime,subprocess
out=Path(__file__).parent;root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((out/'final-source-pins.json').read_text());assert all(sha(root/p)==h for p,h in pins.items())
native=json.loads((out/'independent-native-final.json').read_text());assert native['status']=='passed' and len(native['observations'])==85 and all(native['nativeInventory']['cleanup'].values());assert all(sha(root/p)==h for p,h in native['sourceDigests'].items())
parent=Path('/private/tmp/pg18-catalog-native-prebinding-20261015.json');parent_result=json.loads(parent.read_bytes());assert parent_result['sourceDigests']==native['sourceDigests'];(out/'parent-prebinding-native.json').write_bytes(parent.read_bytes())
controls=json.loads((out/'controls-current.json').read_bytes());assert controls['count']==150 and not controls['failed']
case=next(c for c in json.loads((root/'docs/helix/03-test/security/cases.json').read_text())['cases'] if c['id']=='pg-raw.P02');assert case['status']=='not-run' and case['timeoutMs']==60000
md='''Read-only Astra review of the fixed PostgreSQL18.6 P02 catalog projection candidate.

No remaining actionable finding in the reviewed scope. The final independent native replay passed 85 observations and 156 typed Cells in 9.610 seconds, within the unchanged 60-second case limit. Its 33 repository source digests match the current checkout and the parent prebinding receipt; 539 selected runtime dependency digests were checked before and after execution. Owned container and anonymous volumes were absent after cleanup.

Independent evidence:
- 150 compiler controls pass on final captured source: exact catalog/core/bindings, all13 recipes, domain/output/parameter/null boundaries, source custody, unsupported/native metadata and reserved-name refusal.
- Six actual compiler-source weakenings produce the exact intended failed controls while preserving the positive fixture.
- Three actual native weakenings are detected: lost FORCE RLS, disabled security_barrier, and ordinary base SELECT grant. These runs use the explicitly retained earlier snapshot, not the final runner revision.
- 32 source-extracted refusal/cleanup controls compare historical and final behavior; the historical disappeared-container/live-volume success is retained as a bug witness, not a successful cleanup qualification.
- Nine conditional Z3 queries replay as seven UNSAT/two SAT. Their faithful domain derivation/native expression premises remain assumptions, not a TS/SQL refinement theorem.

Resolved review findings: primitive/nonempty core revision validation; previously unobserved range-property Field/literal closure; emitted JSONB metadata NUL/unpaired-surrogate rejection; retained anonymous-volume identity after container disappearance; reserved PostgreSQL system-column rejection. Generated constraint operators/collation and final SQL-size accounting were also checked. Original witnesses and pre-fix source are retained.

Scope: the original P02 conjunction is supported for these authored13 transformations and fixed three-actor SESSION_USER membership profile on the exact PostgreSQL18.6 image. Typed Cell contents and canonical UTF8 JSON are compared exactly; JSON object member order is normalized. The private native transport is not the general .2 disclosure codec and does not invent policy lineage.

This review does not qualify arbitrary policy/permission compilation, P03 query properties/leakage, P04 writes, P05 generated carriers, production installation, current authority, role/DDL lifetime, general crypto custody, or another backend. Source/native helper custody and excluded administrator premises remain explicit. No case was changed or promoted by this review; governed binding/full-gate acceptance remains the parent's next step.

No authoritative source edits, commits, new subagents, or duplicate long-running native services. Sandbox copies and disposable review fixtures only. Initial Docker sandbox permission failure and earlier exact source versions remain separately recorded.
'''
(out/'review.md').write_text(md)
review={'status':'no-open-actionable-findings-in-fixed-P02-scope','reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authoritativeRoot':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'nativeImage':'postgres@sha256:74935e72241653ca55e0414067e6d8763aceb8a810eb51b452253ec3dcfc4336','requirement':{k:case[k]for k in ['id','assertion','covers','required','layer','timeoutMs']},'caseAtReview':{'status':case['status'],'command':case['command']},'evidence':{'finalCompilerControls':150,'finalSourceCompilerMutants':6,'independentFinalNativeObservations':85,'independentFinalNativeTypedCells':156,'independentFinalNativeSeconds':9.610,'nativeEarlierSourceMutants':3,'nativeOriginalBeforeFinalFraming':{'observations':83,'seconds':10.223},'refusalAndCleanupComparisonControls':32,'formal':{'queries':9,'unsat':7,'sat':2,'scope':'conditional mathematical model, not native/program refinement'},'selectedRepositoryDigests':33,'selectedRuntimeDigests':539},'finalSourcePins':pins,'resolvedFindings':[{'id':'core-revision-carriers','witness':'quick-initial.json'},{'id':'range-property-closure','witness':'quick-initial.json'},{'id':'native-jsonb-metadata-representability','witness':'metadata-utf8-initial.json'},{'id':'lost-volume-observation','witness':'fault-controls.json'},{'id':'reserved-native-columns','witness':'system-columns-initial.json','primaryDocumentation':'https://www.postgresql.org/docs/18/ddl-system-columns.html'}],'nativeMutationScope':'The three native weakening runs use snapshot-pins.json; final native replay uses final-source-pins.json. No inheritance of source qualification is asserted.','sourceEdits':False,'acceptancePromotions':[],'limits':['Fixed authored catalog, typed physical profile and three ordinary SCRAM actors only.','Canonical JSON bytes compare exact typed values after object-key ordering; not raw server formatting equivalence.','Private native transport; not fabricated .2 policy or issuer lineage.','No P03/P04/P05, arbitrary permission compiler, production/native authority/lifecycle, or other-backend qualification.','Core validation precedes literal budget; no total CPU/heap theorem.','Sandbox mutation receipts are sensitivity evidence, not successful product receipts.']}
important=['controls-current.json','current-pure-mutations.json','native-controls.json','independent-native-final.json','independent-native-final-run.json','fault-controls.json','formal-replay/receipt.json','parent-prebinding-native.json','review.md']
review['resultDigests']={p:sha(out/p)for p in important};(out/'review.json').write_text(json.dumps(review,indent=2)+'\n')
selected=[]
for p in out.iterdir():
 if p.is_file() and p.suffix in ['.json','.ts','.py','.log','.patch','.md','.txt'] and p.name!='artifact-manifest.json':selected.append(p)
for folder,pin_file in [('snapshot','snapshot-pins.json'),('final-source','final-source-pins.json')]:
 for rel in json.loads((out/pin_file).read_text()):selected.append(out/folder/rel)
selected.append(out/'snapshot/tools/security/protection-pg18-catalog-initial.ts')
selected.extend(p for p in (out/'formal-replay').iterdir()if p.is_file())
selected=sorted(set(selected));manifest={str(p.relative_to(out)):sha(p)for p in selected};(out/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');selected.append(out/'artifact-manifest.json')
archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in selected:z.write(p,str(p.relative_to(out)))
print(json.dumps({'review':str(out/'review.json'),'reviewSha256':sha(out/'review.json'),'archive':str(archive),'archiveSha256':sha(archive),'bytes':archive.stat().st_size,'files':len(selected)}))
