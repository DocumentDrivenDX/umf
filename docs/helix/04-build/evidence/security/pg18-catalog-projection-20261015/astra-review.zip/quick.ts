import {compilePg18ProtectionCatalog as compile} from '/Users/erik/.codex/worktrees/security-main-integration/umf/tools/security/protection-pg18-catalog';
const base=await Bun.file('/private/tmp/pg18-catalog-p02-astra-20261015/fixture.json').json();const rows=[];
for(const [name,fn] of [
['valid',(x:any)=>{}],
...[[null,'null'],[0,'number'],[true,'bool'],['','empty']].map(([v,n])=>['revision-'+n,(x:any)=>{x.closure.documents[0].revision=v;x.closure.pins[0].revision=v;}]),
['missing-range-domain',(x:any)=>{x.catalog.transforms[0].disclosureProfile=[{kind:'range',bucket:{field:{documentId:'foreign',moduleId:'m',elementId:'missing'},value:{integerToken:'3'}}}];}],
['range-literal-type',(x:any)=>{x.catalog.transforms[0].disclosureProfile=[{kind:'range',bucket:{field:{documentId:'pg18-protection',moduleId:'m',elementId:'input_integer_bucket'},value:{string:'bad'}}}];}],
] as [string,(x:any)=>void][]){const x=structuredClone(base);fn(x);const r=compile(x.catalog,x.closure,x.profile);rows.push({name,status:r.status,reason:r.reason});}console.log(JSON.stringify(rows,null,2));
