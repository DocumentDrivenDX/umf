import {compilePg18ProtectionCatalog as c} from '/Users/erik/.codex/worktrees/security-main-integration/umf/tools/security/protection-pg18-catalog';
const base=await Bun.file('/private/tmp/pg18-catalog-p02-astra-20261015/fixture.json').json();const rows=[];
for(const bad of ['\0','\ud800'])for(const k of ['id','revision']){const f=structuredClone(base);f.catalog[k]='catalog-'+bad;f.profile.catalog[k]=f.catalog[k];const r=c(f.catalog,f.closure,f.profile);rows.push({key:k,value:JSON.stringify(bad),status:r.status,reason:r.reason});}
console.log(JSON.stringify(rows,null,2));
