from pathlib import Path
import json
p=Path(__file__).parent;rows=[]
def check(name,want,got):rows.append({'id':name,'expected':want,'observed':got,'passed':want==got})
ref=lambda e:{'documentId':'domain','moduleId':'m','elementId':e}
string={'facets':{},'family':'string','nullable':False};integer={'facets':{'integerWidth':{'bits':64,'signed':True}},'family':'integer','nullable':False}
def use(path,scan,field,op,operation,required,typ,output=None):
 d={'path':path,'scan':scan,'field':ref(field),'type':ref('Resource'),'operator':op,'operation':operation,'required':required,'propertyStatus':'derived' if required else 'unsupported','logicalType':typ,'fieldIdentity':{'documentId':'domain','module':'m','element':field,'revision':'named-query-core-r1'}}
 if output:d['outputType']=output
 return d
expected={
 'token-equality':[use('filters/0/left','s0','token','predicate','equal',['equality'],string)],
 'token-self-join':[use('joins/0/on/0/left','s0','token','join','equal',['equality'],string),use('joins/0/on/0/right','s1','token','join','equal',['equality'],string),use('groups/0','s0','token','group','group',['equality'],string)],
 'token-order-refusal':[use('order/0','s0','token','order','order',['order'],string)],
 'numeric-sum-unsupported':[use('outputs/0/argument','s0','salary','aggregate','sum',None,integer,{'facets':{},'family':'integer','nullable':True})],
 'field-free-count':[]}
for name,uses in expected.items():
 r=json.loads((p/'lineage-final'/f'{name}.report.json').read_text());check(name+':full-exact-use-metadata',uses,r['uses']);check(name+':exact-scan-map',{s:{'documentId':'domain','module':'m','element':'Resource','revision':'named-query-core-r1'} for s in (['s0','s1'] if name=='token-self-join' else ['s0'])},r['scans']);check(name+':directions',['asc'] if name=='token-order-refusal' else [],r['orderDirections']);check(name+':no-authority',[False,False],[r['authority'],r['securityReady']])
result={'passed':all(r['passed'] for r in rows),'controls':len(rows),'rows':rows,'scope':'Independent exact expected use metadata for the five authored SQL scenarios; no execution/lowering or general compiler refinement.'};(p/'lineage-final-readback-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'controls':len(rows)}));assert result['passed']
