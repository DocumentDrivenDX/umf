import f0 from './source/tests/security/protection/current-query-source.json';
import {compileCandidateCatalogProgram} from './source/src/extensions/security/catalog-program-candidate';
import {inspectCandidateStoredQueryProperties} from './source/src/extensions/security/stored-query-candidate';
import {evaluateCandidateCatalogAction} from './source/src/extensions/security/catalog-runtime-candidate';
const ref=(elementId:string)=>({documentId:'domain',moduleId:'m',elementId});
export function run(){
 const rows:any[]=[];const check=(id:string,expected:any,observed:any)=>rows.push({id,expected,observed,passed:JSON.stringify(expected)===JSON.stringify(observed)});
 const f:any=structuredClone(f0),names=f.closure.documents[0].document.modules[0].elements.map((e:any)=>e.name);check('all-authored-names-unique',names.length,new Set(names).size);
 check('storage-exhaustive-live-fields',f.ontology.entities.reduce((n:number,e:any)=>n+e.fields.length,0),f.owner.storage.length);
 check('stored-query-has-original-output-carrier',['Resource','token','token','clear'],[f.owner.storage.at(-1).type.elementId,f.owner.storage.at(-1).field.elementId,f.catalog.transforms[0].outputDomain.elementId,f.catalog.transforms[0].inputDomain.elementId]);
 check('stored-field-is-protected',true,f.ontology.entities.find((e:any)=>e.type.elementId==='Resource').fields.find((x:any)=>x.ref.elementId==='token').protection==='protected');
 const handle=compileCandidateCatalogProgram(f.policy,f.catalog,f.closure,f.ontology),u={type:ref('Resource'),field:ref('token'),operator:'join',required:['equality']};
 const result=inspectCandidateStoredQueryProperties(handle,f.owner,u);check('conditional-stored-property-positive',['selected','compatible-properties',false,false],[result.status,result.report?.status,result.complete,result.authority]);
 const fact=(type:string,key:string,values:Record<string,any>)=>({type:ref(type),key:[{string:key}],fields:Object.entries(values).map(([field,value])=>({field:ref(field),value})),absent:[]});
 const cut:any={version:'umf.security.logical-facts/0.1',trusted:true,generation:'review1',expectedGeneration:'review1',policy:{id:f.policy.id,revision:f.policy.revision},ontology:f.policy.ontology,protection:f.policy.protection,domains:f.closure.pins,owner:{id:f.owner.id,revision:f.owner.revision},subject:{type:ref('Staff'),key:[{string:'alice'}]},facts:[fact('Staff','alice',{staffId:{string:'alice'}}),fact('Project','p1',{projectId:{string:'p1'}}),fact('Resource','r1',{resourceId:{string:'r1'},salary:{integerToken:'100'},token:{string:'opaque-token'}}),fact('Ownership','o1',{ownerId:{string:'o1'},ownerResource:{string:'r1'},ownerProject:{string:'p1'}}),fact('Assignment','a1',{assignmentId:{string:'a1'},assignmentStaff:{string:'alice'},assignmentProject:{string:'p1'},active:{boolean:true}})],graphs:[],coverage:f.ontology.entities.map((e:any)=>({type:e.type,complete:true,fields:e.fields.map((x:any)=>x.ref)})),graphCoverage:[],context:[],valueProfiles:[],maxFacts:100,maxSteps:100000};
 const request={action:'read',resources:[{type:ref('Resource'),key:[{string:'r1'}]}],targets:[ref('Resource')],fields:[ref('token')]};
 const actual=evaluateCandidateCatalogAction(handle,f.owner,cut,request);check('current-token-read-is-not-admitted',{status:'evaluated',complete:false,authority:false,rows:[{decision:'indeterminate',dispositions:[]}]},actual);
 const salary=evaluateCandidateCatalogAction(handle,f.owner,cut,{...request,fields:[ref('salary')]});check('membership-and-salary-read-positive','permit',salary.rows[0]?.decision);
 const explicit=structuredClone(f);explicit.policy.revision='review-explicit-token-read';explicit.policy.rules[0].disclosure.push({field:ref('token'),disposition:{kind:'original'}});const original=evaluateCandidateCatalogAction(compileCandidateCatalogProgram(explicit.policy,explicit.catalog,explicit.closure,explicit.ontology),explicit.owner,{...cut,policy:{id:explicit.policy.id,revision:explicit.policy.revision}},request);check('explicit-alternative-source-token-read-positive','permit',original.rows[0]?.decision);
 for(const [id,change] of [
 ['foreign-output-domain',(x:any)=>{x.catalog.transforms[0].outputDomain=ref('resourceId')}],
 ['unselected-owner-duplicate',(x:any)=>{x.owner.storage.push(x.owner.storage[0])}],
 ['stored-input-substitution',(x:any)=>{x.owner.storage.at(-1).field=ref('clear')}],
 ['missing-equality',(x:any)=>{x.catalog.transforms[0].disclosureProfile=[];x.catalog.transforms[0].determinism='random'}],
 ['prohibited-join',(x:any)=>{x.catalog.transforms[0].queryUse.join='prohibited'}]
 ] as [string,(x:any)=>void][]){const x=structuredClone(f);change(x);let status:string;try{const h=compileCandidateCatalogProgram(x.policy,x.catalog,x.closure,x.ontology);const r=inspectCandidateStoredQueryProperties(h,x.owner,u);status=r.status==='selected'?r.report!.status:r.status;}catch{status='refused'}check(id,id==='prohibited-join'?'prohibited':'refused',status)}
 return rows;
}
