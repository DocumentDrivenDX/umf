from pathlib import Path
import re,json,hashlib,shutil,subprocess
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent/'source';out.mkdir(exist_ok=True);paths=set()
def visit(p):
 p=p.resolve()
 if p in paths:return
 assert p.is_relative_to(root) and p.is_file(),p;paths.add(p)
 if p.suffix in ['.ts','.js']:
  for rel in re.findall(r'(?:from\s*|import\s*)[\'"](\.[^\'"]+)[\'"]',p.read_text()):
   base=p.parent/rel;q=next((x for x in [base,Path(str(base)+'.ts'),Path(str(base)+'.json'),base/'index.ts'] if x.is_file()),None);assert q,rel;visit(q)
for rel in ['tests/security/protection/current-query-source.json','tests/security/protection/current-query-source-corpus.ts','tests/security/protection/current-query-source.test.ts','tools/security/current-query-source-browser.ts','src/extensions/security/catalog-runtime-candidate.ts','package.json','bun.lock']:visit(root/rel)
pins={}
for p in sorted(paths):
 rel=p.relative_to(root);b=p.read_bytes();q=out/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);pins[str(rel)]=hashlib.sha256(b).hexdigest()
(out/'node_modules').symlink_to(root/'node_modules',target_is_directory=True);(out.parent/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(out.parent/'head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True));print(len(pins))
