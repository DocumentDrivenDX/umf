import * as sdk from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/index';
import p from './fixtures.json';
const f=structuredClone(p.base) as any;
const errors:any[]=[];
for(const text of [null,{},1])try{sdk.decodeSecurityDisclosureV2(text as any,f.policy,f.catalog,f.closure);}catch(e:any){errors.push({input:typeof text,code:e.code??null,name:e.name,message:e.message});}
f.batch.rows=[];f.batch.columns=[];
for(let i=0;i<180;i++){const id='\x01'.repeat(4000)+i;f.closure.documents[0].document.modules[0].elements.push({id,kind:'field',cardinality:'one',scalarType:'string',nullability:'required',extensions:{}});f.batch.columns.push({field:{documentId:'s20-core',moduleId:'m',elementId:id},storageEffect:'canonical'});}
const r=sdk.inspectSecurityDisclosureV2(f.batch,f.policy,f.catalog,f.closure);
let encoding:any;try{encoding={length:sdk.encodeSecurityDisclosureV2(f.batch,f.policy,f.catalog,f.closure).length};}catch(e:any){encoding={name:e.name,code:e.code,message:e.message};}
console.log(JSON.stringify({errors,inspect:r.status,diagnostics:r.diagnostics.filter(d=>d.severity==='error'),encodedUnits:JSON.stringify(f.batch,null,2).length+1,encoding}));
