import {runOracle} from './oracle';
const rows=runOracle();
await Bun.write('/private/tmp/protection-disclosure-astra-20261015/bun-results.json',JSON.stringify({rows,passed:rows.filter(r=>r.passed).length,failed:rows.filter(r=>!r.passed)},null,2)+'\n');
console.log(JSON.stringify({rows:rows.length,passed:rows.filter(r=>r.passed).length,failed:rows.filter(r=>!r.passed)}));
if(rows.some(r=>!r.passed))process.exitCode=1;
