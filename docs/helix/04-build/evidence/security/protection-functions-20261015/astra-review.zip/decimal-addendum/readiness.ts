import {inspectProtectionFunction} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/index';
import {makeFixture,runOracle} from '../oracle';
import packet from '../fixtures.json';
const rows:any[]=[];
for(const side of ['input','output','parameter'])for(const [name,facets,good] of [
 ['missing',undefined,false],['only-precision',{precision:3},false],['only-scale',{scale:0},false],
 ['zero-precision',{precision:0,scale:0},false],['negative-scale',{precision:3,scale:-1},false],
 ['scale-over-precision',{precision:2,scale:3},false],['fractional-precision',{precision:2.5,scale:1},false],
 ['boolean-precision',{precision:true,scale:0},false],['scale-zero',{precision:1,scale:0},true],['scale-equals-precision',{precision:3,scale:3},true]] as any[]){
 const f:any=makeFixture(packet.cases[0]);const index=side==='input'?0:side==='output'?1:3;
 const fld=f.closure.documents[0].document.modules[0].elements[index];
 fld.scalarType='decimal';fld.nullability='absent-allowed';if(facets)fld.facets=facets;
 if(side==='output'){const parameter=f.catalog.transforms[0].parameters[0];parameter.value=null;f.closure.documents[0].document.modules[0].elements[3].nullability='absent-allowed';}
 if(side==='parameter'){f.catalog.transforms[0].parameters[0].value=null;f.closure.documents[0].document.modules[0].elements[1].nullability='absent-allowed';}
 const result=inspectProtectionFunction(f.policy,f.catalog,f.closure,{ruleIndex:0,disclosureIndex:0});
 const pass=result.status===(good?'reference-ready':'refused')&&result.complete===false&&result.authority===false;
 rows.push({side,name,pass,expected:good?'reference-ready':'refused',actual:result.status,diagnostics:result.diagnostics.filter(d=>d.severity==='error')});
}
const oracle=await runOracle();await Bun.write('/private/tmp/protection-functions-astra-20261015/decimal-addendum/results.json',JSON.stringify({rows,oracle},null,2)+'\n');
console.log(JSON.stringify({readiness:rows.length,failed:rows.filter(r=>!r.pass),oracle:oracle.passed}));
if(rows.some(r=>!r.pass)||oracle.failed.length)process.exitCode=1;
