import {runOracle} from '../oracle';
(globalThis as any).runOracle=runOracle;
