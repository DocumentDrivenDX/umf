import {runOracle} from './run';
(globalThis as any).runOracle=runOracle;
