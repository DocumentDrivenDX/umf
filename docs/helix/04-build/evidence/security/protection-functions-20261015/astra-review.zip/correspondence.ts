import {evaluateProtectionValue,inspectProtectionFunction} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/index';
import packet from './fixtures.json';
import {makeFixture} from './run';
const rows=[];
for(const side of ['input','output'])for(const scalarType of ['integer','string']){
 const f:any=makeFixture(packet.cases[0]);f.closure.documents[0].document.modules[0].elements.push({id:'other',kind:'field',scalarType,cardinality:'one',nullability:'required',extensions:{}});
 const ref={documentId:'oracle-domains',moduleId:'m',elementId:'other'};
 if(side==='input')f.policy.rules[0].disclosure[0].field=ref;else f.policy.rules[0].disclosure[0].disposition.field=ref;
 const i=inspectProtectionFunction(f.policy,f.catalog,f.closure,{ruleIndex:0,disclosureIndex:0});
 const r=evaluateProtectionValue(f.policy,f.catalog,f.closure,f.selection);
 rows.push({side,scalarType,inspection:i.status,evaluation:r.status,inputDomain:r.inputDomain,outputDomain:r.outputDomain,value:r.value,diagnostics:r.diagnostics.filter(d=>d.severity==='error')});
}
await Bun.write('/private/tmp/protection-functions-astra-20261015/domain-correspondence-before.json',JSON.stringify(rows,null,2)+'\n');
console.log(JSON.stringify(rows));
