import {chromium} from '/Users/erik/.codex/worktrees/security-main-integration/umf/node_modules/playwright/index.mjs';
const root='/private/tmp/protection-functions-astra-20261015';
const build=await Bun.build({entrypoints:[root+'/browser-entry.ts'],target:'browser',format:'esm',outdir:root+'/browser'});
if(!build.success)throw new Error(build.logs.join('\n'));
const source=await build.outputs[0]!.text();if(source.length>16_000_000)throw new Error('bundle bound');
const server=Bun.serve({hostname:'127.0.0.1',port:0,fetch:r=>new URL(r.url).pathname==='/oracle.js'?new Response(source,{headers:{'content-type':'text/javascript'}}):new Response('<!doctype html><script type="module" src="/oracle.js"></script>',{headers:{'content-type':'text/html'}})});
let browser;const external:string[]=[],errors:string[]=[];
try{
 browser=await chromium.launch({headless:true});
 const page=await browser.newPage();
 page.on('pageerror',e=>errors.push(String(e)));
 const origin='http://127.0.0.1:'+server.port;
 await page.route('**/*',route=>{const u=route.request().url();if(!u.startsWith(origin+'/')){external.push(u);return route.abort();}return route.continue();});
 await page.goto(origin);await page.waitForFunction(()=>typeof (globalThis as any).runOracle==='function');
 const result=await page.evaluate(async()=>({oracle:await (globalThis as any).runOracle(),globals:{Bun:typeof (globalThis as any).Bun,process:typeof (globalThis as any).process,require:typeof (globalThis as any).require}}));
 const receipt={browser:browser.version(),bundleUtf16Units:source.length,external,pageErrors:errors,...result};
 await Bun.write(root+'/browser-results.json',JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({browser:receipt.browser,passed:result.oracle.passed,failures:result.oracle.failed,globals:result.globals,external,pageErrors:errors}));
 if(result.oracle.failed.length||external.length||errors.length)process.exitCode=1;
}finally{await browser?.close();server.stop(true);}
