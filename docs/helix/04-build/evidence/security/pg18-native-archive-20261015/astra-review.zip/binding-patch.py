from pathlib import Path
import json
p=Path('tests/security/native/pg18-native-archive.py');s=p.read_text();a=s.index("if len(sys.argv)!=3");b=s.index("spec=importlib",a)
s=s[:a]+'''CASE='pg-raw.P07';spike=len(sys.argv)==3 and sys.argv[1]=='--output'
if len(sys.argv)!=1 and not spike:raise ValueError('Explicit component output or governed run required')
run_id=str(uuid.uuid4()) if spike else os.environ.get('UMF_SECURITY_RUN_ID','');assert str(uuid.UUID(run_id))==run_id
plan=json.loads((ROOT/'docs/helix/03-test/security/cases.json').read_text());case=next(c for c in plan['cases'] if c['id']==CASE)
if not spike:assert os.environ.get('UMF_SECURITY_CASE_ID')==CASE and case['command']==['python3','tests/security/native/pg18-native-archive.py']
output=Path(sys.argv[2]) if spike else ROOT/case['evidence'];sys.dont_write_bytecode=True
''' +s[b:]
s=s.replace("observations.append(dict(id=label,expected=", "observations.append(dict(id=label,assertionId=CASE+':'+label,expected=")
s=s.replace('dependency_script=',"if not spike:assert set(sources)==set([case['testSource'],case['oracleSource'],*case['implementationSources']])\ndependency_script=",1)
s=s.replace("output.parent.mkdir(parents=True,exist_ok=True);", """receipt.update(id=CASE,backend='pg-raw',command=['python3','tests/security/native/pg18-native-archive.py'],covers=['US-056-AC7'])
receipt['nativeInventory']['objects']=receipt['nativeInventory']['protectedState']['objects']
receipt['nativeInventory']['ordinaryActor']={'observedSessions':[o['observed'] for o in observations if o['id'].endswith(':actual-session')],'settings':receipt['nativeInventory']['ordinaryActor']}
receipt['nativeInventory']['digest']=sha(canonical(receipt['nativeInventory']))
if not spike:
 receipt.update(status='passed',acceptanceReceipt=True,casePromoted=CASE)
 observations.append(dict(assertionId=CASE,expected=True,observed=True))
output.parent.mkdir(parents=True,exist_ok=True);""")
s=s.replace("print(json.dumps(dict(status=receipt['status'],observations=len(observations),output=str(output))))", "print(json.dumps(dict(status=receipt['status'],observations=len(observations),output=str(output))) if spike else json.dumps(receipt,ensure_ascii=False,separators=(',',':')))")
p.write_text(s)
planpath=Path('docs/helix/03-test/security/cases.json');j=json.loads(planpath.read_text());c=next(c for c in j['cases'] if c['id']=='pg-raw.P07');pins=json.loads(Path('/private/tmp/pg18-native-archive-final-component-20261015.json').read_text())['sourceDigests'];c.update(status='implemented',command=['python3','tests/security/native/pg18-native-archive.py'],evidence='docs/helix/04-build/evidence/security/pg18-native-archive-20261015/case.json',testSource='tests/security/native/pg18-native-archive.py',oracleSource='tests/security/native/pg18-native-archive-oracle.py',implementationSources=sorted(set(pins)-{'tests/security/native/pg18-native-archive.py','tests/security/native/pg18-native-archive-oracle.py'}));planpath.write_text(json.dumps(j,indent=2)+'\n')
