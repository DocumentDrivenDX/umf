# P07 independent review

No remaining blocker for the fixed native archive component. Fresh governed acceptance remains separate.

Final independent replay: 45 native observations on the exact Anonymizer3.2.3 / PostgreSQL18.6 image, 103 actual Bun/Chromium controls, 26 capture controls and16 diagnostic controls. All owned native containers/volumes were removed. Five meaningful native weakenings were detected on the hardened pre-DDL source; two trigger/inheritance weakenings were detected on the final source. Seventeen private binding checks preserve every original P07 requirement and all other157 cases.

Retained counterexamples show why the corrections mattered: malformed count/database identities initially passed; a column grant plus SET-owner route leaked100 without changing the old snapshot; dormant triggers and empty inheritance links also evaded it. Final sources reject those controls. Earlier sources/results and two reviewer harness setup failures remain separate and are not counted as successful evidence.

Native labels remain opaque. The admitted view returns0 despite the native207 label, actual interpretation refuses and the receipt stays unverified. This does not qualify dynamic masking, arbitrary extension/DDL/role lifetime closure, a compiler or native authority, P03/B08, or production backend admission. See review.json for exact source stages, pins, methods and limits.
