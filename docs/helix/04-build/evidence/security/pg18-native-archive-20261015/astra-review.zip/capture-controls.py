from pathlib import Path
import json,sys,copy,importlib.util,hashlib
root=Path(sys.argv[1]);receipt=Path(sys.argv[2]);output=Path(sys.argv[3]);sys.dont_write_bytecode=True
sp=root/'tests/security/native/pg18-native-archive-oracle.py';spec=importlib.util.spec_from_file_location('oracle',sp);o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
r=json.loads(receipt.read_text());base=r['baselineCapture'];expected=r['expectedFixtureLabels'];capture=r['catalog']['native']['postgresql']['capture'];rows=[]
def run(name,c,b,e,want):
 got=o.matches(c,b,e);rows.append({'id':name,'expectedAccepted':want,'observedAccepted':got,'passed':got==want})
run('actual-complete-capture',capture,base,expected,True)
c=copy.deepcopy(capture);c['rows'].reverse();run('row-order-does-not-change-identity',c,base,expected,True)
for key,v in [('sharedCount',True),('sharedCount',1.0),('localCount',-1),('localCount','84')]:
 c=copy.deepcopy(capture);c[key]=v;run('strict-'+key+'-'+repr(v),c,base,expected,False)
for label,mut in [
 ('missing-extension-row',lambda c:(c['rows'].pop(0),c.update(localCount=c['localCount']-1))),
 ('duplicate',lambda c:(c['rows'].append(copy.deepcopy(c['rows'][0])),c.update(localCount=c['localCount']+1))),
 ('changed-label',lambda c:c['rows'][0].update(label='changed',labelUtf8Hex='changed'.encode().hex())),
 ('changed-utf8',lambda c:c['rows'][0].update(labelUtf8Hex='00')),
 ('changed-provider',lambda c:c['rows'][0].update(provider='other')),
 ('changed-object',lambda c:c['rows'][0].update(objoid='4294967295')),
 ('changed-local-subid',lambda c:c['rows'][0].update(objsubid='999')),
 ('invented-shared-subid',lambda c:next(x for x in c['rows'] if x['catalog']=='pg_shseclabel').update(objsubid='0')),
 ('changed-local-db',lambda c:c['database'].update(oid='4294967295')),
 ('missing-row-key',lambda c:c['rows'][0].pop('provider')),
 ('unknown-row-key',lambda c:c['rows'][0].update(authority=True)),
 ('unknown-capture-key',lambda c:c.update(authority=True)),
 ]:
 c=copy.deepcopy(capture);mut(c);run(label,c,base,expected,False)
for label,db in [('db-empty',{}),('db-extra',{**capture['database'],'future':True}),('db-zero',{'oid':'0','name':'postgres'}),('db-leading-zero',{'oid':'05','name':'postgres'}),('db-empty-name',{'oid':'5','name':''}),('db-number-oid',{'oid':5,'name':'postgres'})]:
 c=copy.deepcopy(capture);b=copy.deepcopy(base);c['database']=b['database']=db;run(label,c,b,expected,False)
for label,x in [('missing-database',{'localCount':0,'sharedCount':0,'rows':[]}),('empty-malformed-database',{'database':{},'localCount':0,'sharedCount':0,'rows':[]})]:run(label,x,x,[],False)
result={'source':str(sp),'sourceSha256':hashlib.sha256(sp.read_bytes()).hexdigest(),'receiptSha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),'rows':rows};output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'total':len(rows),'passed':sum(x['passed'] for x in rows),'survivors':[x['id'] for x in rows if not x['passed']]}))
