from pathlib import Path
import json,shutil,hashlib,difflib,subprocess,time,sys,concurrent.futures
base=Path(__file__).parent;src=base/'source-ddl-final';out=base/'ddl-profile-final';out.mkdir(exist_ok=True);rel=Path('tests/security/native/pg18-native-archive.py');old=" check('protected-state-after-archive-refusal',baseline_state,protected_state());"
variants=[('latent-trigger',"CREATE FUNCTION archive_names.latent_trigger() RETURNS trigger LANGUAGE plpgsql AS $$BEGIN NEW.amount:=999;RETURN NEW;END$$; CREATE TRIGGER latent_trigger BEFORE UPDATE ON security_mask_write.resource FOR EACH ROW EXECUTE FUNCTION archive_names.latent_trigger();", "SELECT count(*) FROM pg_trigger WHERE tgrelid='security_mask_write.resource'::regclass AND tgname='latent_trigger';"),('empty-inherited-child',"CREATE TABLE archive_names.empty_child () INHERITS (security_mask_write.resource);", "SELECT count(*) FROM pg_inherits WHERE inhparent='security_mask_write.resource'::regclass;")]
for name,sql,probe in variants:
 d=out/name;shutil.copytree(src,d/'source',symlinks=True);before=(d/'source'/rel).read_text();assert before.count(old)==1
 new=' require(sql('+repr(sql)+'))\n check('+repr('actual-drift:'+name)+',1,value('+repr(probe)+'))\n'+old
 after=before.replace(old,new);after=after.replace("  if receipt is not None:receipt['nativeInventory']['cleanup']=cleanup","  if receipt is not None:receipt['nativeInventory']['cleanup']=cleanup\n  output.with_suffix('.cleanup.json').write_text(json.dumps(cleanup))");(d/'source'/rel).write_text(after);(d/'changed-runner.py').write_text(after);(d/'mutation.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(rel),tofile=str(rel))));(d/'source-pins.json').write_text(json.dumps({'original':hashlib.sha256(before.encode()).hexdigest(),'changed':hashlib.sha256(after.encode()).hexdigest()},indent=2)+'\n')
def run(v):
 name,_,_=v;d=out/name;start=time.monotonic()
 with (d/'run.log').open('w') as f:r=subprocess.run([sys.executable,str(d/'source'/rel),'--output',str(d/'receipt.json')],cwd=d/'source',stdout=f,stderr=subprocess.STDOUT,timeout=60)
 receipt=json.loads((d/'receipt.json').read_text()) if (d/'receipt.json').exists() else None
 row={'id':name,'exit':r.returncode,'seconds':time.monotonic()-start,'detected':r.returncode!=0 and "'id': 'protected-state-after-archive-refusal'" in (d/'run.log').read_text(),'observations':len(receipt['observations']) if receipt else None,'cleanup':json.loads((d/'receipt.cleanup.json').read_text()) if (d/'receipt.cleanup.json').exists() else None,'acceptanceReceipt':False};(d/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:rows=list(ex.map(run,variants))
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
