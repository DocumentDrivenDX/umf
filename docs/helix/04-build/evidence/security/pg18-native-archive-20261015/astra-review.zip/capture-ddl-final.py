from pathlib import Path
import json,hashlib,shutil
base=Path(__file__).parent;root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');receipt=Path('/private/tmp/pg18-native-archive-final-component-20261015.json');r=json.loads(receipt.read_text());out=base/'source-ddl-final';out.mkdir();paths=list(r['sourceDigests'])+['tests/security/native/pg18-native-archive-corpus.ts','tools/security/protection-native-archive-browser.ts'];pins={}
for rel in paths:
 p=root/rel;data=p.read_bytes();h=hashlib.sha256(data).hexdigest();assert rel not in r['sourceDigests'] or r['sourceDigests'][rel]==h,rel;target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);pins[rel]=h
(out/'node_modules').symlink_to(root/'node_modules',target_is_directory=True);(base/'source-ddl-final-pins.json').write_text(json.dumps(pins,indent=2)+'\n');shutil.copy2(receipt,base/'parent-ddl-final.json');shutil.copy2('/private/tmp/pg18-native-archive-browser-final-20261015.json',base/'parent-browser-ddl-final.json')
docs=['docs/helix/02-design/technical-designs/TD-056-security-bindings.md','docs/helix/03-test/test-plans/STP-056-security-bindings.md','docs/helix/04-build/plans/security-field-protection-plan.md','docs/helix/03-test/security/cases.json'];docpins={}
for rel in docs:
 p=root/rel
 if not p.exists():continue
 data=p.read_bytes();target=base/'governing'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);docpins[rel]=hashlib.sha256(data).hexdigest()
(base/'governing-pins.json').write_text(json.dumps(docpins,indent=2)+'\n');print(json.dumps({'sourcePins':len(pins),'governingPins':len(docpins)}))
