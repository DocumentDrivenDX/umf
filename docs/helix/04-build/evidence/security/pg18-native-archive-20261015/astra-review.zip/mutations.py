from pathlib import Path
import json,shutil,hashlib,difflib,subprocess,concurrent.futures,time,sys
base=Path(__file__).parent;src=base/'source-final';out=base/'mutations';out.mkdir(exist_ok=True);runner=Path('tests/security/native/pg18-native-archive.py');adapter=Path('tests/security/native/pg18-native-archive.ts');owner=Path('src/extensions/security/protection/catalog.ts')
variants=[
 ('latent-column-and-role-grants',runner," check('protected-state-after-archive-refusal',baseline_state,protected_state());"," require(sql('GRANT SELECT(id) ON security_mask_write.resource TO '+reader+'; GRANT umf_sec_mw_owner TO '+reader+' WITH INHERIT FALSE, SET TRUE;'))\n check('protected-state-after-archive-refusal',baseline_state,protected_state());", "'id': 'protected-state-after-archive-refusal'"),
 ('omit-extension-label',runner,"AS r FROM pg_seclabel\n","AS r FROM pg_seclabel WHERE objoid <> (SELECT min(objoid) FROM pg_seclabel)\n", "'id': 'complete-native-correspondence'"),
 ('allow-interpretation',owner,"throw new UmfError(failure.code,failure.message,failure.path);","return undefined as never;", "'id': 'actual-interpretation-refusal'"),
 ('promote-native-obligation',adapter,"status:'unverified'","status:'verified'", "'id': 'native-obligation-unverified'"),
 ('trust-opaque-authority',adapter,"interpretation,complete:false,authority:false,","interpretation,complete:false,authority:(input as any).native.future.authority,", "'id': 'receipt-never-authority'"),
]
hook="  if receipt is not None:receipt['nativeInventory']['cleanup']=cleanup";s=(src/runner).read_text();assert s.count(hook)==1;harness=s.replace(hook,hook+"\n  output.with_suffix('.cleanup.json').write_text(json.dumps(dict(runId=run_id,name=name,volumes=volumes,cleanup=cleanup)))")
(out/'cleanup-only.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),harness.splitlines(True),fromfile=str(runner),tofile=str(runner))))
for name,rel,old,new,fail in variants:
 d=out/name;shutil.copytree(src,d/'source',symlinks=True);(d/'source'/runner).write_text(harness);before=(d/'source'/rel).read_text();assert before.count(old)==1,(name,before.count(old));after=before.replace(old,new);(d/'source'/rel).write_text(after);(d/'changed-source.txt').write_text(after);(d/'mutation.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(rel),tofile=str(rel))));(d/'pins.json').write_text(json.dumps({'path':str(rel),'originalSHA':hashlib.sha256(before.encode()).hexdigest(),'mutantSHA':hashlib.sha256(after.encode()).hexdigest(),'runnerSHA':hashlib.sha256((d/'source'/runner).read_bytes()).hexdigest()},indent=2)+'\n')
def run(v):
 name,rel,old,new,fail=v;d=out/name;t=time.monotonic()
 with (d/'run.log').open('w') as log:r=subprocess.run([sys.executable,str(d/'source'/runner),'--output',str(d/'receipt.json')],cwd=d/'source',stdout=log,stderr=subprocess.STDOUT,timeout=65)
 log=(d/'run.log').read_text();cleanup=json.loads((d/'receipt.cleanup.json').read_text()) if (d/'receipt.cleanup.json').exists() else None;row={'id':name,'exit':r.returncode,'seconds':time.monotonic()-t,'expectedFailure':fail,'detected':r.returncode!=0 and fail in log,'cleanup':cleanup,'acceptanceReceipt':False};(d/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:rows=list(ex.map(run,variants))
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(x['detected'] and x['cleanup'] and all(x['cleanup']['cleanup'].values()) for x in rows)
