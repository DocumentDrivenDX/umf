from pathlib import Path
import ast,re,json,subprocess,hashlib,sys
p=Path(sys.argv[1]);out=Path(sys.argv[2]);source=p.read_text();tree=ast.parse(source);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='refused');code=compile(ast.Module(body=[node],type_ignores=[]),str(p),'exec');rows=[]
valid='ERROR:  42501: permission denied for table resource\nLOCATION:  aclcheck_error, aclchk.c:1\n'
cases=[('actual-verbose-shape',3,'',valid,True),('wrong-exit',1,'',valid,False),('zero-exit',0,'',valid,False),('stdout-space',3,' ',valid,False),('stdout-secret',3,'100',valid,False),('wrong-code',3,'',valid.replace('42501','23505'),False),('missing-error',3,'','LOCATION: x\n',False),('duplicate-error',3,'',valid+valid,False),('wrong-primary',3,'',valid.replace('resource','secret100'),False),('too-large',3,'',valid+'x'*8193,False)]
for level in ['FATAL','PANIC','NOTICE','WARNING','DETAIL','HINT']:cases.append(('reject-'+level,3,'',valid+level+': secret100\n',False))
for name,exit,stdout,stderr,want in cases:
 ns={'re':re,'reader':'controlled','native_diagnostics':[],'sql':lambda *args,e=exit,o=stdout,s=stderr:subprocess.CompletedProcess([],e,o,s)};exec(code,ns)
 try:r=ns['refused']('SELECT amount FROM security_mask_write.resource;');accepted=r=={'sqlstate':'42501','rows':[]}
 except AssertionError:accepted=False
 rows.append({'id':name,'expectedAccepted':want,'observedAccepted':accepted,'passed':accepted==want})
result={'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'rows':rows,'passed':all(x['passed'] for x in rows),'scope':'Original function AST replay with explicit completed-process outcomes; no native diagnostic generation or total-channel theorem.'};out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'controls':len(rows)}));assert result['passed']
