"""Independent P07 fixture declarations and complete native-label correspondence."""
import json
FIXTURES=[
 ('local','COLUMN','security_mask_write.resource.amount','MASKED WITH VALUE 207'),
 ('local','COLUMN','archive_names."Case".note',"MASKED WITH VALUE 'archivé ''quoted''\nline'"),
 ('local','COLUMN','archive_names."case".note',"MASKED WITH VALUE 'archivé ''quoted''\nline'"),
 ('local','SCHEMA','archive_names','TRUSTED'),
 ('shared','ROLE','umf_sec_archive_unused','MASKED')]
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def identity(row,database):
 if row['catalog']=='pg_seclabel':return canonical([row['catalog'],database,row['classoid'],row['objoid'],row['objsubid'],row['provider']])
 if row['catalog']=='pg_shseclabel':return canonical([row['catalog'],row['classoid'],row['objoid'],row['provider']])
 raise ValueError('Unknown native label catalog')
def rows(capture):
 result={}
 if set(capture)!=set(['database','localCount','sharedCount','rows']):raise ValueError('Exact capture required')
 for row in capture['rows']:
  expected={'catalog','classoid','objoid','provider','label','labelUtf8Hex'}|({'objsubid'} if row['catalog']=='pg_seclabel' else set())
  if set(row)!=expected or any(not isinstance(v,str) for v in row.values()):raise ValueError('Exact native string carriers required')
  if row['label'].encode('utf8').hex()!=row['labelUtf8Hex']:raise ValueError('Original UTF8 bytes required')
  key=identity(row,capture['database'])
  if key in result:raise ValueError('Duplicate native identity')
  result[key]=row
 if sum(r['catalog']=='pg_seclabel' for r in result.values())!=capture['localCount'] or sum(r['catalog']=='pg_shseclabel' for r in result.values())!=capture['sharedCount']:raise ValueError('Complete populations required')
 return result
def matches(capture,baseline,expected):
 try:
  if capture['database']!=baseline['database']:return False
  want=rows(baseline)
  for row in expected:
   key=identity(row,capture['database'])
   if key in want:return False
   want[key]=row
  return canonical(sorted(rows(capture).values(),key=lambda r:identity(r,capture['database'])))==canonical(sorted(want.values(),key=lambda r:identity(r,capture['database'])))
 except (ValueError,KeyError,TypeError,UnicodeError):return False
