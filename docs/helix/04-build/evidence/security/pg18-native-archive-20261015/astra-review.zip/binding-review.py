from pathlib import Path
import json,hashlib,shutil,subprocess,ast,difflib
base=Path(__file__).parent;root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=base/'binding-preview';shutil.copytree(base/'source-ddl-final',out,symlinks=True);rel='docs/helix/03-test/security/cases.json';(out/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/rel,out/rel);script=Path('/private/tmp/bind-native-archive-case.py');shutil.copy2(script,base/'binding-patch.py');before=json.loads((out/rel).read_text());runner=Path('tests/security/native/pg18-native-archive.py');source=(out/runner).read_text();r=subprocess.run(['python3',str(base/'binding-patch.py')],cwd=out,capture_output=True,text=True);(base/'binding-apply.log').write_text(r.stdout+r.stderr);assert r.returncode==0;after=json.loads((out/rel).read_text());changed=(out/runner).read_text();ast.parse(changed);rows=[]
def check(id,condition):rows.append({'id':id,'passed':bool(condition)});assert condition,id
old=next(c for c in before['cases'] if c['id']=='pg-raw.P07');new=next(c for c in after['cases'] if c['id']=='pg-raw.P07');mutable={'status','command','evidence','testSource','oracleSource','implementationSources'}
check('same158inventory',len(before['cases'])==len(after['cases'])==158)
check('other157-exact',[c for c in before['cases'] if c['id']!='pg-raw.P07']==[c for c in after['cases'] if c['id']!='pg-raw.P07'])
check('allP07-immutable-fields-exact',{k:v for k,v in old.items() if k not in mutable}=={k:v for k,v in new.items() if k not in mutable})
check('timeout60-preserved',new['timeoutMs']==60000)
check('governed-original-runner',new['command']==['python3',str(runner)])
check('exact24-source-set',set([new['testSource'],new['oracleSource'],*new['implementationSources']])==set(json.loads((base/'native-ddl-final.json').read_text())['sourceDigests']))
check('status-implemented-not-accepted',new['status']=='implemented')
check('canonical-run-id-gate',"assert str(uuid.UUID(run_id))==run_id" in changed)
check('case-command-environment-gate',"os.environ.get('UMF_SECURITY_CASE_ID')==CASE and case['command']==" in changed)
check('ordinary-sessions-from-observed-native-checks',"[o['observed'] for o in observations if o['id'].endswith(':actual-session')]" in changed)
check('inventory-digest-after-cleanup',changed.index("receipt['nativeInventory']['digest']")>changed.index("receipt['nativeInventory']['cleanup']=cleanup"))
check('original-aggregate-after-all-checks',changed.index("observations.append(dict(assertionId=CASE,expected=True,observed=True))")>changed.index("if any(sha(Path(p).read_bytes())!=h"))
oldtree=ast.parse(source);newtree=ast.parse(changed)
for name in ['sql','refused','protected_state','ordinary']:
 check(name+'-function-unchanged',ast.dump(next(n for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name==name))==ast.dump(next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name==name)))
check('CAPTURE-query-unchanged',next(n.value.value for n in oldtree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CAPTURE' for t in n.targets))==next(n.value.value for n in newtree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CAPTURE' for t in n.targets)))
(base/'binding-preview.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile=str(runner),tofile=str(runner))))
receipt={'status':'passed','checks':rows,'beforeCase':old,'afterCase':new,'patchSha256':hashlib.sha256(script.read_bytes()).hexdigest(),'beforeRunnerSha256':hashlib.sha256(source.encode()).hexdigest(),'previewRunnerSha256':hashlib.sha256(changed.encode()).hexdigest(),'beforeCasesSha256':hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),'scope':'Private application and source/metadata comparison only; no governed native acceptance receipt generated.'};(base/'binding-review.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'checks':len(rows),'status':'passed','previewRunnerSha256':receipt['previewRunnerSha256']}))
