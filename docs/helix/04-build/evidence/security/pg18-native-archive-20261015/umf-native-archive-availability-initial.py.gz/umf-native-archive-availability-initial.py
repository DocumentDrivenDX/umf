import subprocess,json,secrets,uuid,time,os
from pathlib import Path
image='registry.gitlab.com/dalibo/postgresql_anonymizer@sha256:cedfa32f762df460091ae5b0f71a96cf21ea6300c51ff1390ea020dded778d8a';run=str(uuid.uuid4());name='umf-anon-availability-'+run;cid=None

def cmd(args,**kw):
 r=subprocess.run(args,text=True,capture_output=True,timeout=kw.pop('timeout',30),**kw)
 if r.returncode:raise RuntimeError(r.stderr[:2000])
 return r.stdout.strip()
def sql(q):return cmd(['docker','exec','-i',cid,'psql','-X','-qAt','-v','ON_ERROR_STOP=1','-U','postgres'],input=q)
try:
 cid=cmd(['docker','run','--platform','linux/amd64','--name',name,'--label','umf.security.run='+run,'-d','-e','POSTGRES_PASSWORD',image],env={**os.environ,'POSTGRES_PASSWORD':secrets.token_hex(32)})
 deadline=time.monotonic()+35
 while subprocess.run(['docker','exec',cid,'pg_isready','-U','postgres'],capture_output=True).returncode:
  if time.monotonic()>deadline:raise TimeoutError('readiness')
  time.sleep(.2)
 # Initialization may briefly start a temporary server before final startup.
 for _ in range(40):
  try:
   meta=json.loads(sql("SELECT json_build_object('engine',version(),'number',current_setting('server_version_num'),'extensions',(SELECT json_agg(json_build_array(extname,extversion) ORDER BY extname) FROM pg_extension),'preload',current_setting('shared_preload_libraries'),'dynamic',current_setting('anon.transparent_dynamic_masking',true),'localLabels',(SELECT count(*) FROM pg_seclabel),'sharedLabels',(SELECT count(*) FROM pg_shseclabel));"));break
  except RuntimeError:time.sleep(.25)
 else:raise RuntimeError('final startup unavailable')
 sql("CREATE TABLE public.archive_probe(id integer, amount bigint, note text); INSERT INTO public.archive_probe VALUES(1,100,'secret'); SECURITY LABEL FOR anon ON COLUMN public.archive_probe.amount IS 'MASKED WITH VALUE 0'; SECURITY LABEL FOR anon ON COLUMN public.archive_probe.note IS $$MASKED WITH VALUE 'archivé'$$;")
 meta['labels']=json.loads(sql("SELECT json_agg(json_build_array(objoid::text,objsubid,provider,label,encode(convert_to(label,'UTF8'),'hex')) ORDER BY objoid,objsubid,provider) FROM pg_seclabel;"));meta['canonical']=json.loads(sql('SELECT row_to_json(p) FROM public.archive_probe p;'));Path('/private/tmp/umf-native-archive-availability-20261015.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({k:meta[k] for k in ['number','extensions','preload','dynamic','localLabels','sharedLabels']}))
finally:
 if cid:
  info=json.loads(cmd(['docker','inspect',cid]))[0]
  assert info['Config']['Labels'].get('umf.security.run')==run
  volumes=[m['Name'] for m in info['Mounts'] if m['Type']=='volume']
  cmd(['docker','rm','-fv',cid]);assert name not in cmd(['docker','container','ls','-a','--format','{{.Names}}']).splitlines();assert not set(volumes)&set(cmd(['docker','volume','ls','--format','{{.Name}}']).splitlines())
