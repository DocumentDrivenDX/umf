# P07 native archive design review

The proposed use of the existing source/catalog/refusal owners is faithful to the unchanged P07 assertion. Implementation remains unqualified until a fresh native run and independent controls pass.

The substantive risks are accidental provider activation, incomplete catalog capture, identity loss, and a refusal harness that mistakes setup failure for the intended semantic refusal. The required controls are recorded in review.json. Local labels need database identity plus their native class/object/subobject/provider tuple; shared labels have no objsubid. Capture both complete native populations coherently, including extension labels, and independently challenge omissions and identity substitutions.

Keep dynamic masking disabled in the actual ordinary sessions. Isolate MASKED role-label examples on separate NOLOGIN roles and use a label mask different from the admitted constant0. Compare the protected home before label insertion and after archive/refusal. Preserve opaque native authority/enforced fields without elevating the independently reported unverified obligation.

A valid empty-transform protection catalog can carry the archive without inventing interpreted transforms. Existing JSON/YAML owners must preserve it in Bun and real Chromium; requireProtectionInterpretation must produce its expected typed refusal while no install/execute route runs. Pin actual engine/extension/build bytes and enforce complete bounded capture with verified cleanup.

The immutable image/version is a proposed input here, not native evidence. No dynamic masking, whole-extension security, compiler, P03/B08 or lifetime promotion follows.
