import json,shutil,subprocess,hashlib
from pathlib import Path
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent;dest=out/'mutants';dest.mkdir(exist_ok=True)
runtime='src/extensions/security/catalog-runtime-candidate.ts'
variants=[('original',None,None,None),
('omit-scoped-preflight',runtime,'for(const target of request.targets)for(const condition of scoped(target))preflight(condition.condition.expression,target,new Map());',''),
('omit-record-coverage-consistency',runtime,"for(const [type,c] of covered)for(const row of byType.get(type)??[])for(const name of c.fields){step();if(!projections.get(row)!.has(name)&&!absences.get(row)!.has(name))fail('Declared projection is missing');}",''),
('omit-graph-coverage-consistency',runtime,"for(const [key,c] of graphCover)for(const row of graphTables.get(key)!.rows){for(const role of c.roles){step();if(!row.endpoints.has(role))fail('Declared graph role projection is missing');}for(const name of c.fields){step();if(!row.witnessFact||(!projections.get(row.witnessFact)!.has(name)&&!absences.get(row.witnessFact)!.has(name)))fail('Declared graph attribute projection is missing');}}",''),
('omit-normalized-key-uniqueness',runtime,"if(inventory.has(key))fail('Duplicate normalized Record identity');",''),
('reset-literal-meter-per-call',runtime,'const budget=new ProtectionLiteralBudget();',"const budget={step:(n=1)=>new ProtectionLiteralBudget().step(n),retain:(s:string)=>new ProtectionLiteralBudget().retain(s),check:(d:any,f:any,v:any)=>new ProtectionLiteralBudget().check(d,f,v),identity:(d:any,f:any,v:any)=>new ProtectionLiteralBudget().identity(d,f,v)};"),
('omit-composition-work',runtime,"if(decision==='permit')for(const r of request.fields){step();const ds:any[]=[];for(const x of evaluated){step();if(x.rule.effect==='permit'&&x.truth==='T')for(const d of x.rule.disclosure??[]){step();if(id(d.field)===id(r))ds.push(d.disposition);}}","if(decision==='permit')for(const r of request.fields){const ds:any[]=[];for(const x of evaluated){if(x.rule.effect==='permit'&&x.truth==='T')for(const d of x.rule.disclosure??[]){if(id(d.field)===id(r))ds.push(d.disposition);}}"),
('omit-withheld-dominance',runtime,"if(ds.some((d:any)=>d.kind==='withheld'))","if(false)"),
('collapse-distinct-catalog-directives',runtime,'canonicalSchemaJson([d.vocabulary,d.transform,d.version,id(d.field)])','canonicalSchemaJson([d.vocabulary,id(d.field)])'),
('ignore-mixed-unknown-rule',runtime,"evaluated.some((r:any)=>r.truth==='U')?'indeterminate'","evaluated.length>0&&evaluated.every((r:any)=>r.truth==='U')?'indeterminate'"),
('collapse-opaque-witness-namespaces',runtime,'const unique=JSON.stringify([rk,identity]);','const unique=JSON.stringify(identity);'),
('allow-canonical-storage-downgrade',runtime,"if(Object.hasOwn(c,'storageTransform')||stored.length)fail('Canonical downgrade');","if(Object.hasOwn(c,'storageTransform'))fail('Canonical downgrade');"),
('revert-opaque-link-domain-metadata','src/extensions/security/association-candidate.ts',"'facets','allowedValues','references'","'facets','allowedValues'")]
results=[]
for name,path,old,new in variants:
 d=dest/name;shutil.copytree(root/'src',d/'src',dirs_exist_ok=True)
 for dirname in ['spec','node_modules']:
  if not (d/dirname).exists():(d/dirname).symlink_to(root/dirname)
 if path:
  p=d/path;s=p.read_text();assert s.count(old)==1,(name,s.count(old));p.write_text(s.replace(old,new))
 for fixture in ['base-fixture.json','logic-vectors.json']:shutil.copyfile(out/fixture,d/fixture)
 for ts in ['truth-oracle.ts','runtime-oracle.ts','composition-budget-witness.ts','all-oracle.ts']:(d/ts).write_text((out/ts).read_text().replace(str(root),str(d)))
 (d/'run.ts').write_text("import{runOracle}from './all-oracle';const rows=runOracle();await Bun.write(import.meta.dir+'/results.json',JSON.stringify({rows},null,2)+'\\n');console.log(JSON.stringify({count:rows.length,failed:rows.filter(r=>!r.passed).map(r=>r.id)}));")
 r=subprocess.run(['/opt/homebrew/bin/bun',str(d/'run.ts')],cwd=d,text=True,capture_output=True,timeout=45);(d/'run.log').write_text(r.stdout+r.stderr)
 if r.returncode:raise RuntimeError((name,r.returncode,r.stdout,r.stderr))
 rows=json.loads((d/'results.json').read_text())['rows'];failed=[x['id'] for x in rows if not x['passed']]
 result={'variant':name,'count':len(rows),'failed':failed,'changedSource':path,'sha256':hashlib.sha256((d/path).read_bytes()).hexdigest()if path else None};results.append(result);print(json.dumps(result),flush=True)
 assert bool(failed)==(name!='original'),(name,failed)
(out/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
