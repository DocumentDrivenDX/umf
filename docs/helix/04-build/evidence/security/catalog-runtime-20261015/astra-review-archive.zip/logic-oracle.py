"""Independent CONTRACT062 finite truth/composition expectations; no runtime imports."""
import itertools,json,hashlib
from pathlib import Path
out=Path(__file__).parent
truths=('F','T','U')
def neg(a):return {'F':'T','T':'F','U':'U'}[a]
def conj(xs):return 'F' if 'F' in xs else 'U' if 'U' in xs else 'T'
def disj(xs):return 'T' if 'T' in xs else 'U' if 'U' in xs else 'F'
def decide(p,r,f):return 'indeterminate' if 'U' in p+r+f else 'permit' if 'T' in p and all(x=='T'for x in r) and all(x=='F'for x in f) else 'deny'
rows=[]
for t in truths:rows.append({'id':'not-'+t,'operator':'not','input':[t],'expected':neg(t)})
for a,b in itertools.product(truths,repeat=2):
 for name,fn in [('and',conj),('or',disj)]:rows.append({'id':name+'-'+a+b,'operator':name,'input':[a,b],'expected':fn([a,b])})
for size in range(4):
 for xs in itertools.product(truths,repeat=size):rows.append({'id':'exists-'+''.join(xs),'operator':'exists','input':list(xs),'expected':disj(xs),'completeGraphCoverage':True})
for sizes in [(0,0,0),(1,0,0),(1,1,1),(2,1,1),(2,2,2)]:
 n=sum(sizes);a,b,c=sizes
 for xs in itertools.product(truths,repeat=n):
  p,r,f=xs[:a],xs[a:a+b],xs[a+b:];rows.append({'id':'decision-'+'-'.join(map(str,sizes))+'-'+''.join(xs),'operator':'decision','permit':list(p),'require':list(r),'forbid':list(f),'expected':decide(p,r,f)})
packet={'scope':'Finite strong-Kleene operators and actual per-rule permit/require/forbid composition. Complete dependencies are a separate prerequisite; vectors neither invent completeness nor authenticate a cut. No output transforms or write admission qualified.','rows':rows}
text=json.dumps(packet,indent=2)+'\n';(out/'logic-vectors.json').write_text(text);print(len(rows),hashlib.sha256(text.encode()).hexdigest())
