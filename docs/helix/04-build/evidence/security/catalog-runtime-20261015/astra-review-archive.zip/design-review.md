# Canonical0.2 runtime: design review requirements

Baseline `8267602757147035ec4257ee760f615c3d8e2aac`. Read-only review of the next private reference kernel, not runtime approval. Existing source/compiler and transport evidence does not establish native authority or fullS24/S25.

## Facts and identity

Use the exact privately issued program, original ordered association table and target scopes. Snapshot the complete cut/request before interpretation. Exact policy/ontology/core pins and current/expected generation must match, but remain trusted-host assertions, not credentials. Require exactly one Subject of the original ontology type. Bound arrays, object shapes, references, IDs, scalar profiles and all numeric limit carriers before using them.

Facts retain qualified Record type plus ordered original Key tuple. Use the original core encoder; short exponent/key normalization and all retained tuple identities consume one operation ledger. Normalize before deciding duplicate key identity, so `1`/`1.0`/`1e0` cannot create distinct integer facts. Field values supplied for Key components must match those components. Every known projection of the same typed key across Subject, inventory and resource selection must agree under original typed equality. Known null, explicit absence and unknown/missing must remain distinct. A resource cannot silently enlarge an inventory declared complete.

## Graph incidence

Keep graph relation coverage separate from Record inventory/attribute coverage. Empty graph rows are meaningful only under explicit complete coverage of the selected relationship. Every endpoint role/side must match the issued declaration exactly; typed endpoint keys must resolve within the complete endpoint inventory. A Record-key witness resolves exactly to the supplied witness Record; attributes and identity come from that fact. An opaque witness supports existence/endpoints only; its host identifier is scoped dedup metadata, never logical Record equality.

Preserve distinct parallel witnesses. Duplicate IDs are namespaced by the exact relationship. A single Record-key witness must not supply contradictory endpoints within one association. Distinct relationships may reference the same Record. Do not infer graph endpoints from arbitrary associationRecord fields: a separate record-members selector supplies its own authored endpoint mapping. All malformed/unresolved supplied rows refuse rather than being filtered away by a join.

## Preflight and evaluation

Preflight every dependency of every action/target-scoped rule, including false branches, empty resource populations, nested exists and unused branches of and/or. Check graph coverage, endpoint inventories, Record-witness inventory and every relevant attribute independently. Missing coverage is not false or an empty relation. Known absence can yield U under value equality; null is an explicit typed value. Lexical occurrence IDs determine nested witness scope; sibling display names must not alias.

Use strong-Kleene operators and original rule-level composition: any scoped rule result U is indeterminate; otherwise some permit must be true, every require true and every forbid false. Collect disclosures only from true permits. Withheld dominates transform/original directives; conflicting transforms refuse rather than picking order. Catalog transform identity, version, output domain and exact parameter semantics must remain bound; equal sample outputs cannot erase different catalog identities. Empty output still needs full selected rule dependency preflight.

## Values and budgets

Keep constructor/compiler ledgers separate from a fresh runtime ledger. One runtime budget spans preflight, key encoding, all rows, all rules/nested exists, literal/refinement work and every value transform. Repeated calls to the public pure evaluator must not reset work accounting or revalidate entire sources without charging. Prefer a private issued recipe context using the same original checks. Charge before numeric expansion, repeated output construction and retained identity/result text; do not claim a total core-validator/heap/CPU theorem.

Original temporal semantics remain closed. Date value execution must select CONTRACT066 explicitly with its exact unrefined date domain constraints, or refuse. A nullable date Field or family label alone is not a value-profile selection. Non-pure catalog directives can remain unverified logical directives; they cannot mint ciphertext/tokens, recovered plaintext or verified custody. An unsupported output must refuse atomically, including after an earlier valid row.

## Stored carriers and full write dependency

Follow the existing S20/CONTRACT062 model: a stored canonical Field equals the exact storage transform's outputDomain. The inputDomain names pre-storage source data and never overrides canonical fact typing. Original token reads validate the actual canonical token Field. A presentation transform over that token names the token Field as its input; recovered plaintext requires a separate reverse action and operation, not read/original-authorized.

Before fullS24/S25, require an exhaustive owner-selected storage classification for relevant Fields: canonical or one exact stored transform. Refuse missing/ambiguous selection and a canonical tag for a known stored output. Original-read or explicit Field-bound blind permission is necessary for mutation; stored mutation additionally needs the exact separately purposed vault-write action. Read, ordinary field mutation, original-authorized and reverse permission cannot substitute. Purpose metadata alone supplies neither the owner mapping nor an actual grant. Compare complete original/proposed Record and graph states and evaluate all required actions on each operation state under one shared operation budget.

## Independent expectations prepared

`logic-oracle.py` authors finite F/T/U, existential and permit/require/forbid expectations without importing the runtime. Final executable controls will include normalized/compound keys, same-label foreign refs, Record/opaque/parallel graph witnesses, missing/false-branch/zero-resource coverage, contradictory projections, unsupported/date/stored carriers, every disclosure state, permutation invariance, immutable snapshots, stale pins and resource exhaustion. Actual Bun/Chromium replay awaits the new API; no runtime result is claimed here.
