from pathlib import Path
import json,hashlib,datetime,zipfile
out=Path(__file__).parent;root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((out/'source-pins-after.json').read_text());before=json.loads((out/'source-pins-before.json').read_text());assert pins==before
bun=json.loads((out/'all-results.json').read_text());browser=json.loads((out/'browser-results.json').read_text());mutations=json.loads((out/'mutation-exact-discrimination.json').read_text());formal=json.loads((out/'formal-replay.json').read_text());cases=json.loads((out/'case-allocation-check.json').read_text())
assert len(bun['rows'])==1088 and all(r['passed'] for r in bun['rows']);assert browser['rows']==bun['rows'] and browser['parity'] and browser['externalRequests']==0 and browser['pageErrors']==[] and browser['hostGlobalsAbsent'];assert len(mutations['variants'])==13 and all(x['exactFailedSet']for x in mutations['variants']);assert len(formal['queries'])==9
receipt={
 'status':'reviewed-no-remaining-actionable-blocker-within-stated-private-kernel-scope',
 'reviewer':'Astra Ultra independent review',
 'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'baseline':'8267602757147035ec4257ee760f615c3d8e2aac',
 'root':str(root),
 'sourcePins':{'file':'source-pins-after.json','sha256':sha(out/'source-pins-after.json'),'count':len(pins),'beforeAfterEqual':True},
 'selectedSourceSha256':{k:pins[k]for k in ['src/extensions/security/catalog-runtime-candidate.ts','src/extensions/security/association-candidate.ts','tests/security/catalog-runtime.test.ts','tests/security/catalog-runtime-fixture.ts','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md']},
 'independentControls':{'truthAndComposition':902,'boundary':186,'perRuntime':1088,'bun':browser['versions']['bun'],'chromium':browser['versions']['chromium'],'allPass':True,'fullRowsEqual':True,'externalRequests':0,'pageErrors':0,'hostGlobalsAbsent':True},
 'mutations':{'original':1,'sourceWeakenings':12,'exactExpectedFailures':True,'file':'mutation-exact-discrimination.json'},
 'repositoryTestsIndependentlyRun':{'files':3,'testsPassed':26,'assertions':167,'log':'repository-tests.log'},
 'conditionalFormal':{'queries':9,'unsat':5,'sat':4,'z3':formal['z3'],'file':'formal-replay.json','scope':'Definition-level arbitrary witness population and Boolean/budget laws; completeness, same population, faithful charging and validated truths are assumptions. No TS/SQL/native/source refinement.'},
 'resolvedFindings':[{'issue':'Uncharged Field/rule/disclosure composition work','before':'Valid64x64 disclosures across20 resources performed5242880 disclosure comparisons under50000 step limit and returned20rows.','after':'Current charges before each traversal; same witness atomically refuses with zero rows.','evidence':['pre-composition-budget-source.ts','pre-composition-budget-source.json','composition-budget-witness-before.json','composition-budget-witness.json','mutants/omit-composition-work/results.json']},{'issue':'Flat scalar endpoint correspondence rejected opaque non-record reference metadata accepted by original core scalar/Key domains.','after':'Exact closed metadata preserved outside equality-domain identity, record-type and malformed metadata refuse; independently separated flat/graph positives.','scope':'Source compatibility only; metadata does not establish FK, domain, native or authorization semantics.'}],
 'acceptance':{'caseRows':158,'entireFileByteEqualBaseline':cases['byteEqualBaseline'],'S24S25':'unchanged and unbound','file':'case-allocation-check.json'},
 'limits':['Private canonical action/effective-disposition vector only, complete:false and authority:false. evaluated may contain deny/indeterminate/conflict and is not publication permission.','Source/owner/coverage/generation are trusted host comparisons, not authenticated native authority. No native processes or full gate independently rerun.','No Cell renderer, crypto/key/vault execution, query admission, graph-aware writes, S24/S25 promotion, total core-validation/snapshot CPU or heap theorem.','Selected68-source closure is not exhaustive root-package/runtime provenance. Mutant src copies share unchanged spec/node_modules via read-only-use symlinks; no hermeticity claim.','Preliminary withheld fixture falsely claimed missing amount coverage; corrected fixture removes that declaration. Refined/default temporal sources refuse at original core closure, separately tested there. Initial mutant positive dereference error retained and corrected with optional access without changing expectation.'],
 'developmentEvidenceRetained':['runtime-initial.log','runtime-expanded.log','initial-mutation-oracle-dereference-errors.json','source-closure-append.json'],
 'repoEditsByReviewer':False,
 'artifactManifest':'artifact-manifest.json'
}
(out/'review.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'review.md').write_text('''No remaining actionable blocker was found within the private logical action/disposition kernel scope.\n\nIndependently ran1,088 controls in Bun1.4.2 and Chromium153.0.8010.12 with full result parity, no external requests, no page errors and no host globals. These comprise902 authored truth/composition vectors and186 boundary controls. The original plus12 isolated source weakenings produce exactly the intended failed rows. Independently ran26 repository tests/167 assertions and replayed9 conditional Z3 laws (5UNSAT/4SAT).\n\nThe uncharged disclosure loop was a real bounded-work defect: the retained pre-fix witness performed5,242,880 disclosure comparisons while accepting maxSteps50,000 and returning20rows. The corrected source charges each Field/rule/disclosure traversal and refuses the identical input atomically. The separate flat opaque-reference compatibility fix preserves metadata while refusing malformed/record-type semantics; it supplies no inferred relationship or authorization.\n\nAll68 selected source pins are unchanged across the final runs. The complete158-case file is byte-identical to baseline; S24/S25 remain unbound. See review.json, source-pins-after.json, all-results.json, browser-results.json and mutation-exact-discrimination.json.\n\nThis review does not qualify data rendering/publication, native authentication/authority, graph-aware writes, crypto/custody execution or total CPU/heap bounds. An evaluated vector may contain indeterminate/conflict rows. The conditional models are not implementation refinements. Native jobs and the whole acceptance gate were not independently rerun.\n''')
# Retain focused sources/results without copying unrelated spec media or dependency trees.
files=[]
for p in out.rglob('*'):
 if not p.is_file() or p.is_symlink() or p.name in ['artifact-manifest.json','review-archive.zip']:continue
 rel=p.relative_to(out)
 if rel.parts[0]=='mutants':
  variant=rel.parts[1]
  permitted=['run.ts','run.log','results.json']
  item=next((m for m in json.loads((out/'mutation-results.json').read_text())if m['variant']==variant),None)
  if str(Path(*rel.parts[2:])) not in permitted+[item['changedSource']if item and item['changedSource'] else '']:continue
 files.append(p)
manifest={'scope':'Focused independent review packet; original selected source snapshots, exact mutated source file per variant and all finite outcomes. Dependency symlinks excluded.','files':{str(p.relative_to(out)):sha(p)for p in sorted(files)}}
(out/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/'review-archive.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in files+[out/'artifact-manifest.json']:z.write(p,str(p.relative_to(out)))
print(json.dumps({'review':str(out/'review.json'),'reviewSha256':sha(out/'review.json'),'manifest':str(out/'artifact-manifest.json'),'archive':str(archive),'archiveSha256':sha(archive),'sourceCount':len(pins),'files':len(files)},indent=2))
