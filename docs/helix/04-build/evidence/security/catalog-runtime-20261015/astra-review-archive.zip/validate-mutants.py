import json
from pathlib import Path
o=Path(__file__).parent;vectors=json.loads((o/'logic-vectors.json').read_text())['rows']
expected={
'original':[],
'omit-scoped-preflight':[f'boundary/{kind}-{suffix}' for kind in ['record','opaque'] for suffix in ['graph-coverage-missing','graph-incomplete','graph-role-uncovered','endpoint-record-coverage-independent','false-branch-still-needs-graph','empty-request-still-needs-graph']]+['boundary/'+s for s in ['witness-coverage-independent','witness-field-coverage-independent','graph-witness-field-uncovered','DTO-context-missing','DTO-context-missing-in-false-branch','DTO-context-missing-empty-request']],
'omit-record-coverage-consistency':['boundary/unused-covered-record-projection-missing'],
'omit-graph-coverage-consistency':['boundary/unused-covered-graph-role-missing','boundary/unused-covered-graph-attribute-missing'],
'omit-normalized-key-uniqueness':['boundary/duplicate-fact','boundary/normalized-integer-duplicate-key'],
'reset-literal-meter-per-call':['boundary/aggregate-string-facts-refuse-all','boundary/repeated-comparisons-operation-budget-atomic'],
'omit-composition-work':['boundary/composition-work-shared-budget-atomic'],
'omit-withheld-dominance':['boundary/withheld-does-not-invent-value','boundary/withheld-wins-over-transform-conflict','boundary/withheld-dominates-catalog-conflict'],
'collapse-distinct-catalog-directives':['boundary/equal-sample-distinct-catalog-conflict'],
'ignore-mixed-unknown-rule':['truth/'+c['id'] for c in vectors if c['operator']=='decision' and 'U' in c['permit']+c['require']+c['forbid'] and any(t!='U' for t in c['permit']+c['require']+c['forbid'])],
'collapse-opaque-witness-namespaces':['boundary/opaque-ID-namespace-is-relationship'],
'allow-canonical-storage-downgrade':['boundary/storage-canonical-downgrade'],
'revert-opaque-link-domain-metadata':['boundary/flat-opaque-key-metadata-independent']}
results=json.loads((o/'mutation-results.json').read_text());assert len(results)==len(expected)
verified=[]
for r in results:
 wanted=set(expected[r['variant']]);actual=set(r['failed']);assert wanted==actual,(r['variant'],actual-wanted,wanted-actual)
 rows=json.loads((o/'mutants'/r['variant']/'results.json').read_text())['rows'];assert len(rows)==1088;assert len({x['id'] for x in rows})==len(rows)
 assert all(not x.get('error') for x in rows if x['id'] not in wanted)
 # Only source-compatibility regression is allowed to throw during compilation.
 assert all(not x.get('error') for x in rows if x['id'] in wanted and r['variant']!='revert-opaque-link-domain-metadata')
 verified.append({'variant':r['variant'],'expectedFailures':len(wanted),'exactFailedSet':True})
(o/'mutation-exact-discrimination.json').write_text(json.dumps({'status':'pass','variants':verified,'qualification':'Finite original and12 deliberate isolated source weakenings; exact named expected failed rows. No integration source edits, global necessity theorem or complete dependency isolation.'},indent=2)+'\n')
print(json.dumps(verified))
