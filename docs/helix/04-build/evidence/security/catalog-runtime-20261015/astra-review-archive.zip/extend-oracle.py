from pathlib import Path
p=Path(__file__).with_name('runtime-oracle.ts');s=p.read_text();s=s.replace("record(f,'Asset').fields=record(f,'Asset').fields.filter((x:any)=>x.field.elementId!=='amount');});\nfor(const [id,mut]", "record(f,'Asset').fields=record(f,'Asset').fields.filter((x:any)=>x.field.elementId!=='amount');coverage(f,'Asset').fields=coverage(f,'Asset').fields.filter((x:any)=>x.elementId!=='amount');});\nfor(const [id,mut]",1).replace('late-second-resource-projection-refusal-atomic','second-resource-projection-refusal-atomic')
s=s.replace('// A late required projection failure must discard the first row\'s logical output too.','// A malformed second resource must return no logical rows, including the first.')
addition=r'''
// Newly declared global coverage consistency is checked even for unused projections.
refused('unused-covered-record-projection-missing',f=>{record(f,'Person').fields.pop();});
refused('unused-covered-graph-role-missing',f=>{f.policy.rules[0].condition=truth;f.cut.graphs[0].endpoints.pop();},()=>graph(true));
refused('unused-covered-graph-attribute-missing',f=>{f.policy.rules[0].condition=truth;coverage(f,'Link').fields=coverage(f,'Link').fields.filter((r:any)=>r.elementId!=='note');record(f,'Link').fields.pop();},()=>graph());
decision('unclaimed-unused-graph-role-can-be-unprojected','permit',f=>{f.policy.rules[0].condition=truth;f.cut.graphs[0].endpoints.pop();f.cut.graphCoverage[0].roles=['person'];},()=>graph(true));
// Explicit temporal value-profile selection; ordinary scalar metadata is not calendar authority.
const dateFixture=()=>{const f=positive();definition(f,'amount').scalarType='date';record(f,'Asset').fields[1].value={date:'2000-02-29'};f.cut.valueProfiles=[{field:ref('amount'),profile:'umf-gregorian-date/1.0.0'}];return f;};
for(const text of ['0001-01-01','2000-02-29','1900-02-28','9999-12-31'])decision('date-positive-'+text,'permit',f=>record(f,'Asset').fields[1].value={date:text},dateFixture);
for(const text of ['0000-01-01','10000-01-01','1900-02-29','2025-04-31','2024-2-29','2024-02-29T00:00:00Z','２０２４-02-29'])refused('date-invalid-'+text,f=>record(f,'Asset').fields[1].value={date:text},dateFixture);
decision('date-known-null-explicit-profile','permit',f=>record(f,'Asset').fields[1].value=null,dateFixture);
refused('date-known-null-without-profile',f=>{record(f,'Asset').fields[1].value=null;f.cut.valueProfiles=[];},dateFixture);
refused('date-required-null',f=>{definition(f,'amount').nullability='required';record(f,'Asset').fields[1].value=null;},dateFixture);
for(const [id,change]of [['missing',(f:any)=>f.cut.valueProfiles=[]],['duplicate',(f:any)=>f.cut.valueProfiles.push(clone(f.cut.valueProfiles[0]))],['stale',(f:any)=>f.cut.valueProfiles[0].profile='umf-gregorian-date/2.0.0'],['wrong-field',(f:any)=>f.cut.valueProfiles[0].field=ref('asset-key')],['refined',(f:any)=>definition(f,'amount').allowedValues=[{date:'2000-02-29'}]],['defaulted',(f:any)=>definition(f,'amount').default={date:'2000-02-29'}]] as [string,(f:any)=>void][])refused('date-profile-'+id,change,dateFixture);
// Distinct catalogue identities are distinct directives even if they render the same sample value.
const catalogFixture=()=>{const f=positive();f.ontology.actionPurposes=[{action:'read',purposes:['read']}];const t=(id:string)=>({id,version:'r1',kind:'mask',function:'constant',inputDomain:ref('amount'),outputDomain:ref('dto-text','domains'),parameters:[{name:'value',field:ref('dto-text','domains'),value:{string:'same'}}],determinism:'deterministic',reversibility:'none',disclosureProfile:[],queryUse:{}});f.catalog={vocabulary:'umf.security.protection',version:'0.1.0',id:'mask-catalog',revision:'mask-r1',transforms:[t('one'),t('two')]};f.policy.protection={id:f.catalog.id,revision:f.catalog.revision};f.cut.protection=clone(f.policy.protection);f.policy.rules[0].disclosure[0].disposition={kind:'transformed',vocabulary:'umf.security.protection',transform:'one',version:'r1',field:ref('dto-text','domains')};return f;};
decision('one-catalog-directive','permit',()=>{},catalogFixture);
decision('equal-sample-distinct-catalog-conflict','conflict',f=>{const q=clone(f.policy.rules[0]);q.id='two';q.disclosure[0].disposition.transform='two';f.policy.rules.push(q);},catalogFixture);
decision('same-catalog-directive-coalesces','permit',f=>{const q=clone(f.policy.rules[0]);q.id='same';f.policy.rules.push(q);},catalogFixture);
decision('withheld-dominates-catalog-conflict','permit',f=>{const q=clone(f.policy.rules[0]);q.id='two';q.disclosure[0].disposition.transform='two';const w=clone(q);w.id='hidden';w.disclosure[0].disposition={kind:'withheld'};f.policy.rules.push(q,w);},catalogFixture);
decision('stored-custody-declaration-does-not-grant-vault','deny',f=>f.request.action='write-vault',stored);
// All input sources are detached before execution; the issued program is not substituted by later caller mutation.
test('compiled-source-custody',()=>{const f=positive(),h=compile(f.policy,f.catalog,f.closure,f.ontology);f.policy.rules[0].effect='forbid';f.ontology.subject=ref('Asset');definition(f,'amount').scalarType='string';const r=evaluate(h,f.owner,f.cut,f.request);return r.status==='evaluated'&&r.rows[0].decision==='permit';});
test('returned-directive-detached-and-frozen',()=>{const f=catalogFixture(),r=run(f);f.policy.rules[0].disclosure[0].disposition.transform='two';return (r.rows[0].dispositions[0]as any).disposition.transform==='one'&&frozen(r);});
test('source-fact-rule-order-does-not-change-meaning',()=>{const f=graph(),a=run(f);f.cut.facts.reverse();f.cut.coverage.reverse();f.owner.storage.reverse();f.policy.rules.reverse();f.cut.graphs.reverse();return JSON.stringify(run(f))===JSON.stringify(a);});
// An operation-wide literal budget spans distinct facts, not a fresh ledger per fact.
const textFixture=(n:number)=>{const f=positive();definition(f,'amount').scalarType='string';for(let i=0;i<n;i++){const r=clone(record(f,'Asset'));r.key=[{string:'a'+i}];r.fields[0].value={string:'a'+i};r.fields[1].value={string:'x'.repeat(3000)};if(i===0){f.cut.facts=f.cut.facts.filter((r:any)=>r.type.elementId!=='Asset');f.request.resources=[];}f.cut.facts.push(r);f.request.resources.push({type:ref('Asset'),key:[{string:'a'+i}]});}return f;};
test('bounded-string-fact-positive',()=>run(textFixture(1)).rows[0].decision==='permit');
test('aggregate-string-facts-refuse-all',()=>{const f=textFixture(40),r=run(f);return r.status==='refused'&&r.rows.length===0;});
// A comparison's repeated work consumes the same ledger, even when each individual value is small.
const repeatFixture=(n:number)=>{const f=positive();definition(f,'amount').scalarType='string';record(f,'Asset').fields[1].value={string:'x'.repeat(1000)};f.policy.rules[0].condition=eq(attr('resource',ref('amount')),val({string:'x'.repeat(1000)},ref('dto-text','domains')));f.request.resources=Array.from({length:n},()=>({type:ref('Asset'),key:[{string:'a1'}]}));return f;};
test('single-comparison-budget-positive',()=>run(repeatFixture(1)).rows[0].decision==='permit');
test('repeated-comparisons-operation-budget-atomic',()=>{const r=run(repeatFixture(40));return r.status==='refused'&&r.rows.length===0;});
'''
assert 'return rows;}' in s;s=s.replace('return rows;}',addition+'\nreturn rows;}');p.write_text(s)
