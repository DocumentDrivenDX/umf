from pathlib import Path
p=Path(__file__).with_name('runtime-oracle.ts');s=p.read_text();s=s.replace("import{fixture,run}from './truth-oracle';","import{fixture,run}from './truth-oracle';\nimport{makeCompositionFixture}from './composition-budget-witness';")
extra=r'''
test('composition-work-shared-budget-atomic',()=>{const f=makeCompositionFixture(),r=run(f);return r.status==='refused'&&r.rows.length===0;});
for(const graphMode of [false,true]){
 const factory=()=>graphMode?graph():positive();
 decision((graphMode?'graph':'flat')+'-opaque-key-metadata-independent','permit',f=>{definition(f,'person-key').references=[{role:'related',module:'entities',element:'Asset'}];definition(f,'link-person').references=[{role:'different-opaque-role',module:'entities',element:'Link'}];},factory);
 for(const [name,reference]of [['record-valued',{role:'record-type',module:'entities',element:'Asset'}],['missing-role',{module:'entities',element:'Asset'}],['unknown-member',{role:'related',module:'entities',element:'Asset',meaning:'unqualified'}],['empty-role',{role:'',module:'entities',element:'Asset'}],['foreign-element',{role:'related',module:'entities',element:'Missing'}]]as [string,any][])test((graphMode?'graph':'flat')+'-key-reference-'+name+'-source-refusal',()=>{const f=factory();definition(f,'person-key').references=[reference];try{compile(f.policy,f.catalog,f.closure,f.ontology);return false;}catch{return true;}});
}
// A nullable DTO context is not an entity-owned Field and must still be explicitly supplied.
const contextFixture=()=>{const f=positive();f.ontology.context=[ref('dto-text','domains')];f.cut.context=[{field:ref('dto-text','domains'),value:null}];f.policy.rules[0].condition=eq({kind:'context',field:ref('dto-text','domains')},val(null,ref('dto-text','domains')));return f;};
decision('DTO-context-known-null','permit',()=>{},contextFixture);
decision('DTO-context-known-different','deny',f=>f.cut.context[0].value={string:'different'},contextFixture);
refused('DTO-context-missing',f=>f.cut.context=[],contextFixture);
refused('DTO-context-missing-in-false-branch',f=>{f.cut.context=[];f.policy.rules[0].condition={op:'and',args:[{op:'literal',value:false},f.policy.rules[0].condition]};},contextFixture);
refused('DTO-context-missing-empty-request',f=>{f.cut.context=[];f.request.resources=[];},contextFixture);
refused('DTO-context-duplicate',f=>f.cut.context.push(clone(f.cut.context[0])),contextFixture);
refused('DTO-context-wrong-literal',f=>f.cut.context[0].value={integerToken:'1'},contextFixture);
// Equal primitive values under different logical Record types never identify the same entity.
test('typed-identity-separates-same-lexeme',()=>{const f=positive();record(f,'Person').key=[{string:'same'}];record(f,'Person').fields[0].value={string:'same'};f.cut.subject.key=[{string:'same'}];record(f,'Asset').key=[{string:'same'}];record(f,'Asset').fields[0].value={string:'same'};f.request.resources[0].key=[{string:'same'}];return run(f).rows[0].decision==='permit';});
// Ordered compound Key values remain positional through original tuple encoding.
const compoundFixture=()=>{const f=positive();f.ontology.associations=[];const elements=f.closure.documents[0].document.modules[0].elements;for(const name of ['second-key'])elements.push({id:name,kind:'field',scalarType:'string',cardinality:'one',nullability:'required',extensions:{}});const r=definition(f,'Asset');r.members.push({module:'entities',element:'second-key'});r.keys[0].fields.push({module:'entities',element:'second-key'});f.ontology.entities.find((e:any)=>e.type.elementId==='Asset').fields.push({ref:ref('second-key'),protection:'unprotected'});f.owner.storage.push({type:ref('Asset'),field:ref('second-key'),storageEffect:'canonical'});record(f,'Asset').key=[{string:'left'},{string:'right'}];record(f,'Asset').fields[0].value={string:'left'};record(f,'Asset').fields.push({field:ref('second-key'),value:{string:'right'}});coverage(f,'Asset').fields.push(ref('second-key'));f.request.resources[0].key=[{string:'left'},{string:'right'}];return f;};
decision('ordered-compound-key-positive','permit',()=>{},compoundFixture);
refused('ordered-compound-key-swapped',f=>f.request.resources[0].key.reverse(),compoundFixture);
refused('ordered-compound-key-arity',f=>f.request.resources[0].key.pop(),compoundFixture);
refused('ordered-compound-key-projection-conflict',f=>record(f,'Asset').fields.at(-1).value={string:'left'},compoundFixture);
'''
s=s.replace('return rows;}',extra+'\nreturn rows;}');p.write_text(s)
