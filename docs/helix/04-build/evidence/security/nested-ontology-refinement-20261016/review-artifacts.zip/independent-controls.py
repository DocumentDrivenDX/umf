import sys,runpy,json,hashlib,itertools,zipfile
from pathlib import Path
import z3
R=Path(__file__).parent;FROZEN=R/'frozen';source=FROZEN/'prove-nested-ontology-refinement.py'
sys.argv=[str(source),'--output',str(R/'imported-exact-source-replay.json')]
n=runpy.run_path(str(source))
checks=[];models=[]
def assert_check(name,condition):
 checks.append({'id':name,'passed':bool(condition)})
 if not condition:raise AssertionError(name)
def solve(name,conditions,expected):
 s=z3.Solver();s.set(timeout=10000);s.add(*conditions);smt=s.sexpr();result=str(s.check());assert_check(name,result==expected)
 models.append({'id':name,'smt':smt,'expected':expected,'result':result,'model':str(s.model())if result=='sat'else None})
 return result
manifest=json.loads((FROZEN/'manifest.json').read_text())
for name,p in manifest['files'].items():
 b=(FROZEN/name).read_bytes();assert_check('archive-pin:'+name,hashlib.sha256(b).hexdigest()==p['sha256']and len(b)==p['bytes'])
actual=Path('/Users/erik/.codex/worktrees/security-main-integration/umf/tools/security/prove-nested-ontology-refinement.py');assert_check('repository-copy-identical',actual.read_bytes()==source.read_bytes())
supplied=json.loads((FROZEN/'umf-nested-ontology-refinement-r3-20261016.json').read_text());replay=json.loads((R/'replay.json').read_text())
assert_check('z3-version',z3.get_version_string()==supplied['solverVersion']=='4.15.4')
assert_check('source-receipt-pin',supplied['sourceSha256']==hashlib.sha256(source.read_bytes()).hexdigest())
assert_check('18-distinct-queries',len(supplied['queries'])==len({q['id']for q in supplied['queries']})==18)
assert_check('query-partition',sum(q['result']=='unsat'for q in supplied['queries'])==5 and sum(q['result']=='sat'for q in supplied['queries'])==13)
assert_check('replayed-identical-queries',[(q['id'],q['smt'],q['result'])for q in supplied['queries']]==[(q['id'],q['smt'],q['result'])for q in replay['queries']])
for q in supplied['queries']:
 s=z3.Solver();s.set(timeout=10000);s.from_string(q['smt']);assert_check('retained-SMT:'+q['id'],str(s.check())==q['result'])
for k in ['Identity','Witness','Rel','SA','AP','OR','OP','STAFF','PROJECT','ASSIGNMENT','OWNERSHIP','RESOURCE','recordKind','F','U','T','memberL','memberN','srcL','dstL','srcN','dstN','activeL','activeN','r','e','staff','resource','s','o','p','q','L','N','premises','base','complete','endpoints','attributes','neg','empty']:
 globals()[k]=n[k]
# SAT-check the exact premise of each UNSAT query separately from its violation.
for name,prem in [('truth',premises),('negation',premises),('empty',premises+[empty]),('unknown',premises+[L==U]),('false',premises+[L==F])]:solve('nonvacuity:'+name,prem,'sat')
# Strengthen omitted-premise countermodels with well-typed native endpoints too.
typedN=z3.ForAll([r,e],z3.Implies(memberN(r,e),z3.And(*[z3.Implies(r==rel,z3.And(recordKind(srcN(r,e))==sk,recordKind(dstN(r,e))==dk)) for rel,sk,dk in [(SA,STAFF,ASSIGNMENT),(AP,ASSIGNMENT,PROJECT),(OR,OWNERSHIP,RESOURCE),(OP,OWNERSHIP,PROJECT)]])))
for name,ps in [('incidence',[*base,typedN,endpoints,attributes,L==T,N==F]),('endpoint',[*base,typedN,complete,attributes,L!=N]),('attribute',[*base,typedN,complete,endpoints,L!=N])]:solve('typed-omission:'+name,ps,'sat')
sound=z3.ForAll([r,e],z3.Implies(memberN(r,e),memberL(r,e)));complete_only=z3.ForAll([r,e],z3.Implies(memberL(r,e),memberN(r,e)))
solve('missing-only-completeness-false-permit-under-negation',[*base,typedN,sound,endpoints,attributes,L==T,N==F,neg(N)==T],'sat')
solve('missing-only-soundness-false-permit',[*base,typedN,complete_only,endpoints,attributes,L==F,N==T],'sat')
# Independent removal of each correlation/selection anchor, keeping typed complete inputs.
anchors=[srcN(SA,s)==staff,dstN(SA,s)==srcN(AP,o),dstN(AP,o)==dstN(OP,q),srcN(OR,p)==srcN(OP,q),dstN(OR,p)==resource]
for i,label in enumerate(['selected-subject','same-assignment','same-project','same-owner','selected-resource']):
 mutant=z3.Exists([s,o,p,q],z3.And(memberN(SA,s),memberN(AP,o),memberN(OR,p),memberN(OP,q),*[x for j,x in enumerate(anchors)if j!=i],activeN(dstN(SA,s))==T))
 solve('removed-anchor:'+label,premises+[typedN,mutant,L!=T],'sat')
# Unknown is an observed activity truth, not incomplete membership; strong negation preserves it.
solve('complete-unknown-remains-unknown-under-negation',premises+[L==U,neg(L)!=U],'unsat')
allFalse=z3.ForAll(n['a'],activeL(n['a'])==F);allUnknown=z3.ForAll(n['a'],activeL(n['a'])==U)
joined=z3.And(memberL(SA,s),memberL(AP,o),memberL(OR,p),memberL(OP,q),srcL(SA,s)==staff,dstL(SA,s)==srcL(AP,o),dstL(AP,o)==dstL(OP,q),srcL(OR,p)==srcL(OP,q),dstL(OR,p)==resource)
hasPath=z3.Exists([s,o,p,q],joined)
solve('inhabited-all-inactive-nonvacuous',premises+[hasPath,allFalse,L==F,N==F],'sat')
solve('inhabited-all-inactive-cannot-permit',premises+[hasPath,allFalse,z3.Or(L==T,N==T)],'unsat')
solve('inhabited-all-unknown-nonvacuous',premises+[hasPath,allUnknown,L==U,N==U],'sat')
solve('inhabited-all-unknown-cannot-permit',premises+[hasPath,allUnknown,z3.Or(L==T,N==T)],'unsat')
# The advertised mutable error controls are independently false permits with valid typed populations.
solve('typed-split-owner',premises+[typedN,n['weakened'](split_owner=True),L!=T],'sat')
solve('typed-unrelated-active-assignment',premises+[typedN,n['weakened'](split_attribute=True),L!=T],'sat')
# Separate finite exhaustive nested-vs-flat three-valued construction (not implementation proof).
def And(a,b):return 'F'if'F'in(a,b)else'U'if'U'in(a,b)else'T'
def Exists(xs):return'T'if'T'in xs else'U'if'U'in xs else'F'
finite=0
for mask in itertools.product([False,True],repeat=8):
 sa,ap,orr,op=[mask[i:i+2]for i in range(0,8,2)]
 for activity in itertools.product('FUT',repeat=2):
  nested=Exists([And(activity[a],Exists(['T' for owner in range(2)if orr[owner]and op[owner]]))for a in range(2)if sa[a]and ap[a]])
  flat=Exists([activity[a]for a in range(2)for owner in range(2)if sa[a]and ap[a]and orr[owner]and op[owner]])
  if nested!=flat:raise AssertionError((mask,activity,nested,flat))
  finite+=1
assert_check('finite-nested-flat-2304',finite==2304)
(R/'independent-controls.json').write_text(json.dumps({'status':'passed','checks':checks,'count':len(checks),'additionalSolverQueries':len(models),'solverVersion':z3.get_version_string(),'solverQueries':models,'finiteExhaustiveCases':finite,'scope':'Independent exact source/SMT replay plus extra nonvacuity and typed adverse models. Finite nested/flat check is a separate abstract control, not TypeScript/Python/SQL or codec refinement. No native database execution.'},indent=2)+'\n')
print(json.dumps({'status':'passed','checks':len(checks),'additionalSolverQueries':len(models),'finiteCases':finite}))
