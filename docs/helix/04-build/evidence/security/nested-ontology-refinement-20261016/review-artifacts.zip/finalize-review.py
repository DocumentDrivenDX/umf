from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).parent
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
def pin(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
paths=['tools/security/prove-nested-ontology-refinement.py','docs/helix/02-design/technical-designs/TD-056-security-bindings.md','docs/helix/03-test/test-plans/STP-056-security-bindings.md']
assert (root/paths[0]).read_bytes()==(r/'frozen/prove-nested-ontology-refinement.py').read_bytes()
(r/'governance.diff').write_bytes(subprocess.check_output(['git','diff','--',*paths],cwd=root))
(r/'closing-source-pins.json').write_text(json.dumps({n:pin(root/n)for n in paths},indent=2)+'\n')
report={
 'review':'Conditional nested ontology truth correspondence R3',
 'reviewer':'Independent retained Astra Ultra reviewer',
 'status':'passed-with-conditional-formal-scope','remainingFindings':[],
 'packet':{'path':'review.zip',**pin(r/'review.zip')},
 'source':{'path':'frozen/prove-nested-ontology-refinement.py',**pin(r/'frozen/prove-nested-ontology-refinement.py')},
 'suppliedReceipt':{'path':'frozen/umf-nested-ontology-refinement-r3-20261016.json',**pin(r/'frozen/umf-nested-ontology-refinement-r3-20261016.json')},
 'conclusion':'The five UNSAT claims are valid conditional statements of the encoded unbounded first-order model. All theorem premise sets are independently satisfiable. No actionable source or appended-document scope defect found.',
 'executions':[
  {'command':'/private/tmp/umf-security-proof-current-20261015/bin/python frozen/prove-nested-ontology-refinement.py --output replay.json','result':'18 queries passed: 5 UNSAT and 13 SAT; Z3 4.15.4; exact supplied SMT/result pairs reproduced','receipt':'replay.json','log':'replay.log'},
  {'command':'/private/tmp/umf-security-proof-current-20261015/bin/python independent-controls.py','result':'56 checks passed, including 22 additional solver queries and 2304 exhaustive finite nested-versus-flat truth cases','receipt':'independent-controls.json','log':'independent-controls.log'}
 ],
 'independentAdversaries':[
  'SAT-check each of the five theorem premise sets independently, including empty, U and F cases.',
  'Retain native endpoint typing in omitted incidence, endpoint and activity correspondence counterexamples; all remain SAT.',
  'Separate soundness from completeness: missing completeness permits a false negated result; missing soundness permits an extra positive result.',
  'Remove selected subject, same Assignment, same Project, same Ownership, and selected Resource anchors individually; each admits a false-permit countermodel while complete typed populations remain assumed.',
  'Require an actual joined path with all assignment activity F or all U; populated premises are SAT and permit violations UNSAT. Unknown stays U under strong negation.',
  'Independently confirm split-owner and unrelated-active-assignment countermodels with typed native endpoints.',
  'Separately enumerate 2304 finite two-Assignment/two-Ownership populations with all F/U/T activity combinations; nested existential/AND composition equals the flat path truth expression.'
 ],
 'semanticAssessment':[
  'The model preserves same-Assignment, same-Ownership and same-Project correlations and selected Staff/Resource identity. T dominates U across witnesses; U dominates F; empty membership is F. Strong negation preserves U.',
  'Complete sound incidence and exact projected endpoint/activity equality are assumptions, not established native properties. Complete qualified identity is an abstract sort; codecs, key injectivity and physical identity projection are not proved.',
  'The unknown-as-true SAT control is an altered permit predicate. The early-U SAT control demonstrates wrong U priority, not an ordered traversal or concrete implementation mutation. The false-result theorem covers F generally; the reviewer additionally checked inhabited all-inactive populations.',
  'Observed U within complete admitted facts is distinct from missing coverage. The latter must be refused by implementation preflight and is outside this proof.'
 ],
 'governance':{'report':'docs-review/report.json','result':'Exact appended TD-056/STP-056 sections accurately state typed identity/incidence premises, 18-query partition and conditional scope. Final exact source/doc pins are in closing-source-pins.json.'},
 'scopeLimits':[
  'No Python/TypeScript/SQL translation refinement, collector correctness, codec equivalence, native binding, source/caller/current authority, limits/termination, occurrence multiplicity or guarded release is proved.',
  'No native SQL executed. No backend case promotion; original required acceptance allocations remain open.',
  'Z3 and Python are external pinned-version runtime dependencies, not a hermetic proof chain. Source hashes establish reviewed bytes and endpoint correspondence, not continuously held files or ABA exclusion.',
  'R1/R2 development source/receipts/logs remain unchanged in the original frozen packet; R3 alone is the reviewed final model.'
 ],
 'artifactManifest':{'path':'manifest.json','format':'relative path -> {sha256, bytes}; includes every retained file except this top-level manifest'}
}
(r/'review.json').write_text(json.dumps(report,indent=2)+'\n')
files={p.relative_to(r).as_posix():pin(p) for p in sorted(r.rglob('*'))if p.is_file()and p!=r/'manifest.json'and'__pycache__'not in p.parts}
(r/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
for n,v in files.items():assert pin(r/n)==v,n
print(json.dumps({'review':pin(r/'review.json'),'manifest':pin(r/'manifest.json'),'artifacts':len(files),'totalBytes':sum(v['bytes']for v in files.values())},indent=2))
