from pathlib import Path
import sys,copy,json,importlib.util,hashlib
root=Path(sys.argv[1]);receipt=Path(sys.argv[2]);output=Path(sys.argv[3]);sys.dont_write_bytecode=True
path=root/'tests/security/native/pg18-mask-write-oracle.py';s=importlib.util.spec_from_file_location('oracle',path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
a=json.loads(receipt.read_text())['authored'];rows=[]
def check(name,v,want):
 got=m.admit_sources(v);rows.append({'id':name,'expectedAccepted':want,'observedAccepted':got,'passed':got==want})
check('exact-supported-source',a,True)
check('object-member-order-insensitive',json.loads(json.dumps(a,sort_keys=True)),True)
variants=[
 ('legacy-mask-literal',lambda x:x['policy']['rules'][1]['disclosure'][0]['disposition']['value'].update(integerToken='1')),
 ('canonical-mask-literal',lambda x:x['canonicalPolicy']['rules'][1]['disclosure'][0]['disposition']['value'].update(integerToken='1')),
 ('legacy-withhold-to-original',lambda x:x['policy']['rules'][2]['disclosure'][0].update(disposition={'kind':'original'})),
 ('canonical-withhold-to-original',lambda x:x['canonicalPolicy']['rules'][2]['disclosure'][0].update(disposition={'kind':'original'})),
 ('both-mask-minus-zero',lambda x:[x[k]['rules'][1]['disclosure'][0]['disposition']['value'].update(integerToken='-0') for k in ['policy','canonicalPolicy']]),
 ('extra-unused-rule',lambda x:x['canonicalPolicy']['rules'].append({'id':'extra','effect':'permit','actions':['read'],'target':x['canonicalPolicy']['rules'][0]['target'],'condition':{'op':'literal','value':False}})),
 ('legacy-blind-wrong-field',lambda x:x['profile']['readProtection']['blindWriteActions'][0]['field'].update(elementId='resourceId')),
 ('canonical-blind-wrong-field',lambda x:x['currentProfile']['types'][0]['readProtection']['blindWriteActions'][0]['field'].update(elementId='resourceId')),
 ('legacy-no-blind-declaration',lambda x:x['profile']['readProtection'].update(blindWriteActions=[])),
 ('canonical-no-blind-declaration',lambda x:x['currentProfile']['types'][0]['readProtection'].update(blindWriteActions=[])),
 ('ordinary-action-alias',lambda x:x['profile'].update(updateAction='read')),
 ('ordinary-field-action-alias',lambda x:x['profile']['fieldActions'][1].update(action='blindAmount')),
 ('current-authority-alias',lambda x:x['canonicalOntology']['actionPurposes'][-1].update(purposes=['read'])),
 ('legacy-policy-pin',lambda x:x['policy'].update(revision='stale')),
 ('canonical-policy-pin',lambda x:x['canonicalPolicy'].update(revision='stale')),
 ('owner-pin',lambda x:x['owner'].update(revision='stale')),
 ('core-closure-pin',lambda x:x['closure']['pins'][0].update(revision='stale')),
 ('legacy-nullability',lambda x:next(f for f in x['resolution']['documents'][0]['document']['modules'][0]['elements'] if f['id']=='amount').update(nullability='required')),
 ('canonical-domain-width',lambda x:next(f for f in x['closure']['documents'][0]['document']['modules'][0]['elements'] if f['id']=='amount')['facets']['integerWidth'].update(bits=32)),
 ('typed-boolean-one',lambda x:x['canonicalPolicy']['rules'][3]['condition']['right'].update(value={'boolean':1})),
 ('unexpected-source-member',lambda x:x.update(future={'permit':True})),
]
for name,mutate in variants:
 b=copy.deepcopy(a);mutate(b);check(name,b,False)
output.write_text(json.dumps({'oracleSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'parentReceipt':str(receipt),'rows':rows},indent=2)+'\n');print(json.dumps({'total':len(rows),'passed':sum(r['passed'] for r in rows)}));assert all(r['passed'] for r in rows)
