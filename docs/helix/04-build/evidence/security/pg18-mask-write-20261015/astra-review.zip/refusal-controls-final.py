import ast,json,re,sys,hashlib
from pathlib import Path
from types import SimpleNamespace
source=Path(sys.argv[1]);target=Path(sys.argv[2]);parsed=ast.parse(source.read_text());definition=next(x for x in parsed.body if isinstance(x,ast.FunctionDef) and x.name=='classify_refusal')
code=compile(ast.Module(body=[definition],type_ignores=[]),str(source),'exec');ns={'re':re};exec(code,ns)
base='ERROR:  42501: Write authorization refused\nCONTEXT: PL/pgSQL function security_mask_write.assign_amount(text,bigint) line 24 at RAISE\nLOCATION: exec_stmt_raise, pl_exec.c:3911\n'
cases=[('valid',3,'',base,True),('exit0',0,'',base,False),('exit2',2,'',base,False),('data',3,'100\n',base,False),('whitespace',3,'\n',base,False),('wrong-state',3,'',base.replace('42501','23505'),False),('missing-error',3,'','',False),('duplicate-error',3,'',base+base,False),('fatal-after',3,'',base+'FATAL:  57P01: terminating connection\n',False),('panic-before',3,'','PANIC:  XX000: fault\n'+base,False),('notice-preimage',3,'','NOTICE:  00000: old amount100\n'+base,False),('warning-preimage',3,'','WARNING:  01000: old amount100\n'+base,False),('detail-preimage',3,'',base.replace('CONTEXT:','DETAIL: old amount100\nCONTEXT:'),False),('hint-preimage',3,'',base.replace('CONTEXT:','HINT: old amount100\nCONTEXT:'),False),('wrong-primary',3,'',base.replace('Write authorization refused','Hidden value100'),False),('oversized',3,'',base+'x'*8193,False)]
rows=[]
for name,exit_code,stdout,stderr,expected in cases:
 try:ns['classify_refusal'](SimpleNamespace(returncode=exit_code,stdout=stdout,stderr=stderr),'42501','Write authorization refused');actual=True;error=None
 except AssertionError as e:actual=False;error=repr(e)[:9000]
 except Exception as e:raise RuntimeError('Control setup error '+name) from e
 rows.append({'id':name,'expectedAccepted':expected,'observedAccepted':actual,'passed':actual==expected,'error':error})
target.write_text(json.dumps({'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'rows':rows},indent=2)+'\n');print(json.dumps({'total':len(rows),'passed':sum(x['passed'] for x in rows)}));assert all(x['passed'] for x in rows)
