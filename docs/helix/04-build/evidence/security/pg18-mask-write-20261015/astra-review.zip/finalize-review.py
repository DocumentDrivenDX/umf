from pathlib import Path
import json,hashlib,shutil,zipfile,datetime,subprocess
p=Path(__file__).parent;root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda f:json.loads((p/f).read_text())
for filename in ['pg18-mask-write-before-pg18-notnull-fix.py','pg18-mask-write-before-bigint-fix.py','pg18-mask-write-initial-runner.py','pg18-mask-write-first-logical-fixed-20261015.json','pg18-mask-write-first-logical-20261015.json']:
 src=Path('/private/tmp')/filename
 if src.exists():d=p/'historical-parent'/filename;d.parent.mkdir(exist_ok=True);shutil.copy2(src,d)
docs=['docs/helix/03-test/security/cases.json','docs/helix/03-test/security/pg-raw.md','docs/helix/03-test/test-plans/STP-056-security-bindings.md','docs/helix/02-design/technical-designs/TD-056-security-bindings.md','docs/helix/02-design/spikes/security/acceptance.ts','tools/security/prove-native-write-intent.py']
docpins={}
for rel in docs:
 f=root/rel;docpins[rel]=sha(f.read_bytes());d=p/'governing'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,d)
(p/'governing-pins.json').write_text(json.dumps(docpins,indent=2)+'\n')
native=read('native-final.json');historical=read('native-790.json');pins=read('source-final-pins.json');governed=read('governed-source-pins.json');mut=read('mutations/results.json');formal=read('formal-replay/receipt.json');binding=read('binding-review.json');assert native['sourceDigests']==pins;assert all(sha((root/k).read_bytes())==v for k,v in governed.items());assert all(x['detected'] and all(x['cleanup']['cleanup'].values()) for x in mut)
review={
 'status':'no-remaining-blocker-in-reviewed-fixed-component','reviewer':'Astra independent review subagent','createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authoritativeRoot':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'acceptanceReceipt':False,'casesPromoted':[],
 'qualification':'Eligible for fresh execution of the unchanged original pg-raw.P04 assertion under its original 60s deadline. This review is not that acceptance receipt; parent full gate is running separately.',
 'findings':[],
 'resolvedFindings':[
  'Actual per-vector native Resource before images now feed both logical guards, and correspondence is rechecked immediately before the native command.',
  'Post-write disclosed view comparisons now cover all 72 native vectors, including blind writes, NULL and int64 extremes.',
  'Six malformed error-channel outcomes accepted by the initial classifier now refuse; generic primary/SQLSTATE/exit/empty stdout and success stderr are checked.',
  'All nine ordinary identities have effective table/column/sequence and privileged role reachability comparisons; the UPDATE-only RETURNING control is nonvacuous.',
  'Same-session masked and withheld guesses include NULL; missing-target, NULL-key, missing-enrollment, revoked-blind and unsupported-context phases retain full Staff/Resource/effects witnesses.',
  'Native selected columns, PG18 NOT NULL constraint kinds, owner policy, no user triggers, owner flags, owners, FORCE RLS/barrier options and exact routine source are explicitly compared.'
 ],
 'independentEvidence':{
  'finalNative':{'file':'native-final.json','sha256':sha((p/'native-final.json').read_bytes()),'observations':len(native['observations']),'runnerSeconds':native['elapsedSeconds'],'wholeProcessFilesystemIntervalSeconds':(p/'native-final.json').stat().st_mtime-(p/'native-final.log').stat().st_birthtime,'intervalQualification':'Observed log creation to receipt write, not an externally enforced timeout; governed gate enforces original 60s.','cleanup':native['nativeInventory']['cleanup'],'repoSourceFiles':len(pins),'selectedRuntimeFiles':len(native['runtimeSourceDigests']),'image':native['nativeInventory']['image']},
  'historicalIndependentNative':{'file':'native-790.json','observations':len(historical['observations']),'runnerSeconds':historical['elapsedSeconds'],'qualification':'Exact earlier 790 runner, retained separately; final SQL/declarations/oracle unchanged, final runner adds controls.'},
  'diagnosticControls':{'file':'refusal-controls-final.json','total':16,'passed':16,'historicalMalformedSurvivors':6},
  'sourceControls':{'file':'source-controls-final.json','total':23,'passed':23,'positive':2,'negative':21,'scope':'Closed authored source equality; not authenticated source issuance.'},
  'nativeWeakenings':{'file':'mutations/results.json','total':5,'detected':5,'ids':[x['id'] for x in mut],'cleanupVerified':True,'scope':'Actual SQL mutations executed using the isolated 790 runner plus a review-only failure-cleanup receipt hook. Final SQL/declarations/oracle and the per-vector checks detecting these mutations are unchanged. These were not rerun under the later 806 runner; exact snapshots and patches are retained.'},
  'formal':{'file':'formal-replay/receipt.json','queries':7,'unsat':5,'sat':2,'solver':formal['solver'],'scope':formal['scope']},
  'binding':{'file':'binding-review.json','checks':13,'passed':13,'framedObservations':807,'framedStdoutBytes':binding['stdoutBytes'],'scope':'Exact applied patch and case metadata comparison; receipt-tail framing uses retained component results only. No synthetic acceptance receipt retained.'}
 },
 'sourcePins':{'component':'source-final-pins.json','governed':'governed-source-pins.json','governing':'governing-pins.json'},
 'limits':[
  'Fixed PostgreSQL 18.6 source-bound nullable int64 Resource.amount profile and selected subject-only literal/equality rules; not general policy-to-SQL compilation, catalog transform/provider support, graph/Delta support or whole-backend admission.',
  'Logical changed-Field no-op semantics remain distinct from native explicit assignment intent. Native authorization precedes hidden lookup/equality and returns only acknowledgment; no exact no-op parity claim.',
  'Trusted fresh excluded installer, source custody, namespace/role/DDL configuration and selected runtime files remain premises. No continuous authority/revocation, protected manifest, arbitrary DML/trigger, timing or complete deployment-route proof.',
  'Finite NULL and NULL-key tests are distinct from the conditional mathematical-integer model; no embedded-NUL/general native string codec claim.',
  'Native malformed diagnostics and effects checks cover the selected fixed routine and channels; no universal SQL error-channel or kernel refinement theorem.',
  'Historical setup failures, initial classifier survivors and development receipts are retained; they are not final-source passes. Parent gate result and later documentation updates require their own exact receipts.'
 ]
}
(p/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(p/'review.md').write_text('''# Independent P04 component review\n\nNo remaining blocker in the reviewed fixed PostgreSQL 18.6 assignment-intent component. The final isolated native replay passed **806 observations** with exact source/runtime pins and verified container/volume cleanup. The unchanged original P04 assertion/covers/60s deadline is eligible for fresh governed execution; this packet does not itself promote a case.\n\nIndependent evidence: 16 diagnostic controls, 23 closed-source controls, five actual SQL weakening detections with cleanup, and seven conditional Z3 queries (5 UNSAT/2 SAT). The five SQL weakenings used the retained 790-runner snapshot; final SQL and the detecting per-vector checks are unchanged. The final 806 runner was independently replayed separately. Thirteen binding/framing checks preserve the other 157 cases and all original P04 requirements; compact adapted output is 514,105 bytes.\n\nThe fixed native endpoint checks every explicit assignment before hidden equality. Existing logical no-op semantics remain distinct. General compiler/provider support, native source/authority lifetime, timing, graph/Delta, and whole-backend qualification remain open. Formal evidence is conditional, not SQL refinement. See review.json for exact limits, source pins, historical failures, and replay provenance.\n''')
# Include reproducible inputs/results and focused mutation files, never node_modules or full mutant copies.
selected=[]
for f in sorted(p.rglob('*')):
 if not f.is_file() or f.is_symlink():continue
 rel=f.relative_to(p);parts=rel.parts
 if 'node_modules' in parts or '__pycache__' in parts:continue
 if parts[0]=='mutations' and 'source' in parts:continue
 if parts[0]=='binding-reconstruction':continue
 if parts[0]=='source-800' and str(rel)!='source-800/tests/security/native/pg18-mask-write.py':continue
 if f.name in ['archive-manifest.json','archive.json']:continue
 selected.append(f)
manifest={str(f.relative_to(p)):{'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size} for f in selected};(p/'archive-manifest.json').write_text(json.dumps({'format':'selected-evidence-files/1','files':manifest,'excluded':['node_modules','full mutant source copies','binding reconstruction copies','redundant source-800 closure']},indent=2)+'\n');selected.append(p/'archive-manifest.json')
archive=p.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in selected:z.write(f,str(f.relative_to(p)))
result={'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(selected),'review':str(p/'review.json'),'reviewSha256':sha((p/'review.json').read_bytes())};(p/'archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
