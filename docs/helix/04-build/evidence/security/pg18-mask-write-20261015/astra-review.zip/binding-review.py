from pathlib import Path
import json,hashlib,subprocess,shutil,io,contextlib,difflib
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent;rp=Path('tests/security/native/pg18-mask-write.py');cp=Path('docs/helix/03-test/security/cases.json');caseid='pg-raw.P04';rows=[]
def check(name,expected,actual):
 rows.append(dict(id=name,expected=expected,observed=actual,passed=expected==actual));assert expected==actual,name
baseline=json.loads(subprocess.check_output(['git','show','HEAD:'+str(cp)],cwd=root,text=True));current=json.loads((root/cp).read_text());old={c['id']:c for c in baseline['cases']};new={c['id']:c for c in current['cases']}
check('required-case-count',158,len(new));check('case-id-order',[c['id'] for c in baseline['cases']],[c['id'] for c in current['cases']]);check('other-157-exact',True,all(old[k]==new[k] for k in old if k!=caseid))
mutable={'status','command','evidence','testSource','oracleSource','implementationSources'}
check('original-P04-semantics-and-timeout-exact',{k:v for k,v in old[caseid].items() if k not in mutable},{k:v for k,v in new[caseid].items() if k not in mutable})
work=out/'binding-reconstruction';(work/rp).parent.mkdir(parents=True,exist_ok=True);(work/cp).parent.mkdir(parents=True,exist_ok=True);(work/rp).write_bytes((out/'source-final'/rp).read_bytes());(work/cp).write_text(json.dumps(baseline,indent=2)+'\n')
patch=Path('/private/tmp/bind-mask-write-case.py');shutil.copy2(patch,out/'bind-mask-write-case.py');subprocess.run(['python3',str(patch)],cwd=work,check=True)
check('applied-runner-exact-proposed-patch',True,(work/rp).read_bytes()==(root/rp).read_bytes());check('applied-cases-exact-proposed-patch',True,(work/cp).read_bytes()==(root/cp).read_bytes())
sourcepins=json.loads((out/'source-final-pins.json').read_text());currentpins={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sourcepins};check('only-runner-source-changed',[str(rp)],[p for p in sourcepins if sourcepins[p]!=currentpins[p]])
check('exact-source-binding-set',sorted(currentpins),sorted([new[caseid]['testSource'],new[caseid]['oracleSource'],*new[caseid]['implementationSources']]))
source=(root/rp).read_text();tail=source[source.index("receipt.update(id=CASE,"):]
canonical=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode();sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads((out/'native-final.json').read_text());obs=receipt['observations'];
for x in obs:x.update(assertionId=caseid+':'+x['id'],expected=json.loads(canonical(x['expected'])),observed=json.loads(canonical(x['observed'])))
ns={'receipt':receipt,'observations':obs,'CASE':caseid,'sha':sha,'canonical':canonical,'spike':False,'output':out/'framing-only.json','json':json}
stdout=io.StringIO()
with contextlib.redirect_stdout(stdout):exec(compile(tail,'reviewed-governed-tail','exec'),ns)
framed=json.loads(stdout.getvalue());check('complete-806-plus-case-assertion',807,len(framed['observations']));check('exact-observation-parity',True,all(json.dumps(x['expected'])==json.dumps(x['observed']) for x in framed['observations']));check('compact-stdout-below-1MiB',True,len(stdout.getvalue().encode())<1048576);check('ordinary-actor-count',9,len(framed['nativeInventory']['ordinaryActor']));check('selected-native-objects-present',True,len(framed['nativeInventory']['objects'])>0)
# This tail exercise is NOT a fresh native/governed acceptance receipt.
(out/'framing-only.json').unlink();(out/'governed-source-pins.json').write_text(json.dumps(currentpins,indent=2)+'\n');(out/'governed-runner.py').write_bytes((root/rp).read_bytes());(out/'governed-P04-case.json').write_text(json.dumps(new[caseid],indent=2)+'\n');(out/'component-to-governed.patch').write_text(''.join(difflib.unified_diff((out/'source-final'/rp).read_text().splitlines(True),source.splitlines(True),fromfile='component/pg18-mask-write.py',tofile='governed/pg18-mask-write.py')))
result={'status':'passed','acceptanceReceipt':False,'nativeRerun':False,'note':'Exact adoption/metadata comparison plus receipt-tail framing on retained independent component output; no synthetic acceptance receipt retained. Fresh governed native gate remains separate.','rows':rows,'stdoutBytes':len(stdout.getvalue().encode()),'sourcePins':currentpins,'casePlanSha256':sha((root/cp).read_bytes()),'gateSha256':sha((root/'docs/helix/02-design/spikes/security/acceptance.ts').read_bytes())};(out/'binding-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':len(rows),'passed':sum(x['passed'] for x in rows),'stdoutBytes':result['stdoutBytes']}))
