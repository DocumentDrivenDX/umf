from pathlib import Path
import json,shutil,hashlib,difflib,subprocess,concurrent.futures,time,sys
base=Path(__file__).parent;src=base/'source-790';out=base/'mutations';out.mkdir(exist_ok=True)
sp=Path('tests/security/native/pg18-mask-write.sql');rp=Path('tests/security/native/pg18-mask-write.py');original=(src/sp).read_text();runner=(src/rp).read_text()
mutations=[
 ('remove-read-blind',"  OR (actor.read_class='original' OR actor.blind_allowed) IS NOT TRUE THEN"," THEN", "'exit': 0"),
 ('remove-object',"IF actor.normal_allowed IS NOT TRUE OR actor.field_allowed IS NOT TRUE",'IF actor.field_allowed IS NOT TRUE', "'exit': 0"),
 ('remove-field',"IF actor.normal_allowed IS NOT TRUE OR actor.field_allowed IS NOT TRUE",'IF actor.normal_allowed IS NOT TRUE', "'exit': 0"),
 ('return-hidden-preimage',"RETURN '{\"status\":\"acknowledged\"}'::jsonb;","RETURN jsonb_build_object('status','acknowledged','old',before_value::text);", "'label': 'native:"),
 ('extra-subject-effect',"  PERFORM nextval('security_mask_write.effects'::regclass);","  UPDATE security_mask_write.subject SET blind_allowed=true WHERE login='umf_sec_mw_masked';\n  PERFORM nextval('security_mask_write.effects'::regclass);", "'label': 'unchanged-native-subjects:"),
]
hook="  if receipt is not None:receipt['nativeInventory']['cleanup']=cleanup"
replacement=hook+"\n  output.with_suffix('.cleanup.json').write_text(json.dumps(dict(runId=run_id,name=name,volumes=volumes,cleanup=cleanup)))"
assert runner.count(hook)==1
harness=runner.replace(hook,replacement)
(out/'cleanup-harness.patch').write_text(''.join(difflib.unified_diff(runner.splitlines(True),harness.splitlines(True),fromfile=str(rp),tofile=str(rp))))
for name,old,new,expected in mutations:
 assert original.count(old)==1,(name,original.count(old))
 d=out/name;d.mkdir(exist_ok=True);work=d/'source';shutil.copytree(src,work,symlinks=True)
 mutated=original.replace(old,new);(work/sp).write_text(mutated);(work/rp).write_text(harness)
 (d/'mutation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),mutated.splitlines(True),fromfile=str(sp),tofile=str(sp))))
 (d/'source.sql').write_text(mutated)
 (d/'pins.json').write_text(json.dumps({'baselineSQL':hashlib.sha256(original.encode()).hexdigest(),'mutantSQL':hashlib.sha256(mutated.encode()).hexdigest(),'baselineRunner':hashlib.sha256(runner.encode()).hexdigest(),'reviewOnlyCleanupRunner':hashlib.sha256(harness.encode()).hexdigest()},indent=2)+'\n')
def run(m):
 name,old,new,expected=m;d=out/name;beg=time.monotonic()
 with (d/'run.log').open('w') as log:r=subprocess.run([sys.executable,str(d/'source'/rp),'--output',str(d/'receipt.json')],cwd=d/'source',stdout=log,stderr=subprocess.STDOUT,timeout=110)
 log=(d/'run.log').read_text();cp=d/'receipt.cleanup.json';cleanup=json.loads(cp.read_text()) if cp.exists() else None
 result={'id':name,'exit':r.returncode,'wallSeconds':time.monotonic()-beg,'expectedFailureFragment':expected,'detected':r.returncode!=0 and expected in log,'cleanup':cleanup,'acceptanceReceipt':False}
 (d/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:results=list(ex.map(run,mutations))
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');assert all(r['detected'] and r['cleanup'] and all(r['cleanup']['cleanup'].values()) for r in results)
