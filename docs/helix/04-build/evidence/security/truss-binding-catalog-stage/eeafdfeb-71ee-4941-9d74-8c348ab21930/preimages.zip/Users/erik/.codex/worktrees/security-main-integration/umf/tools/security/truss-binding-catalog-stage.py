"""Captured original owner catalog staging on an isolated native transaction."""
import base64,hashlib,json,os,re,select,shutil,subprocess,tempfile,time,uuid,zipfile,importlib.metadata,sys
from pathlib import Path
from urllib.parse import urlparse,parse_qs
import pg8000.native,pgserver
ROOT=Path(__file__).resolve().parents[2]
if Path.cwd()!=ROOT:raise SystemExit('Exact root invocation required')
T=Path('/private/tmp/truss-security-main-integration');O=Path('/private/tmp/truss-umf-runtime-LmpSsH')
IR=ROOT/'docs/helix/04-build/evidence/security/weft-handoff.json'
components=['operation-admission','operation-commit-barrier','catalog-generation-observer','catalog-document-batch','catalog-lineage-producer','catalog-source-integrity','catalog-type-match','catalog-type-stage','catalog-property-match','catalog-property-stage','catalog-key-match','catalog-key-stage','catalog-key-batch','catalog-relationship-match','catalog-relationship-stage','catalog-report-documents','catalog-new-inventory','catalog-observation-recheck','catalog-input-custody','catalog-prestate-capture','catalog-new-prestate-parity','catalog-new-counts','catalog-provisional-empty','catalog-report-immutability','catalog-original-context','operation-generation-observer','canonical-string-bytes','canonical-tree-bytes','object-key-stage','catalog-binding-archive','catalog-binding-observation','catalog-binding-mapping']
layout=T/'docs/helix/04-build/evidence/qualified-property-layout-0.15.owner-export.sql'
paths=[Path(__file__),ROOT/'tools/security/truss-binding-catalog-stage.ts',IR,layout,O/'producer.js',O/'producer-manifest.json',ROOT/'docs/helix/02-design/contracts/CONTRACT-040-core-ideals.md',ROOT/'docs/helix/02-design/contracts/CONTRACT-063-security-enforcement.md']
paths += [T/f'packages/postgresql/native/{n}.sql' for n in components]
for directory in ['packages/umf-bun/src','packages/postgresql/src','docs/helix/02-design/contracts/bindings']:
 paths += [p for p in (T/directory).rglob('*') if p.is_file() and p.suffix in ['.ts','.json']]
paths += [T/'docs/helix/02-design/contracts/acceptance-input-v0.1.schema.json']
paths += [Path(pgserver.__file__).parent/name for name in ['postgres_server.py','_commands.py','utils.py']]
pending_layout='--pending-layout' in sys.argv
pending_ddl=T/'docs/helix/04-build/evidence/catalog-pending-binding-source.owner-export.sql'
if pending_layout:
 if '--opaque' in sys.argv:raise ValueError('Pending source shape fixture requires original association candidate')
 paths += [T/'packages/postgresql/native/catalog-pending-association-stage.sql',pending_ddl,T/'docs/helix/02-design/contracts/catalog-pending-binding-source-v0.1.proposal.sql',T/'docs/helix/02-design/contracts/catalog-pending-binding-source-v0.1.proposal.umf.json',T/'docs/helix/04-build/evidence/design-audit/catalog-pending-binding-source.json']
 capture=json.loads(paths[-1].read_text())
 paths += [ROOT/name for name in capture['ownerSourcePins']]
 for name,h in capture['ownerSourcePins'].items():
  if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=h:raise ValueError('Pending layout owner entry source changed')
 for name,key in [('sourcePath','sourceSha256'),('modelPath','modelSha256'),('ddlPath','ddlSha256')]:
  if hashlib.sha256(Path(capture[name]).read_bytes()).hexdigest()!=capture[key]:raise ValueError('Pending layout owner artifact changed')

interpretation=ROOT/'docs/helix/04-build/evidence/security/association-owner-interpretation/8ed0ba2a-6fb7-407a-a6db-c9fa4e487551'
paths += [interpretation/'binding.json',interpretation/'receipt.json']
# Capture and execute the full declared Ajv dependency closure from copied packages.
pending=[(ROOT/'node_modules/ajv').resolve()];dependencies={}
while pending:
 directory=pending.pop()
 if directory in dependencies:continue
 manifest=json.loads((directory/'package.json').read_text());dependencies[directory]=manifest
 files=[p for p in directory.rglob('*') if p.is_file() and p.suffix in ['.js','.mjs','.cjs','.json'] and 'node_modules' not in p.relative_to(directory).parts]
 paths += files
 for dependency in manifest.get('dependencies',{}):
  candidates=[directory/'node_modules'/dependency,directory.parent/dependency,*[ancestor/'node_modules'/dependency for ancestor in directory.parents]]
  selected=next((p.resolve() for p in candidates if (p/'package.json').is_file()),None)
  if selected is None:raise ValueError('Missing declared Ajv dependency')
  pending.append(selected)
frozen={str(p):p.read_bytes() for p in paths};sha=lambda b:hashlib.sha256(b).hexdigest();pins={p:sha(b) for p,b in frozen.items()}
owner_receipt=json.loads(frozen[str(interpretation/'receipt.json')])
if any(hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h for p,h in owner_receipt['sourceDigests'].items()):raise ValueError('Original interpretation source changed')
binding_bytes=frozen[str(interpretation/'binding.json')] if '--opaque' not in sys.argv else b'\x00\xffopaque 1e999999999999999999999999999999 -1e999999999999999999999999999999'
authored_fixture='--authored-relationship' in sys.argv
composite_fixture='--composite-key' in sys.argv
fixture_artifact=None
if authored_fixture or composite_fixture:
 if not pending_layout or '--opaque' in sys.argv:raise ValueError('Source fixtures require original association pending layout')
 fixture_artifact=next(a for a in json.loads(frozen[str(IR)])['artifacts'] if a['id']=='natural-count-self-join')
 original_core=fixture_artifact['request']['modules'][0]['documentJson'];core=json.loads(original_core)
 if authored_fixture:core['modules'][0]['relationships']=[{'id':'WorksWith','name':'Works with','source':[{'module':'m','element':'Staff'}],'target':[{'module':'m','element':'Project','key':'pk'}],'sourceMultiplicity':{'min':0,'max':'*'},'targetMultiplicity':{'min':0,'max':'*'},'targetLifecycle':'independent','directed':True}]
 if composite_fixture:
  module=core['modules'][0];elements={e['id']:e for e in module['elements']}
  fixture_binding=json.loads(binding_bytes);ontology=json.loads(base64.b64decode(fixture_binding['ontologyArtifact']['bytesBase64']))
  def qualified(element):return {'documentId':'domain','moduleId':'m','elementId':element}
  for record,field in [('Staff','staffTenant'),('Assignment','assignmentStaffTenant')]:
   module['elements'].append({'id':field,'kind':'field','scalarType':'string','nullability':'required','cardinality':'one','extensions':{},'name':field})
   ref={'module':'m','element':field};elements[record]['members'].append(ref)
   elements[record]['keys'][0]['fields'].insert(1,ref)
  ontology['entities'][0]['fields'].append({'ref':qualified('staffTenant'),'protection':'unprotected'})
  ontology['associations'][1]['fields'].append({'ref':qualified('assignmentStaffTenant'),'protection':'unprotected'})
  ontology['associations'][1]['endpoints'][0]['fields'].append(qualified('assignmentStaffTenant'))
  role=fixture_binding['mappings'][1]['roles'][0]
  role['associationFields'].append(qualified('assignmentStaffTenant'));role['targetFields'].append(qualified('staffTenant'))
  ontology_bytes=json.dumps(ontology,separators=(',',':')).encode()
  fixture_binding['ontologyArtifact']['bytesBase64']=base64.b64encode(ontology_bytes).decode()
  fixture_binding['ontologyArtifact']['sha256']=sha(ontology_bytes);fixture_binding['ontologySha256']=sha(ontology_bytes)
  binding_bytes=json.dumps(fixture_binding,separators=(',',':')).encode()
 fixture_artifact['request']['modules'][0]['documentJson']=json.dumps(core,separators=(',',':'))
 new_core_sha=sha(fixture_artifact['request']['modules'][0]['documentJson'].encode());old_core_sha=json.loads(binding_bytes)['coreSha256']
 fixture_artifact['request']['modules'][0]['pin']['sha256']=new_core_sha
 if binding_bytes.count(old_core_sha.encode())!=1:raise ValueError('Unique original core digest required')
 binding_bytes=binding_bytes.replace(old_core_sha.encode(),new_core_sha.encode())
mapping_fragments=([json.dumps(m,separators=(',',':')).encode().hex() for m in json.loads(binding_bytes)['mappings']] if composite_fixture else [next(o['observed'] for o in owner_receipt['observations'] if o['id']==f'original-mapping-fragment-{i}') for i in (0,1)]) if '--opaque' not in sys.argv else []
owned_field_count=11 if composite_fixture else 9
binding={'state':'present','vocabulary':{'identity':'uninterpreted-original-binding' if '--opaque' in sys.argv else 'truss-binary-association-candidate','version':'0.1.0' if '--opaque' in sys.argv else '0.2.0','sha256':sha(b'archive-custody-only-not-vocabulary-authority')},'artifact':{'identity':'original-binding-artifact','bytesBase64':base64.b64encode(binding_bytes).decode(),'sha256':sha(binding_bytes)}}
out=ROOT/'docs/helix/04-build/evidence/security/truss-binding-catalog-stage'/str(uuid.uuid4());out.mkdir(parents=True)
if authored_fixture or composite_fixture:(out/'authored-fixture.json').write_text(json.dumps({'artifact':fixture_artifact,'bindingHex':binding_bytes.hex()},indent=2)+'\n')
with zipfile.ZipFile(out/'preimages.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p,b in frozen.items():archive.writestr(p.lstrip('/'),b)
with zipfile.ZipFile(out/'preimages.zip') as archive:
 if set(archive.namelist())!={p.lstrip('/') for p in frozen} or any(archive.read(p.lstrip('/'))!=b for p,b in frozen.items()):raise ValueError('Exact archived preimages required')
bridge=out/'frozen';bridge.mkdir()
for p,b in frozen.items():
 if p.startswith(str(T)+'/'):dest=bridge/'truss'/Path(p).relative_to(T)
 elif p.startswith(str(O)+'/'):dest=bridge/'owner'/Path(p).relative_to(O)
 elif p.endswith('truss-binding-catalog-stage.ts'):dest=bridge/'bridge.ts'
 else:continue
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
dep_root=bridge/'dependencies';dep_root.mkdir();(dep_root/'package.json').write_text('{}')
for directory,manifest in dependencies.items():
 for p,b in frozen.items():
  if Path(p).is_relative_to(directory):
   dest=dep_root/'node_modules'/manifest['name']/Path(p).relative_to(directory);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
checks=[];server=None;temporary=None;c=None;child=None;phase='runtime';query_log=[]
def check(name,expected,observed):
 checks.append({'id':name,'expected':expected,'observed':observed})
 if expected!=observed:raise ValueError(name)
try:
 check('bun1.4.2','1.4.2',subprocess.run(['bun','--version'],capture_output=True,text=True,check=True,timeout=5).stdout.strip())
 check('pgserver-version','0.1.4+truss.pg16.15',importlib.metadata.version('pgserver'));check('pg8000-version','1.31.5',importlib.metadata.version('pg8000'))
 temporary=tempfile.TemporaryDirectory(prefix='umf-security-pg-',dir='/private/tmp')
 class IsolatedPostgresServer(pgserver.PostgresServer):
  # This database directory has exactly one test process/handle. Preserve the
  # installed startup/cleanup implementation, isolate its filesystem mutex.
  runtime_path=Path(temporary.name)/'runtime'
  lock_path=Path(temporary.name)/'runtime.lock'
  _lock=pgserver.PostgresServer.fasteners.InterProcessLock(lock_path)
 server=IsolatedPostgresServer(Path(temporary.name)/'data',cleanup_mode='delete')
 check('runtime-private-lock-directory',True,server.lock_path.parent==Path(temporary.name))
 uri=urlparse(server.get_uri());host=parse_qs(uri.query).get('host',[uri.hostname])[0];port=uri.port or 5432
 c=pg8000.native.Connection(user='postgres',database=uri.path.lstrip('/'),unix_sock=str(Path(host)/f'.s.PGSQL.{port}'),ssl_context=False,timeout=5)
 check('postgresql16.15',[['160015']],c.run('SHOW server_version_num'))
 phase='layout';c.run(frozen[str(layout)].decode())
 for name in components:phase='install:'+name;c.run(frozen[str(T/f'packages/postgresql/native/{name}.sql')].decode())
 if pending_layout:
  phase='pending-layout';c.run(frozen[str(pending_ddl)].decode())
  phase='pending-association-stage';c.run(frozen[str(T/'packages/postgresql/native/catalog-pending-association-stage.sql')].decode())
 c.run('CREATE ROLE truss_binding_untrusted NOLOGIN');c.run('GRANT USAGE ON SCHEMA truss TO truss_binding_untrusted')
 occupied='--occupied' in sys.argv
 if occupied:
  # Excluded installer seed: inert prior byte custody, not accepted history.
  c.run('ALTER TABLE truss.catalog_binding_archive DISABLE TRIGGER runtime_catalog_generation')
  c.run("INSERT INTO truss.catalog_binding_archive(revision,vocabulary,artifact_identity_utf8,original_binding_bytes,original_input_bytes,original_writer_xid) VALUES(0,'{\"identity\":\"fixture-only\"}'::jsonb,decode('7072696f72','hex'),decode('00ff','hex'),decode('7072696f72','hex'),pg_current_xact_id())")
  c.run('ALTER TABLE truss.catalog_binding_archive ENABLE ALWAYS TRIGGER runtime_catalog_generation')
 prior_archive=c.run('SELECT to_jsonb(a) FROM truss.catalog_binding_archive a ORDER BY revision')
 phase='original-stage';c.run('BEGIN');prior_head=c.run('SELECT rev FROM truss.schema_head')
 artifact=fixture_artifact or next(a for a in json.loads(frozen[str(IR)])['artifacts'] if a['id']=='natural-count-self-join')
 child=subprocess.Popen(['bun',str(bridge/'bridge.ts')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 init={'artifact':artifact,'fixture':json.loads(frozen[str(T/'docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json')]),'ownerDirectory':str(bridge/'owner'),'dependenciesPackage':str(dep_root/'package.json'),'binding':binding}
 def archive_state():
  return c.run("SELECT (SELECT coalesce(jsonb_agg(to_jsonb(a) ORDER BY revision),'[]'::jsonb) FROM truss.catalog_binding_archive a),(SELECT jsonb_agg(to_jsonb(o)) FROM truss.row_home_operation o),(SELECT jsonb_agg(to_jsonb(d) ORDER BY rev,ord) FROM truss.schema_doc d),(SELECT jsonb_agg(to_jsonb(r) ORDER BY rev) FROM truss.schema_rev r),(SELECT coalesce(jsonb_agg(to_jsonb(k) ORDER BY k.type_id,k.key_num),'[]'::jsonb) FROM truss.key_def k),(SELECT coalesce(jsonb_agg(to_jsonb(r) ORDER BY r.rel_type_id),'[]'::jsonb) FROM truss.rel_def r),(SELECT coalesce(jsonb_agg(to_jsonb(e) ORDER BY e.rel_type_id,e.source_type,e.target_type),'[]'::jsonb) FROM truss.rel_endpoint e),(SELECT coalesce(jsonb_agg(to_jsonb(l) ORDER BY l.rel_type_id),'[]'::jsonb) FROM truss.relationship_lineage l),(SELECT coalesce(jsonb_agg(to_jsonb(t) ORDER BY t.type_id),'[]'::jsonb) FROM truss.type_def t),(SELECT coalesce(jsonb_agg(to_jsonb(p) ORDER BY p.prop_id),'[]'::jsonb) FROM truss.prop_def p)")
 def stage_binding(rev,body=binding_bytes):
  return c.run("SELECT truss.runtime_stage_catalog_binding(:r::int,decode(:h,'hex'))",r=str(rev),h=body.hex())
 def refusal(label,query,expected,acting_role=None,**parameters):
  c.run('SAVEPOINT binding_refusal');before=archive_state()
  if acting_role:c.run('SET LOCAL ROLE truss_binding_untrusted')
  try:c.run(query,**parameters)
  except pg8000.exceptions.DatabaseError as error:
   observed_error={'code':error.args[0].get('C'),'message':error.args[0].get('M'),'constraint':error.args[0].get('n')}
   check(label,expected,{key:observed_error[key] for key in expected})
  else:raise ValueError(label+' admitted')
  c.run('ROLLBACK TO SAVEPOINT binding_refusal');c.run('RELEASE SAVEPOINT binding_refusal');check(label+'-zero-effects',before,archive_state())
 def binding_probes(rev):
  baseline=archive_state();check('pre-archive-empty',[[0]],c.run('SELECT count(*) FROM truss.catalog_binding_archive WHERE revision=:r::int',r=str(rev)))
  for label,fault,body,target,message in [
   ('byte-substitution',None,b'substituted-original',rev,'original admitted binding bytes required'),
   ('prior-revision',None,binding_bytes,'0','current unpublished catalog revision and original binding prestate required'),
   ('document-revision',"UPDATE truss.schema_doc SET doc_revision='substituted'",binding_bytes,rev,'original binding document correspondence required'),
   ('document-digest',"UPDATE truss.schema_doc SET content_sha256=repeat('0',64)",binding_bytes,rev,'original binding document correspondence required')]:
   c.run('SAVEPOINT binding_case');generation=c.run('SELECT effect_generation FROM truss.row_home_operation')[0][0]
   check(label+'-agreeing-positive',[[sha(binding_bytes)]],stage_binding(rev))
   check(label+'-generation',[[generation+1]],c.run('SELECT effect_generation FROM truss.row_home_operation'))
   check(label+'-positive-original-bytes',[[binding_bytes.hex()]],c.run("SELECT encode(original_binding_bytes,'hex') FROM truss.catalog_binding_archive WHERE revision=:r::int",r=str(rev)))
   c.run('ROLLBACK TO SAVEPOINT binding_case');check(label+'-positive-rollback',baseline,archive_state())
   if fault:c.run(fault)
   refusal(label,"SELECT truss.runtime_stage_catalog_binding(:r::int,decode(:h,'hex'))",{'code':'55000','message':message},r=str(target),h=body.hex())
   c.run('ROLLBACK TO SAVEPOINT binding_case');c.run('RELEASE SAVEPOINT binding_case');check(label+'-restored',baseline,archive_state())
  if occupied:
   c.run('SAVEPOINT prior_drift');check('occupied-agreeing-positive',[[sha(binding_bytes)]],stage_binding(rev));c.run('SELECT truss.runtime_verify_new_catalog_prestate(:r::int)',r=str(rev));check('occupied-parity-positive',True,True)
   c.run('ROLLBACK TO SAVEPOINT prior_drift');check('occupied-positive-rollback',baseline,archive_state())
   c.run('ALTER TABLE truss.catalog_binding_archive DISABLE TRIGGER runtime_binding_archive_immutable')
   c.run("UPDATE truss.catalog_binding_archive SET artifact_identity_utf8=decode('6472696674','hex') WHERE revision=0")
   c.run('ALTER TABLE truss.catalog_binding_archive ENABLE ALWAYS TRIGGER runtime_binding_archive_immutable')
   refusal('occupied-prior-drift',"SELECT truss.runtime_stage_catalog_binding(:r::int,decode(:h,'hex'))",{'code':'55000','message':'current unpublished catalog revision and original binding prestate required'},r=str(rev),h=binding_bytes.hex())
   refusal('occupied-parity-drift','SELECT truss.runtime_verify_new_catalog_prestate(:r::int)',{'code':'55000','message':'retained catalog differs from original new-only prestate'},r=str(rev))
   c.run('ROLLBACK TO SAVEPOINT prior_drift');c.run('RELEASE SAVEPOINT prior_drift');check('occupied-prior-restored',baseline,archive_state())
  c.run('SAVEPOINT retained_binding');stage_binding(rev)
  for label,sql in [('immutable-update',"UPDATE truss.catalog_binding_archive SET artifact_identity_utf8=convert_to('substituted','UTF8')"),('immutable-delete','DELETE FROM truss.catalog_binding_archive'),('immutable-truncate','TRUNCATE truss.catalog_binding_archive')]:
   if pending_layout and label=='immutable-truncate':
    refusal('pending-fk-truncate-exclusion',sql,{'code':'0A000','message':'cannot truncate a table referenced in a foreign key constraint'})
    label='immutable-truncate-cascade';sql+=' CASCADE'
   refusal(label,sql,{'code':'55000','message':'original binding archive is immutable; retention profile required'})
  refusal('duplicate-stage',"SELECT truss.runtime_stage_catalog_binding(:r::int,decode(:h,'hex'))",{'code':'55000','message':'original binding archive already staged'},r=str(rev),h=binding_bytes.hex())
  for label,sql in [('routine',"SELECT truss.runtime_stage_catalog_binding(1,decode('01','hex'))"),('read','SELECT * FROM truss.catalog_binding_archive'),('insert',"INSERT INTO truss.catalog_binding_archive DEFAULT VALUES"),('update','UPDATE truss.catalog_binding_archive SET revision=revision'),('delete','DELETE FROM truss.catalog_binding_archive'),('truncate','TRUNCATE truss.catalog_binding_archive')]:
   refusal('ordinary-'+label,sql,{'code':'42501'},acting_role=True)
  check('native-immutable-always-triggers',[[3,3]],c.run("SELECT count(*),count(*) FILTER(WHERE tgenabled='A') FROM pg_trigger WHERE tgrelid='truss.catalog_binding_archive'::regclass AND NOT tgisinternal"))
  check('native-binding-routines-invoker',[[3,0]],c.run("SELECT count(*),count(*) FILTER(WHERE prosecdef) FROM pg_proc WHERE pronamespace='truss'::regnamespace AND proname IN ('runtime_stage_catalog_binding','runtime_capture_binding_catalog_prestate','runtime_refuse_binding_archive_change')"))
  c.run('ROLLBACK TO SAVEPOINT retained_binding');c.run('RELEASE SAVEPOINT retained_binding');check('probe-baseline-restored',baseline,archive_state())

 init['pendingReportBasis']=pending_layout
 child.stdin.write((json.dumps(init)+'\n').encode());child.stdin.flush();buffer=b'';deadline=time.monotonic()+60;packet=None
 while packet is None:
  if time.monotonic()>deadline:raise TimeoutError('Bounded stage deadline')
  ready,_,_=select.select([child.stdout,child.stderr],[],[],min(1,deadline-time.monotonic()))
  for stream in ready:
   data=os.read(stream.fileno(),65536)
   if stream is child.stderr:
    if data:raise ValueError('Unexpected bridge stderr')
    continue
   if not data:raise ValueError('Bridge terminated without result')
   buffer+=data
   if len(buffer)>1048576:raise ValueError('Bounded bridge output')
   while b'\n' in buffer:
    line,buffer=buffer.split(b'\n',1);message=json.loads(line)
    if message['kind']!='query':packet=message;break
    sql=message['sql'];params=message['parameters'];query_log.append({'sql':sql,'parametersSha256':sha(json.dumps(params,separators=(',',':')).encode())})
    if len(query_log)>64 or not isinstance(sql,str) or len(sql)>4096 or not all(isinstance(v,str) for v in params):raise ValueError('Bounded original query')
    try:
     if sql.startswith('SELECT truss.runtime_capture_binding_catalog_prestate('):refusal('old-prestate-omission-refused','SELECT truss.runtime_capture_catalog_prestate()',{'code':'55000','message':'catalog binding prestate profile required'})
     if sql.startswith('SELECT truss.runtime_stage_catalog_binding('):binding_probes(params[0])
     converted=re.sub(r'\$(\d+)',lambda m:':p'+m[1],sql);rows=c.run(converted,**{'p'+str(i+1):v for i,v in enumerate(params)})
     cols=[column['name'] for column in c.columns] if c.columns else []
     response={'rows':[{name:str(v) for name,v in zip(cols,row)} for row in (rows or [])]}
    except pg8000.exceptions.DatabaseError as error:response={'error':error.args[0].get('C','unknown')}
    child.stdin.write((json.dumps(response)+'\n').encode());child.stdin.flush()
 if packet.get('kind')!='result':raise ValueError(packet.get('reason','Original staging unavailable'))
 if not pending_layout:
  child.stdin.close();check('bridge-exit',0,child.wait(timeout=5))
 check('original-archive-bridge',artifact['request']['modules'][0]['documentJson'],packet['originalText'])
 check('five-records',5,len(packet['staged']['types']));check('complete-owned-field-count',owned_field_count,len(packet['staged']['properties']));check('five-keys',5,len(packet['staged']['keys']));check('original-core-relationship-count',int(authored_fixture),len(packet['staged']['relationships']))
 check('native-non-primary-keys',[[5,0]],c.run('SELECT count(*),count(*) FILTER(WHERE is_primary) FROM truss.key_def'))
 check('native-original-archive',[[packet['originalText']]],c.run('SELECT document::text FROM truss.schema_doc WHERE doc_id=\'domain\''))
 source=json.loads(packet['originalText']);elements={e['id']:e for e in source['modules'][0]['elements']};records=[e for e in elements.values() if e.get('kind')=='record']
 check('complete-original-native-types',sorted([['domain','m',record['id'],'accepted_document','domain'] for record in records]),c.run('SELECT document_id,module,element,definition_source_kind,definition_document_id FROM truss.type_def ORDER BY document_id,module,element'))
 check('original-native-relationship-and-endpoint-count',[[int(authored_fixture),int(authored_fixture)]],c.run('SELECT (SELECT count(*) FROM truss.rel_def),(SELECT count(*) FROM truss.rel_endpoint)'))
 observed_properties=c.run("SELECT t.element,p.element,p.scalar_type,p.nullability,p.cardinality,p.facets,p.home,p.definition_source_kind,p.definition_document_id,p.declaration_module FROM truss.prop_def p JOIN truss.type_def t ON t.type_id=p.type_id ORDER BY t.element,p.element")
 expected_properties=sorted([[record['id'],ref['element'],elements[ref['element']].get('scalarType'),elements[ref['element']]['nullability'],elements[ref['element']]['cardinality'],elements[ref['element']].get('facets'),'json','accepted_document','domain','m'] for record in records for ref in record['members']],key=lambda r:(r[0],r[1]))
 check('complete-original-property-projection',expected_properties,observed_properties)
 observed_keys=c.run("SELECT t.element,k.key_id,k.is_primary,array_agg(p.element ORDER BY u.ordinality),k.definition_source_kind,k.definition_document_id FROM truss.key_def k JOIN truss.type_def t ON t.type_id=k.type_id CROSS JOIN LATERAL unnest(k.prop_ids) WITH ORDINALITY u(id,ordinality) JOIN truss.prop_def p ON p.prop_id=u.id GROUP BY t.element,k.key_id,k.is_primary,k.definition_source_kind,k.definition_document_id ORDER BY t.element,k.key_id")
 expected_keys=sorted([[record['id'],key['id'],key.get('primary') is True,[ref['element'] for ref in key['fields']],'accepted_document','domain'] for record in records for key in record['keys']],key=lambda r:(r[0],r[1]))
 check('complete-original-ordered-key-projection',expected_keys,observed_keys)
 check('unpublished-head',prior_head,c.run('SELECT rev FROM truss.schema_head'))
 check('archive-exact-native-projection',[[packet['staged']['provisionalRevision'],binding['vocabulary'],binding['artifact']['identity'],binding_bytes.hex(),packet['originalInputHex'],binding['artifact']['sha256']]],c.run("SELECT revision::text,vocabulary,convert_from(artifact_identity_utf8,'UTF8'),encode(original_binding_bytes,'hex'),encode(original_input_bytes,'hex'),encode(binding_sha256,'hex') FROM truss.catalog_binding_archive WHERE revision<>0"))
 check('archive-original-writer',[[True]],c.run("SELECT a.original_writer_xid=o.original_writer_xid FROM truss.catalog_binding_archive a CROSS JOIN truss.row_home_operation o WHERE a.revision<>0"))
 check('archive-native-generation-participates',True,any(o['id']=='byte-substitution-generation' for o in checks))
 c.run('SELECT truss.runtime_verify_new_catalog_prestate(:r::int)',r=packet['staged']['provisionalRevision']);check('complete-stage-retained-parity',True,True)
 for label,fault in [('profile01-with-archive',"UPDATE truss.row_home_operation SET original_prestate_bytes=convert_to(jsonb_set(convert_from(original_prestate_bytes,'UTF8')::jsonb-'bindings','{interfaceVersion}','\"truss-native-catalog-prestate/0.1\"'::jsonb)::text,'UTF8')"),('profile02-without-archive','ALTER TABLE truss.catalog_binding_archive RENAME TO excluded_archive_fixture')]:
  baseline=archive_state();c.run('SAVEPOINT profile_mismatch')
  c.run('SELECT truss.runtime_verify_new_catalog_prestate(:r::int)',r=packet['staged']['provisionalRevision']);check(label+'-agreeing-positive',True,True)
  if label=='profile01-with-archive':c.run('CREATE OR REPLACE FUNCTION truss.runtime_guard_operation_originals() RETURNS trigger LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog,pg_temp AS $$BEGIN RETURN NEW; END;$$')
  c.run(fault)
  if label=='profile01-with-archive':c.run(re.search(r'CREATE FUNCTION truss.runtime_guard_operation_originals\(\).*?\$\$;',frozen[str(T/'packages/postgresql/native/catalog-input-custody.sql')].decode(),re.S).group(0).replace('CREATE FUNCTION','CREATE OR REPLACE FUNCTION',1))
  try:c.run('SELECT truss.runtime_verify_new_catalog_prestate(:r::int)',r=packet['staged']['provisionalRevision'])
  except pg8000.exceptions.DatabaseError as error:check(label,{'code':'55000','message':'original prestate archive profile correspondence required'},{'code':error.args[0].get('C'),'message':error.args[0].get('M')})
  else:raise ValueError(label+' admitted')
  c.run('ROLLBACK TO SAVEPOINT profile_mismatch');c.run('RELEASE SAVEPOINT profile_mismatch');check(label+'-restored',baseline,archive_state())
 check('original-core-only-native-inventory', ([['endpoint',1]] if authored_fixture else [])+[['key',5],['property',owned_field_count]]+([['relationship',1]] if authored_fixture else [])+[['type',5]], c.run('SELECT family,count(*) FROM truss.runtime_collect_new_core_catalog_inventory(:r::int) GROUP BY family ORDER BY family',r=packet['staged']['provisionalRevision']))
 c.run('SAVEPOINT inventory_primary_fault');baseline=archive_state()
 c.run('UPDATE truss.key_def SET is_primary=true WHERE type_id=(SELECT min(type_id) FROM truss.key_def)')
 refusal('inventory-primary-substitution','SELECT * FROM truss.runtime_collect_new_core_catalog_inventory(:r::int)',{'code':'55000','message':'stored original ordered Key definition correspondence'},r=packet['staged']['provisionalRevision'])
 c.run('ROLLBACK TO SAVEPOINT inventory_primary_fault');c.run('RELEASE SAVEPOINT inventory_primary_fault');check('inventory-primary-restored',baseline,archive_state())
 refusal('complete-binding-inventory-unavailable','SELECT * FROM truss.runtime_collect_new_catalog_inventory(:r::int)',{'code':'0A000','message':'registered binding effect inventory required'},r=packet['staged']['provisionalRevision'])
 refusal('complete-binding-counts-unavailable','SELECT * FROM truss.runtime_collect_new_catalog_counts(:r::int)',{'code':'0A000','message':'registered binding effect inventory required'},r=packet['staged']['provisionalRevision'])
 observed=c.run('SELECT * FROM truss.runtime_collect_original_catalog_binding(:r::int)',r=packet['staged']['provisionalRevision'])
 operation=c.run('SELECT original_writer_xid::text,operation_ordinal::text,effect_generation::text FROM truss.row_home_operation')[0]
 check('original-native-binding-observation',[[binding_bytes.hex(),packet['originalInputHex'],sha(binding_bytes),*operation]],observed)
 if '--opaque' not in sys.argv:
  for index in (0,1):
   expected=mapping_fragments[index]
   check(f'native-original-mapping-{index}',[[expected]],c.run("SELECT encode(truss.runtime_collect_original_association_mapping(:r::int,:p),'hex')",r=packet['staged']['provisionalRevision'],p=f'/mappings/{index}'))
  fragment='{ "literal" : "\\\" } ] , mappings 雪", "nested": [{"x":true}], "numeric": 1e999999999999999999 }'.encode()
  lexical=[('first',b'{"mappings":['+fragment+b', {}],"other":null}',fragment),('escaped-root',b' {"other":{"mappings":[]},"mapp\\u0069ngs" : [ \n'+fragment+b' ]} \n',fragment),('last',b'{"other":[{},false],"mappings":[null, {}]}',b'{}')]
  lexical += [('last-index',b'{"mappings":['+b'null,'*4095+b'{}]}',b'{}'),('byte-limit',b'{"mappings":[{}]}'+b' '*(1048576-len(b'{"mappings":[{}]}')),b'{}'),('depth-limit',b'{"before":'+b'['*31+b'null'+b']'*31+b',"mappings":[{}]}',b'{}')]
  lexical += [('suffix-depth-limit',b'{"mappings":[{}],"after":'+b'['*31+b'null'+b']'*31+b'}',b'{}'),('later-mapping-depth-limit',b'{"mappings":[{},'+b'['*30+b'null'+b']'*30+b']}',b'{}')]
  for label,original,expected in lexical:
   pointer='/mappings/4095' if label=='last-index' else '/mappings/1' if label=='last' else '/mappings/0'
   check('native-lexical-'+label,[[expected.hex()]],c.run("SELECT encode(truss.runtime_extract_original_association_mapping(decode(:h,'hex'),:p),'hex')",h=original.hex(),p=pointer))
  check('native-mapping-batch-original-fragments',[[i,mapping_fragments[i]] for i in (0,1)],c.run("SELECT mapping_index,encode(mapping_bytes,'hex') FROM truss.runtime_extract_original_association_mapping_batch(decode(:h,'hex'))",h=binding_bytes.hex()))
  maximum=b'{"mappings":['+b'{},'*4095+b'{}]}'
  check('native-mapping-batch-count-boundary',[[4096,0,4095]],c.run("SELECT count(*)::int,min(mapping_index),max(mapping_index) FROM truss.runtime_extract_original_association_mapping_batch(decode(:h,'hex'))",h=maximum.hex()))
  refusal('native-mapping-batch-count-over',"SELECT * FROM truss.runtime_extract_original_association_mapping_batch(decode(:h,'hex'))",{'code':'54000','message':'original mapping batch count exceeded'},h=(b'{"mappings":['+b'{},'*4096+b'{}]}').hex())
  refusal('native-mapping-batch-later-non-object',"SELECT * FROM truss.runtime_extract_original_association_mapping_batch(decode(:h,'hex'))",{'code':'22023','message':'original mapping object required'},h=b'{"mappings":[{},null]}'.hex())
  for label,original,pointer,code,message in [
   ('duplicate-root',b'{"mappings":[{}],"mapp\\u0069ngs":[{}]}','/mappings/0','22023','unique original mapping JSON required'),
   ('duplicate-nested',b'{"mappings":[{"a":0,"a":1}]}','/mappings/0','22023','unique original mapping JSON required'),
   ('malformed',b'{"mappings":[{}]','/mappings/0','22023','unique original mapping JSON required'),
   ('missing-array',b'{}','/mappings/0','22023','original mapping array required'),
   ('wrong-array',b'{"mappings":{}}','/mappings/0','22023','original mapping array required'),
   ('empty-array',b'{"mappings":[]}','/mappings/0','22023','original mapping index absent'),
   ('absent-index',b'{"mappings":[{}]}','/mappings/1','22023','original mapping index absent'),
   ('non-object',b'{"mappings":[null]}','/mappings/0','22023','original mapping object required'),
   ('leading-zero',b'{"mappings":[{}]}','/mappings/00','22023','original mapping pointer required'),
   ('out-of-range',b'{"mappings":[{}]}','/mappings/4096','54000','original mapping index exceeded'),
   ('wrong-pointer',b'{"mappings":[{}]}','/other/0','22023','original mapping pointer required'),
   ('depth',b'{"before":'+b'['*33+b'null'+b']'*33+b',"mappings":[{}]}','/mappings/0','54000','original JSON depth exceeded'),
   ('deep-suffix',b'{"mappings":[{}],"after":'+b'['*32+b'null'+b']'*32+b'}','/mappings/0','54000','original JSON depth exceeded'),
   ('deep-later-mapping',b'{"mappings":[{},'+b'['*31+b'null'+b']'*31+b']}','/mappings/0','54000','original JSON depth exceeded'),
   ('whole-depth-limit-over',b'{"before":'+b'['*32+b'null'+b']'*32+b',"mappings":[{}]}','/mappings/0','54000','original JSON depth exceeded'),
   ('oversize',b' '*1048577,'/mappings/0','22023','unique original mapping JSON required')]:
   refusal('native-lexical-refusal-'+label,"SELECT truss.runtime_extract_original_association_mapping(decode(:h,'hex'),:p)",{'code':code,'message':message},h=original.hex(),p=pointer)
  refusal('ordinary-mapping-helper',"SELECT truss.runtime_extract_original_association_mapping(decode(:h,'hex'),'/mappings/0')",{'code':'42501'},acting_role=True,h=b'{"mappings":[{}]}'.hex())
  refusal('ordinary-original-mapping',"SELECT truss.runtime_collect_original_association_mapping(:r::int,'/mappings/0')",{'code':'42501'},acting_role=True,r=packet['staged']['provisionalRevision'])
 for label,column,expression,message in [('body','original_binding_bytes',"decode('01','hex')",'original binding archive artifact correspondence required'),('input','original_input_bytes',"decode('01','hex')",'original binding archive operation correspondence required'),('writer','original_writer_xid',"'1'::xid8",'original binding archive operation correspondence required'),('identity','artifact_identity_utf8',"decode('01','hex')",'original binding archive artifact correspondence required'),('vocabulary','vocabulary',"'{}'::jsonb",'original binding archive artifact correspondence required')]:
  baseline=archive_state();c.run('SAVEPOINT observed_binding_fault')
  check('observation-'+label+'-agreeing-positive',observed,c.run('SELECT * FROM truss.runtime_collect_original_catalog_binding(:r::int)',r=packet['staged']['provisionalRevision']))
  c.run('ALTER TABLE truss.catalog_binding_archive DISABLE TRIGGER runtime_binding_archive_immutable')
  c.run('UPDATE truss.catalog_binding_archive SET '+column+'='+expression+' WHERE revision=:r::int',r=packet['staged']['provisionalRevision'])
  c.run('ALTER TABLE truss.catalog_binding_archive ENABLE ALWAYS TRIGGER runtime_binding_archive_immutable')
  refusal('observation-'+label,'SELECT * FROM truss.runtime_collect_original_catalog_binding(:r::int)',{'code':'55000','message':message},r=packet['staged']['provisionalRevision'])
  c.run('ROLLBACK TO SAVEPOINT observed_binding_fault');c.run('RELEASE SAVEPOINT observed_binding_fault');check('observation-'+label+'-restored',baseline,archive_state())
 baseline=archive_state();c.run('SAVEPOINT observed_document_fault')
 check('observation-document-agreeing-positive',observed,c.run('SELECT * FROM truss.runtime_collect_original_catalog_binding(:r::int)',r=packet['staged']['provisionalRevision']))
 c.run("UPDATE truss.schema_doc SET doc_revision='substituted-original-revision' WHERE rev=:r::int",r=packet['staged']['provisionalRevision'])
 refusal('observation-document-revision','SELECT * FROM truss.runtime_collect_original_catalog_binding(:r::int)',{'code':'55000','message':'document carrier substitutes original admitted source bytes/order/identity'},r=packet['staged']['provisionalRevision'])
 c.run('ROLLBACK TO SAVEPOINT observed_document_fault');c.run('RELEASE SAVEPOINT observed_document_fault');check('observation-document-restored',baseline,archive_state())
 refusal('ordinary-binding-observation','SELECT * FROM truss.runtime_collect_original_catalog_binding(:r::int)',{'code':'42501'},acting_role=True,r=packet['staged']['provisionalRevision'])
 check('host-archive-digest',sha(binding_bytes),packet['staged']['bindingArchiveSha256'])
 check('prior-archive-preserved',prior_archive,c.run('SELECT to_jsonb(a) FROM truss.catalog_binding_archive a WHERE revision=0 ORDER BY revision'))
 if pending_layout:
  phase='pending-source-shape';baseline=archive_state();rev=packet['staged']['provisionalRevision']
  candidate_ids=[str(int(c.run('SELECT coalesce(max(rel_type_id),0) FROM truss.rel_def')[0][0])+i+1) for i in range(2)]
  prior_lineage=c.run('SELECT to_jsonb(l) FROM truss.relationship_lineage l ORDER BY rel_type_id')
  c.run('SAVEPOINT pending_candidate_batch');before_generation=c.run('SELECT effect_generation FROM truss.row_home_operation')[0][0]
  allocated=c.run('SELECT * FROM truss.runtime_stage_pending_association_candidate(:r::int)',r=rev)
  check('pending-candidate-original-allocated-batch',[[f'/mappings/{i}',candidate_ids[i]] for i in range(2)],allocated)
  native_types={row[0]:row[1] for row in c.run("SELECT element,type_id::text FROM truss.type_def WHERE document_id='domain' AND module='m'")}
  expected=[]
  for index,(association,source,target) in enumerate([('Ownership','Resource','Project'),('Assignment','Staff','Project')]):
   fragment=mapping_fragments[index]
   expected.append([candidate_ids[index],association,native_types[association],native_types[source],native_types[target],'pk','operation_binding',f'/mappings/{index}',fragment])
  check('pending-candidate-native-correspondence',expected,c.run("SELECT r.rel_type_id::text,r.rel_id,r.assoc_type_id::text,e.source_type::text,e.target_type::text,r.target_key,r.definition_source_kind,r.pending_mapping_pointer,encode(r.pending_mapping_bytes,'hex') FROM truss.rel_def r JOIN truss.rel_endpoint e USING(rel_type_id) WHERE r.definition_source_kind='operation_binding' ORDER BY r.rel_type_id"))
  check('pending-candidate-exact-storage',[[0,None,0,None,'independent',True,False,None],[0,None,0,None,'independent',True,False,None]],c.run("SELECT source_min,source_max,target_min,target_max,lifecycle,directed,composition,inverse FROM truss.rel_def WHERE definition_source_kind='operation_binding' ORDER BY rel_type_id"))
  actual_operation=c.run('SELECT original_writer_xid::text,operation_ordinal::text FROM truss.row_home_operation')[0]
  check('pending-candidate-original-operation',[actual_operation+[rev],actual_operation+[rev]],c.run("SELECT pending_writer_xid::text,pending_operation_ordinal::text,pending_binding_revision::text FROM truss.rel_def WHERE definition_source_kind='operation_binding' ORDER BY rel_type_id"))
  check('pending-candidate-all-original-association-fields',[['Assignment',4 if composite_fixture else 3],['Ownership',2]],c.run("SELECT t.element,count(p.prop_id)::int FROM truss.type_def t JOIN truss.prop_def p ON p.type_id=t.type_id WHERE t.element IN ('Assignment','Ownership') GROUP BY t.element ORDER BY t.element"))
  check('pending-candidate-original-authored-lineage-preserved',prior_lineage,c.run('SELECT to_jsonb(l) FROM truss.relationship_lineage l ORDER BY rel_type_id'))
  check('pending-candidate-observed-generation',[[before_generation+4]],c.run('SELECT effect_generation FROM truss.row_home_operation'))
  source_query='SELECT * FROM truss.runtime_collect_pending_association_source_candidate(:r::int)'
  expected_source=[[f'/mappings/{i}',candidate_ids[i],sha(bytes.fromhex(expected[i][-1])),str(before_generation+4)] for i in range(2)]
  check('pending-source-candidate-exact-original-cohort',expected_source,c.run(source_query,r=rev))
  check('pending-source-candidate-readonly-generation',[[before_generation+4]],c.run('SELECT effect_generation FROM truss.row_home_operation'))
  refusal('ordinary-pending-source-candidate',source_query,{'code':'42501'},acting_role=True,r=rev)
  for fault,mutation,message in [
   ('bytes',"UPDATE truss.rel_def SET pending_mapping_bytes=convert_to('{}','UTF8') WHERE rel_type_id=:candidate_target::int",'pending source candidate exact tuple correspondence required'),
   ('pointer',"UPDATE truss.rel_def SET pending_mapping_pointer='/mappings/9' WHERE rel_type_id=:candidate_target::int",'pending source candidate unique source correspondence required'),
   ('duplicate-pointer',"UPDATE truss.rel_def SET pending_mapping_pointer='/mappings/0' WHERE rel_type_id=:candidate_target::int",'pending source candidate unique source correspondence required')]:
   c.run('SAVEPOINT pending_source_fault');original_state=archive_state();c.run(mutation,candidate_target=candidate_ids[1])
   refusal('pending-source-candidate-'+fault,source_query,{'code':'55000','message':message},r=rev)
   c.run('ROLLBACK TO SAVEPOINT pending_source_fault');c.run('RELEASE SAVEPOINT pending_source_fault')
   check('pending-source-candidate-'+fault+'-restored',original_state,archive_state())
  c.run('SAVEPOINT pending_source_extra_fault');original_state=archive_state()
  c.run("INSERT INTO truss.rel_def(document_id,rel_type_id,module,rel_id,name,source_min,source_max,target_min,target_max,lifecycle,directed,target_key,composition,assoc_type_id,inverse,since_rev,doc_ord,definition_source_kind,pending_writer_xid,pending_operation_ordinal,pending_binding_revision,pending_mapping_pointer,pending_mapping_bytes) SELECT document_id,:extra_id::int,module,rel_id,name,source_min,source_max,target_min,target_max,lifecycle,directed,target_key,composition,assoc_type_id,inverse,since_rev,doc_ord,definition_source_kind,pending_writer_xid,pending_operation_ordinal,pending_binding_revision,'/mappings/9',pending_mapping_bytes FROM truss.rel_def WHERE rel_type_id=:candidate_target::int",candidate_target=candidate_ids[1],extra_id=str(int(candidate_ids[1])+1))
  check('pending-source-candidate-extra-row-present',[[3]],c.run("SELECT count(*) FROM truss.rel_def WHERE definition_source_kind='operation_binding'"))
  refusal('pending-source-candidate-extra-row',source_query,{'code':'55000','message':'pending source candidate complete source cohort required'},r=rev)
  c.run('ROLLBACK TO SAVEPOINT pending_source_extra_fault');c.run('RELEASE SAVEPOINT pending_source_extra_fault')
  check('pending-source-candidate-extra-row-restored',original_state,archive_state())
  c.run('SAVEPOINT pending_source_document_fault');original_state=archive_state()
  c.run("UPDATE truss.schema_doc SET doc_revision='substituted-after-pending' WHERE rev=:r::int",r=rev)
  refusal('pending-source-candidate-original-document',source_query,{'code':'55000','message':'document carrier substitutes original admitted source bytes/order/identity'},r=rev)
  c.run('ROLLBACK TO SAVEPOINT pending_source_document_fault');c.run('RELEASE SAVEPOINT pending_source_document_fault')
  check('pending-source-candidate-original-document-restored',original_state,archive_state())
  refusal('pending-source-candidate-other-revision',source_query,{'code':'55000','message':'pending source candidate unpublished exclusion required'},r=str(int(rev)+1))
  effect_query='SELECT * FROM truss.runtime_collect_pending_association_effect_candidate(:r::int) ORDER BY family,identity::text'
  actual_effects=c.run(effect_query,r=rev)
  check('pending-effect-candidate-complete-new-row-count',[[len(actual_effects)]],c.run("SELECT (SELECT count(*) FROM truss.type_def WHERE since_rev=:r::int)+(SELECT count(*) FROM truss.prop_def WHERE since_rev=:r::int)+(SELECT count(*) FROM truss.key_def WHERE since_rev=:r::int)+(SELECT count(*) FROM truss.rel_def WHERE since_rev=:r::int)+(SELECT count(*) FROM truss.rel_endpoint e JOIN truss.rel_def r USING(rel_type_id) WHERE r.since_rev=:r::int)",r=rev))
  check('pending-effect-candidate-relationship-identities',[['relationship',[candidate_ids[i],'domain','m',name]] for i,name in enumerate(['Ownership','Assignment'])],sorted([row for row in actual_effects if row[0]=='relationship' and row[1][0] in candidate_ids],key=lambda row:int(row[1][0])))
  check('pending-effect-candidate-endpoint-identities',[['endpoint',[candidate_ids[i],native_types[source],native_types[target]]] for i,(source,target) in enumerate([('Resource','Project'),('Staff','Project')])],sorted([row for row in actual_effects if row[0]=='endpoint' and row[1][0] in candidate_ids],key=lambda row:int(row[1][0])))
  if authored_fixture:
   check('pending-effect-candidate-authored-identities-retained',[['endpoint',['1',native_types['Staff'],native_types['Project']]],['relationship',['1','domain','m','WorksWith']]],sorted([row for row in actual_effects if row[0] in ('relationship','endpoint') and row[1][0] not in candidate_ids]))
   c.run('SAVEPOINT authored_effect_fault');original_state=archive_state()
   c.run("UPDATE truss.rel_def SET directed=false WHERE rel_id='WorksWith'")
   refusal('pending-effect-candidate-authored-definition',effect_query,{'code':'55000','message':'stored original relationship definition correspondence'},r=rev)
   c.run('ROLLBACK TO SAVEPOINT authored_effect_fault');c.run('RELEASE SAVEPOINT authored_effect_fault')
   check('pending-effect-candidate-authored-definition-restored',original_state,archive_state())
  value_query='SELECT * FROM truss.runtime_collect_pending_association_value_candidate(:r::int) ORDER BY family,identity::text'
  physical_values=c.run(value_query,r=rev)
  check('pending-value-candidate-verified-identities',actual_effects,[[row[0],row[1]] for row in physical_values])
  tables={'type':'type_def','property':'prop_def','key':'key_def','relationship':'rel_def','endpoint':'rel_endpoint'}
  native_rows={family:c.run('SELECT to_jsonb(t) FROM truss.'+table+' t') for family,table in tables.items()}
  lineage_rows=c.run('SELECT to_jsonb(l) FROM truss.relationship_lineage l')
  independent_values=[]
  for family,identity in actual_effects:
   if family=='type':matches=[row[0] for row in native_rows[family] if str(row[0]['type_id'])==identity[0]]
   elif family=='property':matches=[row[0] for row in native_rows[family] if str(row[0]['prop_id'])==identity[0]]
   elif family=='key':matches=[row[0] for row in native_rows[family] if [str(row[0]['type_id']),row[0]['key_id'],str(row[0]['key_num'])]==identity]
   elif family=='endpoint':matches=[row[0] for row in native_rows[family] if [str(row[0]['rel_type_id']),str(row[0]['source_type']),str(row[0]['target_type'])]==identity]
   else:
    definitions=[row[0] for row in native_rows[family] if str(row[0]['rel_type_id'])==identity[0]]
    lineages=[row[0] for row in lineage_rows if str(row[0]['rel_type_id'])==identity[0]]
    matches=[{'definition':definition,'lineage':lineages[0] if lineages else None} for definition in definitions]
   if len(matches)!=1:raise ValueError('Independent full physical value bijection required')
   independent_values.append([family,identity,matches[0]])
  check('pending-value-candidate-complete-native-values',independent_values,physical_values)
  check('pending-value-candidate-native-order',physical_values,c.run('SELECT * FROM truss.runtime_collect_pending_association_value_candidate(:r::int)',r=rev))
  c.run('SAVEPOINT value_output_configuration');output_state=archive_state()
  c.run("SET LOCAL bytea_output='escape'")
  check('pending-value-candidate-bytea-output-invariant',physical_values,c.run(value_query,r=rev))
  check('pending-value-candidate-caller-output-restored',[['escape']],c.run('SHOW bytea_output'))
  c.run('ROLLBACK TO SAVEPOINT value_output_configuration');c.run('RELEASE SAVEPOINT value_output_configuration')
  check('pending-value-candidate-output-configuration-restored',output_state,archive_state())

  check('pending-value-candidate-readonly-generation',[[before_generation+4]],c.run('SELECT effect_generation FROM truss.row_home_operation'))
  refusal('ordinary-pending-value-candidate',value_query,{'code':'42501'},acting_role=True,r=rev)
  c.run('SAVEPOINT value_generation_fault');generation_state=archive_state()
  effect_definition_query="SELECT pg_get_functiondef('truss.runtime_collect_pending_association_effect_candidate(integer)'::regprocedure)"
  original_effect_definition=c.run(effect_definition_query)[0][0]
  emission='RETURN QUERY SELECT value->>'
  check('pending-value-candidate-generation-fault-single-site',1,original_effect_definition.count(emission))
  changed_effect_definition=original_effect_definition.replace(emission,"UPDATE truss.row_home_operation SET effect_generation=effect_generation+1 WHERE original_writer_xid=pg_current_xact_id_if_assigned();\n "+emission)
  c.run(changed_effect_definition)
  refusal('pending-value-candidate-generation-change',value_query,{'code':'55000','message':'pending association physical value generation changed'},r=rev)
  c.run('ROLLBACK TO SAVEPOINT value_generation_fault');c.run('RELEASE SAVEPOINT value_generation_fault')
  check('pending-value-candidate-generation-fault-full-restoration',generation_state,archive_state())
  check('pending-value-candidate-original-effect-definition-restored',[[original_effect_definition]],c.run(effect_definition_query))
  check('pending-value-candidate-generation-fault-restored-positive',physical_values,c.run(value_query,r=rev))
  child.stdin.write((json.dumps({'kind':'pendingReportBasis','revision':rev})+'\n').encode());child.stdin.flush()
  pending_packet=None;deadline=time.monotonic()+60
  while pending_packet is None:
   if time.monotonic()>deadline:raise TimeoutError('Bounded pending report bridge deadline')
   ready,_,_=select.select([child.stdout,child.stderr],[],[],min(1,deadline-time.monotonic()))
   for stream in ready:
    data=os.read(stream.fileno(),65536)
    if stream is child.stderr:
     if data:raise ValueError('Unexpected pending bridge stderr')
     continue
    if not data:raise ValueError('Pending bridge terminated without result')
    buffer+=data
    if len(buffer)>16777216:raise ValueError('Bounded pending bridge output')
    while b'\n' in buffer:
     line,buffer=buffer.split(b'\n',1);message=json.loads(line)
     if message['kind']!='query':pending_packet=message;break
     sql=message['sql'];params=message['parameters']
     if not isinstance(sql,str) or len(sql)>4096 or len(params)>2 or not all(isinstance(v,str) and len(v)<=16777216 for v in params):raise ValueError('Bounded pending report query')
     query_log.append({'sql':sql,'parametersSha256':sha(json.dumps(params,separators=(',',':')).encode())})
     try:
      converted=re.sub(r'\$(\d+)',lambda m:':p'+m[1],sql);rows=c.run(converted,**{'p'+str(i+1):v for i,v in enumerate(params)})
      cols=[column['name'] for column in c.columns] if c.columns else []
      response={'rows':[{name:str(v) for name,v in zip(cols,row)} for row in (rows or [])]}
     except pg8000.exceptions.DatabaseError as error:response={'error':error.args[0].get('C','unknown')}
     child.stdin.write((json.dumps(response)+'\n').encode());child.stdin.flush()
  if pending_packet.get('kind')!='pendingReportResult':raise ValueError(pending_packet.get('reason','Original pending report bridge unavailable'))
  child.stdin.close();check('bridge-exit',0,child.wait(timeout=5))
  check('pending-report-original-host-custody',{'copied':'Original bound pending report basis required','connection':'Original bound pending report basis required','preparation':'Original validated catalog preparation required','recognizedPreparation':'Original bound pending report basis required'},pending_packet['refusals'])
  check('pending-report-original-host-result-shape-refusals',{name:'Exact bounded original native report basis bytes required' for name in ['empty','duplicate','null','extra','uppercase','odd','nonhex','emptyHex','oversize']},pending_packet['shapeRefusals'])
  check('pending-report-original-host-revision-no-coercion',{name:{'message':'Original positive native revision required','sqlCalls':0} for name in ['numeric','boxed','coercion']},pending_packet['revisionRefusals'])
  check('pending-report-original-host-stale-native-basis','Native staging refusal 55000',pending_packet['staleRefusal'])
  check('pending-report-original-host-scope','original_pending_association_report_basis_only',pending_packet['basis']['scope'])
  check('pending-report-original-host-revision',rev,pending_packet['basis']['provisionalRevision'])
  basis_query="SELECT encode(truss.runtime_collect_pending_association_report_basis_candidate(:r::int),'hex')"
  basis_hex=c.run(basis_query,r=rev)[0][0];basis=json.loads(bytes.fromhex(basis_hex))
  check('pending-report-original-host-exact-bytes',basis_hex,pending_packet['basis']['originalBasisHex'])
  check('pending-report-basis-original-input',packet['originalInputHex'],basis['originalInputHex'])
  check('pending-report-basis-original-binding',binding_bytes.hex(),basis['originalBindingHex'])
  check('pending-report-basis-selected-values',[{'family':row[0],'identity':row[1],'physicalValue':row[2]} for row in physical_values],basis['metadataImage'])
  check('pending-report-basis-full-native-documents',[row[0] for row in c.run('SELECT to_jsonb(d) FROM truss.schema_doc d WHERE rev=:r::int ORDER BY ord',r=rev)],basis['documents'])
  check('pending-report-basis-actual-cut',actual_operation+[str(before_generation+4),rev],[basis['writerXid'],basis['operationOrdinal'],basis['effectGeneration'],basis['revision']])
  check('pending-report-basis-not-accepted-report',False,basis['acceptedReportQualified'])
  check('pending-report-basis-explicit-profile','truss-pending-association-report-basis-candidate/0.1.0',basis['profile'])
  check('pending-report-basis-original-packet-bytes',basis_hex,c.run(basis_query,r=rev)[0][0])
  check('pending-report-basis-original-packet-digest',sha(bytes.fromhex(basis_hex)),c.run("SELECT encode(sha256(truss.runtime_collect_pending_association_report_basis_candidate(:r::int)),'hex')",r=rev)[0][0])
  (out/'report-basis.json').write_text(json.dumps({'basisHex':basis_hex,'sha256':sha(bytes.fromhex(basis_hex)),'profile':basis['profile'],'scope':'private-unregistered-original-source-and-five-family-value-basis'},indent=2)+'\n')

  require_basis="SELECT truss.runtime_require_pending_association_report_basis_candidate(:r::int,decode(:b,'hex'))"
  check('pending-report-basis-current-positive',[['']],c.run(require_basis,r=rev,b=basis_hex))
  refusal('pending-report-basis-byte-substitution',require_basis,{'code':'55000','message':'current original pending association report basis correspondence required'},r=rev,b=(bytes.fromhex(basis_hex)+b' ').hex())
  refusal('pending-report-basis-empty',require_basis,{'code':'22023','message':'bounded original pending association report basis required'},r=rev,b='')
  refusal('pending-report-basis-null',require_basis,{'code':'22023','message':'bounded original pending association report basis required'},r=rev,b=None)
  refusal('pending-report-basis-argument-exact-limit',"SELECT truss.runtime_require_pending_association_report_basis_candidate(:r::int,decode(repeat('00',8388608),'hex'))",{'code':'55000','message':'current original pending association report basis correspondence required'},r=rev)
  refusal('pending-report-basis-argument-limit-over',"SELECT truss.runtime_require_pending_association_report_basis_candidate(:r::int,decode(repeat('00',8388609),'hex'))",{'code':'22023','message':'bounded original pending association report basis required'},r=rev)

  refusal('ordinary-pending-report-basis',basis_query,{'code':'42501'},acting_role=True,r=rev)
  refusal('ordinary-pending-report-basis-recheck',require_basis,{'code':'42501'},acting_role=True,r=rev,b=basis_hex)
  c.run('SAVEPOINT pending_report_generation_fault');report_state=archive_state()
  c.run('UPDATE truss.row_home_operation SET effect_generation=effect_generation+1')
  refusal('pending-report-basis-stale-generation',require_basis,{'code':'55000','message':'current original pending association report basis correspondence required'},r=rev,b=basis_hex)
  c.run('ROLLBACK TO SAVEPOINT pending_report_generation_fault');c.run('RELEASE SAVEPOINT pending_report_generation_fault')
  check('pending-report-basis-generation-restored',report_state,archive_state())
  check('pending-report-basis-restored-current-positive',[['']],c.run(require_basis,r=rev,b=basis_hex))
  c.run('SAVEPOINT pending_report_internal_generation');report_state=archive_state()
  value_definition_query="SELECT pg_get_functiondef('truss.runtime_collect_pending_association_value_candidate(integer)'::regprocedure)"
  original_value_definition=c.run(value_definition_query)[0][0]
  value_emission="RETURN QUERY SELECT v.value->>'family'"
  check('pending-report-basis-generation-single-value-site',1,original_value_definition.count(value_emission))
  c.run(original_value_definition.replace(value_emission,'UPDATE truss.row_home_operation SET effect_generation=effect_generation+1 WHERE original_writer_xid=pg_current_xact_id_if_assigned();\n '+value_emission))
  refusal('pending-report-basis-internal-generation-change',basis_query,{'code':'55000','message':'pending association report basis generation changed'},r=rev)
  c.run('ROLLBACK TO SAVEPOINT pending_report_internal_generation');c.run('RELEASE SAVEPOINT pending_report_internal_generation')
  check('pending-report-basis-internal-generation-full-restoration',report_state,archive_state())
  check('pending-report-basis-original-value-function-restored',[[original_value_definition]],c.run(value_definition_query))
  check('pending-report-basis-internal-generation-restored-positive',[['']],c.run(require_basis,r=rev,b=basis_hex))

  # Coherent changed source with identical mappings and physical values, retaining
  # the original generation: excluded installer drift, not new owner authority.
  changed_binding=json.loads(binding_bytes);changed_ontology=json.loads(base64.b64decode(changed_binding['ontologyArtifact']['bytesBase64']))
  changed_ontology['uninterpretedReportBasisControl']='retained-source-change'
  changed_ontology_bytes=json.dumps(changed_ontology,separators=(',',':')).encode()
  changed_binding['ontologyArtifact']['bytesBase64']=base64.b64encode(changed_ontology_bytes).decode()
  changed_binding['ontologyArtifact']['sha256']=sha(changed_ontology_bytes);changed_binding['ontologySha256']=sha(changed_ontology_bytes)
  changed_binding_bytes=json.dumps(changed_binding,separators=(',',':')).encode()
  if [json.dumps(m,separators=(',',':')).encode().hex() for m in changed_binding['mappings']]!=mapping_fragments:raise ValueError('Unchanged original mapping fragments required for source drift')
  changed_input=json.loads(bytes.fromhex(packet['originalInputHex']));changed_input['binding']['artifact']['bytesBase64']=base64.b64encode(changed_binding_bytes).decode();changed_input['binding']['artifact']['sha256']=sha(changed_binding_bytes)
  changed_input_bytes=json.dumps(changed_input,separators=(',',':')).encode()
  original_guard=c.run("SELECT pg_get_functiondef('truss.runtime_guard_operation_originals()'::regprocedure)")[0][0]
  source_definition_query="SELECT pg_get_functiondef('truss.runtime_collect_pending_association_source_candidate(integer)'::regprocedure)"
  original_source_definition=c.run(source_definition_query)[0][0]
  source_emission='EXCEPTION WHEN no_data_found OR too_many_rows THEN'
  check('pending-report-basis-interleaved-single-source-site',1,original_source_definition.count(source_emission))
  source_change=("UPDATE truss.row_home_operation SET original_input_bytes=decode('"+changed_input_bytes.hex()+"','hex'); "
   +"UPDATE truss.catalog_binding_archive SET original_input_bytes=decode('"+changed_input_bytes.hex()+"','hex'),original_binding_bytes=decode('"+changed_binding_bytes.hex()+"','hex') WHERE revision="+rev+"; "
   +"UPDATE truss.row_home_operation SET effect_generation="+str(before_generation+4)+"; "
   +"EXECUTE convert_from(decode('"+original_guard.encode().hex()+"','hex'),'UTF8'); ALTER TABLE truss.catalog_binding_archive ENABLE ALWAYS TRIGGER runtime_binding_archive_immutable; ")
  c.run('SAVEPOINT pending_report_source_drift');report_state=archive_state()
  c.run('CREATE OR REPLACE FUNCTION truss.runtime_guard_operation_originals() RETURNS trigger LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog,pg_temp AS $$BEGIN RETURN NEW; END;$$')
  c.run('ALTER TABLE truss.catalog_binding_archive DISABLE TRIGGER runtime_binding_archive_immutable')
  c.run(original_source_definition.replace(source_emission,"IF (SELECT original_input_bytes FROM truss.row_home_operation WHERE original_writer_xid=pg_current_xact_id_if_assigned())=decode('"+packet['originalInputHex']+"','hex') THEN "+source_change+" END IF;\n"+source_emission))
  refusal('pending-report-basis-interleaved-equal-generation-source-drift',basis_query,{'code':'55000','message':'pending association report basis original operation changed'},r=rev)
  c.run('ROLLBACK TO SAVEPOINT pending_report_source_drift');c.run('RELEASE SAVEPOINT pending_report_source_drift')
  check('pending-report-basis-interleaved-full-restoration',report_state,archive_state())
  check('pending-report-basis-interleaved-source-function-restored',[[original_source_definition]],c.run(source_definition_query))
  check('pending-report-basis-interleaved-operation-guard-restored',[[original_guard]],c.run("SELECT pg_get_functiondef('truss.runtime_guard_operation_originals()'::regprocedure)"))
  c.run('SAVEPOINT pending_report_aba_source');report_state=archive_state()
  c.run('CREATE OR REPLACE FUNCTION truss.runtime_guard_operation_originals() RETURNS trigger LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog,pg_temp AS $$BEGIN RETURN NEW; END;$$')
  c.run('ALTER TABLE truss.catalog_binding_archive DISABLE TRIGGER runtime_binding_archive_immutable')
  c.run("UPDATE truss.row_home_operation SET original_input_bytes=decode(:i,'hex')",i=changed_input_bytes.hex())
  c.run("UPDATE truss.catalog_binding_archive SET original_input_bytes=decode(:i,'hex'),original_binding_bytes=decode(:b,'hex') WHERE revision=:r::int",i=changed_input_bytes.hex(),b=changed_binding_bytes.hex(),r=rev)
  c.run('UPDATE truss.row_home_operation SET effect_generation=:g::bigint',g=str(before_generation+4));c.run(original_guard)
  c.run('ALTER TABLE truss.catalog_binding_archive ENABLE ALWAYS TRIGGER runtime_binding_archive_immutable')
  check('pending-report-basis-aba-same-cut',[basis['writerXid'],basis['operationOrdinal'],basis['effectGeneration']],c.run('SELECT original_writer_xid::text,operation_ordinal::text,effect_generation::text FROM truss.row_home_operation')[0])
  check('pending-report-basis-aba-same-values',physical_values,c.run(value_query,r=rev))
  changed_basis_hex=c.run(basis_query,r=rev)[0][0]
  check('pending-report-basis-aba-new-source-retained',changed_binding_bytes.hex(),json.loads(bytes.fromhex(changed_basis_hex))['originalBindingHex'])
  check('pending-report-basis-aba-new-source-current',[['']],c.run(require_basis,r=rev,b=changed_basis_hex))
  refusal('pending-report-basis-aba-old-source-refuses',require_basis,{'code':'55000','message':'current original pending association report basis correspondence required'},r=rev,b=basis_hex)
  c.run('ROLLBACK TO SAVEPOINT pending_report_aba_source');c.run('RELEASE SAVEPOINT pending_report_aba_source')
  check('pending-report-basis-aba-full-restoration',report_state,archive_state())
  check('pending-report-basis-aba-original-current',[['']],c.run(require_basis,r=rev,b=basis_hex))



  check('pending-effect-candidate-readonly-generation',[[before_generation+4]],c.run('SELECT effect_generation FROM truss.row_home_operation'))
  refusal('ordinary-pending-effect-candidate',effect_query,{'code':'42501'},acting_role=True,r=rev)
  for fault,mutation,message in [
   ('storage',"UPDATE truss.rel_def SET directed=false WHERE rel_type_id=:candidate_target::int",'pending association exact physical definition correspondence required'),
   ('owner',"UPDATE truss.rel_def SET assoc_type_id=(SELECT type_id FROM truss.type_def WHERE element='Staff') WHERE rel_type_id=:candidate_target::int",'pending association exact physical definition correspondence required'),
   ('name',"UPDATE truss.rel_def SET name='substituted-name' WHERE rel_type_id=:candidate_target::int",'pending association exact physical definition correspondence required'),
   ('orientation',"UPDATE truss.rel_endpoint SET source_type=target_type,target_type=source_type WHERE rel_type_id=:candidate_target::int",'pending association exact physical endpoint correspondence required'),
   ('missing-endpoint',"DELETE FROM truss.rel_endpoint WHERE rel_type_id=:candidate_target::int",'pending association exact physical endpoint correspondence required'),
   ('extra-endpoint',"INSERT INTO truss.rel_endpoint(rel_type_id,source_type,target_type) SELECT rel_type_id,target_type,target_type FROM truss.rel_endpoint WHERE rel_type_id=:candidate_target::int",'pending association exact physical endpoint correspondence required'),
   ('fabricated-lineage',"INSERT INTO truss.relationship_lineage(rel_type_id,lineage_category,identity_profile,original_identity_bytes) VALUES(:candidate_target::int,'authored','excluded-installer-fabrication',decode('abcd','hex'))",'pending association exact physical definition correspondence required'),
   ('core-field',"UPDATE truss.prop_def SET scalar_type='integer' WHERE prop_id=(SELECT min(prop_id) FROM truss.prop_def)",'stored original Field definition correspondence')]:
   c.run('SAVEPOINT pending_effect_fault');original_state=archive_state();c.run(mutation,candidate_target=candidate_ids[1])
   if fault in ('extra-endpoint','fabricated-lineage'):
    check('pending-effect-candidate-'+fault+'-source-custody-still-positive',allocated,c.run('SELECT mapping_pointer,relationship_id FROM truss.runtime_collect_pending_association_source_candidate(:r::int)',r=rev))
   refusal('pending-effect-candidate-'+fault,effect_query,{'code':'55000','message':message},r=rev)
   refusal('pending-value-candidate-'+fault,value_query,{'code':'55000','message':message},r=rev)
   c.run('ROLLBACK TO SAVEPOINT pending_effect_fault');c.run('RELEASE SAVEPOINT pending_effect_fault')
   check('pending-effect-candidate-'+fault+'-restored',original_state,archive_state())
  refusal('pending-candidate-complete-inventory-closed','SELECT * FROM truss.runtime_collect_new_catalog_inventory(:r::int)',{'code':'0A000','message':'registered binding effect inventory required'},r=rev)
  refusal('pending-candidate-repeat-source-closed','SELECT * FROM truss.runtime_stage_pending_association_candidate(:r::int)',{'code':'55000','message':'unique original declaration required'},r=rev)
  refusal('pending-candidate-finalizer-closed','SET CONSTRAINTS truss.runtime_operation_commit_barrier IMMEDIATE',{'code':'55000','message':'complete runtime finalizer is not installed'})
  c.run('ROLLBACK TO SAVEPOINT pending_candidate_batch');c.run('RELEASE SAVEPOINT pending_candidate_batch');check('pending-candidate-batch-restored',baseline,archive_state())
  refusal('ordinary-pending-candidate-stage','SELECT * FROM truss.runtime_stage_pending_association_candidate(:r::int)',{'code':'42501'},acting_role=True,r=rev)
  # Excluded installer paired-source fixtures, not newly issued owner authority.
  for label,positive,expected_error in [
   ('second-storage',False,{'code':'0A000','message':'original binary association mapping subset required'}),
   ('second-role-alias',False,{'code':'55000','message':'unique original association dependency required'}),
   ('association-key-alias',False,{'code':'55000','message':'original association declaration correspondence required'}),
   ('entity-key-alias',False,{'code':'55000','message':'original association target key correspondence required'}),
   ('unused-entity-duplicate',False,{'code':'55000','message':'duplicate original entity identity'}),
   ('unused-entity-malformed',False,{'code':'22023','message':'qualified original association reference required'}),
   ('unknown-ontology-content',True,None),
   ('unknown-ontology-nul',False,{'code':'0A000','message':'native ontology unique-key parser profile unavailable'})]+([
   ('association-fields-reversed',False,{'code':'55000','message':'original association endpoint correspondence required'}),
   ('target-fields-reversed',False,{'code':'55000','message':'original ordered endpoint key correspondence required'})] if composite_fixture else []):
   fixture=json.loads(binding_bytes);ontology=json.loads(base64.b64decode(fixture['ontologyArtifact']['bytesBase64']))
   if label=='association-fields-reversed':fixture['mappings'][1]['roles'][0]['associationFields'].reverse()
   elif label=='target-fields-reversed':fixture['mappings'][1]['roles'][0]['targetFields'].reverse()
   elif label=='second-storage':fixture['mappings'][1]['storage']['directed']=False
   elif label=='second-role-alias':
    ontology['associations'][1]['endpoints'][0]['role']=True;fixture['mappings'][1]['roles'][0]['role']='true';fixture['mappings'][1]['sourceRole']='true'
   elif label=='association-key-alias':ontology['associations'][1]['keyId']=True;fixture['mappings'][1]['instanceKeyId']='true'
   elif label=='entity-key-alias':ontology['entities'][0]['keyId']=True;fixture['mappings'][1]['roles'][0]['targetKeyId']='true'
   elif label=='unused-entity-duplicate':
    unused={'type':{'documentId':'domain','moduleId':'m','elementId':'unused'},'keyId':'pk','fields':[]};ontology['entities'] += [unused,unused]
   elif label=='unused-entity-malformed':ontology['entities'].append({'type':{'documentId':'domain','moduleId':'m','elementId':False},'keyId':'pk'})
   original_ontology=json.dumps(ontology,separators=(',',':')).encode()
   if label=='unknown-ontology-content':original_ontology=original_ontology[:-1]+b',"unknownNumber":1e999999999999999999}'
   if label=='unknown-ontology-nul':original_ontology=original_ontology[:-1]+b',"unknownString":"\\u0000"}'
   fixture['ontologyArtifact']['bytesBase64']=base64.b64encode(original_ontology).decode();fixture['ontologyArtifact']['sha256']=sha(original_ontology);fixture['ontologySha256']=sha(original_ontology)
   original_binding=json.dumps(fixture,separators=(',',':')).encode();original_input=json.loads(bytes.fromhex(packet['originalInputHex']));original_input['binding']['artifact']['bytesBase64']=base64.b64encode(original_binding).decode();original_input['binding']['artifact']['sha256']=sha(original_binding);original_input=json.dumps(original_input,separators=(',',':')).encode()
   baseline=archive_state();c.run('SAVEPOINT paired_candidate_source')
   original_guard=c.run("SELECT pg_get_functiondef('truss.runtime_guard_operation_originals()'::regprocedure)")[0][0]
   c.run('CREATE OR REPLACE FUNCTION truss.runtime_guard_operation_originals() RETURNS trigger LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog,pg_temp AS $$BEGIN RETURN NEW; END;$$');c.run('ALTER TABLE truss.catalog_binding_archive DISABLE TRIGGER runtime_binding_archive_immutable')
   c.run("UPDATE truss.row_home_operation SET original_input_bytes=decode(:h,'hex')",h=original_input.hex())
   c.run("UPDATE truss.catalog_binding_archive SET original_input_bytes=decode(:i,'hex'),original_binding_bytes=decode(:b,'hex') WHERE revision=:r::int",i=original_input.hex(),b=original_binding.hex(),r=rev)
   c.run(original_guard);c.run('ALTER TABLE truss.catalog_binding_archive ENABLE ALWAYS TRIGGER runtime_binding_archive_immutable')
   check('candidate-paired-'+label+'-original-guard-body',[[original_guard]],c.run("SELECT pg_get_functiondef('truss.runtime_guard_operation_originals()'::regprocedure)"))
   check('candidate-paired-'+label+'-guards-restored',[['runtime_binding_archive_immutable','A'],['runtime_operation_originals','A']],c.run("SELECT tgname,tgenabled FROM pg_trigger WHERE tgname IN ('runtime_binding_archive_immutable','runtime_operation_originals') ORDER BY tgname"))
   if positive:
    check('candidate-paired-'+label+'-retained',[[f'/mappings/{i}',candidate_ids[i]] for i in range(2)],c.run('SELECT * FROM truss.runtime_stage_pending_association_candidate(:r::int)',r=rev))
    check('candidate-paired-'+label+'-original-ontology',[[original_binding.hex()]],c.run("SELECT encode(original_binding_bytes,'hex') FROM truss.catalog_binding_archive WHERE revision=:r::int",r=rev))
   else:refusal('candidate-paired-'+label,'SELECT * FROM truss.runtime_stage_pending_association_candidate(:r::int)',expected_error,r=rev)
   if label in ('association-fields-reversed','target-fields-reversed'):
    resolver_query="SELECT pg_get_functiondef('truss.runtime_resolve_pending_association_candidate(integer,bytea)'::regprocedure)"
    original_resolver=c.run(resolver_query)[0][0]
    if label=='association-fields-reversed':
     ordered="(endpoint->'fields')::jsonb IS DISTINCT FROM role->'associationFields'"
     erased="NOT ((endpoint->'fields')::jsonb @> (role->'associationFields') AND (role->'associationFields') @> (endpoint->'fields')::jsonb)"
    else:
     ordered='k.prop_ids=target_fields';erased='k.prop_ids @> target_fields AND k.prop_ids <@ target_fields'
    check('candidate-paired-'+label+'-single-comparison-erasure',1,original_resolver.count(ordered))
    c.run('SAVEPOINT order_erasure_mutant');mutant_state=archive_state()
    c.run(original_resolver.replace(ordered,erased))
    check('candidate-paired-'+label+'-erased-order-admits',[[f'/mappings/{i}',candidate_ids[i]] for i in range(2)],c.run('SELECT * FROM truss.runtime_stage_pending_association_candidate(:r::int)',r=rev))
    check('candidate-paired-'+label+'-erased-order-exact-native-rows',[[candidate_ids[i],f'/mappings/{i}',json.dumps(fixture['mappings'][i],separators=(',',':')).encode().hex()] for i in range(2)],c.run("SELECT rel_type_id::text,pending_mapping_pointer,encode(pending_mapping_bytes,'hex') FROM truss.rel_def WHERE definition_source_kind='operation_binding' ORDER BY rel_type_id"))
    c.run('ROLLBACK TO SAVEPOINT order_erasure_mutant');c.run('RELEASE SAVEPOINT order_erasure_mutant')
    check('candidate-paired-'+label+'-erased-order-full-restoration',mutant_state,archive_state())
    check('candidate-paired-'+label+'-original-resolver-restored',[[original_resolver]],c.run(resolver_query))
    refusal('candidate-paired-'+label+'-restored-order-refuses','SELECT * FROM truss.runtime_stage_pending_association_candidate(:r::int)',expected_error,r=rev)
   c.run('ROLLBACK TO SAVEPOINT paired_candidate_source');c.run('RELEASE SAVEPOINT paired_candidate_source');check('candidate-paired-'+label+'-restored',baseline,archive_state())
  check('pending-native-column-types-and-collation',[['pending_binding_revision','int4',None],['pending_mapping_bytes','bytea',None],['pending_mapping_pointer','text','C'],['pending_operation_ordinal','int8',None],['pending_writer_xid','xid8',None]],c.run("SELECT a.attname,t.typname,coll.collname FROM pg_attribute a JOIN pg_type t ON t.oid=a.atttypid LEFT JOIN pg_collation coll ON coll.oid=a.attcollation WHERE a.attrelid='truss.rel_def'::regclass AND a.attname LIKE 'pending_%' AND NOT a.attisdropped ORDER BY a.attname"))
  native_op=c.run('SELECT original_writer_xid::text,operation_ordinal::text FROM truss.row_home_operation')[0]
  association_id=c.run("SELECT type_id::text FROM truss.type_def WHERE document_id='domain' AND module='m' AND element='Assignment'")[0][0]
  mapping_hex=mapping_fragments[1]
  shape_id=str(int(c.run('SELECT coalesce(max(rel_type_id),0) FROM truss.rel_def')[0][0])+1)
  base={'document_id':'domain','rel_type_id':shape_id,'module':'m','rel_id':'Assignment','name':'Assignment','source_min':'0','source_max':None,'target_min':'0','target_max':None,'lifecycle':'independent','directed':True,'target_key':'pk','composition':False,'assoc_type_id':association_id,'since_rev':rev,'doc_ord':'0','definition_source_kind':'operation_binding','pending_writer_xid':native_op[0],'pending_operation_ordinal':native_op[1],'pending_binding_revision':rev,'pending_mapping_pointer':'/mappings/1','pending_mapping_bytes':mapping_hex}
  types={'rel_type_id':'int','source_min':'int','source_max':'int','target_min':'int','target_max':'int','directed':'boolean','composition':'boolean','assoc_type_id':'int','since_rev':'int','doc_ord':'int','pending_writer_xid':'xid8','pending_operation_ordinal':'bigint','pending_binding_revision':'int','definition_rev':'int','definition_doc_ord':'int','binding_source_rev':'int'}
  def pending_insert(values):
   cols=list(values);expr=[("decode(:"+name+"::text,'hex')" if name in ('pending_mapping_bytes','binding_source_bytes') else ':'+name+'::'+types.get(name,'text')) for name in cols]
   return 'INSERT INTO truss.rel_def('+','.join(cols)+') VALUES('+','.join(expr)+') RETURNING definition_source_kind'
  c.run('SAVEPOINT pending_positive')
  generation=c.run('SELECT effect_generation FROM truss.row_home_operation')[0][0]
  check('pending-shape-complete-original-row',[['operation_binding']],c.run(pending_insert(base),**base))
  check('pending-shape-native-custody',[[*native_op,rev,'/mappings/1',mapping_hex,association_id]],c.run("SELECT pending_writer_xid::text,pending_operation_ordinal::text,pending_binding_revision::text,pending_mapping_pointer,encode(pending_mapping_bytes,'hex'),assoc_type_id::text FROM truss.rel_def WHERE rel_type_id=:shape_id::int",shape_id=shape_id))
  check('pending-shape-observed-generation',[[generation+1]],c.run('SELECT effect_generation FROM truss.row_home_operation'))
  refusal('pending-complete-inventory-still-unregistered','SELECT * FROM truss.runtime_collect_new_catalog_inventory(:r::int)',{'code':'0A000','message':'registered binding effect inventory required'},r=rev)
  refusal('pending-source-observer-not-reusable',"SELECT truss.runtime_collect_original_association_mapping(:r::int,'/mappings/1')",{'code':'55000','message':'unique original declaration required'},r=rev)
  refusal('pending-current-commit-barrier-still-closed','SET CONSTRAINTS truss.runtime_operation_commit_barrier IMMEDIATE',{'code':'55000','message':'complete runtime finalizer is not installed'})
  refusal('ordinary-pending-read','SELECT * FROM truss.rel_def',{'code':'42501'},acting_role=True)
  c.run('ROLLBACK TO SAVEPOINT pending_positive');c.run('RELEASE SAVEPOINT pending_positive');check('pending-shape-positive-restored',baseline,archive_state())
  faults=[(name+'-missing',{name:None},'23514','rel_def_definition_source_complete') for name in ['pending_writer_xid','pending_operation_ordinal','pending_binding_revision','pending_mapping_pointer','pending_mapping_bytes','assoc_type_id']]
  faults += [('missing-kind',{'definition_source_kind':None},'23514','rel_def_definition_source_complete'),('absent-writer',{'pending_writer_xid':'1'},'23503','rel_def_pending_operation_fk'),('empty-pointer',{'pending_mapping_pointer':''},'23514','rel_def_definition_source_complete'),('oversized-pointer',{'pending_mapping_pointer':'x'*4097},'23514','rel_def_definition_source_complete'),('empty-fragment',{'pending_mapping_bytes':''},'23514','rel_def_definition_source_complete'),('oversized-fragment',{'pending_mapping_bytes':'01'*1048577},'23514','rel_def_definition_source_complete'),('mixed-document-source',{'definition_rev':rev,'definition_doc_ord':'0','definition_document_id':'domain'},'23514','rel_def_definition_source_complete'),('mixed-accepted-binding',{'binding_source_rev':rev,'binding_source_pointer':'/mappings/1','binding_source_bytes':'01'},'23514','rel_def_definition_source_complete'),('premature-accepted-kind',{'definition_source_kind':'accepted_binding'},'23514','rel_def_definition_source_complete'),('unknown-kind',{'definition_source_kind':'unknown'},'23514','rel_def_definition_source_complete'),('nonpositive-pending-revision',{'pending_binding_revision':'0'},'23514','rel_def_definition_source_complete'),('negative-ordinal',{'pending_operation_ordinal':'-1'},'23514','rel_def_definition_source_complete'),('absent-operation',{'pending_operation_ordinal':'999'},'23503','rel_def_pending_operation_fk')]
  for label,changes,code,constraint in faults:
   values={**base,**changes};refusal('pending-shape-'+label,pending_insert(values),{'code':code,'constraint':constraint},**values)
  c.run('SAVEPOINT pending_missing_archive')
  c.run('ALTER TABLE truss.catalog_binding_archive DISABLE TRIGGER runtime_binding_archive_immutable')
  c.run('DELETE FROM truss.catalog_binding_archive WHERE revision=:r::int',r=rev)
  c.run('ALTER TABLE truss.catalog_binding_archive ENABLE ALWAYS TRIGGER runtime_binding_archive_immutable')
  refusal('pending-shape-absent-original-archive',pending_insert(base),{'code':'23503','constraint':'rel_def_pending_binding_fk'},**base)
  c.run('ROLLBACK TO SAVEPOINT pending_missing_archive');c.run('RELEASE SAVEPOINT pending_missing_archive');check('pending-missing-archive-restored',baseline,archive_state())
  check('pending-missing-archive-guard-restored',[['A']],c.run("SELECT tgenabled::text FROM pg_trigger WHERE tgrelid='truss.catalog_binding_archive'::regclass AND tgname='runtime_binding_archive_immutable'"))
  c.run('SAVEPOINT pending_revision_equality')
  # Excluded installer document fixture makes the legacy since_rev/doc_ord FK
  # independently valid at revision zero; it is not accepted catalog history.
  c.run('INSERT INTO truss.schema_doc SELECT 0,ord,doc_id,doc_revision,umf_version,content_sha256,document,validation FROM truss.schema_doc WHERE rev=:r::int',r=rev)
  unequal={**base,'since_rev':'0'}
  refusal('pending-shape-positive-archive-revision-must-match-since',pending_insert(unequal),{'code':'23514','constraint':'rel_def_definition_source_complete'},**unequal)
  c.run('ROLLBACK TO SAVEPOINT pending_revision_equality');c.run('RELEASE SAVEPOINT pending_revision_equality');check('pending-revision-equality-fixture-restored',baseline,archive_state())
  refusal('ordinary-pending-insert',pending_insert(base),{'code':'42501'},acting_role=True,**base)
  for kind,source in [('accepted_document',{'definition_rev':rev,'definition_doc_ord':'0','definition_document_id':'domain'}),('accepted_binding',{'binding_source_rev':rev,'binding_source_pointer':'/mappings/1','binding_source_bytes':'01'})]:
   c.run('SAVEPOINT original_source_shape');values={**base,**{name:None for name in ['pending_writer_xid','pending_operation_ordinal','pending_binding_revision','pending_mapping_pointer','pending_mapping_bytes']},**source,'definition_source_kind':kind}
   check('original-'+kind+'-shape-preserved',[[kind]],c.run(pending_insert(values),**values))
   c.run('ROLLBACK TO SAVEPOINT original_source_shape');c.run('RELEASE SAVEPOINT original_source_shape');check('original-'+kind+'-shape-restored',baseline,archive_state())
   for name in ['pending_writer_xid','pending_operation_ordinal','pending_binding_revision','pending_mapping_pointer','pending_mapping_bytes']:
    mixed={**values,name:base[name]}
    refusal('original-'+kind+'-rejects-single-'+name,pending_insert(mixed),{'code':'23514','constraint':'rel_def_definition_source_complete'},**mixed)
  check('pending-source-tests-whole-restored',baseline,archive_state())
 c.run('ROLLBACK');check('rollback-prior-archive-preserved',prior_archive,c.run('SELECT to_jsonb(a) FROM truss.catalog_binding_archive a ORDER BY revision'));check('rollback-catalog',[[0,0,0,0,1 if occupied else 0]],c.run('SELECT (SELECT count(*) FROM truss.type_def),(SELECT count(*) FROM truss.prop_def),(SELECT count(*) FROM truss.key_def),(SELECT count(*) FROM truss.schema_doc),(SELECT count(*) FROM truss.catalog_binding_archive)'))
 phase='source-current';check('source-pins-current',True,all(Path(p).read_bytes()==b for p,b in frozen.items()))
 receipt={'status':'pass','observations':checks,'sourceSha256':pins,'queryLog':query_log,'result':packet,'dependencies':{m['name']:m['version'] for m in dependencies.values()},'scope':'Installer-only original owner cohort and provisional operation-linked binding byte custody, rollback-only','bindingKind':'opaque-binary' if '--opaque' in sys.argv else 'original-association-candidate','occupiedInstallerFixture':occupied,'authoredCoexistenceInstallerFixture':authored_fixture,'compositeKeyInstallerFixture':composite_fixture,'pendingSourceShapeControls':pending_layout,'unregisteredPendingStagingCandidate':pending_layout,'pendingLayoutAdopted':False,'acceptancePromoted':False,'limitations':['Authored coexistence and composite-key selections, when enabled, are explicit source fixtures validated by the original UMF producer; it is not newly owner-issued ontology meaning. Synthetic operation admission artifacts; original prestate is actual native capture but no authenticated owner/issuer/current cut or accepted-report custody','Pending layout controls and original-source physical metadata staging are excluded installer candidates; no registered producer, accepted association lineage, native data authority, complete inventory/report/promotion/post-head publication; native fields are bounded to 256 and escaped NUL ontology content receives an explicit unsupported-parser refusal','RPC adapter, not whole installed public runtime/driver; pgserver startup/cleanup uses a single-handle subclass with a test-private mutex/socket directory and captured implementation sources','Captured declared Ajv JS/JSON closure; native runtime versions observed, not whole installed package qualification']}

except Exception as error:
 (out/'failure.json').write_text(json.dumps({'status':'fail','phase':phase,'reason':str(error),'observations':checks,'sourceSha256':pins,'queryLog':query_log},indent=2)+'\n');print(json.dumps({'status':'fail','receipt':str(out/'failure.json'),'phase':phase,'reason':str(error)}));raise
finally:
 cleanup_errors=[]
 def cleanup(name,action):
  try:action()
  except Exception:cleanup_errors.append(name)
 if child:
  if child.poll() is None:cleanup('child-kill',child.kill);cleanup('child-reap',lambda:child.wait(timeout=5))
  for stream in [child.stdin,child.stdout,child.stderr]:
   if stream:cleanup('child-stream',stream.close)
 if c:cleanup('connection',c.close)
 if server:cleanup('server',server.cleanup)
 if temporary:cleanup('temporary',temporary.cleanup)
 if bridge.exists():cleanup('execution-copy',lambda:shutil.rmtree(bridge))
 if cleanup_errors:
  (out/'cleanup-failure.json').write_text(json.dumps({'status':'fail','cleanup':cleanup_errors})+'\n')
  raise RuntimeError('Required cleanup failed')
receipt['cleanup']='all-required-actions-completed'
(out/'native.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':'pass','receipt':str(out/'native.json'),'observations':len(checks)}))
