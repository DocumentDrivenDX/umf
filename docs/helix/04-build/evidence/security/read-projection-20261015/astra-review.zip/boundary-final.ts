import {catalogRuntimeFixture} from '/Users/erik/.codex/worktrees/security-main-integration/umf/tests/security/catalog-runtime-fixture';
import {compileCandidateCatalogProgram} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-program-candidate';
import {inspectCandidateReadProjection} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/read-projection-candidate';
const f:any=catalogRuntimeFixture();f.owner.disclosure={readAction:'read'};for(const r of f.policy.rules)r.actions=['update'];
const field=f.closure.documents[0].document.modules[0].elements.find((x:any)=>x.id==='salary');field.description='x'.repeat(30_000);
const p=compileCandidateCatalogProgram(f.policy,f.catalog,f.closure,f.ontology),selection={type:{documentId:'domain',moduleId:'m',elementId:'Resource'},field:{documentId:'domain',moduleId:'m',elementId:'salary'}};
const base:any=inspectCandidateReadProjection(p,f.owner,selection);if(base.status!=='inspected')throw Error('baseline failed');
const charge=(r:any)=>[...r.domains,...r.alternatives,r.sources,r.composition].reduce((s:number,v:any)=>s+JSON.stringify(v).length+2,0);
const initial=charge(base),n=4_000_000-JSON.stringify(base).length+f.owner.revision.length;
const rows=[];
for(const delta of [-3_000_000,-1,0,1]){f.owner.revision='r'.repeat(n+delta);const r:any=inspectCandidateReadProjection(p,f.owner,selection);rows.push({delta,status:r.status,jsonLength:JSON.stringify(r).length,charged:r.status==='inspected'?charge(r):null,ownerRevisionLength:f.owner.revision.length});}

const malformed:any=inspectCandidateReadProjection(p,f.owner,{type:{documentId:'d'.repeat(4_000_001)},unexpected:'x'.repeat(4_000_001)});
if(malformed.status!=='refused'||malformed.selection!==null||JSON.stringify(malformed).length>4_000_000)throw Error('Refusal echo escaped');
if(rows.slice(0,3).some(x=>x.status!=='inspected')||rows[2].jsonLength!==4_000_000||rows[3].status!=='refused')throw Error('Exact framing boundary failed');
console.log(JSON.stringify({initial,baseBytes:JSON.stringify(base).length,rows,malformed:{status:malformed.status,selection:malformed.selection,jsonLength:JSON.stringify(malformed).length}}));
