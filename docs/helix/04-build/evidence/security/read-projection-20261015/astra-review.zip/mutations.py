from pathlib import Path
import hashlib,json,re,subprocess
p=Path(__file__).resolve().parent;root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');path=root/'src/extensions/security/read-projection-candidate.ts';source=path.read_text();sha=lambda b:hashlib.sha256(b).hexdigest();before=sha(path.read_bytes());folder=p/'mutants';folder.mkdir(exist_ok=True)
variants=[
 ('whole-owner-validation','const storage=validateCandidateCatalogStorage(program,owner,()=>budget.step());','const storage=new Map(owner.storage.map((entry:any)=>[JSON.stringify([id(entry.type),id(entry.field)]),entry]));','controls.ts','unrelated-storage-downgrade-refuses'),
 ('drop-forbid-require-conditions','conditions.push(retain(','if(rule.effect===\'permit\')conditions.push(retain(','controls.ts','false-exact-condition-population'),
 ('filter-false-contributors','conditions.push(retain(','if(rule.condition.op===\'literal\'&&rule.condition.value===false)continue;conditions.push(retain(','controls.ts','false-exact-permit-population'),
 ('stored-original-to-prestorage',"disposition.kind==='original'?{kind:'original',field:s.field}","disposition.kind==='original'?{kind:'original',field:own.storageTransform?program.catalog.transforms.find((t:any)=>t.id===own.storageTransform.id).inputDomain:s.field}",'controls.ts','tokenize-live-token-only'),
 ('withheld-to-original',":{kind:'withheld'};",":{kind:'original',field:s.field};",'controls.ts','false-projection-origins'),
 ('omit-final-framing',"if(JSON.stringify(result).length>4_000_000)fail();",'','boundary-final.ts','Exact framing boundary failed'),
 ('echo-refused-selection','selection:null,sources:null','selection,sources:null','boundary-final.ts','Refusal echo escaped')]
results=[]
for name,old,new,runner,error in variants:
 assert source.count(old)==1,(name,'selector count',source.count(old));changed=source.replace(old,new)
 changed=re.sub(r"from '([^']+)'",lambda m:"from '"+str((path.parent/m.group(1)).resolve())+"'" if m.group(1).startswith('.') else m.group(0),changed)
 module=folder/(name+'.ts');module.write_text(changed);test=(p/runner).read_text().replace(str(path.with_suffix('')),str(module.with_suffix('')));runfile=folder/(name+'-runner.ts');runfile.write_text(test)
 proc=subprocess.run(['/opt/homebrew/bin/bun',str(runfile)],capture_output=True,text=True);log=proc.stdout+proc.stderr;(folder/(name+'.log')).write_text(log)
 detected=proc.returncode!=0 and 'error: '+error in log
 results.append({'name':name,'sourceSelector':old,'replacement':new,'mutantSha256':sha(module.read_bytes()),'runnerSha256':sha(runfile.read_bytes()),'exit':proc.returncode,'expectedFailure':error,'detected':detected});assert detected,(name,log)
assert sha(path.read_bytes())==before
(p/'mutations.json').write_text(json.dumps({'status':'passed','currentSourceSha256':before,'count':len(results),'results':results,'scope':'Seven exact private helper weakenings executed in Bun with original dependency imports; integration checkout unchanged.'},indent=2)+'\n');print(json.dumps({'detected':len(results)}))
