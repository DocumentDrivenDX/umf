import {catalogRuntimeFixture,graphRuntimeFixture} from '/Users/erik/.codex/worktrees/security-main-integration/umf/tests/security/catalog-runtime-fixture';
import {storedWriteFixture} from '/Users/erik/.codex/worktrees/security-main-integration/umf/tests/security/catalog-write-fixture';
import {compileCandidateCatalogProgram} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-program-candidate';
import {inspectCandidateReadProjection} from '/private/tmp/read-projection-astra-20261015/mutants/whole-owner-validation';
const ref=(elementId:string)=>({documentId:'domain',moduleId:'m',elementId});
const rows:any[]=[];const check=(name:string,expected:any,observed:any)=>{const passed=JSON.stringify(expected)===JSON.stringify(observed);rows.push({name,expected,observed,passed});if(!passed)throw Error(name)};
const make=(g=false)=>{const f:any=g?graphRuntimeFixture():catalogRuntimeFixture();f.owner.disclosure={readAction:'read'};return f};
const compile=(f:any,bindings:any[]=[])=>compileCandidateCatalogProgram(f.policy,f.catalog,f.closure,f.ontology,bindings);
const inspect=(f:any,field='salary',bindings:any[]=[])=>inspectCandidateReadProjection(compile(f,bindings),f.owner,{type:ref('Resource'),field:ref(field)}) as any;
for(const graph of [false,true]){
 const f=make(graph),a=structuredClone(f.policy.rules[0]);f.policy.rules=[
 {...a,id:'original',condition:{op:'literal',value:false},disclosure:[{field:ref('salary'),disposition:{kind:'original'}}]},
 {...a,id:'mask1',condition:{op:'literal',value:true},disclosure:[{field:ref('salary'),disposition:{kind:'transformed',transform:'constant',version:'0.1.0',field:ref('salary'),value:{integerToken:'0'}}}]},
 {...a,id:'withheld',condition:{op:'literal',value:false},disclosure:[{field:ref('salary'),disposition:{kind:'withheld'}}]},
 {...a,id:'missing',condition:{op:'literal',value:true},disclosure:[]},
 {id:'forbid',effect:'forbid',actions:['read'],target:[ref('Resource')],condition:{op:'literal',value:false}},
 {id:'require',effect:'require',actions:['read'],target:[ref('Resource')],condition:{op:'literal',value:true}},
 {...a,id:'wrong-action',actions:['update']},
 {...a,id:'wrong-target',target:[ref('Project')],disclosure:[]}
 ];
 const binding=[{ruleId:'original',target:ref('Resource'),context:{resource:{association:graph?{documentId:'domain',moduleId:'m',relationshipId:'OwnedBy'}:ref('Ownership'),endpoint:'resource'}}}];
 const r=inspect(f,'salary',binding);
 check(`${graph}-exact-permit-population`,[0,1,2,3],r.alternatives.map((x:any)=>x.ruleIndex));
 check(`${graph}-exact-condition-population`,[0,1,2,3,4,5],r.composition.readConditions.map((x:any)=>x.ruleIndex));
 check(`${graph}-no-false-rule-filter`,{op:'literal',value:false},r.composition.readConditions[0].condition);
 check(`${graph}-context-retained`,binding[0].context,r.composition.readConditions[0].contextBindings);
 check(`${graph}-projection-origins`,[{kind:'original',field:ref('salary')},{kind:'transformed',field:ref('salary')},{kind:'withheld'},{kind:'unresolved-missing-disclosure'}],r.alternatives.map((x:any)=>x.projection));
 check(`${graph}-complete-original-dispositions`,f.policy.rules.slice(0,4).map((x:any)=>x.disclosure[0]?.disposition??null),r.alternatives.map((x:any)=>x.disposition));
 check(`${graph}-not-permit`,['inspected',false,false],[r.status,r.complete,r.authority]);
 check(`${graph}-original-complete-Field`,f.closure.documents[0].document.modules[0].elements.find((x:any)=>x.id==='salary'),r.domains[0].element);
 const copy=JSON.stringify(r);f.owner.id='changed';f.policy.rules[0].condition.value=true;check(`${graph}-detached`,copy,JSON.stringify(r));
 check(`${graph}-deep-frozen`,true,Object.isFrozen(r.alternatives[0].disposition)&&Object.isFrozen(r.domains[0].element)&&Object.isFrozen(r.composition.readConditions[0].contextBindings));
}
{
 const f:any=storedWriteFixture();f.owner.disclosure={readAction:'read'};f.policy.rules[0].disclosure.push({field:ref('token'),disposition:{kind:'original'}});
 for(const kind of ['tokenize','encrypt']){f.catalog.transforms[0].kind=kind;const r=inspect(f,'token');check(kind+'-live-token-only',[{kind:'original',field:ref('token')}],r.alternatives.map((x:any)=>x.projection));check(kind+'-no-plaintext-domain',['token'],r.domains.map((d:any)=>d.field.elementId));check(kind+'-stored-tag','stored-transformed',r.sources.storageEffect);}
 const p=compile(f);f.owner.storage.find((e:any)=>e.field.elementId==='token').storageEffect='canonical';delete f.owner.storage.find((e:any)=>e.field.elementId==='token').storageTransform;
 check('unrelated-storage-downgrade-refuses','refused',inspectCandidateReadProjection(p,f.owner,{type:ref('Resource'),field:ref('salary')}).status);
}
{
 const f=make(),p=compile(f),s={type:ref('Resource'),field:ref('salary')};
 for(const [name,mutate]of [ ['wrong-read-purpose',(o:any)=>o.disclosure.readAction='update'],['missing-unrelated-storage',(o:any)=>o.storage.pop()],['duplicate-storage',(o:any)=>o.storage.push(o.storage[0])],['unknown-owner-member',(o:any)=>o.callerPermit=true] ] as const){const o=structuredClone(f.owner);mutate(o);const r=inspectCandidateReadProjection(p,o,s);check(name,['refused',[],[]],[r.status,r.alternatives,r.domains]);}
 let invoked=false;const owner={...f.owner};Object.defineProperty(owner,'extra',{enumerable:true,get(){invoked=true;return true}});check('getter-refused','refused',inspectCandidateReadProjection(p,owner,s).status);check('getter-not-executed',false,invoked);
 check('copied-handle-refused','refused',inspectCandidateReadProjection({...p as any},f.owner,s).status);
 for(const [key,value]of [['scan',0],['path','outputs/0'],['operator','predicate'],['action','read'],['queryValue',{field:ref('salary')}]] as const)check('caller-'+key+'-refused','refused',inspectCandidateReadProjection(p,f.owner,{...s,[key]:value}).status);
}
console.log(JSON.stringify({count:rows.length,passed:rows.every(r=>r.passed),rows}));
