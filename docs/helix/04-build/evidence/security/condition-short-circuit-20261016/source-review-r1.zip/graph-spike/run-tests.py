import sys,unittest,pathlib
root=pathlib.Path(__file__).parent
sys.path.insert(0,'/private/tmp/truss-main-integration-20261010/packages/python/src')
import truss
truss.__path__.insert(0,str(root/'packages/python/src/truss'))
sys.path.insert(0,str(root/'packages/python/tests'))
suite=unittest.defaultTestLoader.loadTestsFromName('test_current_disclosure_graphs')
raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
