"""Actual held UMF process over simulated native graph capture; no SQL/authority."""
import ast,pathlib,sys,json,hashlib,struct,importlib.util
from types import SimpleNamespace
root=pathlib.Path(__file__).parent
sys.path.insert(0,'/private/tmp/truss-main-integration-20261010/packages/python/src');import truss
truss.__path__.insert(0,str(root/'packages/python/src/truss'));sys.path.insert(0,str(root/'packages/python/tests'))
from truss._current_disclosure_facts import _capture_graphs
from truss._current_query_pipe import CurrentQueryPipe
from test_current_disclosure_graphs import Cursor
text=pathlib.Path('/private/tmp/truss-main-integration-20261010/packages/python/tests/test_security_ontology_edges_native.py').read_text();node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='ontology_document');space={};exec(compile(ast.Module(body=[node],type_ignores=[]),'<original ontology fixture>','exec'),space);document=space['ontology_document']('graph-capture')
ref=lambda name:{'documentId':document['id'],'moduleId':'m','elementId':name}
rel=lambda name:{'documentId':document['id'],'moduleId':'m','relationshipId':name}
types={e['id']:i+1 for i,e in enumerate(e for e in document['modules'][0]['elements'] if e['kind']=='record')}
records={e['id']:e for e in document['modules'][0]['elements'] if e['kind']=='record'}
fields={e['id']:e for e in document['modules'][0]['elements'] if e['kind']=='field'}
associations=[];native=[];pairs=[];recipes=[]
for i,declaration in enumerate(document['modules'][0]['relationships']):
 name=declaration['id'];number=31+i;endpoints=[]
 for side in ('source','target'):
  target=declaration[side][0]['element'];endpoints.append({'role':side,'side':side,'target':ref(target),'keyId':'pk'})
 associations.append({'kind':'core-relationship','relationship':rel(name),'witness':{'kind':'opaque-existential'},'endpoints':endpoints})
 native.append({'document_id':document['id'],'module':'m','rel_id':name,'rel_type_id':number,'retired_rev':None,'directed':True,'assoc_type_id':None,'source_min':0,'source_max':None,'target_min':0,'target_max':None,'lifecycle':'independent','composition':False,'inverse':None,'target_key':'pk'})
 pairs.append({'rel_type_id':number,'source_type':types[declaration['source'][0]['element']],'target_type':types[declaration['target'][0]['element']]})
associations.append({'kind':'record-members','type':ref('Assignment'),'keyId':'pk','endpoints':[{'role':'assignment','target':ref('Assignment'),'fields':[ref('assignmentId')]}]})
ontology={'version':'0.2.0','documentId':document['id'],'revision':'1','documents':[{'documentId':document['id'],'revision':'1'}],'subject':ref('Staff'),'entities':[{'type':ref(name),'keyId':'pk','fields':[{'ref':ref(f['element']),'protection':'unprotected'} for f in record['members']]} for name,record in records.items()],'associations':associations,'context':[],'actions':['read']}
ontology['actionPurposes']=[{'action':'read','purposes':['read']}]
v=lambda name,side:{'kind':'variable','name':name,'endpoint':side}
eq=lambda left,right:{'op':'eq','left':left,'right':right}
exists=lambda name,var,args:{'op':'exists','association':rel(name),'as':var,'where':{'op':'and','args':args}}
active={'op':'exists','association':ref('Assignment'),'as':'a','where':{'op':'and','args':[eq({'kind':'variable','name':'a','identity':True},v('sa','target')),eq({'kind':'variable','name':'a','field':ref('active')},{'kind':'constant','field':ref('active'),'value':{'boolean':True}})]}}
condition=exists('OwnershipResource','ow',[eq(v('ow','target'),{'kind':'resource','identity':True}),exists('OwnershipProject','op',[eq(v('op','source'),v('ow','source')),exists('StaffAssignment','sa',[eq(v('sa','source'),{'kind':'subject','identity':True}),exists('AssignmentProject','ap',[eq(v('ap','source'),v('sa','target')),eq(v('ap','target'),v('op','target')),active])])])])
policy={'vocabulary':'umf.security','version':'0.2.0','id':'native-graph-membership','revision':'1','ontology':{'documentId':document['id'],'revision':'1'},'rules':[{'id':'membership','effect':'permit','actions':['read'],'target':[ref('Resource')],'condition':condition,'disclosure':[]}]}
catalog={'vocabulary':'umf.security.protection','version':'0.1.0','id':'graph-catalog','revision':'1','transforms':[]}
policy['protection']={'id':catalog['id'],'revision':catalog['revision']}
owner={'version':'umf.security.logical-owner/0.1','id':'graph-owner','revision':'1','storage':[{'type':e['type'],'field':f['ref'],'storageEffect':'canonical'} for e in ontology['entities'] for f in e['fields']],'disclosure':{'readAction':'read'}}
closure={'pins':ontology['documents'],'documents':[{'revision':'1','document':document}]}
source={'policy':policy,'catalog':catalog,'closure':closure,'ontology':ontology,'associationBindings':[],'extensionSelection':None}
raw=json.dumps(document,separators=(',',':'));pin={'documentId':document['id'],'revision':'1','umfVersion':'0.8.0','sha256':hashlib.sha256(raw.encode()).hexdigest()}
captured_sources=SimpleNamespace(initialize_bytes=json.dumps({'kind':'initialize','requestId':'initialize','sources':source}).encode(),accepted_request_bytes=json.dumps({'modules':[{'pin':pin,'documentJson':raw}]}).encode(),accepted_assessment_bytes=json.dumps({'inventory':{'relationships':native,'endpoints':pairs}}).encode())
for name in records:recipes.append((types[name],ref(name),[],{'key_id':'pk'},b''))
rows=(('Client','c',{'clientId':'C'}),('Project','pa',{'projectId':'A'}),('Project','pb',{'projectId':'B'}),('Staff','alice',{'staffId':'Alice'}),('Staff','bob',{'staffId':'Bob'}),('Staff','outsider',{'staffId':'Outsider'}),('Resource','ra',{'resourceId':'RA','salary':100}),('Resource','rb',{'resourceId':'RB','salary':200}),('Resource','ro',{'resourceId':'RO','salary':300}),('Assignment','aa',{'assignmentId':'AA','active':True}),('Assignment','ai',{'assignmentId':'AI','active':False}),('Assignment','ba',{'assignmentId':'BA','active':True}),('Ownership','oa',{'ownershipId':'OA'}),('Ownership','ob',{'ownershipId':'OB'}))
links=[('ProjectClient','pa','c'),('ProjectClient','pb','c'),('StaffAssignment','alice','aa'),('StaffAssignment','alice','ai'),('StaffAssignment','bob','ba'),('AssignmentProject','aa','pa'),('AssignmentProject','ai','pb'),('AssignmentProject','ba','pb'),('OwnershipResource','oa','ra'),('OwnershipResource','ob','rb'),('OwnershipProject','oa','pa'),('OwnershipProject','ob','pb')]
ids={alias:str(i+1) for i,(_,alias,_) in enumerate(rows)};row_types={alias:record for record,alias,_ in rows};facts=[];private=[]
for record,alias,values in rows:
 key_name=records[record]['keys'][0]['fields'][0]['element'];values_out=[]
 for name,value in values.items():values_out.append({'field':ref(name),'value':{'boolean':value} if type(value) is bool else {'integerToken':str(value)} if type(value) is int else {'string':value}})
 facts.append({'type':ref(record),'key':[{'string':values[key_name]}],'fields':values_out,'absent':[]});private.append((ids[alias],str(types[record]),'1',b'',b'',b''))
coverage=[{'type':e['type'],'complete':True,'fields':[f['ref'] for f in e['fields']]} for e in ontology['entities']]
relations={r['rel_id']:str(r['rel_type_id']) for r in native};version='umf.security.private-disclosure-child/0.2-candidate';wire=lambda v:json.dumps(v,separators=(',',':')).encode();frame=lambda b:struct.pack('>I',len(b))+b
bundle='/private/tmp/umf-short-circuit-native-child-r1-20261016/current-native-disclosure-child.mjs';observations=[];test_packets=[]
for label,selected_links in [('base',links),('parallel',links+[links[2]]),('empty',[]),('inactive-only',[l for l in links if l!=('StaffAssignment','alice','aa')]),('sibling-owner',[l if l!=('OwnershipProject','oa','pa') else ('OwnershipProject','oa','pb') for l in links])]:
 edge_rows=[(str(i+90),relations[name],'1',ids[s],str(types[row_types[s]]),ids[t],str(types[row_types[t]])) for i,(name,s,t) in enumerate(selected_links)]
 graphs_raw,graph_coverage_raw,_=_capture_graphs(Cursor(edge_rows),captured_sources,recipes,facts,private)
 # Independent native-ID incidence oracle, not UMF decisions or projected keys.
 incidence={name:{(ids[s],ids[t]) for r,s,t in selected_links if r==name} for name in relations};active_ids={ids[alias] for record,alias,values in rows if record=='Assignment' and values['active']}
 owned={(resource,project) for ownership,resource in incidence['OwnershipResource'] for same,project in incidence['OwnershipProject'] if ownership==same}
 for staff,subject_key in [('alice','Alice'),('bob','Bob'),('outsider','Outsider')]:
  projects={project for person,assignment in incidence['StaffAssignment'] for same,project in incidence['AssignmentProject'] if person==ids[staff] and assignment==same and assignment in active_ids}
  expected=[values['resourceId'] for record,alias,values in rows if record=='Resource' and any(resource==ids[alias] and project in projects for resource,project in owned)]
  initial=wire({'version':version,'kind':'initialize','requestId':'init','sources':{k:v for k,v in source.items() if k!='extensionSelection'},'owner':owner,'selection':{'type':ref('Resource'),'fields':[ref('resourceId'),ref('salary')]}});receipt=hashlib.sha256(frame(initial)).hexdigest()
  cut={'version':'umf.security.logical-facts/0.1','trusted':True,'generation':'supplied-graph-cut','expectedGeneration':'supplied-graph-cut','policy':{'id':policy['id'],'revision':'1'},'ontology':policy['ontology'],'protection':{'id':catalog['id'],'revision':'1'},'domains':closure['pins'],'owner':{'id':owner['id'],'revision':'1'},'subject':{'type':ref('Staff'),'key':[{'string':subject_key}]},'facts':facts,'coverage':coverage,'graphs':json.loads(graphs_raw),'graphCoverage':json.loads(graph_coverage_raw),'context':[],'valueProfiles':[],'maxFacts':10000,'maxSteps':1000000}
  test_packets.append({'id':label+':'+subject_key,'cut':cut,'expectedKeys':expected});(root/'composition-test-packets.json').write_text(json.dumps({'initialize':json.loads(initial),'packets':test_packets},indent=2)+'\n')
  (root/'last-initialize.json').write_bytes(initial);(root/'last-cut.json').write_bytes(wire(cut))
  with CurrentQueryPipe(('/opt/homebrew/bin/bun',bundle),timeout_seconds=20) as child:
   initialized=json.loads(child.exchange(initial,source_receipt=receipt));assert initialized['kind']=='initialized',initialized
   evaluated=json.loads(child.exchange(wire({'version':version,'kind':'evaluate-disclosure','requestId':'evaluate','sourceReceipt':receipt,'cut':cut}),source_receipt=receipt));assert evaluated['kind']=='disclosure-evaluated',evaluated
   result=evaluated['result'];assert result['status']=='rendered',result
   actual=[r['key'][0]['string'] for r in result['resources']];assert actual==expected,(label,staff,expected,actual)
   inspection=json.loads(child.exchange(wire({'version':version,'kind':'inspect-native-disclosure','requestId':'inspect','sourceReceipt':receipt,'batch':result['batch']}),source_receipt=receipt));assert inspection['kind']=='native-disclosure-inspected',inspection
  assert child._cleanup_complete
  observations.append({'case':label,'subject':subject_key,'expected':expected,'observed':actual,'graphs':len(edge_rows),'inspection':inspection,'batch':result['batch']})
out=root/'original-umf-composition.json';out.write_text(json.dumps({'status':'passed','observations':observations,'document':document,'ontology':ontology,'policy':policy,'scope':'Simulated native cursor and supplied physical assessment -> actual graph capture -> actual held UMF producer/inspector. Independent incidence oracle. No SQL, authenticated source/caller/current authority/release or acceptance promotion.'},indent=2)+'\n');print(json.dumps({'status':'passed','cases':len(observations),'nativeSql':False}))
