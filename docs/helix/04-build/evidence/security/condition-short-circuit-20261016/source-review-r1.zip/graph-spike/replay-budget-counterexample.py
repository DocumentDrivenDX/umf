import sys,pathlib,json,hashlib,struct
sys.path.insert(0,'/private/tmp/truss-main-integration-20261010/packages/python/src')
from truss._current_query_pipe import CurrentQueryPipe
root=pathlib.Path(__file__).parent;initial=(root/'last-initialize.json').read_bytes();cut=json.loads((root/'last-cut.json').read_bytes());bundle=pathlib.Path('/private/tmp/umf-native-disclosure-child-bundle-r1-20261016/current-native-disclosure-child.mjs');receipt=hashlib.sha256(struct.pack('>I',len(initial))+initial).hexdigest()
with CurrentQueryPipe(('/opt/homebrew/bin/bun',str(bundle)),timeout_seconds=20) as child:
 initialized=json.loads(child.exchange(initial,source_receipt=receipt));evaluation=json.dumps({'version':'umf.security.private-disclosure-child/0.2-candidate','kind':'evaluate-disclosure','requestId':'evaluate','sourceReceipt':receipt,'cut':cut},separators=(',',':')).encode();evaluated=json.loads(child.exchange(evaluation,source_receipt=receipt))
assert initialized['kind']=='initialized' and evaluated['result']['status']=='refused'
output={'status':'counterexample-reproduced','bundleSha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'initialize':json.loads(initial),'cut':cut,'initialized':initialized,'evaluated':evaluated,'scope':'Exact reviewed2069/d333 process initializes valid source, then refuses14fact12graph nested condition. Separate diagnostic instrumentation identifies literalwork bound. NoSQL/nativeauthority.'}
(root/'eager-budget-counterexample.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({'status':output['status'],'facts':len(cut['facts']),'graphs':len(cut['graphs'])}))
