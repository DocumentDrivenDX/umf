
def _relationship_identity(ref):
    if type(ref) is not dict or set(ref)!={'documentId','moduleId','relationshipId'} or any(type(v) is not str or not v for v in ref.values()):
        raise ValueError('Original qualified graph relationship required')
    return tuple(ref[k] for k in ('documentId','moduleId','relationshipId'))


def _positive_native(value):
    if type(value) is not str or not value.isascii() or not value.isdecimal() or value.startswith('0') or int(value)>9223372036854775807:
        raise ValueError('Exact positive native graph identity required')
    return value


def _graph_recipes(sources, records):
    """Native correspondence only. Original UMF still validates ontology semantics."""
    original=_envelope(sources.initialize_bytes)['sources']
    modules=require_current_model_correspondence(sources.initialize_bytes,sources.accepted_request_bytes)
    inventory=decode_owner_evidence_json(sources.accepted_assessment_bytes)['inventory']
    entities={_identity(e['type']):e for e in original['ontology']['entities']}
    record_map={_identity(ref):(number,key) for number,ref,_,key,_ in records}
    recipes=[];seen=set();native_seen=set()
    for association in original['ontology']['associations']:
        if association.get('kind')=='record-members':continue
        if association.get('kind')!='core-relationship':
            raise ValueError('Original graph association selection required')
        relationship=association['relationship'];identity=_relationship_identity(relationship)
        if identity in seen:raise ValueError('Distinct graph relationship selection required')
        seen.add(identity)
        # Record-backed witnesses need a separate edge-property/key realization;
        # never turn their native attributes into an opaque existential.
        if association['witness']!={'kind':'opaque-existential'}:
            raise ValueError('Record-backed native graph witness capture remains required')
        document=decode_owner_evidence_json(modules[identity[0]]['documentJson'].encode())
        source_modules=[m for m in document['modules'] if m['id']==identity[1]]
        declarations=[r for m in source_modules for r in m.get('relationships',[]) if r['id']==identity[2]]
        if len(source_modules)!=1 or len(declarations)!=1:raise ValueError('Exact original graph declaration required')
        declaration=declarations[0]
        if declaration.get('directed') is not True or 'associationRecord' in declaration:
            raise ValueError('Original directed opaque graph declaration required')
        native=[r for r in inventory['relationships'] if (r['document_id'],r['module'],r['rel_id'])==identity and r['retired_rev'] is None]
        if len(native)!=1:raise ValueError('Exact active native graph definition required')
        native=native[0];number=native['rel_type_id']
        if type(number) is not int or not 0<number<=2147483647 or number in native_seen:
            raise ValueError('Distinct active native graph definition required')
        native_seen.add(number)
        if native['directed'] is not True or native['assoc_type_id'] is not None:
            raise ValueError('Native graph witness realization mismatch')
        for side in ('source','target'):
            multiplicity=declaration[side+'Multiplicity']
            low=multiplicity['min'];high=multiplicity['max']
            if type(low) is not int or low<0 or not (high=='*' or type(high) is int and high>=low):
                raise ValueError('Original graph multiplicity required')
            if native[side+'_min']!=low or native[side+'_max']!=(None if high=='*' else high):
                raise ValueError('Native graph multiplicity differs from original')
        if (native['lifecycle']!=declaration['targetLifecycle'] or native['composition'] is not declaration.get('composition',False)
                or native['inverse']!=declaration.get('inverse')):
            raise ValueError('Native graph lifecycle differs from original')
        endpoints=association['endpoints']
        if type(endpoints) is not list or len(endpoints)!=2 or {e['side'] for e in endpoints}!={'source','target'}:
            raise ValueError('Complete original binary graph roles required')
        roles=set();ordered=[]
        for side in ('source','target'):
            endpoint=next(e for e in endpoints if e['side']==side);role=endpoint['role'];target=endpoint['target'];target_id=_identity(target)
            if type(role) is not str or not role or role in roles or target_id not in record_map or target_id not in entities:
                raise ValueError('Distinct original graph endpoint roles required')
            roles.add(role);actual=declaration[side]
            if (len(actual)!=1 or target_id!=(identity[0],actual[0]['module'],actual[0]['element'])
                    or endpoint['keyId']!=entities[target_id]['keyId'] or record_map[target_id][1]['key_id']!=endpoint['keyId']
                    or 'key' in actual[0] and actual[0]['key']!=endpoint['keyId']):
                raise ValueError('Original typed graph endpoint Key correspondence required')
            ordered.append((role,target,record_map[target_id][0]))
        if native['target_key']!=declaration['target'][0].get('key'):
            raise ValueError('Native graph target Key differs from original')
        pairs=[r for r in inventory['endpoints'] if r['rel_type_id']==number]
        if len(pairs)!=1 or (pairs[0]['source_type'],pairs[0]['target_type'])!=(ordered[0][2],ordered[1][2]):
            raise ValueError('Complete native graph endpoint alternatives required')
        recipes.append((number,relationship,tuple(ordered)))
    if len(recipes)>256:raise ValueError('Bounded original graph source required')
    return recipes


def _capture_graphs(cursor,sources,records,facts,private):
    recipes=_graph_recipes(sources,records)
    if not recipes:return b'[]',b'[]',()
    if len(facts)!=len(private):raise ValueError('Complete original graph endpoint population required')
    record_types={str(number):ref for number,ref,_,_,_ in records};objects={}
    for fact,row in zip(facts,private,strict=True):
        object_id,type_id,version,*_=row
        _positive_native(object_id);_positive_native(type_id);_positive_native(version)
        if (object_id,type_id) in objects or type_id not in record_types or fact['type']!=record_types[type_id]:
            raise ValueError('Exact distinct original graph endpoint identity required')
        objects[object_id,type_id]=fact
    cursor.execute('LOCK TABLE ONLY truss.edge IN SHARE MODE NOWAIT',prepare=False)
    homes=_text_rows(cursor,"SELECT c.relkind::text,c.relpersistence::text,c.relrowsecurity::text,c.relforcerowsecurity::text,(c.relowner=i.owner_oid)::text,EXISTS(SELECT 1 FROM pg_catalog.pg_inherits p WHERE p.inhrelid=c.oid OR p.inhparent=c.oid)::text FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace CROSS JOIN truss.catalog_runtime_installation i WHERE n.nspname='truss' AND c.relname='edge' AND i.singleton",limit=1)
    if homes!=[('r','p','false','false','true','false')]:
        raise ValueError('Complete unfiltered native graph home required')
    numbers=[r[0] for r in recipes]
    census=_text_rows(cursor,"SELECT count(*)::text,coalesce(sum(octet_length(props::text)),0)::text,coalesce(bool_or(props<>'{}'::jsonb),false)::text FROM ONLY truss.edge WHERE rel_type_id=ANY(%s::int[])",(numbers,),1)
    if (len(census)!=1 or not census[0][0].isascii() or not census[0][0].isdigit() or int(census[0][0])+len(facts)>10000
            or not census[0][1].isascii() or not census[0][1].isdigit() or int(census[0][1])>8388608 or census[0][2]!='false'):
        raise ValueError('Bounded complete native opaque graph population required')
    rows=_text_rows(cursor,'SELECT id::text,rel_type_id::text,ver::text,source_id::text,source_type::text,target_id::text,target_type::text FROM ONLY truss.edge WHERE rel_type_id=ANY(%s::int[]) ORDER BY rel_type_id,id',(numbers,),10000)
    if len(rows)!=int(census[0][0]):raise ValueError('Complete native graph census correspondence required')
    selected={str(number):(ref,endpoints) for number,ref,endpoints in recipes};seen=set();graphs=[]
    for edge_id,relationship_id,version,source_id,source_type,target_id,target_type in rows:
        for token in (edge_id,relationship_id,version,source_id,source_type,target_id,target_type):_positive_native(token)
        if edge_id in seen or relationship_id not in selected:raise ValueError('Distinct selected native graph occurrence required')
        seen.add(edge_id);relationship,endpoints=selected[relationship_id];projected=[]
        for (role,ref,number),object_id,type_id in zip(endpoints,(source_id,target_id),(source_type,target_type),strict=True):
            fact=objects.get((object_id,type_id))
            if type_id!=str(number) or fact is None or fact['type']!=ref:
                raise ValueError('Complete typed original graph endpoint required')
            projected.append({'role':role,'key':fact['key']})
        graphs.append({'relationship':relationship,'witness':{'kind':'opaque-existential','id':edge_id},'endpoints':projected})
    coverage=[{'relationship':ref,'complete':True,'roles':[role for role,_,_ in endpoints],'fields':[]} for _,ref,endpoints in recipes]
    encoded=json.dumps(graphs,separators=(',',':'),ensure_ascii=True).encode();covered=json.dumps(coverage,separators=(',',':'),ensure_ascii=True).encode()
    if len(encoded)+len(covered)>8388608:raise ValueError('Complete graph output exceeds logical limit')
    return encoded,covered,tuple(rows)
