import {compileCandidateCatalogProgram} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-program-candidate';
import {evaluateCandidateCatalogReadDisclosureBatch} from '/private/tmp/truss-current-graph-capture-debug-runtime';
const p=await Bun.file('/private/tmp/truss-current-graph-capture-owner-20261016/last-initialize.json').json(),cut=await Bun.file('/private/tmp/truss-current-graph-capture-owner-20261016/last-cut.json').json(),s=p.sources;
const h=compileCandidateCatalogProgram(s.policy,s.catalog,s.closure,s.ontology,s.associationBindings);console.log(evaluateCandidateCatalogReadDisclosureBatch(h,p.owner,cut,p.selection));
