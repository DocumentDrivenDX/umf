from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess,time
R=Path(__file__).parent;S=R/'source';O=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');D=R/'dependency-supplement-ajv';D.mkdir();pins={}
for p in (O/'node_modules/ajv').rglob('*'):
 if p.is_file():
  n=Path('node_modules/ajv')/p.relative_to(O/'node_modules/ajv');dest=S/n;b=p.read_bytes()
  if dest.exists():assert dest.read_bytes()==b
  else:
   dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);q=D/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);pins[str(n)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
with zipfile.ZipFile(R/'dependency-supplement-ajv.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in pins:z.write(D/n,n)
(R/'dependency-supplement-ajv.json').write_text(json.dumps({'scope':'Remaining installed Ajv support files; all previously captured input bytes checked unchanged.','files':pins},indent=2)+'\n')
cmd=['/opt/homebrew/bin/bun','test','tests/security/protection/catalog.test.ts'];t=time.monotonic()
with (R/'catalog-dependency-check-r2.log').open('w') as f:p=subprocess.run(cmd,cwd=S,stdout=f,stderr=subprocess.STDOUT)
(R/'catalog-dependency-check-r2-execution.json').write_text(json.dumps({'argv':cmd,'cwd':str(S),'exitCode':p.returncode,'seconds':time.monotonic()-t},indent=2)+'\n');raise SystemExit(p.returncode)
