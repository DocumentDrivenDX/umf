from pathlib import Path
import json,subprocess,tarfile,shutil,zipfile,hashlib
R=Path(__file__).parent;S=R/'source';O=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');D=R/'dependency-supplement';D.mkdir()
with (R/'base-spikes.tar').open('wb') as f:subprocess.run(['git','archive','206951ff20d766874b9af7d29fdf8027c3bab499','docs/helix/02-design/spikes/security'],cwd=O,stdout=f,check=True)
with tarfile.open(R/'base-spikes.tar') as t:t.extractall(D)
for name in ['yaml/browser','@bufbuild/protobuf']:
 src=O/'node_modules'/name;dest=D/'node_modules'/name;shutil.copytree(src,dest)
assert (S/'node_modules/yaml/package.json').read_bytes()==(O/'node_modules/yaml/package.json').read_bytes()
pins={}
for p in D.rglob('*'):
 if p.is_file():
  n=str(p.relative_to(D));b=p.read_bytes();pins[n]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};dest=S/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
with zipfile.ZipFile(R/'dependency-supplement.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in pins:z.write(D/n,n)
(R/'dependency-supplement.json').write_text(json.dumps({'scope':'Missing base committed spike schemas plus external installed YAML browser/protobuf module bytes needed by independent full tests/browser build. Original selected bundle source pins unchanged; external executable closure remains non-hermetic.','files':pins},indent=2)+'\n')
print(len(pins),'supplemental files')
