from pathlib import Path
import json,shutil,zipfile,hashlib,subprocess,time
R=Path(__file__).parent;S=R/'source';O=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');D=R/'dependency-supplement-r4';D.mkdir()
for name in ['avsc','flatbuffers','buffer','base64-js','ieee754','util','inherits','is-arguments','is-generator-function','is-typed-array','which-typed-array','available-typed-arrays','call-bind','call-bound','call-bind-apply-helpers','get-intrinsic','es-errors','gopd','has-tostringtag','has-symbols','hasown','function-bind','define-data-property','es-object-atoms','math-intrinsics','get-proto','dunder-proto','is-callable','for-each','possible-typed-array-names','set-function-length','has-property-descriptors']:
 src=O/'node_modules'/name
 if src.exists():shutil.copytree(src,D/'node_modules'/name)
pins={}
for p in D.rglob('*'):
 if p.is_file():
  n=str(p.relative_to(D));b=p.read_bytes();pins[n]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};dest=S/n;dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists():assert dest.read_bytes()==b
  else:shutil.copyfile(p,dest)
with zipfile.ZipFile(R/'dependency-supplement-r4.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in pins:z.write(D/n,n)
(R/'dependency-supplement-r4.json').write_text(json.dumps({'scope':'Installed Avro/FlatBuffers/browser built-in support dependencies needed by broad public index legacy test; captured separately from 257 builder inputs.','files':pins},indent=2)+'\n')
cmd=['/opt/homebrew/bin/bun','test','tests/security/protection/catalog.test.ts'];t=time.monotonic()
with (R/'catalog-dependency-check.log').open('w') as f:p=subprocess.run(cmd,cwd=S,stdout=f,stderr=subprocess.STDOUT)
(R/'catalog-dependency-check-execution.json').write_text(json.dumps({'argv':cmd,'cwd':str(S),'exitCode':p.returncode,'seconds':time.monotonic()-t},indent=2)+'\n')
raise SystemExit(p.returncode)
