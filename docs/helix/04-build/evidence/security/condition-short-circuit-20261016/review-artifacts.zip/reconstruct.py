from pathlib import Path
import subprocess,tarfile,zipfile,json,hashlib,shutil
R=Path(__file__).parent;F=R/'frozen';S=R/'source';S.mkdir();base='206951ff20d766874b9af7d29fdf8027c3bab499';roots=['src','tests/security','tools/security','spec','AGENTS.md','.helix.yml','docs/helix/README.md','docs/helix/02-design/contracts','package.json','bun.lock','tsconfig.json','bunfig.toml','tsconfig.tools.json']
with (R/'base.tar').open('wb') as out:subprocess.run(['git','archive',base,*roots],cwd='/Users/erik/.codex/worktrees/security-main-integration/umf',stdout=out,check=True)
with tarfile.open(R/'base.tar') as t:
 for x in t.getmembers():assert not x.name.startswith('/') and '..' not in Path(x.name).parts and not x.issym() and not x.islnk()
 t.extractall(S)
with zipfile.ZipFile(F/'selected-source-inputs.zip') as z:
 for n in z.namelist():assert not n.startswith('/') and '..' not in Path(n).parts
 z.extractall(S)
for p in (F/'overlay').rglob('*'):
 if p.is_file():d=S/p.relative_to(F/'overlay');d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
for p in (F/'bundle/notices').rglob('*'):
 if p.is_file():d=S/'node_modules'/p.relative_to(F/'bundle/notices');d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
pins={str(p.relative_to(S)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in S.rglob('*') if p.is_file()}
(R/'source-before.json').write_text(json.dumps(pins,indent=2)+'\n')
with zipfile.ZipFile(R/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(pins):z.write(S/p,p)
print(len(pins),'reconstructed')
