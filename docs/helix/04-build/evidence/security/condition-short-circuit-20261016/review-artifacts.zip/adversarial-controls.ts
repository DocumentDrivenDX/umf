import {writeFileSync} from 'node:fs';
import {catalogRuntimeFixture,compileRuntimeFixture} from './source/tests/security/catalog-runtime-fixture';
import {ref} from './source/tests/security/fixture';
import * as next from './source/src/extensions/security/catalog-runtime-candidate';
import * as old from './source/src/extensions/security/catalog-runtime-eager-astra';
const R=import.meta.dir,checks:any[]=[],observations:any[]=[],check=(id:string,ok:boolean)=>{checks.push({id,passed:ok});if(!ok)throw Error(id);},canon=(v:any)=>JSON.stringify(v);
function fixture(){const f=catalogRuntimeFixture();f.owner.disclosure={readAction:'read'};f.cut.maxSteps=1000000;const salary=f.closure.documents[0].document.modules[0].elements.find((x:any)=>x.id==='salary');salary.nullability='absent-allowed';const resource=f.cut.facts.find((x:any)=>x.type.elementId==='Resource');resource.fields=resource.fields.filter((x:any)=>x.field.elementId!=='salary');resource.absent=[ref('salary')];return f;}
const expr=(t:string):any=>t==='U'?{op:'eq',left:{kind:'resource',field:ref('salary')},right:{kind:'constant',field:ref('salary'),value:{integerToken:'100'}}}:{op:'literal',value:t==='T'};
const fold=(op:string,vs:string[])=>op==='and'?(vs.includes('F')?'F':vs.includes('U')?'U':'T'):(vs.includes('T')?'T':vs.includes('U')?'U':'F');
const combinations=(n:number):string[][]=>n===0?[[]]:combinations(n-1).flatMap(xs=>['F','U','T'].map(x=>[...xs,x]));
const rules:any[]=[],expected:string[]=[];
for(const op of ['and','or'])for(const n of [2,3,4])for(const values of combinations(n)){rules.push({id:op+values.join(''),effect:'permit',actions:['read'],target:[ref('Resource')],condition:{op,args:values.map(expr)}});expected.push(fold(op,values));}
const f=fixture();f.policy.rules=rules;const h=compileRuntimeFixture(f);const actual:any=next.evaluateCandidateCatalogReadRuleScan(h,f.owner,f.cut,{type:ref('Resource')}),prior:any=old.evaluateCandidateCatalogReadRuleScan(h,f.owner,f.cut,{type:ref('Resource')});
check('exhaustive-current-evaluated',actual.status==='evaluated');check('exhaustive-original-evaluated',prior.status==='evaluated');check('exhaustive-exact-correspondence',canon(actual)===canon(prior));for(let i=0;i<expected.length;i++)check('actual-compiled-'+rules[i].id,actual.rows[0].rules[i].truth===expected[i]);
for(const values of [[],...combinations(1),...combinations(2),...combinations(3)]){
 const f=fixture();f.policy.rules=[{id:'existential',effect:'permit',actions:['read'],target:[ref('Resource')],condition:{op:'exists',association:ref('Assignment'),as:'a',where:{op:'eq',left:{kind:'variable',name:'a',field:ref('active')},right:{kind:'constant',field:ref('active'),value:{boolean:true}}}}}];
 f.closure.documents[0].document.modules[0].elements.find((x:any)=>x.id==='active').nullability='absent-allowed';const original=f.cut.facts.find((x:any)=>x.type.elementId==='Assignment');f.cut.facts=f.cut.facts.filter((x:any)=>x.type.elementId!=='Assignment');
 for(const [i,t]of values.entries()){const row=structuredClone(original);row.key=[{string:'a'+i}];row.fields.find((x:any)=>x.field.elementId==='assignmentId').value={string:'a'+i};if(t==='U'){row.fields=row.fields.filter((x:any)=>x.field.elementId!=='active');row.absent=[ref('active')];}else row.fields.find((x:any)=>x.field.elementId==='active').value={boolean:t==='T'};f.cut.facts.push(row);}
 const h=compileRuntimeFixture(f),result:any=next.evaluateCandidateCatalogReadRuleScan(h,f.owner,f.cut,{type:ref('Resource')}),prior=old.evaluateCandidateCatalogReadRuleScan(h,f.owner,f.cut,{type:ref('Resource')});check('exists-'+values.join('')+'-truth',result.status==='evaluated'&&result.rows[0].rules[0].truth===fold('or',values));check('exists-'+values.join('')+'-correspondence',canon(result)===canon(prior));
}
// Refusal dependencies remain mandatory even behind an absorbing first child.
for(const op of ['and','or'])for(const defect of ['missing-coverage','missing-projection','invalid-value','wrong-owner-storage','wrong-source','exhausted-steps','facts-limit','missing-context']){
 const f=fixture();let dependency:any=expr('U');
 if(defect==='missing-context'){const field={id:'ctx',kind:'field',scalarType:'integer',cardinality:'one',nullability:'required',extensions:{}};f.closure.documents[0].document.modules[0].elements.push(field);f.ontology.context=[ref('ctx')];dependency={op:'eq',left:{kind:'context',field:ref('ctx')},right:{kind:'constant',field:ref('ctx'),value:{integerToken:'1'}}};}
 f.policy.rules=[{id:'absorbing',effect:'permit',actions:['read'],target:[ref('Resource')],condition:{op,args:[expr(op==='and'?'F':'T'),dependency]}}];
 const h=compileRuntimeFixture(f);
 if(defect==='missing-coverage')f.cut.coverage.find((x:any)=>x.type.elementId==='Resource').fields=[ref('resourceId')];
 if(defect==='missing-projection')f.cut.facts.find((x:any)=>x.type.elementId==='Resource').absent=[];
 if(defect==='invalid-value'){const r=f.cut.facts.find((x:any)=>x.type.elementId==='Resource');r.absent=[];r.fields.push({field:ref('salary'),value:{integerToken:'bad'}});}
 if(defect==='wrong-owner-storage')f.owner.storage=[];
 if(defect==='wrong-source')f.cut.policy.revision='stale';
 if(defect==='exhausted-steps')f.cut.maxSteps=1;
 if(defect==='facts-limit')f.cut.maxFacts=1;
 for(const [name,api]of [['new',next],['old',old]] as const)check(op+'-'+defect+'-'+name,(api.evaluateCandidateCatalogReadRuleScan(h,f.owner,f.cut,{type:ref('Resource')}) as any).status==='refused');
}
for(const scalarType of ['date','time','timestamp','uuid']){const f=fixture();f.closure.documents[0].document.modules[0].elements.push({id:'dto',kind:'field',scalarType,cardinality:'one',nullability:'required',extensions:{}});f.policy.rules=[{id:'c',effect:'permit',actions:['read'],target:[ref('Resource')],condition:{op:'or',args:[expr('T'),{op:'eq',left:{kind:'constant',field:ref('dto'),value:{[scalarType]:'2024-01-01'}},right:{kind:'constant',field:ref('dto'),value:{[scalarType]:'2024-01-01'}}}]}}];let refused=false;try{compileRuntimeFixture(f)}catch{refused=true}check('unsupported-constant-'+scalarType+'-compile-refused',refused);}
observations.push({rules:rules.length,actual,prior});writeFileSync(R+'/adversarial-controls.json',JSON.stringify({status:'passed',scope:'Actual issued compiled programs, old/new runtime correspondence and explicit negative preflight controls. No database/native authority; operational work charges may be lower by design.',checks,observations},null,2)+'\n');console.log(checks.length,'passed');
