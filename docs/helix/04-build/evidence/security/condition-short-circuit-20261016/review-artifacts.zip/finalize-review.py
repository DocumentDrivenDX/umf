from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil
R=Path(__file__).parent;S=R/'source';F=R/'frozen';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda n:json.loads((R/n).read_text());write=lambda n,d:(R/n).write_text(json.dumps(d,indent=2)+'\n')
# Closing exact byte checks, separate from the already retained earlier audit.
before=read('source-before.json');closing=[]
for n,pin in before.items():
 assert sha((S/n).read_bytes())==pin['sha256'],n;closing.append(n)
m=read('frozen/bundle/manifest.json')
for n,h in m['sourcePins'].items():assert sha((S/n).read_bytes())==h,n
q=read('evidence-qualification-r2/counterexample-qualification.json');ce=read('frozen/graph-spike/eager-budget-counterexample.json');process=read('process-replay.json')
assert q['originalReceiptSha256']==sha((F/'graph-spike/eager-budget-counterexample.json').read_bytes())
assert len(ce['cut']['facts'])==q['actualFacts']==14 and len(ce['cut']['graphs'])==q['actualGraphs']==13
assert q['actualSubject']==ce['cut']['subject'] and ce['evaluated']['result']['status']==q['actualResult']=='refused'
for who in ['Alice','Outsider']:
 d=process['additionalExactBase'+who+'14facts12graphs']['evaluated']['result'];claim=q['independentOriginalBase'+who];assert d['status']==claim['status']=='rendered';assert [v['key'][0]['string']for v in d['resources']]==claim['resourceKeys']
qualification_files={str(p.relative_to(R/'evidence-qualification-r2')):sha(p.read_bytes())for p in (R/'evidence-qualification-r2').rglob('*')if p.is_file()}
write('closing-custody.json',{'status':'passed','initialReconstructionFilesUnchanged':len(closing),'selectedBundleInputsUnchanged':len(m['sourcePins']),'initialCounterexampleUnchanged':True,'qualificationFiles':qualification_files,'scope':'Endpoint comparisons; does not establish continuous file holding, absence of ABA changes, or hermetic executable dependencies.'})
# Preserve independent reviewer variants without relying on the expanded source tree.
mutants={}
with zipfile.ZipFile(R/'reviewer-runtime-variants.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((S/'src/extensions/security').glob('*-astra.ts')):
  n=str(p.relative_to(S));b=p.read_bytes();z.writestr(n,b);mutants[n]={'sha256':sha(b),'bytes':len(b)}
write('reviewer-runtime-variants.json',mutants)
graph=read('graph-context-tests.json');graph_map={}
with zipfile.ZipFile(R/'graph-context-dependencies.zip','w',zipfile.ZIP_DEFLATED) as z:
 for i,(name,h)in enumerate(sorted(graph['pins'].items())):
  p=Path(name);b=p.read_bytes();assert sha(b)==h;member=f'{i:03d}/'+p.name;z.writestr(member,b);graph_map[name]={'member':member,'sha256':h,'bytes':len(b)}
write('graph-context-dependencies.json',graph_map)
playwright=Path('/Users/erik/Projects/weft/node_modules/playwright/package.json');shutil.copyfile(playwright,R/'independent-playwright-package.json')
write('execution-summary.json',{'scope':'Independent executions on reconstructed frozen sources. Installed executables/external broad-test and browser dependencies are non-hermetic.','commands':[
 {'argv':['python3',str(R/'reconstruct.py')],'result':'base plus exact packet overlay reconstructed'},
 {'argv':['/opt/homebrew/bin/bun','tools/security/build-current-native-disclosure-child.ts',str(R/'rebuilt-bundle')],'cwd':str(S),'result':'bundle SHA matches frozen548b7f; all257 source pins match'},
 read('security-final-execution.json'),
 {'argv':['/opt/homebrew/bin/bun',str(R/'adversarial-controls.ts')],'result':'353 passed'},
 {'argv':['/opt/homebrew/bin/bun',str(R/'mutation-controls.ts')],'result':'4 mutations detected'},
 {'argv':['/private/tmp/umf-security-proof-current-20261015/bin/python','tools/security/prove-condition-short-circuit.py',str(R/'proof.json')],'cwd':str(S),'result':'30 queries;12 UNSAT/18 SAT; Z34.15.4'},
 {'argv':['/opt/homebrew/bin/bun','tools/security/nested-graph-conditions-browser.ts',str(R/'browser-r3.json')],'cwd':str(S),'result':'98 browser controls; Playwright1.62.1, Chromium151.0.7922.34; distinct from supplied Chromium153 epoch'},
 {'argv':['/private/tmp/truss-practical-performance-env/bin/python',str(R/'replay-process.py')],'result':'15 new held processes and3 old-bundle observations'},
 {'argv':['/private/tmp/truss-practical-performance-env/bin/python','-B',str(R/'graph-context-tests.py')],'result':'6 supplied simulated-cursor mapping tests'},
 {'argv':['python3',str(R/'custody-audit.py')],'result':'3567 correspondence checks'}]})
review={
 'status':'review-complete-no-open-product-findings',
 'reviewer':'Astra Ultra independent retained reviewer',
 'base':'206951ff20d766874b9af7d29fdf8027c3bab499',
 'pins':{'sourcePacketSha256':sha((R/'review.zip').read_bytes()),'evidenceQualificationR2Sha256':sha((R/'evidence-qualification-r2.zip').read_bytes()),'runtimeSha256':sha((S/'src/extensions/security/catalog-runtime-candidate.ts').read_bytes()),'rebuiltBundleSha256':sha((R/'rebuilt-bundle/current-native-disclosure-child.mjs').read_bytes()),'originalBundleSha256':sha((R/'original-eager-child.mjs').read_bytes())},
 'conclusion':'The frozen optimization preserves tested strong-Kleene truth, full dependency refusal, and the existing rule/disclosure/recipe fold. Only pure truth evaluation stops on F for AND or T for OR/exists; global preflight and budget ceilings are byte-identical. No product-code defect remains. One historical evidence-label finding is resolved by a separate qualification without rewriting the original receipt.',
 'findings':[],
 'resolvedFindings':[{'id':'SHORT-CIRCUIT-EVIDENCE-001','severity':'low','kind':'evidence-label','original':'The retained eager-budget-counterexample receipt and R1 narrative called a14-fact/13-edge parallel:Alice packet a12-edge counterexample. The embedded packet is authoritative.','independentResult':'Exact old d333 parallel:Alice14/13 refuses. Exact old base:Alice14/12 renders RA and base:Outsider14/12 renders empty; both pass held inspection. New548b7f passes all15 supplied vectors.','resolution':'Separate R2 counterexample qualification and TD/STP/implementation text identify the13-edge case and successful12-edge controls. Original packet, source, receipt and failed reviewer assumptions remain retained.','evidence':['process-replay.json','evidence-qualification-r2/counterexample-qualification.json','process-replay-r2.log','process-replay-r3.log']}],
 'independentChecks':[
 {'artifact':'security-final.log','result':'333 tests,6027 assertions,0 failures; includes six top-level original security tests and all tests/security'},
 {'artifact':'adversarial-controls.json','result':'353 checks:234 actual compiled AND/OR truth sequences of length2..4;40 existential populations length0..3; full old/new results; absorbing-branch missing coverage/projection/context, invalid values, source/storage substitutions and resource bounds refuse; unsupported typed constants refuse compilation'},
 {'artifact':'mutation-controls.json','result':'4 actual isolated runtime mutations detected: early-U AND, OR, exists, and removed dependency preflight'},
 {'artifact':'proof.json','result':'30 exact-source SMT queries replayed with Z34.15.4:12 UNSAT and18 SAT, including every theorem premise SAT'},
 {'artifact':'browser-r3.json','result':'98 matching Bun/Chromium151.0.7922.34 controls; no page errors, external requests or Node/Bun browser globals; Playwright1.62.1. Supplied Chromium153.0.8010.12 remains a separate checked receipt'},
 {'artifact':'process-replay.json','result':'15 actual new held-process producer/inspector operations, exact keys and frame hashes; parent cleanup verified; old13-edge refusal reproduced and two12-edge successes explicitly retained'},
 {'artifact':'graph-context-tests.json','result':'6 supplied isolated graph mapping tests with simulated cursor, no SQL'},
 {'artifact':'custody-audit.json','result':'3567 checks: exact257 captured builder inputs and rebuilt byte-identical bundle;570 unique accepted endpoint pins/2236 repeated occurrences; fresh supplied S24/S25/P04 receipts296/124/807 observations;42 retained accepted cases qualified'},
 {'artifact':'closing-custody.json','result':str(len(closing))+' original reconstruction inputs unchanged at close, plus257 exact builder pins; R2 evidence qualification verified'}],
 'analysis':[
 'All scoped rules still execute and retain original order; the code after truth evaluation, including decision dominance, selected source occurrences, disclosure/recipe resolution and output folding, is unchanged.',
 'U is never absorbing. Empty existential remains F. Preflight traverses the complete condition tree and full supplied populations before truth evaluation, including unused branches.',
 'The suspected unsupported date constant bypass is disproved: original entity-term compilation admits only its closed scalar families and validates constants; date/time/timestamp/UUID controls refuse before runtime.',
 'SMT establishes conditional ordered F/U/T fold properties over arbitrary finite relations, not a TypeScript translation or budget/termination proof. The skipped-preflight SAT item is an illustrative unvalidated-state premise, not a modeled implementation equivalence; the independent removed-preflight runtime mutant supplies a concrete negative control.',
 'The old refusal cause is attributed to literal-work exhaustion by separately retained owner diagnostic instrumentation. Independent uninstrumented replay establishes exact observable refusal/success only. Avoid treating diagnostic-modified source as the production execution cohort.',
 'The isolated graph draft explicitly restricts fact Fields to JSON home and graph witnesses to opaque-existential. It is not active Truss capture, complete non-JSON field support, Record-backed witness/attribute support, or backend acceptance.'
 ],
 'retainedAttempts':[
 'Reviewer reconstruction initially omitted base spike/evidence fixtures, top-level security tests and installed public-index adapter dependencies. The missing-import attempts and exact supplements are retained; the complete final333-test run passes.',
 'Initial reviewer browser launch could not create its local loopback server in the sandbox; the authorized local-browser retry passes. This was not a product assertion failure.',
 'Initial process harness incorrectly compared vector provenance metadata and expected the mislabeled14/12 refusal. Those source attempts/logs remain; final replay records exact cases without assuming outcomes.',
 'Initial custody script used the wrong canonical-gate path and exact stdout filename matching; corrected to the historical acceptance.json and explicit fresh receipt paths, retaining failed scripts/logs.',
 'Owner initial typecheck annotation, local-listener refusal, graph composition and diagnostic attempts remain in frozen/root-evidence and diagnostic-instrumentation.'
 ],
 'limits':[
 'No independent SQL/native database campaign, authenticated caller/source/current-cut proof, native graph admission, guarded release or query-operator qualification.',
 'No new full158-case canonical gate: only supplied fresh S24/S25/P04 and current byte correspondence for42 retained cases. Full158 cases/34 criteria remain mandatory,45 implemented and113 missing; no promotion.',
 'Source endpoint checks and captured selected inputs are not continuously held files, absence-of-ABA evidence, or a hermetic external runtime/toolchain closure.',
 'The graph collector is an isolated draft; later collector deadline/output changes outside the frozen packet receive no credit here.'
 ],
 'commands':'execution-summary.json',
 'artifactManifest':'manifest.json',
 'manifestFormat':'JSON object mapping relative artifact paths to {sha256, bytes}; manifest excludes itself. Expanded source/dependency trees are represented by exact retained ZIPs and maps; redundant base TAR archives are excluded.'
}
write('review.json',review)
# Standard immutable artifact manifest. Preserve ZIPs, maps, scripts, logs and extracted
# input packet; omit redundant expanded reconstruction/dependencies and bytecode.
excluded_roots={'source','dependency-supplement','dependency-supplement-r3','dependency-supplement-r4','dependency-supplement-ajv','relative-import-supplement'}
excluded_files={'manifest.json','base.tar','base-spikes.tar'}
files={}
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(R)
 if rel.parts[0] in excluded_roots or str(rel) in excluded_files or '__pycache__' in rel.parts:continue
 b=p.read_bytes();files[str(rel)]={'sha256':sha(b),'bytes':len(b)}
write('manifest.json',files)
for n,pin in read('manifest.json').items():
 b=(R/n).read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],n
print(json.dumps({'reviewSha256':sha((R/'review.json').read_bytes()),'manifestSha256':sha((R/'manifest.json').read_bytes()),'artifacts':len(files),'bytes':sum(v['bytes']for v in files.values())}))
