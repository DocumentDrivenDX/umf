from pathlib import Path
import subprocess,json,time,os
R=Path(__file__).parent;S=R/'source';runs=[]
for name,args in [('security',['/opt/homebrew/bin/bun','test','tests/security']),('proof',['/private/tmp/umf-security-proof-current-20261015/bin/python','tools/security/prove-condition-short-circuit.py',str(R/'proof.json')]),('build',['/opt/homebrew/bin/bun','tools/security/build-current-native-disclosure-child.ts',str(R/'rebuilt-bundle')])]:
 with (R/(name+'.log')).open('wb') as log:
  start=time.monotonic();p=subprocess.run(args,cwd=S,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 runs.append({'name':name,'argv':args,'cwd':str(S),'exitCode':p.returncode,'seconds':time.monotonic()-start});(R/'executions.json').write_text(json.dumps(runs,indent=2)+'\n');print(name,p.returncode,flush=True)
