import sys,pathlib,unittest,hashlib,json
sys.dont_write_bytecode=True
R=pathlib.Path(__file__).parent;prior=pathlib.Path('/private/tmp/truss-presence-consumer-astra-20261016/source/packages/python/src');assert prior.is_dir()
sys.path.insert(0,str(prior));import truss
truss.__path__.insert(0,str(R/'frozen/graph-spike/packages/python/src/truss'));sys.path.insert(0,str(R/'frozen/graph-spike/packages/python/tests'))
suite=unittest.defaultTestLoader.loadTestsFromName('test_current_disclosure_graphs');result=unittest.TextTestRunner(verbosity=2).run(suite)
pins={}
for name,m in tuple(sys.modules.items()):
 path=getattr(m,'__file__',None)
 if name.startswith('truss.') and path and pathlib.Path(path).is_file():pins[path]=hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
(R/'graph-context-tests.json').write_text(json.dumps({'status':'passed' if result.wasSuccessful() else 'failed','tests':result.testsRun,'pins':pins,'scope':'Supplied graph draft mapping tests with simulated cursor, using retained independent exact consumer source reconstruction for dependencies. No database, activation, non-JSON storage or Record-backed witness coverage.'},indent=2)+'\n');raise SystemExit(not result.wasSuccessful())
