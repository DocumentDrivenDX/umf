from pathlib import Path
import json,hashlib,struct,types,shutil
R=Path(__file__).parent;F=R/'frozen';sha=lambda b:hashlib.sha256(b).hexdigest();wire=lambda v:json.dumps(v,separators=(',',':')).encode();frame=lambda b:struct.pack('>I',len(b))+b
pipe=Path('/private/tmp/umf-held-native-disclosure-astra-20261016/frozen/evidence/15-_current_query_pipe.py').read_bytes();assert sha(pipe)=='39c7ab62660f64241f59008f5cb0b16b721f741657c44d321189237655031d7f';(R/'reviewed-pipe.py').write_bytes(pipe);m=types.ModuleType('reviewed_pipe');exec(compile(pipe,str(R/'reviewed-pipe.py'),'exec'),m.__dict__)
new=R/'rebuilt-bundle/current-native-disclosure-child.mjs';old=R/'original-eager-child.mjs';shutil.copyfile('/private/tmp/umf-held-native-disclosure-astra-20261016/frozen/bundle/current-native-disclosure-child.mjs',old)
assert sha(new.read_bytes())=='548b7ff64dabf3bc796afe99ecca265f5bcf242202e367ba7125e62c64f0a735';assert sha(old.read_bytes())=='d333226d9186136704d3f84a9c9dbfc44796efebab563dbc732d60337d2e03eb'
d=json.loads((F/'overlay/tests/security/nested-graph-condition-vectors.json').read_text());g=json.loads((F/'graph-spike/composition-test-packets.json').read_text());assert d==g
observations=[]
def run(bundle,initial,cut,expected=None):
 raw=wire(initial);pin=sha(frame(raw));evaluation=wire({'version':initial['version'],'kind':'evaluate-disclosure','requestId':'evaluate','sourceReceipt':pin,'cut':cut})
 with m.CurrentQueryPipe(('/opt/homebrew/bin/bun',str(bundle)),timeout_seconds=30) as child:
  initialized=json.loads(child.exchange(raw,source_receipt=pin));assert initialized['kind']=='initialized'
  evaluated=json.loads(child.exchange(evaluation,source_receipt=pin));inspection=None
  if expected is not None:
   result=evaluated['result'];assert result['status']=='rendered';keys=[r['key'][0]['string'] for r in result['resources']];assert keys==expected
   inspected=wire({'version':initial['version'],'kind':'inspect-native-disclosure','requestId':'inspect','sourceReceipt':pin,'batch':result['batch']})
   inspection=json.loads(child.exchange(inspected,source_receipt=pin));assert inspection['status']=='validated-disclosure';assert inspection['evaluationFrameSha256']==sha(frame(evaluation));assert inspection['inspectionFrameSha256']==sha(frame(inspected));assert inspection['complete'] is False and inspection['authority'] is False
  else:assert evaluated['result']['status']=='refused'
 assert child._cleanup_complete
 return {'initialized':initialized,'evaluated':evaluated,'inspection':inspection,'cleanupComplete':child._cleanup_complete,'sourceReceipt':pin}
for p in d['packets']:
 observations.append({'id':p['id'],'expected':p['expectedKeys'],'actual':run(new,d['initialize'],p['cut'],p['expectedKeys'])})
ce=json.loads((F/'graph-spike/eager-budget-counterexample.json').read_text());assert len(ce['cut']['facts'])==14 and len(ce['cut']['graphs'])==12
prior=run(old,ce['initialize'],ce['cut']);assert prior['evaluated']==ce['evaluated']
result={'status':'passed','scope':'Independent actual process replay; supplied graph cuts and expected keys retained from independently authored native-incidence fixtures. No fresh SQL or native authority. Pipe close verifies parent kill/join, not natural terminal exit.','positiveOperations':len(observations),'oldCounterexample':prior,'facts':14,'graphs':12,'pins':{'newBundle':sha(new.read_bytes()),'oldBundle':sha(old.read_bytes()),'pipe':sha(pipe)},'observations':observations}
(R/'process-replay.json').write_text(json.dumps(result,indent=2)+'\n');print('15 new process operations and old 14/12 refusal passed')
