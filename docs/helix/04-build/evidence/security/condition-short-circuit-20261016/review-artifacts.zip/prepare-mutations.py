from pathlib import Path
import json,hashlib
R=Path(__file__).parent;d=R/'source/src/extensions/security';original=(d/'catalog-runtime-candidate.ts').read_text();mutations={
 'early-u-and':("if(truth==='F')return 'F';","if(truth==='F'||truth==='U')return truth;"),
 'early-u-or':("if(truth==='T')return 'T';}return truth;","if(truth==='T'||truth==='U')return truth;}return truth;"),
 'early-u-exists':("if(truth==='T')return 'T';unknown ||= truth==='U';","if(truth==='T'||truth==='U')return truth;unknown ||= truth==='U';"),
 'skip-preflight':('for(const target of request.targets)for(const condition of scoped(target))preflight(condition.condition.expression,target,new Map());','// AST dependency preflight removed by reviewer mutation only')}
result={}
for name,(a,b) in mutations.items():
 assert original.count(a)==1,(name,original.count(a));changed=original.replace(a,b);p=d/('catalog-runtime-'+name+'-astra.ts');p.write_text(changed);result[name]={'relativePath':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'original':a,'mutant':b}
(R/'mutation-sources.json').write_text(json.dumps(result,indent=2)+'\n')
