from pathlib import Path
import json,subprocess,shutil,zipfile,hashlib,time
R=Path(__file__).parent;S=R/'source';O=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');D=R/'dependency-supplement-r3';D.mkdir()
for n in ['docs/helix/04-build/evidence/security/truss-graph-compiler-input.json','docs/helix/04-build/evidence/security/relationship-selector-spike.json']:
 b=subprocess.check_output(['git','show','206951ff20d766874b9af7d29fdf8027c3bab499:'+n],cwd=O);p=D/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
shutil.copytree(O/'node_modules/graphql',D/'node_modules/graphql')
pins={}
for p in D.rglob('*'):
 if p.is_file():
  n=str(p.relative_to(D));b=p.read_bytes();pins[n]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};dest=S/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
with zipfile.ZipFile(R/'dependency-supplement-r3.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in pins:z.write(D/n,n)
(R/'dependency-supplement-r3.json').write_text(json.dumps({'scope':'Two exact committed legacy evidence fixtures and installed GraphQL dependency omitted from reviewer selected reconstruction. Not changes to reviewed product sources.','files':pins},indent=2)+'\n')
t=time.monotonic();cmd=['/opt/homebrew/bin/bun','test','tests/security']
with (R/'security-r3.log').open('w') as f:p=subprocess.run(cmd,cwd=S,stdout=f,stderr=subprocess.STDOUT)
(R/'security-r3-execution.json').write_text(json.dumps({'argv':cmd,'cwd':str(S),'exitCode':p.returncode,'seconds':time.monotonic()-t},indent=2)+'\n')
raise SystemExit(p.returncode)
