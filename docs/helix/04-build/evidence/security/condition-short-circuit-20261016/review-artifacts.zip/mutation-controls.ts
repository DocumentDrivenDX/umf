import {writeFileSync} from 'node:fs';
import {catalogRuntimeFixture,compileRuntimeFixture} from './source/tests/security/catalog-runtime-fixture';
import {ref} from './source/tests/security/fixture';
import * as actual from './source/src/extensions/security/catalog-runtime-candidate';
const controls:any[]=[];
const base=()=>{const f=catalogRuntimeFixture();f.owner.disclosure={readAction:'read'};f.cut.maxSteps=1000000;return f;};
const evaluate=(api:any,f:any)=>api.evaluateCandidateCatalogReadRuleScan(compileRuntimeFixture(f),f.owner,f.cut,{type:ref('Resource')});
for(const name of ['early-u-and','early-u-or','early-u-exists','skip-preflight']){
 const api=await import('./source/src/extensions/security/catalog-runtime-'+name+'-astra.ts'),f=base();let condition:any,expected:string;
 if(name==='skip-preflight'){
  f.closure.documents[0].document.modules[0].elements.push({id:'ctx',kind:'field',scalarType:'integer',cardinality:'one',nullability:'required',extensions:{}});f.ontology.context=[ref('ctx')];
  condition={op:'or',args:[{op:'literal',value:true},{op:'eq',left:{kind:'context',field:ref('ctx')},right:{kind:'constant',field:ref('ctx'),value:{integerToken:'1'}}}]};expected='refused';
 }else if(name==='early-u-exists'){
  f.closure.documents[0].document.modules[0].elements.find((x:any)=>x.id==='active').nullability='absent-allowed';const a=f.cut.facts.find((x:any)=>x.type.elementId==='Assignment'),b=structuredClone(a);a.fields=a.fields.filter((x:any)=>x.field.elementId!=='active');a.absent=[ref('active')];b.key=[{string:'second'}];b.fields.find((x:any)=>x.field.elementId==='assignmentId').value={string:'second'};b.fields.find((x:any)=>x.field.elementId==='active').value={boolean:true};f.cut.facts.push(b);
  condition={op:'exists',association:ref('Assignment'),as:'a',where:{op:'eq',left:{kind:'variable',name:'a',field:ref('active')},right:{kind:'constant',field:ref('active'),value:{boolean:true}}}};expected='T';
 }else{
  f.closure.documents[0].document.modules[0].elements.find((x:any)=>x.id==='salary').nullability='absent-allowed';const r=f.cut.facts.find((x:any)=>x.type.elementId==='Resource');r.fields=r.fields.filter((x:any)=>x.field.elementId!=='salary');r.absent=[ref('salary')];const op=name==='early-u-and'?'and':'or';
  condition={op,args:[{op:'eq',left:{kind:'resource',field:ref('salary')},right:{kind:'constant',field:ref('salary'),value:{integerToken:'100'}}},{op:'literal',value:op==='or'}]};expected=op==='and'?'F':'T';
 }
 f.policy.rules=[{id:'control',effect:'permit',actions:['read'],target:[ref('Resource')],condition}];const baseline:any=evaluate(actual,f),mutant:any=evaluate(api,f);const baselineMeaning=baseline.status==='refused'?'refused':baseline.rows[0].rules[0].truth,mutantMeaning=mutant.status==='refused'?'refused':mutant.rows[0].rules[0].truth;
 if(baselineMeaning!==expected||mutantMeaning===expected)throw Error(name+' ineffective');controls.push({id:name,passed:true,baselineMeaning,mutantMeaning,baseline,mutant});
}
writeFileSync(import.meta.dir+'/mutation-controls.json',JSON.stringify({status:'passed',scope:'Four actual runtime mutations in separate reviewer files. Original source unchanged. Concrete controlled semantic counterexamples, not formal refinement.',controls},null,2)+'\n');console.log(controls.length,'effective mutants');
