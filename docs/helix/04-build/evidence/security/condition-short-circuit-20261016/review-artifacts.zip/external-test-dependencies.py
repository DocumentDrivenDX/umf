from pathlib import Path
import json,subprocess,time,hashlib
R=Path(__file__).parent;S=R/'source';O=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');pkg=json.loads((S/'package.json').read_text());links={}
for name in pkg['dependencies']:
 target=O/'node_modules'/name;dest=S/'node_modules'/name
 if not dest.exists() and target.exists():
  dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(target.resolve(),target_is_directory=True);meta=(target/'package.json').read_bytes();links[name]={'resolvedPath':str(target.resolve()),'packageSha256':hashlib.sha256(meta).hexdigest(),'installedVersion':json.loads(meta)['version']}
(R/'external-test-dependencies.json').write_text(json.dumps({'scope':'Remaining unchanged public-index adapters use installed declared dependencies. Their executable closure is explicitly non-hermetic; no product source or captured bundle bytes are modified.','links':links},indent=2)+'\n')
cmd=['/opt/homebrew/bin/bun','test','tests/security'];t=time.monotonic()
with (R/'security-r4.log').open('w') as f:p=subprocess.run(cmd,cwd=S,stdout=f,stderr=subprocess.STDOUT)
(R/'security-r4-execution.json').write_text(json.dumps({'argv':cmd,'cwd':str(S),'exitCode':p.returncode,'seconds':time.monotonic()-t},indent=2)+'\n')
raise SystemExit(p.returncode)
