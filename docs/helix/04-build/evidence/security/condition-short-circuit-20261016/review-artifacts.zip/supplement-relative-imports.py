from pathlib import Path
import re,subprocess,json,hashlib,zipfile,time
R=Path(__file__).parent;S=R/'source';O=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');D=R/'relative-import-supplement';D.mkdir();pins={}
for p in list((S/'src').rglob('*.ts'))+list((S/'tests/security').rglob('*.ts')):
 for m in re.finditer(r'''(?:from\s*|import\s*)['"](\.[^'"]+)['"]''',p.read_text()):
  q=(p.parent/m.group(1)).resolve();possible=[q,Path(str(q)+'.ts'),Path(str(q)+'.json'),q/'index.ts']
  if any(x.is_file() for x in possible):continue
  for x in possible:
   try:n=str(x.relative_to(S))
   except ValueError:continue
   cmd=['git','show','206951ff20d766874b9af7d29fdf8027c3bab499:'+n];out=subprocess.run(cmd,cwd=O,capture_output=True)
   if out.returncode==0:
    b=out.stdout;x.parent.mkdir(parents=True,exist_ok=True);x.write_bytes(b);dest=D/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);pins[n]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};break
with zipfile.ZipFile(R/'relative-import-supplement.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in pins:z.write(D/n,n)
(R/'relative-import-supplement.json').write_text(json.dumps({'scope':'Exact base committed relative imports omitted from reviewer reconstruction, no owner changes.','files':pins},indent=2)+'\n');print(len(pins),'files')
cmd=['/opt/homebrew/bin/bun','test','tests/security/protection/catalog.test.ts'];t=time.monotonic()
with (R/'catalog-dependency-check-r3.log').open('w') as f:p=subprocess.run(cmd,cwd=S,stdout=f,stderr=subprocess.STDOUT)
(R/'catalog-dependency-check-r3-execution.json').write_text(json.dumps({'argv':cmd,'cwd':str(S),'exitCode':p.returncode,'seconds':time.monotonic()-t},indent=2)+'\n');raise SystemExit(p.returncode)
