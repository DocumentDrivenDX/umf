from pathlib import Path
import json,hashlib,zipfile,subprocess
R=Path(__file__).parent;F=R/'frozen';S=R/'source';O=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def check(n,b):
 checks.append({'id':n,'passed':bool(b)})
 if not b:raise AssertionError(n)
check('packet-digest',sha((R/'review.zip').read_bytes())=='f64d1c803a252bac9f13ea1c2de789a4404dbece137d7b0bd8c421b0ed246730')
manifest=json.loads((F/'bundle/manifest.json').read_text());rebuilt=json.loads((R/'rebuilt-bundle/manifest.json').read_text());pins=manifest['sourcePins'];z=zipfile.ZipFile(F/'selected-source-inputs.zip');check('exact-257-members',set(z.namelist())==set(pins) and len(pins)==257)
for n,h in pins.items():
 check('captured:'+n,sha(z.read(n))==h);check('reconstructed-endpoint:'+n,sha((S/n).read_bytes())==h)
check('rebuilt-source-pins',rebuilt['sourcePins']==pins);check('rebuilt-bundle-exact',sha((R/'rebuilt-bundle/current-native-disclosure-child.mjs').read_bytes())==manifest['bundleSha256']==sha((F/'bundle/current-native-disclosure-child.mjs').read_bytes()))
for p in (F/'overlay').rglob('*'):
 if p.is_file():check('overlay:'+str(p.relative_to(F/'overlay')),(S/p.relative_to(F/'overlay')).read_bytes()==p.read_bytes())
prior=(R/'prior-runtime.ts').read_text();current=(S/'src/extensions/security/catalog-runtime-candidate.ts').read_text();check('unchanged-preflight',prior.split(' const evaluate=')[0]==current.split(' // Dependencies are preflighted above')[0]);check('unchanged-post-truth-fold',prior.split(' const traces:')[1]==current.split(' const traces:')[1])
for n in ['src/extensions/security/logic.ts','src/extensions/security/operation-budget-candidate.ts','src/extensions/security/catalog-program-candidate.ts','src/extensions/security/entity-terms-candidate.ts','src/extensions/security/protection/functions.ts','tools/security/current-native-disclosure-child.ts','tools/security/build-current-native-disclosure-child.ts']:
 b=subprocess.check_output(['git','show','206951ff20d766874b9af7d29fdf8027c3bab499:'+n],cwd=O);check('unchanged-base:'+n,b==(S/n).read_bytes())
proof=json.loads((R/'proof.json').read_text());check('proof-counts',len(proof['queries'])==30 and sum(q['result']=='unsat' for q in proof['queries'])==12 and sum(q['result']=='sat' for q in proof['queries'])==18)
for n,h in proof['sourceDigests'].items():check('proof-source:'+n,sha((S/n).read_bytes())==h)
for prefix in ['browser-r3.json','frozen/root-evidence/umf-nested-graph-browser-r2-20261016.json']:
 d=json.loads((R/prefix).read_text());snapshot=json.loads((R/(prefix+'.source-snapshot.json')).read_text());check('browser-success:'+prefix,d['status']=='passed' and d['controls']==98 and d['sourcesUnchanged'] and not d['pageErrors'] and not d['externalRequests']);check('browser-bundle:'+prefix,sha((R/(prefix+'.bundle.js')).read_bytes())==d['bundleSha256'])
 for n,h in d['selectedSourceDigests'].items():check('browser-source:'+prefix+':'+n,sha(snapshot['sources'][n].encode())==h and sha((S/n).read_bytes())==h)
a=json.loads((F/'accepted-case-revalidation.json').read_text());allpins={};repeated=0
for c in a['cases']:
 for n,h in c['sourceDigests'].items():
  check('consistent-case-pin:'+c['id']+':'+n,n not in allpins or allpins[n]==h);allpins[n]=h;repeated+=1
check('case-scope-counts',(a['requiredCases'],a['implementedCases'],a['missingCases'],len(a['cases']),len(allpins))==(158,45,113,45,570))
check('fresh-case-ids',a['freshCases']==['S24','S25','pg-raw.P04'])
check('plan-pin',sha((O/'docs/helix/03-test/security/cases.json').read_bytes())==a['planDigest'])
check('canonical-gate-pin',sha((O/'docs/helix/04-build/evidence/security/acceptance.json').read_bytes())==a['canonicalGateSha256'])
endpointmap={}
with zipfile.ZipFile(R/'accepted-endpoint-inputs.zip','w',zipfile.ZIP_DEFLATED) as out:
 for i,(n,h) in enumerate(sorted(allpins.items())):
  p=Path(n) if Path(n).is_absolute() else O/n;b=p.read_bytes();check('accepted-endpoint:'+n,sha(b)==h);member=f'{i:04d}/'+p.name;out.writestr(member,b);endpointmap[n]={'member':member,'sha256':h,'bytes':len(b)}
expected={'S24':296,'S25':124,'pg-raw.P04':807};found={}
for p in (F/'root-evidence').rglob('*stdout.json'):
 if 'previous-case-evidence' in p.parts:continue
 try:d=json.loads(p.read_text())
 except (ValueError,UnicodeError):continue
 if type(d)is dict and d.get('id') in expected and d.get('observations'):
  c=next(c for c in a['cases']if c['id']==d['id'])
  if d.get('runId')!=c['runId']:continue
  check('fresh-receipt:'+c['id'],len(d['observations'])==expected[c['id']] and d['sourceDigests']==c['sourceDigests']);found[c['id']]=str(p.relative_to(R))
check('three-fresh-receipts',set(found)==set(expected))
(R/'accepted-endpoint-map.json').write_text(json.dumps(endpointmap,indent=2)+'\n')
(R/'custody-audit.json').write_text(json.dumps({'status':'passed','checks':checks,'count':len(checks),'acceptedPins':len(allpins),'acceptedOccurrences':repeated,'freshReceipts':found,'scope':'Reconstructed and endpoint byte correspondence. Fresh original S24/S25/P04 supplied receipts inspected; no independent SQL run, no new canonical158-case gate, no held-file/ABA guarantee or hermetic executable closure.','independentBrowser':json.loads((R/'browser-r3.json').read_text())['browser'],'suppliedBrowser':json.loads((F/'root-evidence/umf-nested-graph-browser-r2-20261016.json').read_text())['browser']},indent=2)+'\n');print(len(checks),'checks')
