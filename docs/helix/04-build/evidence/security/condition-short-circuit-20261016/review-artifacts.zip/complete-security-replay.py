from pathlib import Path
import subprocess,json,zipfile,hashlib,time
R=Path(__file__).parent;S=R/'source';O=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');names=subprocess.check_output(['git','ls-tree','--name-only','206951ff20d766874b9af7d29fdf8027c3bab499:tests'],cwd=O).decode().splitlines();names=['tests/'+n for n in names if n.startswith('security') and n.endswith('.ts')];pins={}
with zipfile.ZipFile(R/'base-security-root-tests.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in names:
  b=subprocess.check_output(['git','show','206951ff20d766874b9af7d29fdf8027c3bab499:'+n],cwd=O);(S/n).write_bytes(b);z.writestr(n,b);pins[n]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
(R/'base-security-root-tests.json').write_text(json.dumps(pins,indent=2)+'\n');cmd=['/opt/homebrew/bin/bun','test','tests/security',*names];t=time.monotonic()
with (R/'security-final.log').open('w') as f:p=subprocess.run(cmd,cwd=S,stdout=f,stderr=subprocess.STDOUT)
(R/'security-final-execution.json').write_text(json.dumps({'argv':cmd,'cwd':str(S),'exitCode':p.returncode,'seconds':time.monotonic()-t},indent=2)+'\n');raise SystemExit(p.returncode)
