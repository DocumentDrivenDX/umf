import hashlib,json,subprocess,difflib,shutil
from pathlib import Path
ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads((ROOT/p).read_text())
plan_path='docs/helix/03-test/security/cases.json'
old=json.loads(subprocess.check_output(['git','show','HEAD:'+plan_path],cwd=ROOT));new=load(plan_path)
a={c['id']:c for c in old['cases']};b={c['id']:c for c in new['cases']}
selected=['pg-raw.B'+x for x in ['01','02','03','04','05','06','07','11','13','14','15','16']]+['pg-raw.L01','pg-raw.L02']
rows=[]
def check(name,actual):rows.append({'id':name,'passed':bool(actual)})
check('all158-original-case-identities',list(a)==list(b) and len(a)==158)
check('all-other144-cases-exact',all(a[k]==b[k] for k in a if k not in selected))
allowed={'command','testSource','oracleSource','implementationSources','evidence'}
changes={}
for k in selected:
 changed=[p for p in set(a[k])|set(b[k]) if a[k].get(p)!=b[k].get(p)];changes[k]=sorted(changed)
 check(k+':assertion-covers-timeout-status-preserved',set(changed)<=allowed)
 check(k+':separate-evidence',b[k]['evidence'].startswith('docs/helix/04-build/evidence/security/pg18-replay-20261015/'))
baseline=json.loads((OUT/'baseline-source-pins.json').read_text())
check('all30-historical-source-files-exact',len(baseline)==30 and all(sha((ROOT/p).read_bytes())==h for p,h in baseline.items()))
check('all14-historical-receipts-exact',all((ROOT/a[k]['evidence']).read_bytes()==subprocess.check_output(['git','show','HEAD:'+a[k]['evidence']],cwd=ROOT) for k in selected))
mapping=load('docs/helix/04-build/evidence/security/pg18-replay-20261015/mapping.json')
def diff(a,b,path='$'):
 if type(a)!=type(b):return [(path,a,b)]
 if isinstance(a,dict):
  if set(a)!=set(b):return [(path,a,b)]
  return sum([diff(a[k],b[k],path+'.'+k) for k in a],[])
 if isinstance(a,list):
  if len(a)!=len(b):return [(path,a,b)]
  return sum([diff(x,y,path+'['+str(i)+']') for i,(x,y) in enumerate(zip(a,b))],[])
 return [] if a==b else [(path,a,b)]
oracle_diffs={}
for before,after in mapping.items():
 if before.endswith('-oracle.json'):
  d=diff(load(before),load(after));oracle_diffs[after]=d
  check(after+':only-declared-engine-change',len(d)==1 and d[0][0] in ['$.engine','$.hashCollision.engine'] and d[0][1:] == ('170009','180006'))
 if before.endswith('.ts'):
  expected=(ROOT/before).read_text()
  for src,dst in mapping.items():expected=expected.replace(src,dst)
  if after.endswith('/scale-runtime.ts'):expected=expected.replace('PostgreSQL17.9 million-row runtime aggregate','PostgreSQL18.6 million-row runtime aggregate')
  check(after+':runtime-source-exact-except-relocation-and-scope-version',expected==(ROOT/after).read_text())
check('B07-disclosure-internal-schema-pinned','src/validation/internal-schema.ts' in b['pg-raw.B07']['implementationSources'])
for k in ['pg-raw.B13','pg-raw.B16','pg-raw.L01','pg-raw.L02']:
 deps=load('tests/security/native/pg-runtime-dependency-inventory.json')
 check(k+':all70-original-driver-files-pinned',len(deps['files'])==70 and set(deps['files'])<=set(b[k]['implementationSources']))
paths=set([plan_path,*mapping.keys(),*mapping.values(),'tools/security/pg18-replay/runtime-typecheck.json','docs/helix/03-test/security/pg-raw.md','docs/helix/03-test/test-plans/STP-056-security-bindings.md','docs/helix/04-build/security-field-protection-plan.md'])
for k in selected:paths.update([b[k]['testSource'],b[k]['oracleSource'],*b[k]['implementationSources']])
pins={p:sha((ROOT/p).read_bytes()) for p in sorted(paths)}
(OUT/'final-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
# Selected exact repository sources only. External original driver/runtime remains separately pinned.
for p in paths:
 if Path(p).is_absolute():continue
 target=OUT/'final-source'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,target)
result={'status':'passed' if all(r['passed'] for r in rows) else 'failed','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'checks':rows,'caseBindingChanges':changes,'oracleDifferences':oracle_diffs,'sourcePins':len(pins),'scope':'Additive source/case comparison;14 existing case bindings only, assertions/covers/status/timeouts and other144 cases unchanged. Selected dependency closure, not hermetic OS/runtime proof.'}
(OUT/'source-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(rows),'pins':len(pins),'failures':[r for r in rows if not r['passed']]}))
assert result['status']=='passed'
