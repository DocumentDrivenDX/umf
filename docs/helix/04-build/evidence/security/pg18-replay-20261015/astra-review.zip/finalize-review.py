from pathlib import Path
import datetime,hashlib,json,zipfile
OUT=Path(__file__).resolve().parent;ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');E=ROOT/'docs/helix/04-build/evidence/security/pg18-replay-20261015'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
evidence_pins={str(p.relative_to(ROOT)):sha(p) for p in sorted(E.rglob('*')) if p.is_file() and p.suffix in ['.json','.md','.log','.zip'] and 'astra' not in p.name}
(OUT/'parent-final-evidence-pins.json').write_text(json.dumps(evidence_pins,indent=2)+'\n')
checks=json.loads((OUT/'source-review.json').read_text());native=json.loads((OUT/'parent-native-review.json').read_text())
assert checks['status']=='passed' and native['status']=='passed'
review={
 'status':'reviewed-no-remaining-actionable-source-blocker',
 'reviewer':'Astra Ultra independent review','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'root':str(ROOT),'baselineHead':'7fc87eddcd922f113f59c4c27dbc5d99a09cc2f2',
 'scope':'Additive PostgreSQL18.6 replay of original B01-B07/B11/B13-B16/L01/L02 fixed raw vectors; no changes to their behavioral requirements.',
 'sourceAudit':{'checks':45,'selectedPins':443,'pins':'final-source-pins.json','receipt':'source-review.json','unchangedHistoricalSources':30,'unchangedHistoricalReceipts':14,'otherCasesUnchanged':144,'oracleDifference':'Only170009-to180006 declarations in four additive oracles; data, collision, rows, effects, budgets and expected decisions unchanged.'},
 'independentPureControls':{'helperFaults':43,'constraintSensitivity':47,'associationSensitivity':53,'total':143,'receipts':['helper-controls-final.json','inventory-controls.json','association-controls.json'],'scope':'Isolated actual functions/checker AST and retained native metadata mutations; no claim of native failure injection or SQL refinement.'},
 'sourceMutations':{'count':2,'exactFailureCounts':[5,4],'scope':'Omitted PK and FK enforcement guards; expected independent rows fail exactly, no setup/import errors counted.'},
 'independentNative':[
  {'case':'pg-raw.B02','observations':88,'elapsedSeconds':9.275738875,'timeoutMs':90000,'currentWholeSource':True,'receipt':'pg-raw.B02-native.json'},
  {'case':'pg-raw.B13','observations':144,'elapsedSeconds':11.16365275,'timeoutMs':120000,'currentWholeSource':False,'receipt':'pg-raw.B13-native.json'},
  {'case':'pg-raw.L02','observations':1164,'elapsedSeconds':45.573100915999994,'timeoutMs':120000,'currentWholeSource':False,'receipt':'pg-raw.L02-native.json'}],
 'nativeSourceQualification':'B13/L02 retain original whole membership-file fingerprints. The later B02 branch loader change is after their exec(prefix) boundary; exact prefix SHA90d949352c81e46f97e62008eedeea17fea99abff22fed7d50d84322717b399b and all their other selected sources remain identical. See executed-prefix-correspondence.json. These receipts are not relabeled as full-file-current reruns.',
 'nativeCleanup':'All three independent runs used fresh generated names/run IDs, exact image74935e72.../server180006 and original timeouts. Original cleanup plus independent Docker absence queries confirmed each exact container and anonymous volume absent.',
 'parentNativeInspected':{'cases':14,'observations':3526,'allCurrentSourcePins':True,'receipt':'parent-native-review.json','rerunByReviewer':False,'scale':'Original1k/100k/1M stages, paired plans,1ms timeout/25P02 recovery and managed actual driver verified.','writeVectors':{'L01':29,'L02':34}},
 'gate':{'requiredCases':158,'criteria':34,'executed':40,'accepted':40,'requiredUnbound':118,'unexpectedExecutionFailures':0,'source':'parent-native-review.json'},
 'resolvedFindings':['B02 accidentally retained17.9-only helper guard; separate18 helper now checks current native engine and enforced/immediate keys/FKs.','L01/L02 and standalone identity historical output paths corrected to additive18 evidence.','Scalar refusal classification tightened to exact primary SQLSTATE/exit3/empty stdout; ordinary mixed-error recovery remains separate.','Owned anonymous-volume cleanup now verified before publication and inventory digest rebinding; wrong image refusal does not suppress cleanup.','PG18 NOT NULL rows now checked separately with exact shape/column sets and enforcement/validation/deferral on resource and three selected authority dependencies.','B07 selected internal-schema dependency now fingerprinted.'],
 'withdrawnFinding':'Early B13 governed-output overwrite suspicion did not reproduce; its governed route was already selected_case evidence. Only standalone fallback needed relocation.',
 'retainedDevelopmentEvidence':['before-association-fix/','association-before-engine-witness.json','source-review-initial-failure.json','parent-development-evidence-pins.json','parent-final-evidence-pins.json'],
 'reviewerSetupFailure':'Initial static runtime-source comparison omitted the legitimate B16 textual17.9-to18.6 scope label; exact difference inspected and comparison corrected, no production change or failed native result hidden.',
 'limits':['No full M2/backend/Truss/Ashlar/Delta/native-current-authority/compiler/graph/final-publication qualification.','Fixed original fixture populations/actors/stable-cut assumptions; excluded installer/Docker administrator remain outside ordinary principal scope.','Constraint enforcement completeness checks apply to the four named write tables only; other native metadata is retained without new exhaustive assertion.','Driver inventory and443 source pins are selected custody evidence, not a hermetic OS/runtime dependency or held-source/ABA proof.','No PostgreSQL18 protocol3.2/cancel-key/general RETURNING/virtual-generated-carrier qualification inferred.','Overall goal remains open with118 required unbound cases.'],
 'edits':'No authoritative source/document/case edits or commits by reviewer; independent artifacts only in this private tmp packet.',
 'archive':'review-archive.zip'
}
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(OUT/'README.md').write_text('''# PostgreSQL18 raw replay independent review

No remaining actionable source blocker in the reviewed fixed subset.

-45 source/binding audit checks;143 isolated fault/metadata controls;2 actual enforcement guard omissions detected.
- Independent native B02:88 observations/9.276s; B13:144/11.164s; L02:1164/45.573s. Exact owned cleanup independently confirmed.
- B13/L02 precede a whole-file B02 loader change, but their executed prefix and all other selected sources match. Their original receipts remain unchanged.
- Parent final14 native receipts:3526 observations, current source fingerprints and cleanup verified by inspection. Full gate40 accepted/158 required,118 unbound.
- Historical17.9 inputs/receipts, native development failures, the old B02 engine refusal and a reviewer comparison setup failure are retained and distinguished.

`review.json` gives scope and limits. `archive-manifest.json` lists included bytes. Disposable copied replay roots and node_modules are excluded; final selected relative source snapshots, scripts, receipts and source pins are included. External managed driver/runtime dependencies remain pinned at original paths rather than copied. No full backend, current authority, compiler refinement or finalizer qualification is inferred.
''')
exclude={'native-replay-root','native-association-root','review-archive.zip','archive-summary.json','archive-manifest.json'}
files=[p for p in OUT.rglob('*') if p.is_file() and not any(part in exclude for part in p.relative_to(OUT).parts) and not p.is_symlink() and '__pycache__' not in p.parts]
manifest={'version':1,'files':{str(p.relative_to(OUT)):sha(p) for p in sorted(files)},'excluded':'Disposable duplicate replay roots, all node_modules, bytecode and archive/self-digest files.'}
(OUT/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files.append(OUT/'archive-manifest.json')
with zipfile.ZipFile(OUT/'review-archive.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,str(p.relative_to(OUT)))
summary={'review':str(OUT/'review.json'),'reviewSha256':sha(OUT/'review.json'),'archive':str(OUT/'review-archive.zip'),'archiveSha256':sha(OUT/'review-archive.zip'),'archiveBytes':(OUT/'review-archive.zip').stat().st_size,'files':len(files),'sourcePinsSha256':sha(OUT/'final-source-pins.json')}
(OUT/'archive-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
