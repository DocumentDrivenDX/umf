"""Independent fresh native replay from exact frozen sources; never writes root receipts."""
import hashlib,json,os,shutil,subprocess,time,uuid,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');WORK=OUT/'native-association-root'
if WORK.exists():raise RuntimeError('Refusing reused independent root')
shutil.copytree(OUT/'final-source',WORK)
(WORK/'node_modules').symlink_to(ROOT/'node_modules',target_is_directory=True)
for p in ['package.json','bun.lock']:
 if (ROOT/p).exists():shutil.copyfile(ROOT/p,WORK/p)
plan=json.loads((WORK/'docs/helix/03-test/security/cases.json').read_text());cases={c['id']:c for c in plan['cases']}
selected=['pg-raw.B02'];runs=[]
for identity in selected:
 case=cases[identity];run_id=str(uuid.uuid4());name='umf-sec-pgraw-'+run_id
 evidence=WORK/case['evidence'];evidence.parent.mkdir(parents=True,exist_ok=True)
 paths=[case['testSource'],case['oracleSource'],*case['implementationSources']]
 before={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in paths}
 source_original={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
 if before!=source_original:raise RuntimeError('Source copy differs')
 env={**os.environ,'UMF_SECURITY_CASE_ID':identity,'UMF_SECURITY_RUN_ID':run_id}
 command=case['command'];assert isinstance(command,list),command
 start=time.monotonic();proc=subprocess.Popen(command,cwd=WORK,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 try:stdout,stderr=proc.communicate(timeout=case['timeoutMs']/1000)
 except subprocess.TimeoutExpired:
  proc.terminate()
  try:stdout,stderr=proc.communicate(timeout=20)
  except subprocess.TimeoutExpired:proc.kill();stdout,stderr=proc.communicate()
  (OUT/(identity+'-timeout.log')).write_text(stdout+'\nSTDERR\n'+stderr)
  raise
 elapsed=time.monotonic()-start
 (OUT/(identity+'-native.stdout')).write_text(stdout);(OUT/(identity+'-native.stderr')).write_text(stderr)
 if proc.returncode!=0:raise RuntimeError('Native subset failed '+identity+': '+stderr[-2000:])
 receipt=json.loads(stdout);file_receipt=json.loads(evidence.read_text())
 assert receipt==file_receipt
 assert receipt['runId']==run_id and receipt['id']==identity and receipt['status']=='passed'
 assert receipt['sourceDigests']==before
 assert before=={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in paths}
 assert before=={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
 native=dict(receipt['nativeInventory']);digest=native.pop('digest')
 assert hashlib.sha256(json.dumps(native,sort_keys=True,separators=(',',':')).encode()).hexdigest()==digest
 cleanup=native['cleanup'];assert cleanup['containerAbsent'] is True and cleanup['volumesAbsent'] is True
 # Independent read-only native absence confirmation after the original cleanup.
 absent=subprocess.run(['docker','container','ls','-a','--filter','id='+cleanup['containerId'],'--format','{{.ID}}'],text=True,capture_output=True,check=True)
 volumes=subprocess.run(['docker','volume','ls','--format','{{.Name}}'],text=True,capture_output=True,check=True)
 assert absent.stdout.strip()=='' and not (set(volumes.stdout.splitlines()) & set(cleanup['ownedAnonymousVolumes']))
 snapshot=OUT/(identity+'-native.json');snapshot.write_text(json.dumps(receipt,indent=2)+'\n')
 runs.append({'id':identity,'runId':run_id,'elapsedSeconds':elapsed,'originalTimeoutMs':case['timeoutMs'],'exitCode':proc.returncode,'observations':len(receipt['observations']),'sourceUnchanged':True,'independentlyConfirmedCleanup':True,'receiptSha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),'version':receipt['versions']['postgresql'],'cleanup':cleanup})
 (OUT/'native-association-review.json').write_text(json.dumps({'status':'passed' if len(runs)==len(selected) else 'running','runs':runs,'scope':'Independent fresh native subset from byte-identical copied frozen source and original case metadata. Root evidence paths are relative to isolated copy. Shared original managed driver dependencies remain pinned; no new runtime/model oracle.'},indent=2)+'\n')
 print(json.dumps(runs[-1]),flush=True)
