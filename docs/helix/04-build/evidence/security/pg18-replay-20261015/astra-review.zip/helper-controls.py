"""Independent pure fault controls for actual pg18 helper functions. No Docker."""
import ast,hashlib,json,re,subprocess,sys,types
from pathlib import Path

ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
OUT=Path(__file__).resolve().parent
path=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'tests/security/native/pg18-replay/membership.py'
data=path.read_bytes();tree=ast.parse(data)
ns={'json':json,'re':re,'hashlib':hashlib,'run_id':'a06b132a-3a5c-4189-9d0b-d66fa9b45c13'}
ns['PG_IMAGE']=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PG_IMAGE' for t in n.targets))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(path),'exec'),ns)
rows=[]
def check(name,expected,observed):rows.append({'id':name,'expected':expected,'observed':observed,'pass':type(expected)==type(observed) and expected==observed})
for state in ['42501','57014','P0001']:
 base='ERROR:  '+state+': native diagnostic\nLOCATION:  native_function, native.c:1\n'
 cases=[('exact',3,'',base,True),('wrong-exit',2,'',base,False),('row-output',3,'private-row\n',base,False),('whitespace-output',3,'\n',base,False),('wrong-primary',3,'','ERROR:  22023: mentions '+state+'\n',False),('transport',3,'','daemon mentioned '+state+'\n',False),('fatal',3,'',base+'FATAL:  08006: lost\n',False),('multiple',3,'',base+base,False)]
 for label,code,stdout,stderr,expected in cases:check('state:'+state+':'+label,expected,bool(ns['statement_error'](types.SimpleNamespace(returncode=code,stdout=stdout,stderr=stderr),state)))

CID='a'*64;VOL='v'*64
def run_cleanup(mode):
 commands=[]
 ownership={'Id':CID,'Image':ns['PG_IMAGE'].split('@')[1],'Config':{'Labels':{'umf.security.run':ns['run_id']}},'Mounts':[{'Type':'volume','Name':VOL}]}
 if mode=='foreign-owner':ownership['Config']['Labels']['umf.security.run']='foreign'
 if mode=='wrong-image':ownership['Image']='sha256:'+'b'*64
 def command(args,**_kw):
  commands.append(args)
  code=0;stdout='';stderr=''
  if args[:2]==['docker','inspect']:
   stdout=ownership['Image'] if '--format' in args else json.dumps([ownership])
   if mode=='inspect-error':code=1;stderr='daemon unavailable'
  elif args[:3]==['docker','container','ls']:
   if any(a.startswith('volume=') for a in args):
    stdout=('b'*12 if mode=='shared-volume' else CID[:12])+'\n'
    if mode=='users-error':code=1;stderr='access denied'
   else:
    stdout=CID+'\n' if mode=='container-remains' else ''
    if mode=='container-query-error':code=1;stderr='daemon unavailable'
  elif args[:2]==['docker','rm']:
   assert args==['docker','rm','-fv',CID],args
   if mode=='remove-error':code=1;stderr='remove failed'
  elif args[:3]==['docker','volume','ls']:
   stdout=VOL+'\n' if mode=='volume-remains' else ''
   if mode=='volume-query-error':code=1;stderr='daemon unavailable'
  else:raise AssertionError(('Unexpected command',args))
  return types.SimpleNamespace(returncode=code,stdout=stdout,stderr=stderr)
 ns['command']=command
 try:result=ns['cleanup_owned_fixture'](CID);accepted=True
 except RuntimeError:result=None;accepted=False
 return accepted,result,commands

for mode in ['clean','foreign-owner','wrong-image','shared-volume','inspect-error','users-error','remove-error','container-query-error','volume-query-error','container-remains','volume-remains']:
 accepted,result,commands=run_cleanup(mode)
 check('cleanup:'+mode,mode in ['clean','wrong-image'],accepted)
 if mode in ['foreign-owner','shared-volume','inspect-error','users-error']:
  check('cleanup:'+mode+':no-delete',True,not any(c[:2]==['docker','rm'] for c in commands))
 if accepted:
  receipt={'nativeInventory':{'prior':'retained','digest':'old'}};ns['retain_cleanup'](receipt,result)
  native=dict(receipt['nativeInventory']);digest=native.pop('digest')
  check('cleanup:'+mode+':digest-rebound',True,digest==hashlib.sha256(json.dumps(native,sort_keys=True,separators=(',',':')).encode()).hexdigest())

for image,expected in [(ns['PG_IMAGE'].split('@')[1],True),('sha256:'+'b'*64,False)]:
 ns['command']=lambda _args,image=image:types.SimpleNamespace(returncode=0,stdout=image,stderr='')
 try:ns['verify_native_image'](CID);actual=True
 except RuntimeError:actual=False
 check('early-image:'+str(expected),expected,actual)

result={'status':'passed' if all(r['pass'] for r in rows) else 'failed','source':str(path),'sourceSha256':hashlib.sha256(data).hexdigest(),'scope':'Pure isolated function fault injection only, no real Docker failure-injection or native lifecycle claims. Wrong-image owned fixture cleans up but cannot pass image qualification.','rows':rows}
print(json.dumps(result,indent=2))
