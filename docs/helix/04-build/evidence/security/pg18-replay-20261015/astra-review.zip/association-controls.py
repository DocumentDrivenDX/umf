"""Independent comparison controls over retained genuine native descriptors; no SQL."""
import copy,hashlib,json
from pathlib import Path
ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');OUT=Path(__file__).resolve().parent
source=ROOT/'tests/security/native/pg18-replay/association.py';data=source.read_text()
receipt=(ROOT/'docs/helix/04-build/evidence/security/pg18-replay-20261015/cases/pg-raw-B02.json').read_bytes();native=json.loads(receipt)['nativeInventory']['associationDescriptors']
selection=json.loads((ROOT/'tests/security/native/pg-raw-membership-oracle.json').read_text())['associationSelection'];base=native['qualified'];mapping=selection['mapping']
(OUT/'association-input.json').write_text(json.dumps({'selection':selection,'descriptors':native,'parentReceiptSha256':hashlib.sha256(receipt).hexdigest()},indent=2)+'\n')
scenarios=[('native-current-positive',mapping,base,True)]
for engine in ['170009','180005','180006x',180006]:
 x=copy.deepcopy(base);x['engine']=engine;scenarios.append(('engine:'+str(engine),mapping,x,False))
for label,x in native.items():
 if label!='qualified':scenarios.append(('original-native:'+label,mapping,x,False))
used={x['home']['table'] for x in selection['types']} | {x['home']['table'] for x in selection['definitions']}
for ti,t in enumerate(base['tables']):
 if t['home']['table'] not in used:continue
 table=t['home']['table']
 for ki,k in enumerate(t['keys']):
  if not k['primary']:continue
  for prop,value in [('enforced',False),('validated',False),('deferrable',True),('deferred',True)]:
   x=copy.deepcopy(base);x['tables'][ti]['keys'][ki][prop]=value;scenarios.append(('key:'+table+':'+prop,mapping,x,False))
 if table not in {x['home']['table'] for x in selection['definitions']}:continue
 for fi,fk in enumerate(t['foreignKeys']):
  for prop,value in [('enforced',False),('validated',False),('deferrable',True),('triggers',[]),('triggers',['D'])]:
   x=copy.deepcopy(base);x['tables'][ti]['foreignKeys'][fi][prop]=value;scenarios.append(('fk:'+table+':'+str(fi)+':'+prop+':'+str(value),mapping,x,False))
for label in ['reversed-roles','wrong-type','wrong-column','duplicate-role','reversed-key']:
 m=copy.deepcopy(mapping);v=m['associations'][1]
 if label=='reversed-roles':v['endpoints'].reverse()
 if label=='wrong-type':v['endpoints'][1]['logicalType']=copy.deepcopy(selection['types'][0]['logicalType'])
 if label=='wrong-column':v['endpoints'][0]['columns']=['project_id']
 if label=='duplicate-role':v['endpoints'][1]['role']=v['endpoints'][0]['role']
 if label=='reversed-key':v['keyColumns'].reverse()
 scenarios.append(('mapping:'+label,m,base,False))
def execute(text):
 ns={'__name__':'independent_association'};exec(compile(text,str(source),'exec'),ns)
 admission=ns['AssociationAdmission'](selection['types'],selection['definitions']);rows=[]
 for label,m,inv,expected in scenarios:
  calls=[]
  def operation():calls.append(True);return [['independent-operation-witness']]
  result=admission.read(m,lambda:inv,operation)
  want={'status':'admitted','rows':[['independent-operation-witness']]} if expected else {'status':'refused','rows':[]}
  passed=result==want and len(calls)==int(expected)
  rows.append({'id':label,'expected':want,'observed':result,'calls':len(calls),'passed':passed})
 return rows
rows=execute(data);assert all(r['passed'] for r in rows)
old=(ROOT/'tools/security/pg-association.py').read_text();old_rows=execute(old)
witness=next(r for r in old_rows if r['id']=='native-current-positive')
assert witness['observed']=={'status':'refused','rows':[]} and witness['calls']==0
(OUT/'association-before-engine-witness.json').write_text(json.dumps({'scope':'Original17 helper rejects actual retained180006 baseline before callback; no native rerun or engine rewriting.','sourceSha256':hashlib.sha256(old.encode()).hexdigest(),'witness':witness},indent=2)+'\n')
mutants=[]
for label,needle,replacement,count in [('omit-key-enforcement'," and k['enforced']",'',2),('omit-fk-enforcement'," or not fk['enforced']",'',1)]:
 assert data.count(needle)==count
 text=data.replace(needle,replacement);(OUT/(label+'.py')).write_text(text)
 failed=[r['id'] for r in execute(text) if not r['passed']]
 expected=[r[0] for r in scenarios if r[0].startswith('key:' if label=='omit-key-enforcement' else 'fk:') and ':enforced' in r[0]]
 assert sorted(failed)==sorted(expected),(label,failed,expected)
 mutants.append({'id':label,'sha256':hashlib.sha256(text.encode()).hexdigest(),'failedControlIds':failed,'exactFailuresMatched':True})
result={'status':'passed','sourceSha256':hashlib.sha256(data.encode()).hexdigest(),'parentReceiptSha256':hashlib.sha256(receipt).hexdigest(),'controls':rows,'mutants':mutants,'scope':'Independent synthetic metadata/mapping refusals and2 actual source guard omissions. Genuine current/native-adverse descriptors inspected, not independently executed by this script. Fixed selected immediate deterministic TEXT junction mapping, not issuer authentication/lifetime/native semantic refinement.'}
(OUT/'association-controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','controls':len(rows),'mutants':len(mutants),'exactMutantFailures':[len(m['failedControlIds']) for m in mutants]}))
