"""Inspect fresh governed receipts; does not rerun their native lifecycles."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');OUT=Path(__file__).resolve().parent
plan=json.loads((ROOT/'docs/helix/03-test/security/cases.json').read_text());cases={c['id']:c for c in plan['cases']}
ids=['pg-raw.B'+x for x in ['01','02','03','04','05','06','07','11','13','14','15','16']]+['pg-raw.L01','pg-raw.L02'];image='sha256:74935e72241653ca55e0414067e6d8763aceb8a810eb51b452253ec3dcfc4336'
def exact(a,b):
 if type(a)!=type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
rows=[]
for identity in ids:
 c=cases[identity];p=ROOT/c['evidence']
 if not p.exists():rows.append({'id':identity,'passed':False,'missing':True});continue
 raw=p.read_bytes();r=json.loads(raw);obs=r['observations'];native=dict(r['nativeInventory']);digest=native.pop('digest');engine=r['versions']['postgresql'];num=engine.get('number',engine.get('serverVersionNum'))
 expected={s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest() for s in [c['testSource'],c['oracleSource'],*c['implementationSources']]}
 checks={'status':r['status']=='passed','id':r['id']==identity,'command':r['command']==c['command'],'covers':r['covers']==c['covers'],'fingerprints':r['sourceDigests']==expected,'allObservationsExact':all(exact(o['expected'],o['observed']) for o in obs),'uniqueObservationIds':len({o['assertionId'] for o in obs})==len(obs),'primaryCaseObservation':sum(o['assertionId']==identity for o in obs)==1,'engine':num=='180006','exactImage':native['imageId']==image,'cleanup':native['cleanup']['containerAbsent'] is True and native['cleanup']['volumesAbsent'] is True and native['cleanup']['imageId']==image,'inventoryDigest':hashlib.sha256(json.dumps(native,sort_keys=True,separators=(',',':')).encode()).hexdigest()==digest}
 rows.append({'id':identity,'passed':all(checks.values()),'checks':checks,'observations':len(obs),'runId':r['runId'],'path':c['evidence'],'sha256':hashlib.sha256(raw).hexdigest(),'sourceDigests':r['sourceDigests'],'engine':engine,'cleanup':native['cleanup']})
# Independently authored expected profile facts retained unchanged across upgrade.
scale=json.loads((ROOT/cases['pg-raw.B16']['evidence']).read_text());n=scale['nativeInventory']
scale_check={'populations':[s['actualResources'] for s in n['stagePlans']]==[1000,100000,1000000],'threeProtectedAndAssessorPlans':all(s['protectedPlan'] and s['excludedAssessorPlan'] for s in n['stagePlans']) and len(n['stagePlans'])==3,'budgets':n['selectedBudgets']=={'originalResponseTimeoutMs':30000,'statementTimeoutMs':1,'runtimeProcessSeconds':90},'actualDriverEveryStage':len(n['runtimeArtifacts'])==3 and all(s['status']=='passed' and s['driverEntry']==n['managedDependencyInventory']['entry'] and all(exact(o['expected'],o['observed']) for o in s['observations']) for s in n['runtimeArtifacts'])}
identity=json.loads((ROOT/cases['pg-raw.B13']['evidence']).read_text());hashobs=[o for o in identity['observations'] if 'hash' in o['assertionId']]
write_vectors={}
for ident,count in [('pg-raw.L01',29),('pg-raw.L02',34)]:
 r=json.loads((ROOT/cases[ident]['evidence']).read_text());runtime=r['runtimeReceipts'];write_vectors[ident]={'expectedVectors':count,'actualVectors':len(runtime),'passed':len(runtime)==count and all(x['status']=='passed' and all(exact(o['expected'],o['observed']) for o in x['observations']) for x in runtime)}
gateraw=(ROOT/'docs/helix/04-build/evidence/security/acceptance.json').read_bytes();g=json.loads(gateraw);executions={e['id']:e for e in g['execution']};gate_checks={'cases158':g['requiredCases']==158,'criteria34':g['allocatedAcceptanceCriteria']==34,'all14ExecutedAndAccepted':all(i in executions and executions[i].get('accepted') is True for i in ids),'all14MatchReceiptRun':all(executions.get(r['id'],{}).get('runId')==r.get('runId') for r in rows),'noUnexpectedExecutionFailure':all(e.get('accepted') is True for e in g['execution']),'planUnchanged':g['planDigest']==g['finalPlanDigest']==hashlib.sha256((ROOT/'docs/helix/03-test/security/cases.json').read_bytes()).hexdigest()}
result={'status':'passed' if all(r['passed'] for r in rows) and all(scale_check.values()) and all(x['passed'] for x in write_vectors.values()) and all(gate_checks.values()) else 'pending-or-failed','scope':'Parent native receipts and governed gate inspected, not independently rerun by this script. Independent B02/B13/L02 runs separately retained. Fixed raw18.6 subset only; no production compiler/Truss/Ashlar/complete backend/current-authority qualification.','cases':rows,'scaleChecks':scale_check,'identityHashObservations':hashobs,'writeVectors':write_vectors,'gate':{'path':'docs/helix/04-build/evidence/security/acceptance.json','sha256':hashlib.sha256(gateraw).hexdigest(),'checks':gate_checks,'executed':len(g['execution']),'accepted':sum(e.get('accepted',False) for e in g['execution']),'errors':len(g['errors']),'unexpectedErrors':[e for e in g['errors'] if 'required reviewed runner/oracle/implementation binding not implemented' not in e]}}
(OUT/'parent-native-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'observations':sum(r.get('observations',0) for r in rows),'failedCases':[{'id':r['id'],'checks':[k for k,v in r.get('checks',{}).items() if not v]} for r in rows if not r['passed']],'gate':result['gate'],'scale':scale_check,'writeVectors':write_vectors}))
