"""Independent PG18 constraint sensitivity; executes actual selected AST checks, no DB."""
import ast,copy,hashlib,json
from pathlib import Path
ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
OUT=Path(__file__).resolve().parent
source=ROOT/'tests/security/native/pg18-replay/write-inventory.py'
data=source.read_bytes();f=next(n for n in ast.parse(data).body if isinstance(n,ast.FunctionDef) and n.name=='collect')

def check_id(n):
 if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='check':
  a=n.value.args[0]
  if isinstance(a,ast.Constant):return a.value
 return ''
selected=[]
for n in f.body:
 if check_id(n) in ['inventory:resource-columns','inventory:resource-constraints','inventory:resource-not-null-shape','inventory:resource-not-null','inventory:resource-enforced-validated']:
  selected.append(n)
 if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['dependency_columns','expected_constraints']:selected.append(n)
 if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='dependency_columns':selected.append(n)
code=compile(ast.Module(body=selected,type_ignores=[]),str(source),'exec')
receipt_path=ROOT/'docs/helix/04-build/evidence/security/pg18-replay-20261015/cases/pg-raw-L01.json'
receipt_data=receipt_path.read_bytes();base=json.loads(receipt_data)['nativeInventory']
# This is captured genuine native inventory used only as input to synthetic checks.
(OUT/'constraint-input.json').write_text(json.dumps({'inventory':base,'receiptSha256':hashlib.sha256(receipt_data).hexdigest()},indent=2)+'\n')
rows=[]
def run(label,inventory,expected_prefix=None):
 observed=[]
 def check(name,expected,actual):
  observed.append(name)
  if type(expected) is not type(actual) or expected!=actual:raise AssertionError(name)
 try:
  exec(code,{'inventory':inventory,'dependency':inventory['authorityDependencies'],'check':check})
  outcome='accepted'
 except AssertionError as e:outcome=str(e)
 except Exception as e:outcome='UNEXPECTED:'+type(e).__name__+':'+str(e)
 passed=outcome=='accepted' if expected_prefix is None else outcome.startswith(expected_prefix)
 rows.append({'id':label,'expected':'accepted' if expected_prefix is None else expected_prefix+'*','observed':outcome,'passed':passed})
run('native-input-positive',copy.deepcopy(base))
for table in ['resource','employee','m2m_employee_project','project']:
 for mutation in ['missing-n','duplicate-n','extra-n','empty-vector','wide-vector','unenforced-n','unvalidated-n','deferrable-n','deferred-n','unenforced-p','unenforced-f','wrong-fk']:
  inv=copy.deepcopy(base);target=inv if table=='resource' else inv['authorityDependencies'];constraints=target['constraints'];cs=[c for c in constraints if c['table']==table]
  n=next(c for c in cs if c['kind']=='n')
  prefix='inventory:resource-' if table=='resource' else 'inventory:dependency-'
  if mutation=='missing-n':constraints.remove(n);expected=prefix+'not-null'
  elif mutation=='duplicate-n':constraints.append(copy.deepcopy(n));expected=prefix+'not-null'
  elif mutation=='extra-n':x=copy.deepcopy(n);x['columnNames']=['extra'];constraints.append(x);expected=prefix+'not-null'
  elif mutation=='empty-vector':n['columnNames']=[];expected=prefix+'not-null-shape'
  elif mutation=='wide-vector':n['columnNames']=['id','other'];expected=prefix+'not-null-shape'
  elif mutation in ['unenforced-n','unvalidated-n','deferrable-n','deferred-n']:
   key,val={'unenforced-n':('enforced',False),'unvalidated-n':('validated',False),'deferrable-n':('deferrable',True),'deferred-n':('deferred',True)}[mutation];n[key]=val;expected=prefix+'enforced-validated'
  elif mutation in ['unenforced-p','unenforced-f']:
   candidates=[c for c in cs if c['kind']==mutation[-1]]
   if not candidates:continue
   candidates[0]['enforced']=False;expected=prefix+'enforced-validated'
  elif mutation=='wrong-fk':
   candidates=[c for c in cs if c['kind']=='f']
   if not candidates:continue
   candidates[0]['definition']='FOREIGN KEY (id) REFERENCES wrong.home(id)';expected=prefix+('constraints' if table=='resource' else 'keys')
  run(table+':'+mutation,inv,expected)
result={'status':'passed' if all(r['passed'] for r in rows) else 'failed','source':str(source.relative_to(ROOT)),'sourceSha256':hashlib.sha256(data).hexdigest(),'nativeInputReceiptSha256':hashlib.sha256(receipt_data).hexdigest(),'scope':'Synthetic mutations of retained genuine18.6 catalog inventory against exact selected original checker AST. No native ALTER/DB failure injection and no general catalog closure theorem. Fixed checked tables only; unrelated tables retained but not newly certified.','controls':rows}
(OUT/'inventory-controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'controls':len(rows),'failures':[r for r in rows if not r['passed']]}))
assert result['status']=='passed'
