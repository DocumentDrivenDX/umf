from pathlib import Path
import copy,json,hashlib,textwrap
p=Path(__file__).resolve().parent
source=Path('/Users/erik/.codex/worktrees/security-main-integration/umf/tools/security/weft-sum-child-interop.py').read_text()
(p/'before-semantic-verifier.py').write_text(source)
producer=textwrap.dedent(source[source.index('  expected_scans,'):source.index('  routes=[',source.index('  expected_scans,'))])
producer='for operation in packet["operations"]:\n if operation["kind"]=="sum": assert operation["outputType"]=={"family":"integer","facets":{},"nullable":name!="grouped-sum"}\n'+producer
response=textwrap.dedent(source[source.index("   expected='deny'"):source.index('   record=',source.index("   expected='deny'"))])
(p/'extracted-producer-checks.py').write_text(producer);(p/'extracted-response-checks.py').write_text(response)
base=Path('/private/tmp/umf-weft-sum-child-interop-20261015-r2')
scalar=([('s0','Resource')],[],[('s0','outputs/0/argument','salary','aggregate','sum',['nullity'])],['query-original-salary-sum'])
signatures={'sum':scalar,'false-sum':scalar,'inactive-sum':scalar,'grouped-sum':([('s0','Resource')],[('s0','outputs/0/expression','token')],[('s0','groups/0','token','group','group',['equality']),('s0','outputs/1/argument','salary','aggregate','sum',['nullity'])],[None,'query-original-salary-sum']),'field-free-count':([('s0','Resource')],[],[],[])}
results=[]
def run(name,stage,mutation=None,label='baseline'):
 r=json.loads((base/(name+'.json')).read_text())
 if mutation:mutation(r)
 env=dict(r,name=name,inactive=name=='inactive-sum',expected_signatures=signatures,field_ref=lambda x:{'documentId':x['documentId'],'moduleId':x['module'],'elementId':x['element']})
 env['evaluated']=r['evaluation'];env['batch']=r['evaluation']['batch'];env['routes']=[{'id':'route'+str(i),'use':x} for i,x in enumerate(r['packet']['routes'])];env['action_ops']=[x['id'] for x in r['operations'] if x['kind']=='action']
 try:exec(compile(producer if stage=='producer' else response,str(p/('extracted-'+stage+'-checks.py')),'exec'),env);status='accepted'
 except AssertionError:status='rejected'
 except Exception as e:status='setup-error:'+type(e).__name__+':'+str(e)
 results.append({'case':name,'stage':stage,'control':label,'outcome':status})
for n in signatures:
 for s in ['producer','response']:run(n,s)
run('field-free-count','producer',lambda r:r['packet'].update(operations=[]),'COUNT-operation-omitted')
run('false-sum','producer',lambda r:r['packet']['operations'][0].update(boolean=True),'FALSE-filter-changed-to-TRUE')
run('sum','producer',lambda r:r['packet']['operations'][0]['operands'][0]['input'].update(logicalType={'family':'string','facets':{},'nullable':True}),'SUM-input-domain-changed')
run('sum','producer',lambda r:r['packet']['operations'][0]['operands'][0]['input']['identity'].update(revision='foreign-revision'),'SUM-input-revision-changed')
run('sum','response',lambda r:r['evaluation']['routeResults'][0]['result']['plan']['branches'][0].update(status='compatible-disclosed-properties'),'SUM-route-silently-disclosed')
run('sum','response',lambda r:r['evaluation']['routeResults'][0]['result']['plan']['branches'][0].update(queryValue={'origin':'pre-storage-field','field':{'documentId':'domain','moduleId':'m','elementId':'clear'}}),'SUM-route-wrong-value-origin')
run('sum','response',lambda r:r['evaluation']['routeResults'][0]['result']['rows'][0]['activeBranches'].append(999),'extra-unresolved-active-branch')
run('sum','response',lambda r:r['evaluation']['batch']['operations'][0]['outcome']['rows'][0].update(decision='deny'),'actual-read-denial')
run('sum','producer',lambda r:r['packet']['operations'][0]['outputType'].update(nullable=False),'global-SUM-wrong-nullability')
assert all(x['outcome']=='accepted' for x in results if x['control']=='baseline')
assert not any(x['outcome'].startswith('setup-error') for x in results)
(p/'before-verifier-controls.json').write_text(json.dumps({'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'scope':'Exact selected semantic verifier statements extracted from current root tool; original retained reports mutated as data. Does not simulate native compiler/child execution or cryptographic custody checks.','results':results},indent=2)+'\n')
print(json.dumps(results,indent=2))
