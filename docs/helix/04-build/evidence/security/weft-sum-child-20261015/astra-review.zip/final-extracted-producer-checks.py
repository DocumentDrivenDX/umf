def operand(path,element,action):
 return {'path':path,'input':{'kind':'field','scan':'s0','identity':{'documentId':'domain','revision':'query-value-core-r1','module':'m','element':element},'logicalType':{'family':'integer','facets':{'integerWidth':{'bits':64,'signed':True}},'nullable':False} if element=='salary' else {'family':'string','facets':{},'nullable':False},'originalAction':action}}
def operation(path,kind,operator=None,operands=None,output=None,boolean=None):return {'path':path,'kind':kind,'operator':operator,'operands':operands or [],'outputType':output,'boolean':boolean,'direction':None}
grouped=name=='grouped-sum'
sum_path='outputs/1' if grouped else 'outputs/0'
sums=[operation(sum_path,'sum','aggregate',[operand(sum_path+'/argument','salary','query-original-salary-sum')],{'family':'integer','facets':{},'nullable':not grouped})]
expected_operations=([operation('groups/0','group','group',[operand('groups/0','token',None)])] if grouped else [])+sums
if name=='false-sum':expected_operations.insert(0,operation('filters/0','boolean',boolean=False))
if name=='field-free-count':expected_operations=[operation('outputs/0','count',output={'family':'integer','facets':{},'nullable':False})]
assert packet['operations']==expected_operations
expected_scans,expected_projections,expected_routes,expected_actions=expected_signatures[name]
assert [(x['scan'],x['type']['elementId']) for x in packet['scans']]==expected_scans
assert [(x['scan'],x['path'],x['field']['element']) for x in packet['projections']]==expected_projections
assert [(x['scan'],x['path'],x['field']['elementId'],x['operator'],x['operation'],x['required']) for x in packet['routes']]==expected_routes
assert [x['originalAction'] for x in designation['uses']]==expected_actions
for scan in packet['scans']:assert scan['type']=={'documentId':'domain','moduleId':'m','elementId':'Resource'} and scan['record']=={'documentId':'domain','revision':'query-value-core-r1','module':'m','element':'Resource'}
for projection in packet['projections']:assert projection['field']=={'documentId':'domain','revision':'query-value-core-r1','module':'m','element':projection['field']['element']}
fields=[(op,x) for op in packet['operations'] for x in op['operands'] if x['input']['kind']=='field']
assert len(fields)==len(packet['routes'])==len(designation['uses'])
assert [(x['scan'],x['path']) for x in packet['routes']]==[(x['input']['scan'],x['path']) for _,x in fields]
assert [(x['scan'],x['path']) for x in designation['uses']]==[(x['scan'],x['path']) for x in packet['routes']]
for route,(operation,operand) in zip(packet['routes'],fields):
 assert route['field']==field_ref(operand['input']['identity']) and route['operator']==operation['operator'] and route['operation']==operation['kind']
