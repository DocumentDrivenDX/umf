from pathlib import Path
import json,hashlib,subprocess,datetime,zipfile
p=Path(__file__).parent
r=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
def sha(b):return hashlib.sha256(b).hexdigest()
def write(path,v):path.write_text(json.dumps(v,indent=2)+'\n')
pins=json.loads((p/'source-pins.json').read_text())
changed=[x for x,h in pins.items() if sha((r/x).read_bytes())!=h];assert not changed
bun=json.loads((p/'bun-results.json').read_text());chrome=json.loads((p/'chromium-results.json').read_text());mut=json.loads((p/'mutation-results.json').read_text());browser=json.loads((p/'browser-summary.json').read_text())
assert len(bun)==253 and all(x['passed'] for x in bun) and bun==chrome and browser['status']=='passed'
assert len(mut)==9 and all(x['detected'] for x in mut)
f=p/'formal-delta';formal=json.loads((f/'source/docs/helix/04-build/evidence/security/formal.json').read_text());assert len(formal['cases'])==20 and all(x['status']=='passed' for x in formal['cases'])
a=(f/'prove-before.py').read_text();b=(f/'source/docs/helix/02-design/spikes/security/prove.py').read_text();assert a.split('def digest(path):')[0].replace('import sys\n','')==b.split('def digest(path):')[0].replace('import sys\n','')
write(f/'review.json',{'status':'no-blocker-in-metadata-delta','exactQuerySourceUnchanged':True,'passedModels':20,'solver':formal['solverVersion'],'actualPython':formal['pythonVersion'],'actualInvocation':['/private/tmp/umf-write-comparison-proof-env-20261013/bin/python',str(f/'source/docs/helix/02-design/spikes/security/prove.py')],'change':'Receipt command uses sys.executable and records sys.version; the existing mathematical query source is unchanged.','limits':'Existing conditional models only. No implementation refinement, new stored-query theorem or native installation proof. Replay used copied source and wrote only the copied receipt.','sourcePins':'source-pins.json'})
casepath='docs/helix/03-test/security/cases.json';old=json.loads(subprocess.check_output(['git','show','HEAD:'+casepath],cwd=r));new=json.loads((r/casepath).read_text());delta=[]
assert len(old['cases'])==len(new['cases'])==158
for before,after in zip(old['cases'],new['cases']):
 if before!=after:
  keys=[k for k in set(before)|set(after) if before.get(k)!=after.get(k)]
  assert keys==['implementationSources'], keys
  assert after['implementationSources']==sorted(set(before['implementationSources']+['src/extensions/security/catalog-storage-candidate.ts']))
  delta.append({'id':after['id'],'changedKeys':keys,'added':['src/extensions/security/catalog-storage-candidate.ts']})
assert len(delta)==2
write(p/'case-binding-review.json',{'totalCases':158,'changes':delta,'assertionsCoversTimeoutStatusRunnerUnchanged':True,'newAcceptancePromotion':False})
write(p/'pin-recheck.json',{'count':len(pins),'changed':changed,'allExact':True})
review={
 'review':'Astra Ultra independent stored-query source inspection review',
 'date':'2026-10-15','status':'no-actionable-blocker-within-stated-private-comparison-scope',
 'repositoryHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),
 'rootSourceEdited':False,'acceptanceReceipt':False,'nativeExecuted':False,
 'scope':['Private originally-issued program + complete owner storage source selection','Shared whole-owner storage validator and existing action-kernel integration','Original transformed-helper property comparison extraction','Conditional catalog output-domain query properties; no effective read permission','Separate existing formal receipt interpreter metadata correction'],
 'evidence':{'independentlyAuthoredBun':{'passed':253,'total':253,'version':subprocess.check_output(['/opt/homebrew/bin/bun','--version'],text=True).strip()},'actualChromium':browser,'fullPublicHelperBeforeAfterReports':45,'sourceWeakenings':{'detected':9,'total':9,'results':'mutation-results.json'},'exactSelectedRootSourcePins':81,'formalMetadataDelta':{'passedExistingModels':20,'source':'formal-delta/review.json'}},
 'sourcePins':'source-pins.json','pinRecheck':'pin-recheck.json','caseBindings':'case-binding-review.json',
 'findings':[],
 'observations':[
  'Tokenize and encrypt resolve the exact explicitly selected storage transform, including two transforms sharing one output domain; the canonical query domain is the output Field, never the plaintext input Field.',
  'Actual denied and withheld action results coexist with successful conditional storage classification; selection grants no ORIGINAL read permission.',
  'Missing, extra, duplicate, foreign, unknown and canonical-downgraded unrelated owner entries refuse atomically. The operation shares the parameter/property/whole-map scan budget; a valid smaller population succeeds while a valid 400-field/256-transform scan refuses.',
  'Detached immutable snapshots and issued-handle custody are retained. An invalid/unissued handle refuses before owner/use capture and returns null sources, selection and report; successful-source retention wording does not promise capture on an unresolvable invocation.',
  'The existing transformed helper produces identical complete reports in 45 independent determinism/mode/operator vectors before and after extraction. Shared-validator scan charges are explicit and may cause earlier refusal at a fixed low operation budget; no universal resource-limit compatibility theorem is claimed.',
  'Only S24/S25 implementation-source metadata adds the shared validator; all 158 case assertions, covers, timeouts, statuses and runner bindings remain unchanged.'
 ],
 'limits':[
  'Finite independently authored controls, not an exhaustive semantic or program-refinement proof.',
  'Private handle issuance and owner source provenance are model custody, not authenticated authority. Required properties remain supplied assumptions.',
  'No native jobs, compiler-derived dependency lineage, effective ORIGINAL-read proof, fixed key/runtime custody, mixed-mode physical integration, SQL dispatch, current-authority or P03/B08 qualification.',
  'The selected static source/import closure is pinned; dependency installations and complete root-barrel/runtime provenance are not hermetically archived.',
  'The 20 old conditional models are reviewed only for the interpreter-metadata correction, not as a proof of this resolver.',
  'The parent whole acceptance gate is separate and was still running at receipt creation; no result is inferred here.'
 ],
 'preservedHistory':['initial245-* and oracle-initial245.ts: passing earlier finite corpus before final additional controls','browser-sandbox-listen-failure.log: setup refusal, no browser observations','baseline-property-kernel.json and queries-before-extraction.ts: original HEAD helper comparator','formal-delta/prove-before.py and prove.diff: exact metadata preimage','design/: earlier separately qualified design review'],
 'reproduction':['Make original node_modules dependencies available to source/node_modules and the review directory; no dependencies are included in this archive.','Run /opt/homebrew/bin/bun run.ts from this directory for 253 Bun controls.','Run /opt/homebrew/bin/bun browser.ts from this directory with Playwright Chromium available and permitted local loopback listening.','Run python3 run-mutations.py in a fresh extracted packet; it creates isolated mutant source copies and checks exact failed row names.','Replay copied formal source with the Z3 interpreter recorded in formal-delta/review.json.']
}
write(p/'review.json',review)
(p/'review.md').write_text('''# Scoped independent review\n\nNo actionable blocker found in the private stored-query source inspector, shared storage validator or property-helper extraction.\n\n- Independently authored 253 controls pass in Bun and Chromium 153 with exact parity; 45 full public-helper reports match the previous implementation.\n- All nine focused source weakenings fail their intended named controls.\n- All 81 selected root source pins remain exact. Only S24/S25 source metadata changes; all 158 case requirements and bindings remain unchanged.\n- The separate existing 20-model Z3 replay passes. Only interpreter receipt metadata changed; this is not a resolver proof.\n\nSuccessful selection is conditional source classification, including when actual read is denied or withheld. It supplies no native, query-compiler, read-permission, key-scope or authority qualification. P03/B08 remain unqualified. Invalid handles refuse before input capture and return null sources. No root files were edited and no native jobs were launched.\n\nSee review.json, source-pins.json, mutation-results.json, browser-summary.json and formal-delta/review.json for exact custody and limits.\n''')
# Select a bounded reproducible packet; omit full mutant copies, dependencies, and generated browser bundle.
files=[]
for x in p.rglob('*'):
 rel=x.relative_to(p)
 if x.is_symlink() or not x.is_file() or any(s in {'node_modules','mutants','__pycache__'} for s in rel.parts):continue
 if rel.as_posix() in {'browser-bundle.js','archive.json','manifest.json'}:continue
 files.append(x)
write(p/'manifest.json',{'files':{str(x.relative_to(p)):sha(x.read_bytes()) for x in sorted(files)},'excluded':['node_modules','full mutants source directories','generated browser-bundle.js'],'sourceClosure':'81 selected exact root files plus the original property helper preimage; formal sources separately pinned'})
files.append(p/'manifest.json')
z=p.with_suffix('.zip')
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
 for x in sorted(files):out.write(x,p.name+'/'+str(x.relative_to(p)))
archive={'path':str(z),'sha256':sha(z.read_bytes()),'bytes':z.stat().st_size,'files':len(files),'reviewSha256':sha((p/'review.json').read_bytes())};write(p/'archive.json',archive);print(json.dumps(archive))
