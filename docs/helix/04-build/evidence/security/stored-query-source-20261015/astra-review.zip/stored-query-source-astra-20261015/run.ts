import {runOracle} from './oracle';
const rows=runOracle();await Bun.write(new URL('./bun-results.json',import.meta.url),JSON.stringify(rows,null,2));const failures=rows.filter(r=>!r.passed);console.log(JSON.stringify({count:rows.length,failed:failures.length,failures}));if(failures.length)process.exitCode=1;
