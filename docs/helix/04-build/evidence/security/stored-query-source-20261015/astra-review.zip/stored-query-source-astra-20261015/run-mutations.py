from pathlib import Path
import shutil,subprocess,json,time,difflib,hashlib
B=Path(__file__).parent
storage='src/extensions/security/catalog-storage-candidate.ts';selected='src/extensions/security/stored-query-candidate.ts';queries='src/extensions/security/protection/queries.ts'
variants=[
 ('omit-completeness',storage,"for(const [type,members] of fields)for(const field of members){step();if(!storage.has(JSON.stringify([type,field])))fail('Incomplete owner storage map');}",'','omit-unrelated'),
 ('omit-duplicate',storage,'||storage.has(key)','','duplicate-unrelated'),
 ('omit-member',storage,'!fields.get(type)?.has(field)||','','extra-nonmember'),
 ('omit-canonical-downgrade',storage,'||stored.length','','canonical-downgrade:runtime-common-validator'),
 ('ignore-stored-output-domain',storage,'id(t.outputDomain)===field',"(entry.storageEffect==='stored-transformed'||id(t.outputDomain)===field)",'unrelated-stored-wrong-domain'),
 ('first-transform-instead-of-owner',selected,'c.transforms.find((t:any)=>t.id===entry.storageTransform.id&&t.version===entry.storageTransform.version)','c.transforms[0]','explicit-second-transform'),
 ('input-domain-as-query-domain',selected,'queryDomain:transform.outputDomain','queryDomain:transform.inputDomain','token-original:canonical-domain'),
 ('drop-shared-scan-charge',selected,'validateCandidateCatalogStorage(program,o,()=>budget.step())','validateCandidateCatalogStorage(program,o,()=>{})','whole-storage-scan-budget'),
 ('random-token-join-admission',queries,"if(transform.kind==='tokenize'&&transform.determinism==='random'", "if(false&&transform.kind==='tokenize'&&transform.determinism==='random'",'random-join')
]
rows=[]
for name,rel,old,new,witness in variants:
 home=B/'mutants'/name;shutil.copytree(B/'source',home/'source',symlinks=True)
 for file in ['oracle.ts','run.ts']:shutil.copy(B/file,home/file)
 (home/'node_modules').symlink_to((B/'node_modules').resolve(),target_is_directory=True)
 path=home/'source'/rel;original=path.read_text();assert original.count(old)==1,(name,original.count(old));changed=original.replace(old,new);path.write_text(changed)
 d=B/'mutation-patches';d.mkdir(exist_ok=True);(d/(name+'.diff')).write_text(''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile=rel,tofile=rel)))
 start=time.monotonic();p=subprocess.run(['/opt/homebrew/bin/bun','run.ts'],cwd=home,capture_output=True,text=True,timeout=60);elapsed=time.monotonic()-start;(d/(name+'.log')).write_text(p.stdout+p.stderr)
 observed=json.loads((home/'bun-results.json').read_text()) if (home/'bun-results.json').exists() else [];failed=[r for r in observed if not r['passed']]
 (d/(name+'-failures.json')).write_text(json.dumps(failed,indent=2)+'\n')
 row=dict(id=name,exitCode=p.returncode,seconds=round(elapsed,3),expectedFailedRow=witness,failedRows=[r['id'] for r in failed],detected=p.returncode!=0 and any(r['id']==witness for r in failed),mutatedSourceSha256=hashlib.sha256(changed.encode()).hexdigest());rows.append(row);print(json.dumps(row),flush=True)
(B/'mutation-results.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(r['detected'] for r in rows)
