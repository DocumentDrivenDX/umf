import {compileCandidateCatalogProgram} from './source/src/extensions/security/catalog-program-candidate';
import {inspectCandidateStoredQueryProperties as inspect} from './source/src/extensions/security/stored-query-candidate';
import {evaluateCandidateCatalogAction as action} from './source/src/extensions/security/catalog-runtime-candidate';
import {inspectProtectionQueryProperties as current} from './source/src/extensions/security/protection/queries';
import {inspectProtectionQueryProperties as before} from './source/src/extensions/security/protection/queries-before-extraction';
const ref=(elementId:string)=>({documentId:'independent-stored',moduleId:'review',elementId});
const clone=(v:any)=>JSON.parse(JSON.stringify(v));
function fixture(){
 const definitions:any[]=[['Person',['personId']],['Asset',['assetId','cipher']],['Auxiliary',['auxId','label']]];
 const field=(id:string)=>({id,kind:'field',scalarType:'string',nullability:'required',cardinality:'one',extensions:{}});
 const elements:any[]=definitions.flatMap(([id,fields]:any)=>[{id,kind:'record',members:fields.map((element:string)=>({module:'review',element})),keys:[{id:'identity',name:'Primary',fields:[{module:'review',element:fields[0]}]}],extensions:{}},...fields.map(field)]);
 elements.push(field('plaintext'),field('otherDTO'));
 const document={umf:'0.8.0',id:'independent-stored',vocabularies:{},modules:[{id:'review',namespace:'',elements}]};
 const entities=definitions.map(([name,fields]:any)=>({type:ref(name),keyId:'identity',fields:fields.map((name:string)=>({ref:ref(name),protection:name==='cipher'?'protected':'unprotected'}))}));
 const ontology:any={version:'0.2.0',documentId:'independent-ontology',revision:'o7',documents:[{documentId:document.id,revision:'d3'}],subject:ref('Person'),entities,associations:[],context:[],actions:['see','recover','maintain-vault'],actionPurposes:[{action:'see',purposes:['read']},{action:'recover',purposes:['reverse']},{action:'maintain-vault',purposes:['vault-write']}]};
 const closure={pins:ontology.documents,documents:[{revision:'d3',document}]};
 const transform:any={id:'sealed',version:'r4',kind:'tokenize',inputDomain:ref('plaintext'),outputDomain:ref('cipher'),determinism:'keyed-deterministic',reversibility:'vault',reverseAction:'recover',disclosureProfile:['equality'],queryUse:{predicate:'disclosed',order:'disclosed',group:'disclosed',join:'disclosed',aggregate:'disclosed'},parameters:[],custody:{owner:'excluded',vaultRef:'review-vault',vaultWriteAction:'maintain-vault',formatPreserving:false,storageEffect:'stored-transformed',propagation:{history:'opaque-history',snapshots:'opaque-snapshot',exports:'opaque-export',feeds:'opaque-feed',caches:'opaque-cache'}}};
 const catalog:any={vocabulary:'umf.security.protection',version:'0.1.0',id:'review-catalog',revision:'c2',transforms:[transform]};
 const policy:any={vocabulary:'umf.security',version:'0.2.0',id:'review-policy',revision:'p9',ontology:{documentId:ontology.documentId,revision:ontology.revision},protection:{id:catalog.id,revision:catalog.revision},rules:[{id:'view',effect:'permit',actions:['see'],target:[ref('Asset')],condition:{op:'literal',value:true},disclosure:[{field:ref('cipher'),disposition:{kind:'original'}}]}]};
 const owner:any={version:'umf.security.logical-owner/0.1',id:'owner-review',revision:'w2',storage:entities.flatMap((e:any)=>e.fields.map((f:any)=>({type:e.type,field:f.ref,storageEffect:f.ref.elementId==='cipher'?'stored-transformed':'canonical',...(f.ref.elementId==='cipher'?{storageTransform:{id:transform.id,version:transform.version}}:{})})))};
 const facts=definitions.map(([name,fields]:any)=>({type:ref(name),key:[{string:name+'-one'}],fields:fields.map((name:string,i:number)=>({field:ref(name),value:{string:i===0?name==='personId'?'Person-one':name==='assetId'?'Asset-one':'Auxiliary-one':'opaque-unchanged'}})),absent:[]}));
 const cut:any={version:'umf.security.logical-facts/0.1',trusted:true,generation:'g1',expectedGeneration:'g1',policy:{id:policy.id,revision:policy.revision},ontology:policy.ontology,protection:policy.protection,domains:closure.pins,owner:{id:owner.id,revision:owner.revision},subject:{type:ref('Person'),key:[{string:'Person-one'}]},facts,graphs:[],coverage:entities.map((e:any)=>({type:e.type,complete:true,fields:e.fields.map((f:any)=>f.ref)})),graphCoverage:[],context:[],valueProfiles:[],maxFacts:30,maxSteps:10000};
 const request={action:'see',resources:[{type:ref('Asset'),key:[{string:'Asset-one'}]}],targets:[ref('Asset')],fields:[ref('cipher')]};
 const use:any={type:ref('Asset'),field:ref('cipher'),operator:'join',required:['equality']};
 return {ontology,closure,catalog,policy,owner,cut,request,use};
}
export function runOracle(){
 const rows:any[]=[];const record=(id:string,expected:any,actual:any)=>rows.push({id,expected,actual,passed:JSON.stringify(expected)===JSON.stringify(actual)});
 function run(id:string,expected:string,change?:(f:any)=>void,ownerChange?:(f:any)=>void,handleKind='original'){
  const f=fixture();change?.(f);const h=compileCandidateCatalogProgram(f.policy,f.catalog,f.closure,f.ontology);ownerChange?.(f);const input=JSON.stringify({owner:f.owner,use:f.use});const r=inspect(handleKind==='copy'?{...h as object}:handleKind==='fake'?{}:h,f.owner,f.use);
  record(id,expected,r.status==='selected'?r.report!.status:r.status);record(id+':source-preserved',input,JSON.stringify({owner:f.owner,use:f.use}));record(id+':no-authority',[false,false],[r.complete,r.authority]);
  if(r.status==='refused')record(id+':atomic',[null,null],[r.selection,r.report]);else record(id+':canonical-domain',[ref('cipher'),ref('plaintext')],[(r.selection as any).queryDomain,(r.selection as any).inputDomain]);
  return {f,h,r};
 }
 const positive=run('token-original','compatible-properties');record('actual-original-read','original',(action(positive.h,positive.f.owner,positive.f.cut,positive.f.request).rows[0] as any)?.dispositions[0]?.disposition.kind);
 run('encrypt-original','compatible-properties',f=>{f.catalog.transforms[0].kind='encrypt';});
 const denied=run('source-selected-read-denied','compatible-properties',f=>{f.policy.rules[0].condition.value=false;});record('actual-read-still-denied','deny',action(denied.h,denied.f.owner,denied.f.cut,denied.f.request).rows[0]?.decision);
 const withheld=run('source-selected-read-withheld','compatible-properties',f=>{f.policy.rules[0].disclosure[0].disposition={kind:'withheld'};});record('actual-read-still-withheld','withheld',(action(withheld.h,withheld.f.owner,withheld.f.cut,withheld.f.request).rows[0] as any)?.dispositions[0]?.disposition.kind);
 run('explicit-second-transform','compatible-properties',f=>{const second=clone(f.catalog.transforms[0]);second.id='chosen-second';f.catalog.transforms[0].queryUse.join='prohibited';f.catalog.transforms.push(second);f.owner.storage.find((x:any)=>x.field.elementId==='cipher').storageTransform.id=second.id;});
 run('explicit-first-transform-prohibited','prohibited',f=>{const second=clone(f.catalog.transforms[0]);second.id='unchosen-second';f.catalog.transforms[0].queryUse.join='prohibited';f.catalog.transforms.push(second);});
 run('omitted-mode','prohibited',f=>{delete f.catalog.transforms[0].queryUse.join;});
 run('original-authorized-not-permit','requires-original-action',f=>{f.catalog.transforms[0].queryUse.join='original-authorized';});
 const implied=run('implied-not-authored','compatible-properties',f=>{f.catalog.transforms[0].disclosureProfile=[];});record('implied-versus-authored',[[],['equality']],[(implied.r.report as any).authoredProperties,(implied.r.report as any).impliedProperties]);
 for(const op of ['join','group'])run('random-'+op,'refused',f=>{f.catalog.transforms[0].determinism='random';f.use.operator=op;});
 run('missing-order','refused',f=>{f.use.operator='order';});
 run('forged-handle','refused',undefined,undefined,'fake');run('copied-handle','refused',undefined,undefined,'copy');
 const badOwners:[string,(f:any)=>void][]=[['omit-unrelated',f=>f.owner.storage.splice(0,1)],['duplicate-unrelated',f=>f.owner.storage.push(clone(f.owner.storage[0]))],['wrong-unrelated-type',f=>f.owner.storage[0].type=ref('Asset')],['wrong-unrelated-field',f=>f.owner.storage[0].field=ref('otherDTO')],['unknown-owner-member',f=>f.owner.current=true],['unknown-unrelated-entry',f=>f.owner.storage[0].extension=true],['unrelated-canonical-transform',f=>f.owner.storage[0].storageTransform={id:'sealed',version:'r4'}],['unrelated-stored-wrong-domain',f=>{f.owner.storage[0].storageEffect='stored-transformed';f.owner.storage[0].storageTransform={id:'sealed',version:'r4'};}],['canonical-downgrade',f=>{const x=f.owner.storage.find((x:any)=>x.field.elementId==='cipher');x.storageEffect='canonical';delete x.storageTransform;}],['stale-transform',f=>f.owner.storage.find((x:any)=>x.field.elementId==='cipher').storageTransform.version='r3'],['wrong-read-purpose',f=>f.owner.disclosure={readAction:'recover'}],['owner-version',f=>f.owner.version='future'],['owner-id-type',f=>f.owner.id=1],['owner-array-bound',f=>f.owner.storage=Array(4097).fill(f.owner.storage[0])]];
 for(const [id,change] of badOwners){const r=run(id,'refused',undefined,change);record(id+':runtime-common-validator','refused',action(r.h,r.f.owner,r.f.cut,r.f.request).status);}
 run('valid-optional-read','compatible-properties',undefined,f=>{f.owner.disclosure={readAction:'see'};});
 const badUse:[string,(f:any)=>void][]=[['select-inputDTO',f=>f.use.field=ref('plaintext')],['select-otherDTO',f=>f.use.field=ref('otherDTO')],['select-canonical',f=>f.use.field=ref('assetId')],['wrong-selection-type',f=>f.use.type=ref('Auxiliary')],['field-document-alias',f=>f.use.field.documentId='elsewhere'],['field-module-alias',f=>f.use.field.moduleId='foreign'],['unknown-use',f=>f.use.originalAction='recover'],['empty-required',f=>f.use.required=[]],['too-many-required',f=>f.use.required=Array(33).fill('equality')],['unknown-property',f=>f.use.required=['future']],['unknown-operator',f=>f.use.operator='filter'],['overlong-ref',f=>f.use.field.elementId='x'.repeat(4097)],['missing-field',f=>delete f.use.field],['null-use',f=>f.use=null]];
 for(const [id,change] of badUse)run(id,'refused',undefined,change);
 const snap=run('snapshot','compatible-properties');const saved=JSON.stringify(snap.r);snap.f.owner.storage=[];snap.f.use.required=['order'];snap.f.catalog.transforms=[];record('detached-snapshot',saved,JSON.stringify(snap.r));record('snapshot-frozen',true,Object.isFrozen(snap.r)&&Object.isFrozen(snap.r.owner)&&Object.isFrozen(snap.r.use)&&Object.isFrozen(snap.r.selection));
 let calls=0;const accessor:any={};Object.defineProperty(accessor,'storage',{enumerable:true,get(){calls++;return [];}});record('accessor-refuses','refused',inspect(snap.h,accessor,snap.f.use).status);record('accessor-not-executed',0,calls);
 const noCatalog=fixture();delete noCatalog.policy.protection;const noHandle=compileCandidateCatalogProgram(noCatalog.policy,null,noCatalog.closure,noCatalog.ontology);record('no-catalog-refuses','refused',inspect(noHandle,noCatalog.owner,noCatalog.use).status);
 const big=fixture(),bigH=compileCandidateCatalogProgram(big.policy,big.catalog,big.closure,big.ontology);big.owner.id='x'.repeat(4_000_001);record('owner-text-budget','refused',inspect(bigH,big.owner,big.use).status);
 // Differential extraction control: same actual public API inputs, baseline implementation and extracted implementation.
 for(const determinism of ['keyed-deterministic','deterministic','random'])for(const mode of ['disclosed','prohibited','original-authorized'])for(const operator of ['predicate','order','group','join','aggregate']){
  const f=fixture();f.catalog.transforms[0].determinism=determinism;f.catalog.transforms[0].queryUse[operator]=mode;f.policy.rules[0].disclosure=[{field:ref('plaintext'),disposition:{kind:'transformed',vocabulary:'umf.security.protection',transform:'sealed',version:'r4',field:ref('cipher')}}];
  const use={ruleIndex:0,disclosureIndex:0,operator,required:['equality']};record('public-differential:'+determinism+':'+mode+':'+operator,before(f.policy,f.catalog,f.closure,use),current(f.policy,f.catalog,f.closure,use));
 }
 return rows;
}
