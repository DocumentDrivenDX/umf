from pathlib import Path
import hashlib,io,json,subprocess,tarfile,zipfile
p=Path(__file__).resolve().parent
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
run=Path('/private/tmp/truss-current-query-root-replay-20261015')
truss=Path('/private/tmp/truss-main-integration-20261010')
wheel=Path('/private/tmp/weft-current-rows-wheels/weft_sql-0.4.32-cp39-abi3-macosx_11_0_arm64.whl')
sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((run/'receipt.json').read_text());pins=r['trackedInputs'];checks=[]
def check(name,result,count=None):
 checks.append({'name':name,'passed':bool(result),'count':count});assert result,name
check('retained-receipt-one-test-passed',r['status']=='passed' and r['tests']==1)
harness='tools/security/truss-current-query-replay.py'
check('harness-current-exact',sha((root/harness).read_bytes())==r['harnessSha256'])
check('input-zip-exact',sha((run/'original-inputs.zip').read_bytes())==r['archiveSha256'])
with zipfile.ZipFile(run/'original-inputs.zip') as z:
 check('exact-unique-archive-population',len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(pins),len(pins))
 check('archived-input-digests',all(sha(z.read(k))==v for k,v in pins.items()),len(pins))
check('extracted-input-digests',all(sha((run/'original'/k).read_bytes())==v for k,v in pins.items()),len(pins))
paths=['packages/python/src','packages/python/tests','packages/postgresql','docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json']
data=subprocess.run(['git','-C',str(truss),'archive',r['sourceCommit'],*paths],check=True,stdout=subprocess.PIPE).stdout
with tarfile.open(fileobj=io.BytesIO(data)) as t:
 actual={m.name:sha(t.extractfile(m).read()) for m in t.getmembers() if m.isfile()}
check('exact-fixed-commit-population-and-bytes',actual==pins,len(actual))
mods=r['loadedTrussModules']
check('every-loaded-truss-module-committed-and-exact',all(pins.get(v['path'])==v['sha256'] and (run/'original'/v['path']).resolve().is_relative_to((run/'original').resolve()) for v in mods.values()),len(mods))
check('exact-original-child',pins['packages/python/src/truss/_current_query_owner/current-query-child.mjs']==r['originalChildSha256']=='36e2c63fb0d942c9b94141f1753bcd9b56aad9e32dec5aa1a9ee27aabc674248')
check('exact-weft-wheel',sha(wheel.read_bytes())==r['weftWheelSha256']=='3e9bd6f6ac42c944dd12e36ce3ea0481ca116a3ab639ef2c2ede933751ff17a8')
with zipfile.ZipFile(wheel) as z:
 selected={k:sha(z.read(k)) for k in z.namelist() if Path(k).suffix in ('.so','.py')}
check('exact-wheel-python-and-native-population',selected==r['weftLoadedFiles'],len(selected))
check('extracted-weft-files-exact',all(sha((run/'original-weft'/k).read_bytes())==v for k,v in selected.items()),len(selected))
check('selected-native-postgres-exact',sha(Path('/private/tmp/truss-clean-install-20261013/lib/python3.12/site-packages/pgserver/pginstall/bin/postgres').read_bytes())==r['postgresBinarySha256'])
check('native-profile-receipt',r['nativeObservation']['serverVersion']=='18.6' and r['pgserverDistribution']=='18.6.1' and r['libpqVersion']==180006)
check('retained-owned-cleanup',all(r[k] is True for k in ('originalRuntimeStopped','leaseReleased','testDirectoryAbsent')) and r['nativeObservation']['postmasterAbsent'] is True)
check('original-data-directory-still-absent',not Path(r['nativeObservation']['dataDirectory']).exists())
check('unittest-log-exact-success', (run/'unittest.log').read_text().count(' ... ok\n')==1 and 'Ran 1 test in 12.697s\n\nOK' in (run/'unittest.log').read_text())
check('no-acceptance-promotion',r['acceptanceCasesPromoted']==[])
selected_sources=['packages/python/src/truss/'+s for s in ['catalog_runtime.py','current_query.py','_current_query_runtime.py','_current_query_evaluation.py','_current_query_stage.py','_current_query_originals.py','_current_query_sources.py','_current_query_subjects.py','_current_query_facts.py','_current_query_computation.py','_current_query_pipe.py','local_runtime.py']]+['packages/python/tests/'+s for s in ['test_current_query_runtime_native.py','test_current_query_full_sources_native.py','test_current_query_subjects_native.py','test_catalog_runtime_native.py','fixtures/current-query-weft-request.json']]
additional=[run/'receipt.json',run/'unittest.log',Path('/private/tmp/truss-private-carrier-budget-witness-20261015.json'),Path('/private/tmp/truss-private-scan-budget-witness-20261015.json'),Path('/private/tmp/truss-current-query-legacy-probe-20261015.json'),Path('/private/tmp/truss-current-query-legacy-probe-20261015.py')]
record={'sourceCommit':r['sourceCommit'],'harness':{harness:r['harnessSha256']},'selectedOriginals':{k:pins[k] for k in selected_sources},'referencedEvidence':{str(f):sha(f.read_bytes()) for f in additional},'inputArchive':{'path':str(run/'original-inputs.zip'),'sha256':r['archiveSha256']},'wheel':{'path':str(wheel),'sha256':r['weftWheelSha256']},'extractedWeft':selected}
(p/'source-pins.json').write_text(json.dumps(record,indent=2)+'\n')
result={'status':'passed','checks':checks,'count':len(checks),'nativeExecutionPerformedByReviewer':False,'scope':'Read-only source/archive/wheel/selected-module correspondence and retained native evidence; no native DB, child or cloud execution.'}
(p/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','checks':len(checks),'committedInputs':len(pins),'loadedTrussModules':len(mods),'weftPythonNativeFiles':len(selected)}))
