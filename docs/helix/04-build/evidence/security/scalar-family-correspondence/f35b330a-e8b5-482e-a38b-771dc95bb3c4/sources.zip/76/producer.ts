export {inspectCoreScalarType} from './src/model/scalar-type';
