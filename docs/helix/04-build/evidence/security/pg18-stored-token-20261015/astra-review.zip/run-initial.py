import pathlib,subprocess,time,json
out=pathlib.Path(__file__).parent;runs=[]
for name,wd in [('current-55',out/'source'),('encrypt-declaration',out/'initial-mutants/encrypt-declaration'),('random-declaration',out/'initial-mutants/random-declaration')]:
 start=time.monotonic();r=subprocess.run(['python3','tests/security/native/pg18-stored-token.py','--output',str(out/(name+'-native.json'))],cwd=wd,capture_output=True,text=True,timeout=60);elapsed=time.monotonic()-start
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 item={'name':name,'exit':r.returncode,'seconds':elapsed,'stdout':r.stdout,'stderr':r.stderr[-2000:]};runs.append(item);(out/'initial-native-runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(item),flush=True)
