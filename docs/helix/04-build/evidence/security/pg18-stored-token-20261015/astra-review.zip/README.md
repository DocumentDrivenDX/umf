# P08 independent review

No remaining blocker within the unchanged stored-token stand-in assertion. Final independent native replay: **65 observations, 5.998 seconds**, PostgreSQL18.6/pgcrypto1.4, original60s budget, verified owned container/volume cleanup. Five declaration/report faults fail before database creation; five actual SQL weakenings fail their expected native checks. Eighteen strict refusal classifier controls pass; the conditional model replays3UNSAT/1SAT.

Initial complete native runs accepted encrypt and random/no-equality substitutions because the runner compared only obligation kinds/statuses. Exact independent declaration/domain/owner/pin checks now reject both, plus coordinated catalog/policy substitution. Historical survivor receipts are retained separately from the final source.

Tokenization, custody and propagation remain unverified obligations. The excluded detokenizer grant deliberately exposes fixture plaintext; the collision injection tests an ambiguous stored map, not an actual HMAC collision. The formal model is conditional and does not refine SQL, cryptography or ACLs. Native transport is a fixed fixture representation, not a general0.2 permission or lineage proof.

See review.json and final-pins.json. The compact archive includes selected source closure, changed mutant modules/diffs, scripts, logs, receipts and SMT files; it excludes copied node_modules/full mutant trees. Native runners require original installed dependencies, whose actual files are pinned in receipts. Exact parent setup preimages were unavailable; parent-attempts.json preserves the honest narrative and no replay claim is made.
