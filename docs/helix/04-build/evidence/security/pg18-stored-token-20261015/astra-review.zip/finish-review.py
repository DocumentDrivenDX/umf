import pathlib,json,hashlib,datetime,subprocess,zipfile,shutil
out=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
native=json.loads((out/'current-65-final-native.json').read_text());sources=native['sourceDigests'];runtime=native['nativeInventory']['runtimeDependencies']['sourceDigests'];runs=json.loads((out/'final-native-runs.json').read_text());formal=json.loads((out/'formal-replay/receipt.json').read_text());faults=json.loads((out/'refusal-fault-controls.json').read_text())
assert len(native['observations'])==65 and all(x['expected']==x['observed'] for x in native['observations'])
assert all(x['matched'] for x in runs) and len(runs)==11 and all(x['pass'] for x in faults['rows'])
assert native['nativeInventory']['cleanup']=={'containerAbsent':True,'volumesAbsent':True}
assert all(sha(repo/p)==h for p,h in sources.items()) and all(sha(pathlib.Path(p))==h for p,h in runtime.items())
assert all(x['expected']==x['observed'] for x in formal['queries'])
case=lambda p:next(c for c in json.loads(p.read_text())['cases'] if c['id']=='pg-raw.P08');original=case(out/'source/docs/helix/03-test/security/cases.json');current=case(repo/'docs/helix/03-test/security/cases.json');immutable=['id','backend','covers','name','assertion','required','layer','timeoutMs','assertionIds'];assert all(original[k]==current[k] for k in immutable)
(out/'requirement.json').write_text(json.dumps({'caseBeforeBinding':original,'immutableFields':immutable,'immutableFieldsUnchanged':True},indent=2)+'\n')
for name in ['README.md','attempts.json']:
 src=repo/'docs/helix/04-build/evidence/security/pg18-stored-token-20261015'/name
 if src.exists():shutil.copy2(src,out/('parent-'+name))
report={
 'version':'independent-security-review/1','status':'scoped-review-passed','remainingBlockers':[],
 'reviewer':'Astra Ultra review subagent','timeUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':str(repo),'headAtFinalSnapshot':json.loads((out/'final-pins.json').read_text())['head'],
 'scope':'Original pg-raw.P08 / US-056-AC6 tokenization stand-in, unchanged assertion and 60000ms. Native PostgreSQL 18.6 HMAC storage, excluded vault, ordinary denial, exact token joins/transport, and original shared unverified obligations.',
 'sourceDigests':sources,'currentSourceCorrespondence':True,'runtimeFileCount':len(runtime),'currentRuntimeCorrespondence':True,'caseImmutableFieldsUnchanged':True,
 'independentEvidence':{
  'native':{'count':65,'seconds':runs[0]['seconds'],'underOriginal60Seconds':True,'independentlyExecuted':True,'artifact':'current-65-final-native.json','engine':'PostgreSQL 18.6','image':native['nativeInventory']['imageId'],'pgcrypto':native['versions']['pgcrypto'],'cleanup':native['nativeInventory']['cleanup']},
  'sourceWeakenings':{'count':10,'detected':10,'preDatabase':5,'actualNativeSQL':5,'artifact':'final-native-runs.json','definitions':'mutations.json'},
  'refusalClassifier':{'count':18,'positive':3,'negative':15,'allPassed':True,'artifact':'refusal-fault-controls.json'},
  'formal':{'count':4,'unsat':3,'sat':1,'independentlyReplayed':True,'artifact':'formal-replay/receipt.json','source':'formal.py','scope':'Conditional partial-map laws under exact identity and atomic modeled enrollment. Arbitrary digest collisions allowed. No SQL/HMAC/ACL/custody refinement.'}
 },
 'resolvedFinding':{'title':'Native declaration and transport could decouple without failure.','historicalWitnesses':[{'mutation':'tokenize to encrypt','exit':0,'observations':55,'artifact':'encrypt-declaration-native.json'},{'mutation':'keyed-deterministic/equality to random/no property','exit':0,'observations':55,'artifact':'random-declaration-native.json'}],'fix':'Before native installation, compare exact independently authored transform, stored owner binding, String input/output domains and catalog/core/ontology pins. Native hardcoded carrier metadata and declaration now refer to the same selected fixture.','finalControls':'Both historical substitutions and a coordinated catalog/policy identity substitution fail exact preinstallation checks.','classification':'Evidence-correspondence defect; not a demonstrated ordinary vault bypass.'},
 'nativeMutantEffects':[
  'PUBLIC detokenizer EXECUTE makes an ordinary query return actual fixture plaintext; strict expected-42501 check fails.',
  'Changed vault table owner, with original vault access retained, fails exact native owner comparison.',
  'Canonical storageEffect substitution fails native disclosure oracle.',
  'Including Resource ID in token input fails independent HMAC comparison.',
  'Removed ambiguity guard reaches duplicate Resource 23505 rather than required earlier 55000; no actual cryptographic collision is claimed.'
 ],
 'qualification':{'P08BindingClear':True,'acceptanceCasesPromotedByReview':[],'fullGate':'Parent-owned; component prebinding evidence only.','obligations':'All eight retain unverified status and authority false.','transport':'Fixed native JSON representation of canonical stored token with explicit storageEffect/transform metadata; not general security0.2 Cell or policy lineage.'},
 'limits':[
  'Finite native fixture and source controls do not qualify a reusable tokenization provider, algorithm strength, full UMF String representability, key custody, rotation, backup/replication enforcement or complete privilege/lifecycle closure.',
  'Dump/replica propagation is explicitly declared, not executed or enforced; shared five propagation obligations remain unverified.',
  'Fixed original SESSION_USER membership supplies eligibility, not a new canonical0.2 permission compiler or authenticated native authority.',
  'Fresh ephemeral 32-byte key is used in each replay and not retained; old receipt token outputs cannot be regenerated from its receipt alone.',
  'Selected repository/runtime endpoint hashes are not hermetic host custody or ABA immunity.',
  'Formal proof assumes exact identity, fixed deterministic digest, atomic admitted updates and no excluded-owner mutation; it does not establish those premises natively.',
  'Failed native mutants complete the reviewed finally cleanup path; no error-injected cleanup theorem is claimed. Current positive receipt explicitly verifies container and volume absence.'
 ],
 'failureHistory':{'exactIndependentHistoricalRuns':'initial-native-runs.json','independentHarnessSetup':'Initial refusal harness used reserved Python pass keyword; parse failure preserved separately and fixed before 18 controls executed.','parentDevelopmentAttempts':'parent-attempts.json honestly records initial triple-quote and pg_catalog.boolean failures; original failing bytes were not independently available and are not represented as replayed controls.'}
}
(out/'review.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text('''# P08 independent review\n\nNo remaining blocker within the unchanged stored-token stand-in assertion. Final independent native replay: **65 observations, 5.998 seconds**, PostgreSQL18.6/pgcrypto1.4, original60s budget, verified owned container/volume cleanup. Five declaration/report faults fail before database creation; five actual SQL weakenings fail their expected native checks. Eighteen strict refusal classifier controls pass; the conditional model replays3UNSAT/1SAT.\n\nInitial complete native runs accepted encrypt and random/no-equality substitutions because the runner compared only obligation kinds/statuses. Exact independent declaration/domain/owner/pin checks now reject both, plus coordinated catalog/policy substitution. Historical survivor receipts are retained separately from the final source.\n\nTokenization, custody and propagation remain unverified obligations. The excluded detokenizer grant deliberately exposes fixture plaintext; the collision injection tests an ambiguous stored map, not an actual HMAC collision. The formal model is conditional and does not refine SQL, cryptography or ACLs. Native transport is a fixed fixture representation, not a general0.2 permission or lineage proof.\n\nSee review.json and final-pins.json. The compact archive includes selected source closure, changed mutant modules/diffs, scripts, logs, receipts and SMT files; it excludes copied node_modules/full mutant trees. Native runners require original installed dependencies, whose actual files are pinned in receipts. Exact parent setup preimages were unavailable; parent-attempts.json preserves the honest narrative and no replay claim is made.\n''')
selected=[p for p in out.iterdir() if p.is_file() and p.suffix in ['.json','.md','.py','.ts','.diff','.stdout','.stderr','.txt']]
for rel in sorted(set(sources)|{'docs/helix/03-test/security/cases.json'}):selected.append(out/'final-source'/rel)
for rel in ['tests/security/native/pg18-stored-token.py','tests/security/native/pg18-stored-token-oracle.py','docs/helix/03-test/security/cases.json']:selected.append(out/'source'/rel)
for m in json.loads((out/'mutations.json').read_text()):selected.append(out/'final-mutants'/m['name']/m['relativeSource'])
selected.extend((out/'formal-replay').iterdir())
manifest={str(p.relative_to(out)):sha(p) for p in sorted(set(selected))};(out/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');selected.append(out/'archive-manifest.json');archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(selected)):z.write(p,str(p.relative_to(out)))
print(json.dumps({'review':str(out/'review.json'),'reviewSha256':sha(out/'review.json'),'archive':str(archive),'archiveSha256':sha(archive),'bytes':archive.stat().st_size,'files':len(set(selected)),'sources':len(sources),'runtimeFiles':len(runtime)}))
