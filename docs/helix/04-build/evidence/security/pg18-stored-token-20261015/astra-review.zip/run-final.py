import pathlib,subprocess,time,json
out=pathlib.Path(__file__).parent;runs=[];cases=[dict(name='current-65',expectedFailure=None)]+json.loads((out/'mutations.json').read_text())
for c in cases:
 name=c['name'];wd=out/'final-source' if name=='current-65' else out/'final-mutants'/name
 start=time.monotonic();r=subprocess.run(['python3','tests/security/native/pg18-stored-token.py','--output',str(out/(name+'-final-native.json'))],cwd=wd,capture_output=True,text=True,timeout=60);elapsed=time.monotonic()-start
 (out/(name+'-final.stdout')).write_text(r.stdout);(out/(name+'-final.stderr')).write_text(r.stderr)
 needle=c['expectedFailure'];matched=r.returncode==0 if needle is None else r.returncode!=0 and needle in r.stderr
 if name=='detokenize-public-execute':matched=matched and "'exit': 0" in r.stderr
 item={**c,'exit':r.returncode,'seconds':elapsed,'matched':matched,'stdout':r.stdout,'stderr':r.stderr[-3000:]};runs.append(item);(out/'final-native-runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(item),flush=True)
assert all(r['matched'] for r in runs)
