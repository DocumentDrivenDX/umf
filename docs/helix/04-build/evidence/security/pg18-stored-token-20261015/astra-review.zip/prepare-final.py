import pathlib,shutil,hashlib,json,subprocess,difflib
out=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf');final=out/'final-source';shutil.copytree(out/'source',final,symlinks=True)
for rel in ['tests/security/native/pg18-stored-token.py','tests/security/native/pg18-stored-token-oracle.py']:shutil.copy2(repo/rel,final/rel)
pins={p:hashlib.sha256((final/p).read_bytes()).hexdigest() for p in json.loads((out/'initial-pins.json').read_text())['files']}
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in pins.items())
(out/'final-pins.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':pins},indent=2)+'\n')
sql='tests/security/native/pg18-stored-token.sql';decl='tests/security/native/pg18-stored-token-declarations.ts'
cases=[
 ('encrypt-declaration',decl,'const declaration=inspectProtectionObligations',"f.catalog.transforms[0].kind='encrypt'; const declaration=inspectProtectionObligations",'exact-selected-tokenize-declaration'),
 ('random-declaration',decl,'const declaration=inspectProtectionObligations',"f.catalog.transforms[0].determinism='random'; f.catalog.transforms[0].disclosureProfile=[]; const declaration=inspectProtectionObligations",'exact-selected-tokenize-declaration'),
 ('catalog-pin-substitution',decl,'const declaration=inspectProtectionObligations',"f.catalog.id='another-catalog'; f.policy.protection.id='another-catalog'; const declaration=inspectProtectionObligations",'exact-selected-catalog'),
 ('verified-obligation',decl,'owner:f.owner,declaration}',"owner:f.owner,declaration:{...declaration,obligations:declaration.obligations.map((x:any)=>({...x,status:'verified'}))}}",'all-tokenize-obligations-unverified'),
 ('authority-claim',decl,'owner:f.owner,declaration}',"owner:f.owner,declaration:{...declaration,authority:true}}",'declared-not-enforced'),
 ('detokenize-public-execute',sql,'REVOKE ALL ON FUNCTION security_token_vault.enroll(text,text),security_token_vault.detokenize(text) FROM PUBLIC;', 'REVOKE ALL ON FUNCTION security_token_vault.enroll(text,text),security_token_vault.detokenize(text) FROM PUBLIC; GRANT EXECUTE ON FUNCTION security_token_vault.detokenize(text) TO PUBLIC;',"alpha"),
 ('vault-owner',sql,'REVOKE ALL ON ALL TABLES IN SCHEMA security_token_vault FROM PUBLIC;', 'REVOKE ALL ON ALL TABLES IN SCHEMA security_token_vault FROM PUBLIC;', 'vault-excluded-owner'),
 ('storage-effect',sql,"'storageEffect','stored-transformed'","'storageEffect','canonical'",'stored-disclosure:umf_sec_alice'),
 ('equality-mapping',sql,"pg_catalog.convert_to(cleartext,'UTF8')","pg_catalog.convert_to(cleartext OPERATOR(pg_catalog.||) resource_id,'UTF8')",'native-token:RA'),
 ('collision-guard',sql," IF NOT EXISTS(SELECT 1 FROM security_token_vault.entries WHERE token=result AND plaintext=cleartext) THEN RAISE EXCEPTION 'ambiguous token refused' USING ERRCODE='55000'; END IF;",'', '23505'),
]
records=[]
for name,rel,old,new,expected in cases:
 dst=out/'final-mutants'/name;shutil.copytree(final,dst,symlinks=True);p=dst/rel;before=p.read_text();assert before.count(old)==1,(name,before.count(old));after=before.replace(old,new)
 if name=='vault-owner':after+='\nALTER TABLE security_token_vault.entries OWNER TO postgres; GRANT ALL ON security_token_vault.entries TO umf_sec_token_vault;\n'
 assert after!=before;p.write_text(after)
 (out/(name+'.diff')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=rel,tofile=rel)))
 records.append({'name':name,'relativeSource':rel,'originalSha256':hashlib.sha256(before.encode()).hexdigest(),'mutantSha256':hashlib.sha256(after.encode()).hexdigest(),'expectedFailure':expected})
(out/'mutations.json').write_text(json.dumps(records,indent=2)+'\n')
