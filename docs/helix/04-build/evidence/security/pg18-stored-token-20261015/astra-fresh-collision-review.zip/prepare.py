import pathlib,shutil,json,hashlib,difflib
base=pathlib.Path('/private/tmp/pg18-stored-token-astra-20261015/final-source');out=pathlib.Path('/private/tmp/pg18-stored-token-fresh-collision-astra-20261015');out.mkdir(exist_ok=True)
original=out/'original';shutil.copytree(base,original,symlinks=True)
relative=pathlib.Path('tests/security/native/pg18-stored-token.py');p=original/relative;s=p.read_text();start=s.index(' # Excluded collision injection');end=s.index(' inventory=value(',start)
replacement=''' # Supplemental private witness: fresh Resource parent excludes duplicate-PK
 # failure as a possible explanation. A conflicting stored map is injected;
 # this is not an actual digest collision or an ordinary-authority operation.
 mode=os.environ.get('P08_FRESH_COLLISION_EXPECT_UNSAFE','0')
 if mode not in ['0','1']:raise ValueError('Exact private comparison mode required')
 unsafe=mode=='1';fresh_id='RFRESH';conflicting='conflicting-private'
 require(sql("INSERT INTO security_raw.resource(id,value) VALUES('RFRESH','fresh collision control');"))
 check('fresh-parent-present',1,value("SELECT to_json(count(*)) FROM security_raw.resource WHERE id='RFRESH';"))
 check('fresh-canonical-row-absent',0,value("SELECT to_json(count(*)) FROM security_tokens.resource WHERE id='RFRESH';"))
 collision="BEGIN; UPDATE security_token_vault.entries SET plaintext="+literal(conflicting)+" WHERE token="+literal(canonical_rows[0][1])+"; SELECT security_token_vault.enroll("+literal(fresh_id)+","+literal(oracle.ROWS[0][1])+"); COMMIT;"
 result=sql('\\\\set VERBOSITY verbose\\n'+collision)
 codes=re.findall(r'^ERROR:\\s+([0-9A-Z]{5}):',result.stderr,re.M)
 if re.search(r'^(FATAL|PANIC):',result.stderr,re.M):raise AssertionError('Unexpected infrastructure failure')
 check('fresh-enrollment-transaction-result',dict(exit=0,stdout=canonical_rows[0][1]+'\\n',sqlstates=[]) if unsafe else dict(exit=3,stdout='',sqlstates=['55000']),dict(exit=result.returncode,stdout=result.stdout,sqlstates=codes))
 current=value("SELECT coalesce(json_agg(json_build_object('id',r.id,'token',r.token,'plaintext',v.plaintext)),'[]'::json) FROM security_tokens.resource r JOIN security_token_vault.entries v ON v.token=r.token WHERE r.id='RFRESH';")
 check('fresh-enrollment-committed-readback',[dict(id=fresh_id,token=canonical_rows[0][1],plaintext=conflicting)] if unsafe else [],current)
 check('original-vault-map-after-attempt',conflicting if unsafe else oracle.ROWS[0][1],value('SELECT to_json(security_token_vault.detokenize('+literal(canonical_rows[0][1])+'));'))
 if not unsafe:check('guard-refusal-keeps-canonical-storage',canonical_rows,value('SELECT json_agg(json_build_array(id,token) ORDER BY id) FROM security_tokens.resource;'))
 else:check('unsafe-committed-map-differs-from-requested-plaintext',True,current[0]['plaintext']!=oracle.ROWS[0][1])
 delta=dict(expectedUnsafe=unsafe,resource=fresh_id,originalPlaintext=oracle.ROWS[0][1],conflictingPlaintext=conflicting,transaction=dict(exit=result.returncode,stdout=result.stdout,stderr=result.stderr,sqlstates=codes),committedReadback=current,scope='Excluded stored-map conflict and fresh enrollment. No real HMAC collision or ordinary-authority exploit.')
'''
after=s[:start]+replacement+s[end:]
marker="receipt['nativeInventory']['digest']=sha(canonical(receipt['nativeInventory']));"
after=after.replace(marker,"receipt.update(id='independent.pg18.fresh-enrollment-conflict', supplementalTo='pg-raw.P08', acceptanceReceipt=False, freshCollision=delta, scope=delta['scope']); "+marker)
p.write_text(after)
(out/'private-probe.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),after.splitlines(True),fromfile=str(relative),tofile=str(relative))))
mutant=out/'guard-removed';shutil.copytree(original,mutant,symlinks=True);sqlrelative=pathlib.Path('tests/security/native/pg18-stored-token.sql');p=mutant/sqlrelative;before=p.read_text();guard=" IF NOT EXISTS(SELECT 1 FROM security_token_vault.entries WHERE token=result AND plaintext=cleartext) THEN RAISE EXCEPTION 'ambiguous token refused' USING ERRCODE='55000'; END IF;";assert before.count(guard)==1;after=before.replace(guard,'');p.write_text(after)
(out/'guard-removed.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(sqlrelative),tofile=str(sqlrelative))))
parent=json.loads(pathlib.Path('/private/tmp/pg18-stored-token-astra-20261015/current-65-final-native.json').read_text());sources=parent['sourceDigests'];pins={}
for mode,root in [('original',original),('guard-removed',mutant)]:pins[mode]={rel:hashlib.sha256((root/rel).read_bytes()).hexdigest() for rel in sources}
(out/'pins.json').write_text(json.dumps({'parentReviewSha256':hashlib.sha256(pathlib.Path('/private/tmp/pg18-stored-token-astra-20261015/review.json').read_bytes()).hexdigest(),'baseSourceDigests':sources,'variants':pins},indent=2)+'\n')
shutil.copy2(__file__,out/'prepare.py')
