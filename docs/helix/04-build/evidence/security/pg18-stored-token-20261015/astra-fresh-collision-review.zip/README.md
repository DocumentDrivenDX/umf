# Supplemental P08 fresh-enrollment conflict

Original SQL: 68 observations/6.978 seconds, exact55000 refusal, no RFRESH canonical row, and original vault mapping restored after rollback. Removing only the ambiguity guard: 68 observations/5.798 seconds, actual COMMIT, and an RFRESH canonical token resolving to conflicting-private instead of the requested plaintext. Both owned fixtures/volumes are absent.

This closes the physical-witness gap left by the earlier duplicate-Resource23505 ordering control. The excluded administrator deliberately corrupts an existing mapping; no actual HMAC collision or ordinary exploit is claimed. Both receipts use an independent supplemental ID and acceptanceReceipt=false. Original P08/root sources remain unchanged; no obligation becomes verified.

The packet retains the original private driver/source closure and the one-file guard-removal variant. prepare.py derives both variants from the separately pinned prior review packet. run.py executes each with its explicit expected mode and a60s bound. For standalone reconstruction, copy original/ to guard-removed/ then overlay guard-removed/tests/security/native/pg18-stored-token.sql; supply the original pinned installed dependencies (not included).
