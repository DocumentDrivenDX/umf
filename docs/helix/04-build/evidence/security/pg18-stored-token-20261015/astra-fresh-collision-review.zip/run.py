import pathlib,subprocess,time,json,os
out=pathlib.Path(__file__).parent;runs=[]
for name,mode in [('original','0'),('guard-removed','1')]:
 start=time.monotonic();r=subprocess.run(['python3','tests/security/native/pg18-stored-token.py','--output',str(out/(name+'-native.json'))],cwd=out/name,env={**os.environ,'P08_FRESH_COLLISION_EXPECT_UNSAFE':mode},capture_output=True,text=True,timeout=60)
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr);item=dict(name=name,expectUnsafe=mode,exit=r.returncode,seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr);runs.append(item);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(item),flush=True)
assert all(r['exit']==0 for r in runs)
