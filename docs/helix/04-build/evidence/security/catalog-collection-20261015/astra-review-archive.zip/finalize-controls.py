import json,hashlib,shutil,subprocess
from pathlib import Path
p=Path(__file__).parent;root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
# Preserve the first selector-label bookkeeping. Expected semantic outcomes are unchanged.
for name in ['mutations.py','mutation-results.json','mutations.log']:shutil.copyfile(p/name,p/('initial-selector-labels-'+name))
fix={'source-purpose-field':'source-read-purpose-field-only','late-U-clears-earlier-output':'late-unknown-clears-earlier-original','empty-original-needs-coverage':'empty-original-coverage','copied-definition-context-refused':'copied-definition-context-refuses'}
s=(p/'mutations.py').read_text()
for old,new in fix.items():s=s.replace(old,new)
s=s.replace("assert bool(failed)==(name!='original'),(name,failed)","assert bool(failed)==(name!='original'),(name,failed)\n assert set(expected).issubset(failed),(name,expected,failed)")
(p/'mutations.py').write_text(s)
rows=json.loads((p/'mutation-results.json').read_text())
for row in rows:
 row['expectedSelectedFailures']=[fix.get(x,x)for x in row['expectedSelectedFailures']]
 row['selectedFailuresObserved']=set(row['expectedSelectedFailures']).issubset(row['failed'])
 actual=json.loads((p/'mutants'/row['variant']/'results.json').read_text())['rows'];failed=[x['id']for x in actual if not x['passed']]
 assert failed==row['failed'] and row['selectedFailuresObserved'] and len(actual)==525
 assert bool(failed)==(row['variant']!='original')
(p/'mutation-results.json').write_text(json.dumps(rows,indent=2)+'\n')
(p/'mutation-validation.json').write_text(json.dumps({'status':'pass','variants':len(rows),'weakenings':len(rows)-1,'originalPass':True,'allSelectedFailuresObserved':True,'selectorCorrection':'Four bookkeeping labels corrected to existing oracle IDs; initial scripts/results/log retained; no semantic expectations or source mutations changed.'},indent=2)+'\n')
# Keep the genuine pre-fix packet immutable; replay the identical witness on final source.
s=(p/'empty-witness.ts').read_text().replace('empty-witness-result.json','empty-witness-final-result.json');(p/'empty-witness-final.ts').write_text(s)
r=subprocess.run(['/opt/homebrew/bin/bun',str(p/'empty-witness-final.ts')],capture_output=True,text=True,check=True);(p/'empty-witness-final.log').write_text(r.stdout+r.stderr)
assert json.loads((p/'empty-witness-final-result.json').read_text())['actual']['status']=='refused'
# Exact unchanged case inventory; no native acceptance inferred from these controls.
case='docs/helix/03-test/security/cases.json'
if not(root/case).exists():
 case=next(str(x.relative_to(root))for x in root.rglob('cases.json')if 'security' in str(x) and 'node_modules' not in str(x))
before=subprocess.check_output(['git','show','20cf9f11:'+case],cwd=root);now=(root/case).read_bytes();assert before==now
(p/'case-preservation.json').write_text(json.dumps({'path':case,'baseline':'20cf9f11','sha256':hashlib.sha256(now).hexdigest(),'byteIdentical':True,'scope':'All case assertions, bindings and acceptance status unchanged by this increment; S24/S25 remain unbound.'},indent=2)+'\n')
# Retain independently authored recipe generator, without rerunning/changing its historical fixtures.
shutil.copyfile('/private/tmp/protection-functions-astra-20261015/oracle.py',p/'function-oracle.py')
formal=json.loads((p/'formal-replay.json').read_text());assert len(formal['queries'])==14 and all(x['result']==x['expected']for x in formal['queries'])
print(json.dumps({'mutants':len(rows)-1,'casesUnchanged':True,'formal':{v:sum(x['result']==v for x in formal['queries'])for v in ['sat','unsat']}}))
