import json,hashlib,datetime,zipfile
from pathlib import Path
p=Path(__file__).parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
pins=json.loads((p/'source-pins-after.json').read_text());browser=json.loads((p/'browser-results.json').read_text());rows=json.loads((p/'all-results.json').read_text())['rows'];mutations=json.loads((p/'mutation-results.json').read_text());formal=json.loads((p/'formal-replay.json').read_text())
assert len(rows)==1613 and all(x['passed']for x in rows) and browser['parity'] and not browser['externalRequests'] and not browser['pageErrors'] and browser['hostGlobalsAbsent']
assert len(mutations)==16 and all(x['selectedFailuresObserved']for x in mutations)
artifacts=['oracle.ts','function-oracle.py','function-fixtures.json','base-fixture.json','all-oracle.ts','run-all.ts','all-results.json','all.log','run-browser.ts','browser-results.json','browser.log','mutations.py','mutation-results.json','mutation-validation.json','mutations.log','focused-tests.log','formal.py','formal-replay.json','source-pins-before.json','source-pins-after.json','case-preservation.json','empty-preflight-before.ts','empty-preflight-before.json','empty-witness.ts','empty-witness-result.json','empty-witness-final.ts','empty-witness-final-result.json','empty-witness-final.log','initial.log','expanded.log','final-collection.log','initial-selector-labels-mutations.py','initial-selector-labels-mutation-results.json','initial-selector-labels-mutations.log']
review={
 'status':'reviewed-no-remaining-actionable-findings-within-stated-component-scope',
 'reviewedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'baseline':'20cf9f112df8b56d9ad0a5fa687f9275fece19a0',
 'scope':'Private canonical catalog collection renderer and compiler-issued pure definition bridge. Actual scoped policy grants, deny filtering, atomic refusal, SecurityOutput-style cells and explicit Gregorian output profiles under supplied logical owner/cut premises. No repository sources changed by reviewer.',
 'sources':{'selectedCount':len(pins),'beforeAfterIdentical':True,'manifest':'source-pins-after.json','closure':'Selected static relative-import closure plus selected tests, canonical schemas, contract and metadata; not entire root/runtime provenance.'},
 'keySourcePins':{k:pins[k]for k in ['src/extensions/security/catalog-runtime-candidate.ts','src/extensions/security/catalog-program-candidate.ts','src/extensions/security/protection/functions.ts','src/extensions/security/protection/literals.ts','tests/security/catalog-collection.test.ts','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md']},
 'independentChecks':{'collection':525,'priorActionRegression':1088,'totalEachRuntime':1613,'bun':browser['versions']['bun'],'chromium':browser['versions']['chromium'],'allPassed':True,'fullRowParity':True,'externalRequests':0,'pageErrors':[],'hostGlobalsAbsent':True,'recipeExpectedValues':'459 reused independent Python-authored recipe fixtures; 66 additional independently authored collection/custody/resource controls. Negative recipes may refuse during genuine source compilation or runtime; no claim every refusal reaches rendering.','mutations':{'original':525,'sourceWeakenings':15,'allDetected':True,'allSelectedFailuresObserved':True,'scope':'Bun replay of actual isolated source changes; selected diagnostic failures, not universal necessity/completeness.'},'repositoryFocusedTests':{'tests':37,'assertions':219,'failures':0},'formal':{'queries':14,'unsat':8,'sat':6,'scope':'Independent replay of parent-authored conditional formulas. Faithful failure accounting, complete population and delayed publication are premises; no TypeScript/native/authority refinement.'}},
 'resolvedFindings':[
  {'issue':'Empty requested target initially bypassed output coverage/recipe/profile preflight.','before':'empty-witness-result.json + exact empty-preflight-before.ts','after':'Identical witness refuses; final static source-scoped preflight and unconditional withholding/transformation suppression independently covered.'},
  {'issue':'Initial design would have changed legacy inline constant and denied-row collection semantics.','resolution':'Final renderer filters deny rows, refuses whole batch on U/conflict/failure, preserves input-independent inline constants, refuses catalog known absence and retains original absence/null distinctly.'}
 ],
 'remainingFindings':[],
 'limits':[
  'Conservative source-scoped empty-target preflight is not blanket equivalence to all legacy collection behavior. Conditional withholding does not suppress potential plaintext dependencies; unconditional withholding and transformation suppression are explicit selected rules.',
  'Issued private program/definition identity is model custody, not authenticated source, caller, compiler or native authority. Owner/cut completeness and provenance remain trusted premises.',
  'Pure function output is tested against independent finite expected values and original core domains. Hash/token/encrypt/native execution, keys/vaults/reversal/propagation are not implemented or authorized. Stored original token remains the canonical stored token.',
  'Operation step/literal/text and retained-output ledgers are bounded selected work; no total CPU, pre-snapshot allocation or heap theorem. Per-cell resets and action/render resets are independently killed.',
  'No streaming, public .2 interpretation, native admission, query rewrite, write grant, crypto/custody enforcement or S24/S25 promotion. All 158 acceptance cases remain byte-identical to baseline.',
  'Parent whole gate and full regression results were reported separately; reviewer did not rerun native acceptance or qualify them as independent evidence.'
 ],
 'developmentEvidence':{
  'expanded.log':'Retained oracle calibration failure: output-only 30x3000 characters fit the actual ledger. Replaced with independently excessive combined action+render work; expected refusal unchanged for the corrected input.',
  'initial-selector-labels-*':'Four selected mutation expectation labels initially misspelled existing oracle IDs. Original full failed sets retained; final selector names corrected without changing semantic expectations or source mutations.',
  'initial.log/final-collection.log':'Earlier finite oracle stages retained as development evidence, not exact final 525-control qualification.'
 },
 'artifacts':{name:sha(p/name)for name in artifacts}
}
(p/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(p/'review.md').write_text('''# Atomic pure collection renderer — independent review

No remaining actionable defect found within the stated private logical component scope.

- Final 525 collection controls and unchanged 1088 action controls pass in Bun 1.4.2 and Chromium 153.0.8010.12, with complete row parity, no external requests/page errors, and no host globals.
- Fifteen isolated source weakenings are detected by selected existing oracle failures. These include owner/action binding, source read purpose, atomic U/conflict refusal, deny filtering, empty-target preflight, inline independence, issued definition identity, exact recipe selection, output validation/profiles, and action/render/per-cell budget resets.
- Focused repository tests: 37 pass, 219 assertions. Parent-authored conditional formal model independently replays 14 expected results (8 UNSAT, 6 SAT); assumptions are explicit and this is not implementation/native refinement.
- Seventy-five selected source pins are identical before/after. The full 158-case file is byte-identical to baseline; no acceptance promotion.

The actual earlier empty-target gap is retained with its exact source and input. The same input now refuses. Legacy inline constants remain source-independent; catalog pure recipes require present input; original absence, null, withheld, and transformed null remain distinct. Denied rows are filtered in order; later uncertainty/conflict/domain/budget failure clears all output.

Empty-target preflight deliberately uses a conservative source-scoped rule, not universal equivalence to legacy collection behavior. Private issuance is model custody only. Trusted source/owner/cut premises, native authority, public interpretation, crypto/vault execution, query/write authorization, and full S24/S25 remain outside this qualification. Resource ledgers do not establish a total CPU/heap bound.

See review.json for source hashes, artifact hashes, historical oracle-calibration and selector-label corrections. No repository sources were edited; no native acceptance jobs were started by this review.
''')
# Focused reproducibility archive: no symlink/dependency tree, generated bundle, unrelated spec/media or full mutant source copies.
selected=[]
for f in p.rglob('*'):
 if not f.is_file()or f.is_symlink():continue
 rel=f.relative_to(p)
 if rel.parts[0]=='mutants':
  name=rel.parts[1];record=next(x for x in mutations if x['variant']==name)
  allowed={'results.json','run.log','run.ts'}|{x['path']for x in record['changedSources']}
  if str(Path(*rel.parts[2:]))not in allowed:continue
 if rel.name in {'review-archive.zip','archive.json','artifact-manifest.json'}:continue
 selected.append(f)
manifest={str(f.relative_to(p)):sha(f)for f in sorted(selected)}
(p/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(p/'review-archive.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in sorted(selected)+[p/'artifact-manifest.json']:z.write(f,str(f.relative_to(p)))
archive={'path':str(p/'review-archive.zip'),'sha256':sha(p/'review-archive.zip'),'files':len(selected)+1,'bytes':(p/'review-archive.zip').stat().st_size,'reviewSha256':sha(p/'review.json'),'manifestSha256':sha(p/'artifact-manifest.json')}
(p/'archive.json').write_text(json.dumps(archive,indent=2)+'\n');print(json.dumps(archive))
