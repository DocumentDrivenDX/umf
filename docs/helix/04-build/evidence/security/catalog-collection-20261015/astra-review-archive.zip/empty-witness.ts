import base from './base-fixture.json';
import{compileCandidateCatalogProgram as compile}from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-program-candidate';
import{evaluateCandidateCatalogCollection as render}from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-runtime-candidate';
const ref=(elementId:string)=>({documentId:'review-domain',moduleId:'entities',elementId});
const f:any=structuredClone(base);f.owner.disclosure={readAction:'read'};f.ontology.actionPurposes=[{action:'read',purposes:['read']}];f.policy.rules[0].disclosure[0].disposition={kind:'original'};f.request.resources=[];f.request.fields=[ref('amount')];f.cut.coverage.find((c:any)=>c.type.elementId==='Asset').fields=[];
const result=render(compile(f.policy,null,f.closure,f.ontology),f.owner,f.cut,f.request);await Bun.write(import.meta.dir+'/empty-witness-result.json',JSON.stringify({input:f,expected:'refused',actual:result},null,2)+'\n');console.log(JSON.stringify(result));
