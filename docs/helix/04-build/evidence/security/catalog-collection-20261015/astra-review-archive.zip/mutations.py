import json,shutil,subprocess,hashlib
from pathlib import Path
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent;dest=out/'mutants';dest.mkdir(exist_ok=True)
runtime='src/extensions/security/catalog-runtime-candidate.ts'; functions='src/extensions/security/protection/functions.ts'
variants=[('original',[],[]),
('omit-owner-request-binding',[(runtime,"if(render&&(!owner.disclosure||request.action!==owner.disclosure.readAction))fail('Collection requires exact owner read action');",'')],['owner-request-action-mismatch-despite-two-grants']),
('omit-source-read-purpose',[(runtime,"!ontology.actionPurposes?.some((p:any)=>p.action===action&&p.purposes.includes('read'))",'false')],['source-read-purpose-field-only']),
('omit-unresolved-batch-refusal',[(runtime,"if(rows.some(r=>r.decision==='indeterminate'||r.decision==='conflict'))fail('Collection decision is unresolved');",'')],['late-unknown-clears-earlier-original']),
('retain-denied-rows',[(runtime,".filter(r=>r.row.decision==='permit')",'')],['deny-filter-retains-order-and-duplicates']),
('omit-empty-target-preflight',[(runtime,"if(!resourceTypes.has(id(target)))",'if(false)')],['empty-original-coverage','empty-nonpure-token-directive-refused']),
('omit-unconditional-withheld-suppression',[(runtime,'if(alwaysWithheld)continue;','')],['empty-unconditional-withheld-suppresses-original']),
('omit-unconditional-transform-suppression',[(runtime,"if(d.kind==='transformed')alwaysTransformed=true;",'')],['empty-guaranteed-inline-suppresses-original-true','empty-guaranteed-inline-suppresses-original-false']),
('require-inline-input',[(runtime,"if(d.vocabulary!=='umf.security.protection'){literal(d.field,d.value);continue;}","if(d.vocabulary!=='umf.security.protection'){admitField(resource.type,r,[resource]);literal(d.field,d.value);continue;}")],['legacy-inline-unavailable']),
('reset-pure-budget-per-cell',[(runtime,'evaluateIssuedProtectionDefinition(program.functionDefinitions,recipe(d),value(resource,r),budget)','evaluateIssuedProtectionDefinition(program.functionDefinitions,recipe(d),value(resource,r),new ProtectionLiteralBudget())')],['all-pure-cells-share-operation-ledger']),
('reset-budget-after-action',[(runtime,'const budget=new ProtectionLiteralBudget();','let budget=new ProtectionLiteralBudget();'),(runtime,"if(!render)return freeze({status:'evaluated',complete:false,authority:false,rows});","if(!render)return freeze({status:'evaluated',complete:false,authority:false,rows});budget=new ProtectionLiteralBudget();")],['action-and-output-share-budget']),
('omit-retained-output-accounting',[(runtime,'while(pending.length){step();budget.step();','while(false){step();budget.step();')],['escaped-output-size-ledger-refuses','aggregate-original-output-work-refuses']),
('select-first-recipe',[(runtime,'evaluateIssuedProtectionDefinition(program.functionDefinitions,recipe(d),value(resource,r),budget)','evaluateIssuedProtectionDefinition(program.functionDefinitions,0,value(resource,r),budget)')],['exact-transform-ID-selects-original-issued-definition']),
('omit-output-profile',[(runtime,'outputProfiles.set(id(r),{field:r,profile:GREGORIAN_DATE_PROFILE});','')],['original-date-retains-exact-profile','date-output-profile-deduplicated-for-rendered-cells']),
('admit-copied-definition-context',[(functions,"if(!context)fail('Original issued definition context required');","if(!context&&issued&&typeof issued==='object')return inspect(null,null,null,{transformIndex,value},true,{parameters:issued as any,fields:protectionFieldIndex((issued as any).closure),budget});if(!context)fail('Original issued definition context required');")],['copied-definition-context-refuses']),
('omit-output-domain-validation',[(functions,"checkedValue(to,value,budget,isDate);return finish('transformed');","return finish('transformed');")],['late-output-refinement-clears-earlier-transformed'])]
results=[]
for name,edits,expected in variants:
 d=dest/name;shutil.copytree(root/'src',d/'src',dirs_exist_ok=True)
 for dirname in ['spec','node_modules']:
  if not (d/dirname).exists():(d/dirname).symlink_to(root/dirname)
 for path,old,new in edits:
  p=d/path;s=p.read_text();assert s.count(old)==1,(name,s.count(old));p.write_text(s.replace(old,new))
 for fixture in ['base-fixture.json','function-fixtures.json']:shutil.copyfile(out/fixture,d/fixture)
 (d/'oracle.ts').write_text((out/'oracle.ts').read_text().replace(str(root),str(d)))
 (d/'run.ts').write_text("import{runOracle}from './oracle';const rows=runOracle();await Bun.write(import.meta.dir+'/results.json',JSON.stringify({rows},null,2)+'\\n');console.log(JSON.stringify({count:rows.length,failed:rows.filter(r=>!r.passed).map(r=>r.id)}));")
 r=subprocess.run(['/opt/homebrew/bin/bun',str(d/'run.ts')],cwd=d,text=True,capture_output=True,timeout=45);(d/'run.log').write_text(r.stdout+r.stderr)
 if r.returncode:raise RuntimeError((name,r.returncode,r.stdout,r.stderr))
 rows=json.loads((d/'results.json').read_text())['rows'];failed=[x['id'] for x in rows if not x['passed']]
 result={'variant':name,'count':len(rows),'failed':failed,'expectedSelectedFailures':expected,'selectedFailuresObserved':set(expected).issubset(failed),'changedSources':[{'path':path,'sha256':hashlib.sha256((d/path).read_bytes()).hexdigest()}for path in dict.fromkeys(x[0]for x in edits)]};results.append(result);print(json.dumps(result),flush=True)
 (out/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
 assert bool(failed)==(name!='original'),(name,failed)
 assert set(expected).issubset(failed),(name,expected,failed)
