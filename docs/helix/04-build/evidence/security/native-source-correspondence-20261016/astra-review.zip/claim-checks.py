from pathlib import Path
import json,hashlib,subprocess
out=Path(__file__).parent;repo=Path('/private/tmp/truss-disclosure-main-integration-20261016');umf=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
def pin(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
checks=[]
def check(name,v):
 assert v,name;checks.append({'id':name,'pass':True})
d=out/'tracked/native-source-descriptor-20261016';o=out/'tracked/native-source-observation-20261016'
for prefix,folder,source,installed,n in [('descriptor',d,'truss-native-descriptor-integration-unit-20261016.log','truss-native-descriptor-installed-tests-r2-20261016.log',15),('observer',o,'truss-native-source-observation-integration-unit-20261016.log','truss-native-observer-installed-unit-20261016.log',7)]:
 for role,f in [('source',source),('installed',installed)]:
  text=(folder/f).read_text();check(prefix+'-'+role+'-count',f'Ran {n} tests' in text and '\nOK\n' in text)
check('descriptor-wheel499',json.loads((d/'truss-native-descriptor-wheel-verification-r2-20261016.json').read_text())['sourceMembers'].__len__()==499)
check('observer-wheel500',len(json.loads((o/'truss-native-observer-wheel-check-20261016.json').read_text())['sourcePins'])==500)
check('main22pass4skip','Ran 26 tests' in (o/'postrebase-source-tests.log').read_text() and 'OK (skipped=4)' in (o/'postrebase-source-tests.log').read_text())
check('boundary1485','passed (1485 imports)' in (o/'truss-native-source-observation-integration-boundaries-20261016.log').read_text())
r=json.loads((o/'truss-native-source-observation-r2-astra-20261016-review.json').read_text());check('four-findings-resolved',len(r['resolvedFindings'])==4 and r['remainingFindings']==[])
check('supplied-native4-8.156',r['suppliedNativeEvidence']['reviewerRanSQL']==False and '4supplied original-host tests passed8.156s onPG18.6' in r['suppliedNativeEvidence']['result'])
check('native-source-overlay-qualified',r['testedSourceEpoch']['runtimeRelease']=='truss-catalog-runtime/0.71-candidate' and '6differences' in r['testedSourceEpoch']['qualification'])
a=umf/'docs/helix/04-build/evidence/security/acceptance.json';j=json.loads(a.read_bytes());check('allocation-only158-34-45-113',j['requiredCases']==158 and j['allocatedAcceptanceCriteria']==34 and len(j['execution'])==45 and len(j['errors'])==113 and j['status']=='failed')
p=Path('/private/tmp/weft-presence-bridge-astra-20261016/reconstructed/crates/weft-core/src/current_presence.rs');b=p.read_bytes();(out/'inputs/current_presence.rs').write_bytes(b)
check('actual-borrowed-parent-binding',all(x in b for x in [b"original:&'a ApplicationLineage",b'get("native-binding")?',b'binding.sha256!=profile.binding.sha256',b'sha256(original.source_request_json().as_bytes())']))
for rel in ['docs/helix/04-build/implementation-plan.md','docs/helix/04-build/evidence/security/native-source-correspondence-20261016/README.md','docs/helix/04-build/evidence/security/native-source-correspondence-20261016/receipt.json']:
 check('checkpoint-unchanged:'+rel,(out/'inputs'/rel).read_bytes()==(umf/rel).read_bytes())
(out/'claim-checks.json').write_text(json.dumps({'status':'passed','checks':checks,'acceptance':{'path':str(a),**pin(a),'historicalNotReexecuted':True},'constructionOrderSource':{'path':str(p),**pin(p)},'scope':'Historical evidence reconciliation only, no rerun of source/package/native campaigns.'},indent=2)+'\n');print(json.dumps({'passed':len(checks)}))
