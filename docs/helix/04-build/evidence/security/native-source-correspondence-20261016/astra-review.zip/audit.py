from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).resolve().parent
repo=Path('/private/tmp/truss-disclosure-main-integration-20261016'); commit='984d6a65569adb084c6868fcfd8f5674c5a23ea3'
def sha(b):return hashlib.sha256(b).hexdigest()
def show(path):return subprocess.check_output(['git','show',commit+':'+path],cwd=repo)
rows=[]
for folder in ['native-source-descriptor-20261016','native-source-observation-20261016']:
 rel='docs/helix/04-build/evidence/'+folder;raw=show(rel+'/retention.json');manifest=json.loads(raw)
 for name,pin in manifest.items():
  b=show(rel+'/'+name);assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],name
  rows.append({'path':rel+'/'+name,**pin,'matches':True})
  if name.endswith(('.json','.log','.md','.py')):
   p=out/'tracked'/folder/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 print(folder,len(manifest),sha(raw))
ancestry={}
for c in ['31ce4449010051832398e50130582acd9999c7e9','72db646fb76c6932f00e462a4c767592d60a3720']:
 r=subprocess.run(['git','merge-base','--is-ancestor',c,commit],cwd=repo);assert r.returncode==0;ancestry[c]=True
sources={}
for name,expected in [('_native_source_descriptor.py','092b3580c2ba4c185238e2d5def47d6ca3b8488897e2124e9fb0a86e71239589'),('_native_source_observation.py','c260315436a6ed420d6a38a594d1becfb65f7ee9993416be806846719469f3df')]:
 b=show('packages/python/src/truss/'+name);assert sha(b)==expected;sources[name]={'sha256':sha(b),'bytes':len(b),'matchesPriorReviewedSource':True}
(out/'audit.json').write_text(json.dumps({'status':'passed','commit':commit,'verifiedArtifacts':len(rows),'artifacts':rows,'ancestors':ancestry,'sources':sources},indent=2)+'\n')
(out/'commit-files.txt').write_bytes(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',commit],cwd=repo))
for folder in ['native-source-descriptor-20261016','native-source-observation-20261016']:
 for p in (out/'tracked'/folder).glob('*'):
  if p.suffix in ['.log','.md'] and ('tests' in p.name or 'unit' in p.name or 'boundaries' in p.name or p.name=='README.md'): print(p.name,p.read_text()[-3500:])
for name in ['truss-native-descriptor-wheel-verification-r2-20261016.json','truss-native-observer-wheel-check-20261016.json','truss-native-descriptor-postrebase-20261016.json']:
 p=next((out/'tracked').rglob(name)); j=json.loads(p.read_text());print(name,{k:(len(v) if isinstance(v,(dict,list)) else v) for k,v in j.items()})
