---
ddx:
  id: CONTRACT-004
  type: contract
  activity: design
  status: draft
  authoring:
    home: repo
  links:
    - id: FEAT-005
      kind: informed_by
    - id: weft.architecture
      kind: informed_by
---

# CONTRACT-004: Versioned application reads

**Versions:** proposed `weft-sql/0.2.0`, `weft-ir/0.2.0`, `weft-compile/0.2.0` and recognizer profile `weft-application-read/0.2.0`. **Status:** required product outcomes; draft concrete extension with B-002A frontend evidence; public/native backend support remains unqualified. The owner requested incorporation of [PR #2's discovery input](../../00-discover/application-read-requirements-input.md).

## Purpose and Scope

Support complete entity reads, bounded keyset pages, counts, related keys and typed source parameters. Keep CONTRACT-001's 0.1 behavior and fixtures unchanged. Version selection is explicit; no query upgrades itself based on target or recognizer acceptance. B-002A finalizes executable grammar/IR/result schemas and fixtures before plugin/adapter work relies on these constructs.

## Whole-entity projection and presence

`SELECT c.* FROM Customer c` selects every declared Field in the exact ordered `Record.members` list, resolving local dependencies by identity. Bare `*` stays excluded. Duplicate output labels block; explicit scalar projections may coexist only without collisions. Unknown/missing selected member meaning refuses rather than omitting the member.

Each output descriptor names field identity, cardinality, availability, exact type graph, carrier and decoder. Core `required` asserts a value; `absent-allowed` permits absence; `unspecified` asserts neither and cannot establish an application-read representation by itself. Explicit native null is a separate capability, not an inferred meaning of `absent-allowed`. A host-visible cell uses a tagged presence envelope `{state:"absent"}`, `{state:"null"}` or `{state:"value",value:...}` when those states are meaningful. A binding that cannot distinguish required states refuses. Plain SQL NULL cannot substitute for both absence and explicit null.

Lists have ordered items and a recursively declared item Field type, following `itemType`. Structured values follow explicit `references` with role `record-type`; the descriptor is an identity graph, with cycles represented as references rather than recursively expanded forever. Missing item/record meaning blocks. Exact numeric leaves use strings inside structured JSON carriers; no native JSON-number conversion through JS/Python floats. Map keys, item absence, explicit native-null permission and storage encoding require a recognized native/binding profile; core cardinality alone never chooses their encoding. An entire structured value is not silently flattened, truncated or JSON-stringified without a declared descriptor.

## Bounded deterministic reads and keyset continuation

Application entity-page profile requires `ORDER BY` the complete fields of an authored unique key, in its declared order and ASC, plus `LIMIT n`. `n` is a positive literal integer up to a declared profile bound; 1,000 is the initial application safety maximum, with compiler rejection above it or for quoted/fractional/negative bounds. Backend ordering must prove exact numeric order or a stated exact text order/collation and selected key uniqueness/stability. No OFFSET or hidden row cut. General 0.1 queries remain governed by their own unbounded semantics.

Scalar `key_column > literal_or_parameter` supports single-field key continuation. Composite continuation uses `(key_col1,key_col2,...) > (value1,value2,...)` with lexicographic comparison in the same complete key order. A conjunction of independent `>` comparisons is not a composite keyset cursor. Tuple arity/type mismatch refuses. Cursor context includes model/binding revisions and publication/snapshot assumptions; concurrent mutations can change pages unless the host supplies a consistent read context. Never claim cross-page snapshot stability solely from ORDER BY.

## Counting

`COUNT(*)` counts rows in the current bag, including join duplicates. It returns an exact mathematical integer, with text carrier/decoder. Global empty input returns one row containing zero; grouped empty input returns zero rows. Count cannot infer distinct entity count or collapse relationships. Bounded native count domains and exact-or-error obligations are explicit.

## Relationships and inverse names

Proposed source forms: `HAS_RELATED(c.orders, KEY(:order_id))` as a WHERE predicate and `RELATED_KEYS(c.orders, 20) AS orders` as a projection. Parameter/literal tuples follow the target's explicitly named authored key, in declared component order. Resolve `orders` against supplied module-level authored `relationships`, including its stable ID and source endpoint; inverse names resolve from the target endpoint with direction reversed. Ambiguous names, unkeyed inverse endpoints, polymorphic endpoints without a complete supported domain, association records without supported traversal and unknown multiplicity/lifecycle semantics refuse. An ordinary property join is never converted into a relationship automatically.

HAS_RELATED is existential and cannot multiply the source row. RELATED_KEYS preserves endpoint/edge multiplicity as declared by the relationship/profile; its result is `{items:[keyTuples],truncated:boolean}`. Items are ordered by the complete target key; equal key tuples retain multiplicity. Truncation is true exactly when more than the requested bound exist in the same qualified read context. Empty related results have an empty list and false marker. Backend must obtain a lookahead or equivalent exact cardinality proof; silently cutting a list is forbidden. Multiple endpoint variants require tagged key tuples, not an inferred common identity.

### Participation degree and occurrence bags

For the supported owning UMF core 0.7/0.8 relationship meaning, participation
multiplicity MUST count distinct associated endpoint Record instances in the
complete authorized pinned dataset. It MUST NOT count edge occurrences, key
component values or projected key tuples. After verifying source scope, endpoint
Record type and identity, schema revision, endpoint existence and key uniqueness,
a backend MAY count distinct physical endpoint pairs within that exact relationship
scope. Forward target participation groups by source instance; inverse source
participation groups by target instance. Zero-associated instances MUST remain in
minimum-participation checks. Unknown endpoint meaning or incomplete authority
MUST refuse rather than infer a degree.

Independent edge occurrence identity and uniqueness remain separate constraints.
Two different edges between the same source and target contribute one neighbor to
each degree, but MUST remain two occurrences in RELATED_KEYS, exact lookahead and
truncation. Deduplicating the degree input MUST NOT deduplicate result inputs,
existential source rows, occurrence ordering or any future path bag. Distinct
physical endpoint pairs are a guarded representation of original Record identity,
not a replacement authored key or an invented association Record.

This clarification changes only relationship-integrity degree checks for newly
built compiler realizations. It does not change language, logical-plan, binding or
result shapes, nor silently upgrade an immutable compiler package or trusted
index. A previously qualified realization retains its original bytes and guard
receipts. Hosts MUST separately admit the exact new compiler realization and
its changed checks before execution; they MUST NOT label old occurrence-count
checks as distinct-neighbor evidence. Non-relationship artifacts and relationship
result SQL MUST retain their existing behavior. Native degree/parallel-occurrence
qualification is separate from compiler tests. Two-hop traversal remains outside
this application-read surface until separately versioned.

These outcomes require known bindings of UMF relationship IDs to actual Truss edges/foreign keys or Ashlar layout. Missing backend access paths/capabilities refuse. Read authorization applies to source and related entities; inverse traversal cannot elevate privileges.

## Parameters, literals and recognizable subsets

Source marker `:name` is a typed parameter after model resolution. The 0.2 request supplies a named parameter map with explicit family/type and exact string value; references intersect all required field/key domains. Missing, surplus or incompatible parameter bindings refuse. The emitter allocates ordered native slots from typed data; source values never become SQL fragments. Null/presence parameter forms need explicit semantics and are not inferred from string `null`. Literal quote escaping, Unicode scalar preservation, base-ten exact numbers and no exponent/backslash-escape convention retain CONTRACT-001 rules with fixtures.

Publish named `entity-page`, `count-summary` and `related-entity-page` subsets of this dialect, including grammar, required model/key/type checks and positive/refusal fixtures. A host recognizer must state its profile/version, refuse excluded constructs by name and perform the subset's supplied-model checks before claiming a query is Weft-valid. Syntactic recognition alone is not semantic validation or a backend capability claim. Recognition never constructs target SQL from caller text. Replacing a recognizer with the shared compiler must preserve acceptance and meaning for the pinned subset; language expansion requires an explicit profile change.

## Backend and Host Obligations

Truss requires qualified type/key/property-home scans, exact missing/null/list decoding, bounded key order and authored edge mappings. Ashlar requires accepted gold tables/types, exact ordering/count behavior, published read context and matching related layouts. Hosts report the selected publication/feed position and enforce policy/prepared execution. Compiler output can declare these obligations; it cannot obtain the position or attest authorization itself.

## Compatibility, Diagnostics and Validation

B-002A implements the draft frontend extension against the [0.2 grammar](weft-sql-v0.2.ebnf), [typed plan schema](logical-plan-v0.2.schema.json), [request schema](compile-request-v0.2.schema.json) and [value carrier schema](application-result-v0.2.schema.json). These structures and maxima have structural, independent result, resource/refusal and real-browser component evidence in [B-002A](../../04-build/evidence/B-002A-application-reads.md); public/native backend qualification remains incomplete. Backend interfaces must include capabilities for whole-entity member representations, presence, key order/tuple comparison, limit, count, relationships and parameters. Unsupported selected meaning, representation, ordering or obligations blocks atomically with a named construct. Independent fixtures cover all US-007 criteria, including composite keys, inverse names, absence/null/empty-list distinctions and unchanged 0.1 refusals. No native backend or release support is implied by this contract.


## Executable draft details for B-002A

The explicit 0.2 frontend retains 0.1 relational operations and adds COUNT(*),
whole-entity expansion, related reads, comparison, ordering, bounds and named
parameters. No version is inferred. The test frontend report remains distinct
from CONTRACT-003's public compile response; B-004 implements that boundary.
A named profile is supplied as `readProfile: {version:
"weft-application-read/0.2.0", subset: "entity-page"}` (or `count-summary` /
`related-entity-page`). Omitting it selects the general 0.2 dialect, which does
not imply boundedness or deterministic pages.

The typed IR is a sequence of relational stages: source and ordered inner joins,
conjunctive filters, aggregation when indicated, projection, order, then limit.
Joins preserve bag duplicates; HAS_RELATED is existential. Global aggregates
produce one row on empty input; grouped aggregates produce none. Ordering fields
remain available through the relational stages even when not projected. An
entity page identifies its selected authored `pageKey` as well as ordering
fields; a backend must qualify that identity's uniqueness/stability. All fields
in a tuple comparison retain their order; parameter domains are attached at each
use, with validation against every domain before a plan can be returned.

Named input bindings are `{family:"integer", value:"18446744073709551615"}` (or
boolean/string/decimal). Keys are ASCII identifiers and case-folded; duplicate
folded names refuse. Parameter markers are unquoted. Boolean values are exactly
`true` / `false`; exact numbers match `-?[0-9]+(\.[0-9]+)?`, without exponent,
plus sign, whitespace or implicit rounding. String values preserve Unicode and
quote characters and exclude NUL in this initial text profile. All values stay
typed data; they are never SQL fragments. Each occurrence can require a narrower
field domain than another occurrence of the same parameter.

`entity-page` excludes joins and aggregation, requires one source and a complete,
unambiguous authored key in ASC order with a positive LIMIT through 1,000.
Cursors compare that entire ordered key to a literal/parameter tuple.
`related-entity-page` has the same page constraints and requires a related
projection or predicate. `entity-page` excludes both. `count-summary` requires
COUNT(*) with optional grouped scalar projections and equality filters; inner
joins are permitted. It excludes SUM, entity/related projections, related filters
and cursor predicates. A global count excludes ORDER/LIMIT because it produces
one row; grouped count requires the complete grouping tuple in its declared order
and LIMIT. A grouping tuple is a unique result key even when it is not an entity
key. Backend text order must be qualified; exact logical text ordering in fixtures
uses Unicode scalar order, without normalization, trimming or locale folding.

The initial relationship traversal subset has one source, one target, directed
semantics, an explicitly named target key, known owned/independent lifecycle and
no association Record. Other selected variants refuse explicitly. Source key selection (and inverse target
key selection) uses a sole primary key, otherwise a sole authored key; ambiguity
refuses. Descriptors retain both multiplicities and lifecycle in their authored
orientation plus the inverse flag. Backend capability assessment must retain
these obligations; descriptors alone do not prove storage enforcement.

The descriptor graph is bounded to 4,096 reachable identities and depth 128 per
selected root, with cycles referring to prior identities. Availability is separate
from scalar type: a scalar descriptor's `nullable:false` describes its ideal
value domain and cannot authorize dropping absent/null distinctions. Ordered lists,
map string keys, structured members and exact numeric leaves need qualified
carriers/decoders. Native null permission must be explicit in the eventual binding
and output descriptor. The result schema models allowed envelope shapes, not
permission to use every state for every field.

## Separately versioned two-hop proposal

[CONTRACT-005](CONTRACT-005-authored-two-hop-paths.md) proposes bounded path
collections and relational path expansion/counting. This preserves the one-hop
surface here: RELATED_KEYS still returns its original terminal-key bag. A future
path bag must retain both actual edge occurrences and the intermediate identity;
degree remains distinct-associated-instance counting, separate from path bags.
