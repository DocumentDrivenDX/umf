"""Native value/presence/refinement boundary component; not P03 admission.
@covers US-056-AC6
"""
import argparse,copy,hashlib,importlib,json,os,pathlib,re,secrets,subprocess,time,uuid,zipfile
import weft
p=argparse.ArgumentParser()
for n in ['umf-root','packet','wheel','output']:p.add_argument('--'+n,type=pathlib.Path,required=True)
a=p.parse_args();root=a.umf_root.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
image='postgres@sha256:74935e72241653ca55e0414067e6d8763aceb8a810eb51b452253ec3dcfc4336'
run_id=str(uuid.uuid4());name='umf-pg18-presence-'+run_id;attempted=False;observations=[];statements=[];result={'status':'incomplete','runId':run_id};password=secrets.token_hex(32)
sha=lambda b:hashlib.sha256(b).hexdigest()
def text(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def command(args,**kw):return subprocess.run(args,text=True,capture_output=True,timeout=kw.pop('timeout',30),**kw)
def require(r):
 if r.returncode:raise RuntimeError(r.stderr[:2000])
 return r.stdout.strip()
def sql(s):statements.append(s);return require(command(['docker','exec','-i',name,'psql','-X','-qAt','-v','ON_ERROR_STOP=1','-U','postgres'],input=s))
def val(s):return json.loads(sql(s))
def literal(s):return "E'"+s.replace('\\','\\\\').replace("'","''")+"'"
def check(id,expected,actual):
 observations.append({'id':id,'expected':expected,'actual':actual});assert expected==actual,id
paths=[pathlib.Path(__file__).resolve(),a.packet.resolve(),a.wheel.resolve(),root/'tests/security/protection/disclosure-fixtures.json',root/'tools/security/native_owned_cleanup.py']
frozen={str(p):p.read_bytes()for p in paths};native=pathlib.Path(importlib.import_module('weft.weft').__file__);shim=pathlib.Path(weft.__file__);frozen[str(native)]=native.read_bytes();frozen[str(shim)]=shim.read_bytes()
with zipfile.ZipFile(a.wheel)as z:
 binaries=[n for n in z.namelist()if n.endswith(('.so','.pyd'))];assert len(binaries)==1 and z.read(binaries[0])==frozen[str(native)]and z.read('weft/__init__.py')==frozen[str(shim)]
cleanup_ns={};exec(compile(frozen[str(root/'tools/security/native_owned_cleanup.py')],str(root/'tools/security/native_owned_cleanup.py'),'exec'),cleanup_ns)
packet=json.loads(frozen[str(a.packet.resolve())]);base=json.loads(frozen[str(root/'tests/security/protection/disclosure-fixtures.json')])['base'];vectors=[v for v in packet['vectors']if v['backend']=='postgresql'and v['kind']=='rows'];assert len(vectors)==4
assert packet['pinsBeforeAfter']==dict(wheelSha256=sha(frozen[str(a.wheel.resolve())]),nativeModuleSha256=sha(frozen[str(native)]),shimSha256=sha(frozen[str(shim)]))
result.update(sourceDigests={p:sha(v)for p,v in frozen.items()},observations=observations,sqlStatements=statements,scope='Owned excluded-admin fixture: actual compiler SQL/native data/refinement boundary only; no P03 admission, authenticated source/caller/current cut, disclosure enforcement or guarded release.')
try:
 assert name not in require(command(['docker','container','ls','-a','--format','{{.Names}}'])).splitlines();attempted=True
 require(command(['docker','run','-d','--name',name,'--label','umf.security.run='+run_id,'-e','POSTGRES_PASSWORD',image],env={**os.environ,'POSTGRES_PASSWORD':password}))
 end=time.monotonic()+30
 while command(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],timeout=3).returncode:
  if time.monotonic()>end:raise TimeoutError('Owned PostgreSQL readiness')
  time.sleep(.1)
 result['engine']=val("SELECT json_build_object('version',version(),'number',current_setting('server_version_num'),'client',current_setting('client_encoding'),'sessionUser',session_user,'currentUser',current_user)");assert result['engine']['number']=='180006'
 sql('CREATE SCHEMA private_stage;CREATE TABLE private_stage.current_values(private_key text PRIMARY KEY,eligible boolean NOT NULL,token text COLLATE "C");')
 # Native rows feed the actual issued Rust checker; no fixed supplied result rows.
 def capture():return val("SELECT coalesce(json_agg(json_build_object('key',private_key,'cells',json_build_object('token',json_build_object('family','string','value',token))) ORDER BY private_key),'[]'::json) FROM private_stage.current_values WHERE eligible IS TRUE")
 def native_results(artifact):
  query=artifact['sql']
  for param in sorted(artifact['parameters'],key=lambda p:p['ordinal'],reverse=True):
   assert param['nativeType']=='text';query=re.sub(r'\$'+str(param['ordinal'])+r'\b',lambda _:literal(param['value']),query)
  # row_to_json preserves the emitted column order, including the private tuple.
  rows=val('SELECT coalesce(json_agg(row_to_json(q)),\'[]\'::json) FROM ('+query+')q')
  return [list(row.values())for row in rows]
 issued=[]
 for vector in vectors:
  parent=weft.prepare_application_lineage(vector['request']);child=parent.prepare_current_query();binding=vector['binding'];artifact_text=child.lower_postgresql_bounded_current_rows_candidate_json(binding);check(vector['id']+':actual-artifact-parity',vector['artifact'],artifact_text);artifact=json.loads(artifact_text)
  sql('TRUNCATE private_stage.current_values;INSERT INTO private_stage.current_values VALUES (\'k0\',true,'+literal('😀')+'),(\'k1\',true,\'z\'),(\'k2\',true,'+literal('é')+');')
  frame=json.loads(vector['input']);rows=capture();frame['scans']=[dict(scan='s0',expectedRowCount=str(len(rows)),rows=rows)];frame['resultRows']=native_results(artifact);raw=text(frame);report=json.loads(child.check_postgresql_bounded_current_rows_candidate_json(binding,raw));check(vector['id']+':native-frame-matches',True,report['matched']);assert report['authority']is False and report['securityReady']is False
  issued.append(dict(id=vector['id'],request=vector['request'],binding=binding,artifact=artifact_text,frame=raw,report=report))
  sql("UPDATE private_stage.current_values SET token=NULL WHERE private_key='k2'")
  bad=copy.deepcopy(frame);bad['scans'][0]['rows']=capture();bad['resultRows']=native_results(artifact)
  try:child.check_postgresql_bounded_current_rows_candidate_json(binding,text(bad))
  except (ValueError,TypeError)as e:observations.append(dict(id=vector['id']+':native-null-refuses',refused=True,errorType=type(e).__name__,diagnostic=str(e),frame=bad))
  else:raise AssertionError('Native NULL accepted as required String')
 # Exact original declared disclosure population has two orthogonal dimensions.
 cells=[row[0]for row in base['batch']['rows']];assert len(cells)==5
 sql('CREATE TABLE private_stage.disclosure_carrier(ordinal int PRIMARY KEY,disposition text NOT NULL,payload_present boolean NOT NULL,payload jsonb,selection jsonb,output_domain jsonb,transform jsonb);')
 for i,c in enumerate(cells):
  j=lambda x:'NULL'if x is None else literal(text(x))+'::jsonb'
  payload=literal(text(c['value']))+'::jsonb'if 'value'in c else'NULL'
  sql('INSERT INTO private_stage.disclosure_carrier VALUES ('+str(i)+','+literal(c['disposition'])+','+('true'if'value'in c else'false')+','+payload+','+j(c.get('selection'))+','+j(c.get('outputDomain'))+','+j(c.get('transform'))+');')
 carrier=val("SELECT json_agg(json_build_object('ordinal',ordinal,'disposition',disposition,'payloadPresent',payload_present,'sqlNull',payload IS NULL,'jsonNull',payload='null'::jsonb,'payload',payload,'selection',selection,'outputDomain',output_domain,'transform',transform) ORDER BY ordinal) FROM private_stage.disclosure_carrier")
 decoded=[]
 for row in carrier:
  cell={'disposition':row['disposition']}
  if row['payloadPresent']:cell['value']=row['payload']
  if row['disposition']=='transformed':cell.update(selection=row['selection'],outputDomain=row['outputDomain'],transform=row['transform'])
  decoded.append(cell)
 check('native-tagged-five-outcomes-roundtrip',cells,decoded)
 check('SQL-null-versus-JSON-null',[False,True,True,False,False],[c['sqlNull']for c in carrier])
 naive=val("SELECT json_agg(payload->>'string' ORDER BY ordinal) FROM private_stage.disclosure_carrier")
 check('weakened-nullable-scalar-collapses-four-distinct-states',[None,None,None,None,'masked'],naive)
 check('original-null-and-transformed-null-same-payload',carrier[0]['payload'],carrier[3]['payload']);check('original-null-and-transformed-null-different-disposition',True,carrier[0]['disposition']!=carrier[3]['disposition'])
 # Current required-only source producer must refuse original optional semantics.
 source=json.loads(vectors[0]['request']);doc=json.loads(source['modules'][0]['documentJson']);token=next(f for f in doc['modules'][0]['elements']if f['id']=='token');token['nullability']='absent-allowed';source['modules'][0]['documentJson']=text(doc);source['modules'][0]['pin']['sha256']=sha(text(doc).encode());before=len(statements)
 try:weft.prepare_application_lineage(text(source))
 except (ValueError,TypeError)as e:result['optionalSourceRefusal']={'request':text(source),'diagnostic':str(e),'nativeApplicationStatementsAdded':len(statements)-before}
 else:raise AssertionError('Optional source silently accepted by required-only producer')
 assert len(statements)==before
 if any(pathlib.Path(p).read_bytes()!=v for p,v in frozen.items()):raise RuntimeError('Captured source or artifact changed')
 result.update(status='native-carrier-refusal-component-passed',observations=observations,issuedQueries=issued,originalDisclosure={'batch':base['batch'],'nativeCarrier':carrier,'decodedCells':decoded,'naiveScalarRows':naive},sourceDigests={p:sha(v)for p,v in frozen.items()},sourcesUnchanged=True,sqlStatements=statements,scope='Actual PostgreSQL18.6 compiler SQL/driver values/issued Rust checker and physical disclosure carrier observations. The current-value relation is an owned declared fixture, not authenticated policy-selected complete source/caller/current-cut. Original disclosure rows are declared transport cells, not actual policy decisions or transforms. No P03, null/absence operator semantics, role/guarded release or backend admission is accepted.')
except BaseException as e:result.update(failure={'type':type(e).__name__,'message':str(e)},observations=observations);raise
finally:
 cleanup=cleanup_ns['cleanup_owned'](command,name,run_id,attempted);result['cleanup']=cleanup
 if not cleanup['verified']and result['status']=='native-carrier-refusal-component-passed':result['status']='component-passed-cleanup-unverified'
 (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['status']=='native-carrier-refusal-component-passed'
print(json.dumps({'status':result['status'],'observations':len(observations),'issuedQueries':len(issued),'cleanupVerified':cleanup['verified']}))
