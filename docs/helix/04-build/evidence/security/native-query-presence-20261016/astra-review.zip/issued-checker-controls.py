import copy,hashlib,importlib,json,pathlib,sys
r=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(r/'wheel-extracted'))
import weft
n=json.loads((r/'frozen/docs/helix/04-build/evidence/security/native-query-presence-20261016/native.json').read_text())
idx=json.loads((r/'native-index.json').read_text());native=pathlib.Path(importlib.import_module('weft.weft').__file__);shim=pathlib.Path(weft.__file__)
pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [native,shim]}
assert pins[str(native)]==next(v['sha256']for k,v in idx.items()if k.endswith('weft.abi3.so'))
assert pins[str(shim)]==next(v['sha256']for k,v in idx.items()if k.endswith('weft/__init__.py'))
controls=[]
def save(id):controls.append({'id':id,'passed':True})
def raw(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
for vector in n['issuedQueries']:
 id=vector['id'];parent=weft.prepare_application_lineage(vector['request']);child=parent.prepare_current_query();b=vector['binding']
 assert child.lower_postgresql_bounded_current_rows_candidate_json(b)==vector['artifact'];save(id+'/artifact-exact')
 assert json.loads(child.check_postgresql_bounded_current_rows_candidate_json(b,vector['frame']))==vector['report'];save(id+'/original-report-exact')
 frame=json.loads(vector['frame'])
 mods=[('hidden-null',lambda f:f['scans'][0]['rows'][2]['cells']['token'].update(value=None)),('hidden-overbound',lambda f:f['scans'][0]['rows'][2]['cells']['token'].update(value='😀'*65)),('hidden-wrong-family',lambda f:f['scans'][0]['rows'][2]['cells']['token'].update(family='integer',value='1')),('duplicate-key',lambda f:f['scans'][0]['rows'][2].update(key='k0')),('wrong-count',lambda f:f['scans'][0].update(expectedRowCount='2')),('missing-population',lambda f:f['scans'][0].update(rows=[])),('wrong-artifact',lambda f:f.update(compiledArtifactSha256='0'*64)),('wrong-source',lambda f:f.update(sourceRequestSha256='0'*64)),('invented-public-result',lambda f:f['resultRows'].append(['forged',json.dumps({'version':'weft.stage-row-tuple/0.1-candidate','rows':[{'scan':'s0','key':'k2'}]})]))]
 for label,change in mods:
  f=copy.deepcopy(frame);change(f)
  try:child.check_postgresql_bounded_current_rows_candidate_json(b,raw(f))
  except (ValueError,TypeError):save(id+'/'+label+'-refused')
  else:raise AssertionError((id,label))
 q=next(x for x in n['observations']if x['id']==id+':native-null-refuses')
 try:child.check_postgresql_bounded_current_rows_candidate_json(b,raw(q['frame']))
 except(ValueError,TypeError):save(id+'/recorded-native-null-frame-refused')
 else:raise AssertionError(id)
q=json.loads((r/'frozen/docs/helix/04-build/evidence/security/native-query-presence-20261016/queryable-source.json').read_text())
assert weft.prepare_application_lineage(raw(q['requiredSourceRequest']))is not None;save('required-source-prepares')
try:weft.prepare_application_lineage(raw(q['optionalSourceRequest']))
except(ValueError,TypeError)as ex:assert str(ex).startswith('WFT-APPLICATION-LINEAGE-AVAILABILITY:');save('optional-source-refuses-availability')
else:raise AssertionError('optional source accepted')
assert pins=={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [native,shim]}
report={'status':'passed','checks':len(controls),'python':sys.version,'modulePins':pins,'controls':controls,'scope':'Actual captured candidate wheel issued-object artifact/refinement component replay over supplied original native frames and independently mutated frames. No PostgreSQL or Truss execution.'}
(r/'issued-checker-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','checks':len(controls),'nativeModule':str(native)}))
