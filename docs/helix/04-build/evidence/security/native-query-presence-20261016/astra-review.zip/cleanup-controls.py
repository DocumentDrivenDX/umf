import json,pathlib,types,subprocess,hashlib
r=pathlib.Path(__file__).resolve().parent;s=r/'reconstructed-r3/tools/security/native_owned_cleanup.py';ns={};exec(compile(s.read_bytes(),str(s),'exec'),ns)
R=lambda code=0,out='',err='':types.SimpleNamespace(returncode=code,stdout=out,stderr=err)
absent=R(1,'[]\n','error: no such object: fixture\n');cases=[
 ('not-attempted',False,[],True,False),
 ('owned-removal',True,[R(out='run\n'),R(out='fixture\n'),absent],True,True),
 ('already-absent',True,[absent],True,False),
 ('foreign-label',True,[R(out='foreign\n')],False,False),
 ('empty-label',True,[R(out='\n')],False,False),
 ('inspect-daemon-error',True,[R(1,'','cannot connect')],False,False),
 ('different-name-error',True,[R(1,'[]\n','error: no such object: other')],False,False),
 ('remove-fails',True,[R(out='run'),R(1,'','denied')],False,False),
 ('post-remove-still-present',True,[R(out='run'),R(),R(out='[{}]')],False,True),
 ('post-remove-unknown',True,[R(out='run'),R(),R(1,'','timeout')],False,True),
 ('inspect-timeout',True,[TimeoutError()],False,False),
 ('remove-timeout',True,[R(out='run'),TimeoutError()],False,False),
]
results=[]
for name,attempted,replies,verified,removed in cases:
 calls=[];remaining=list(replies)
 def command(argv):
  calls.append(argv);x=remaining.pop(0)
  if isinstance(x,Exception):raise x
  return x
 outcome=ns['cleanup_owned'](command,'fixture','run',attempted)
 assert not remaining and outcome['verified']is verified and outcome['removed']is removed,(name,outcome)
 if name in ['foreign-label','empty-label','inspect-daemon-error','different-name-error','inspect-timeout','already-absent','not-attempted']:assert not any(a[:2]==['docker','rm']for a in calls)
 results.append({'id':name,'outcome':outcome,'calls':calls})
report={'status':'passed','checks':len(results),'sourceSha256':hashlib.sha256(s.read_bytes()).hexdigest(),'controls':results,'scope':'Modeled command responses only. Actual final tmpfs mount and owned container absence are inspected supplied native receipt evidence.'}
(r/'cleanup-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':len(results),'status':'passed'}))
