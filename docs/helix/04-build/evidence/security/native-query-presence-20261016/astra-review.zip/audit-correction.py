from pathlib import Path
import zipfile,json,hashlib,io,shutil,subprocess
r=Path(__file__).resolve().parent;e=r/'custody-r3/docs/helix/04-build/evidence/security/native-query-presence-20261016';old=r/'frozen/docs/helix/04-build/evidence/security/native-query-presence-20261016';z=zipfile.ZipFile(e/'native-sources.zip');idx=json.loads(z.read('index.json'));n=json.loads((e/'native.json').read_text());q=json.loads((e/'queryable-source.json').read_text());repo=r/'reconstructed-r3';h=lambda b:hashlib.sha256(b).hexdigest();root='/Users/erik/.codex/worktrees/security-main-integration/umf/'
assert len(idx)==len(n['sourceDigests'])==57
assert h((e/'native.json').read_bytes())=='663d2098a14504c93c7493d3bafff9ca6c210f9fa16dea84fcc33dd7d6def2d5'
assert h((e/'native-sources.zip').read_bytes())==n['sourceArchiveSha256']=='2f66d6788feca39b2ac6355534360f6340da593d734b87b12897677fb0d3f845'
for path,entry in idx.items():
 b=z.read(entry['archive'])if'archive'in entry else zipfile.ZipFile(io.BytesIO(z.read(entry['wheelArchive']))).read(entry['wheelMember'])
 assert h(b)==entry['sha256']==n['sourceDigests'][path]
 if path.startswith(root):
  out=repo/path[len(root):];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
assert len(q['sourcePins'])==34
for rel,sha in q['sourcePins'].items():assert h((repo/rel).read_bytes())==sha==idx[root+rel]['sha256']
assert q['externalDependencyAssumptions']['externalClosureHermetic']is False
for f in ['handoff.json','native-sources.zip','native.json','queryable-source.json','queryable-source.log']:assert (old/f).read_bytes()==(e/'superseded-r1'/f).read_bytes()
for f in ['tools/security/prove-disclosure-carrier.py','tests/security/protection/current-query-presence-source.json','docs/helix/02-design/technical-designs/TD-056-security-bindings.md','docs/helix/03-test/test-plans/STP-056-security-bindings.md']:assert(r/'frozen'/f).read_bytes()==(r/'custody-r3'/f).read_bytes()
for f in (old/'formal').iterdir():assert f.read_bytes()==(e/'formal'/f.name).read_bytes()
oldq=json.loads((old/'queryable-source.json').read_text())
for k in oldq:
 if k!='sourcePins':assert oldq[k]==q[k]
oldn=json.loads((old/'native.json').read_text())
for k in ['observations','issuedQueries','originalDisclosure','alternateBagCarrier','sqlStatements','mounts','engine']:assert oldn[k]==n[k],k
assert n['sourcesUnchanged']is True and n['status']=='native-carrier-refusal-component-passed'
assert all(n['cleanup'][k]is True for k in ['ownedLabelVerified','removed','verified'])
assert h((e/'native.json').read_bytes())==json.loads((e/'handoff.json').read_text())['nativeReceiptSha256']
# Copy the local external runtime for this new independent component replay only.
# Historical R3 dependency custody remains explicitly non-hermetic.
packages=['ajv','yaml','fast-deep-equal','fast-uri','json-schema-traverse','require-from-string']
for name in packages:
 src=Path(root)/'node_modules'/name;dst=repo/'node_modules'/name
 if dst.exists():shutil.rmtree(dst)
 shutil.copytree(src,dst,symlinks=False)
external={str(p.relative_to(repo)):h(p.read_bytes())for name in packages for p in(repo/'node_modules'/name).rglob('*')if p.is_file()}
cmd=['/opt/homebrew/bin/bun','tools/security/current-query-presence-source.ts',str(r/'independent-queryable-r3.json')]
p=subprocess.run(cmd,cwd=repo,capture_output=True,text=True);(r/'queryable-r3.stdout').write_text(p.stdout);(r/'queryable-r3.stderr').write_text(p.stderr);assert p.returncode==0,p.stderr
actual=json.loads((r/'independent-queryable-r3.json').read_text());assert actual==q
assert all(h((repo/rel).read_bytes())==sha for rel,sha in q['sourcePins'].items())
assert external=={str(p.relative_to(repo)):h(p.read_bytes())for name in packages for p in(repo/'node_modules'/name).rglob('*')if p.is_file()}
(r/'independent-external-pins.json').write_text(json.dumps(external,indent=2)+'\n')
report={'status':'passed','nativeInputCount':len(idx),'generatorInputCount':len(q['sourcePins']),'allPinsAndCrossReceiptMatches':True,'sourceCorrectionResolvedByFreshEvidence':True,'r1ArchivedByteIdentically':True,'formalAndSemanticInputsUnchanged':True,'nativeObservationsAndIssuedFramesUnchanged':True,'independentQueryableReplay':{'command':cmd,'exitCode':p.returncode,'semanticAndPinEqualityToR3':True,'sourcePinsBeforeAfterUnchanged':True,'externalCopiedFiles':len(external)},'nativeCleanupVerified':True,'qualifications':['Independent queryable-model component replay only; no PostgreSQL rerun.','Original R1 missing source closure remains historical; R3 is separate fresh evidence.','Original external executable dependency closure remains explicitly non-hermetic.']}
(r/'correction-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
