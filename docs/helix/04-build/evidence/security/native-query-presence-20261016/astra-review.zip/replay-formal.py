import pathlib,hashlib,subprocess,json,sys
r=pathlib.Path(__file__).resolve().parent
s=r/'frozen/tools/security/prove-disclosure-carrier.py';out=r/'independent-formal';py='/private/tmp/umf-security-proof-current-20261015/bin/python'
cmd=[py,'-B',str(s),'--output',str(out)]
p=subprocess.run(cmd,capture_output=True,text=True);(r/'formal.stdout').write_text(p.stdout);(r/'formal.stderr').write_text(p.stderr)
assert p.returncode==0,p.stderr
j=json.loads((out/'formal.json').read_text());original=json.loads((r/'frozen/docs/helix/04-build/evidence/security/native-query-presence-20261016/formal/formal.json').read_text())
assert j['sourceSha256']==original['sourceSha256']==hashlib.sha256(s.read_bytes()).hexdigest()
assert len(j['checks'])==16
for x,y in zip(j['checks'],original['checks']):
 assert all(x[k]==y[k]for k in ['id','expected','actual','smt2Sha256'])
result={'command':cmd,'exitCode':p.returncode,'solver':j['solver'],'checks':16,'sat':sum(x['actual']=='sat'for x in j['checks']),'unsat':sum(x['actual']=='unsat'for x in j['checks']),'allFrozenSMTAndResultPinsMatch':True,'scope':'Independent Z3 replay of the supplied abstract conditional algebra; no implementation or native proof.'}
(r/'formal-execution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
