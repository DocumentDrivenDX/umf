import {inspectSecurityDisclosureV2 as inspect} from './reconstructed-r3/src/extensions/security/protection/disclosure';
import {createHash} from 'node:crypto';
const root=import.meta.dir, e=root+'/custody-r3/docs/helix/04-build/evidence/security/native-query-presence-20261016';
const native=await Bun.file(e+'/native.json').json();
const fixture=await Bun.file(root+'/reconstructed-r3/tests/security/protection/disclosure-fixtures.json').json();
const base=fixture.base, tests:any[]=[];
function check(id:string,b:any,expected:string){const r=inspect(b,base.policy,base.catalog,base.closure);if(r.status!==expected||r.authority!==false||r.complete!==false)throw Error(id+': '+JSON.stringify(r.diagnostics));tests.push({id,status:r.status,authority:r.authority,complete:r.complete});}
check('original-native-batch',native.originalDisclosure.nativeBatch,'validated-disclosure');
const mods:[string,(b:any)=>void][]=[
 ['wrong-original-document',b=>b.columns[0].field.documentId='foreign'],['wrong-original-revision',b=>b.domains[0].revision='foreign'],['wrong-policy-revision',b=>b.policy.revision='foreign'],['wrong-catalog-revision',b=>b.protection.revision='foreign'],
 ['original-null-missing-key',b=>delete b.rows[0][0].value],['absent-value',b=>b.rows[1][0].value=null],['withheld-value',b=>b.rows[2][0].value=null],['transformed-null-missing-key',b=>delete b.rows[3][0].value],
 ['transformed-missing-selection',b=>delete b.rows[3][0].selection],['transformed-missing-domain',b=>delete b.rows[3][0].outputDomain],['transformed-missing-transform',b=>delete b.rows[3][0].transform],['transformed-wrong-domain',b=>b.rows[3][0].outputDomain.elementId='amount'],['transformed-wrong-version',b=>b.rows[3][0].transform.version='other'],['transformed-wrong-identity',b=>b.rows[3][0].transform.id='mask'],['transformed-wrong-selection',b=>b.rows[3][0].selection.ruleIndex=1],
 ['selection-negative',b=>b.rows[3][0].selection.ruleIndex=-1],['selection-fraction',b=>b.rows[3][0].selection.disclosureIndex=.5],['selection-boolean',b=>b.rows[3][0].selection.ruleIndex=true],['selection-string',b=>b.rows[3][0].selection.ruleIndex='0'],['selection-unsafe',b=>b.rows[3][0].selection.ruleIndex=9007199254740992],['extra-cell-authority',b=>b.rows[0][0].authority=true],['original-metadata',b=>b.rows[0][0].transform={id:'mask',version:'v1'}],['unknown-disposition',b=>b.rows[1][0].disposition='missing'],['literal-wrong-original-type',b=>b.rows[0][0].value={string:'333'}],['literal-wrong-transformed-type',b=>b.rows[4][0].value={integer:'333'}],['rows-bound',b=>b.rows=Array.from({length:4097},()=>[{disposition:'withheld'}])],['literal-bound',b=>b.rows[4][0].value={string:'x'.repeat(4097)}],['ragged-row',b=>b.rows[0].push({disposition:'withheld'})],['duplicate-column',b=>b.columns.push(structuredClone(b.columns[0]))]
];
for(const[id,change]of mods){const b=structuredClone(native.originalDisclosure.nativeBatch);change(b);check(id,b,'refused');}
// Data-valid declared alternatives remain non-authoritative even when no actor decision selected them.
for(let i=0;i<5;i++){const b=structuredClone(native.originalDisclosure.nativeBatch);b.rows=[b.rows[i]];check('single-declared-outcome-'+i,b,'validated-disclosure');}
const report={status:'passed',checks:tests.length,bun:Bun.version,sourceSha256:createHash('sha256').update(await Bun.file(root+'/reconstructed-r3/src/extensions/security/protection/disclosure.ts').arrayBuffer()).digest('hex'),tests,scope:'Actual public data inspector against frozen native carrier and independent mutations. No policy decision, actual transform execution, authenticated owner or database replay.'};
await Bun.write(root+'/inspector-controls.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:'passed',checks:tests.length}));
