from pathlib import Path
import zipfile,json,hashlib,io,shutil,os
r=Path(__file__).resolve().parent;e=r/'frozen/docs/helix/04-build/evidence/security/native-query-presence-20261016';z=zipfile.ZipFile(e/'native-sources.zip');idx=json.loads(z.read('index.json'));n=json.loads((e/'native.json').read_text());repo=r/'reconstructed'
rows=[]
for p,v in idx.items():
 if 'archive' in v:
  b=z.read(v['archive'])
  if '/umf/' in p:
   rel=p.split('/umf/',1)[1];out=repo/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
  if p.endswith('.whl'):wheel=b
 else:b=zipfile.ZipFile(io.BytesIO(z.read(v['wheelArchive']))).read(v['wheelMember'])
 assert hashlib.sha256(b).hexdigest()==v['sha256']==n['sourceDigests'][p];rows.append({'path':p,'sha256':v['sha256'],'bytes':len(b)})
z2=zipfile.ZipFile(io.BytesIO(wheel))
for f in z2.namelist():
 assert not Path(f).is_absolute() and '..'not in Path(f).parts
z2.extractall(r/'wheel-extracted')
source=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
if not (repo/'node_modules').exists():(repo/'node_modules').symlink_to(source/'node_modules',target_is_directory=True)
for f in ['docs/helix/04-build/evidence/security/native-query-presence-20261016/README.md','docs/helix/04-build/implementation-plan.md','AGENTS.md','.helix.yml','docs/helix/README.md']:
 out=r/'scope-docs'/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((source/f).read_bytes())
readme=(r/'scope-docs/docs/helix/04-build/evidence/security/native-query-presence-20261016/README.md').read_text()
assert 'not the separately published' in readme and 'unverified' in readme
assert n['sourceArchiveSha256']==hashlib.sha256((e/'native-sources.zip').read_bytes()).hexdigest()
assert n['status']=='native-carrier-refusal-component-passed' and n['sourcesUnchanged']is True
assert len(n['observations'])==len({v['id']for v in n['observations']})==43
counts={'matching':0,'refused':0,'descriptive':0}
for v in n['observations']:
 if 'expected'in v:assert v['expected']==v['actual'];counts['matching']+=1
 elif v.get('refused')is True:counts['refused']+=1
 else:assert v['id'].endswith(':actual-native-presence-proposal');counts['descriptive']+=1
assert n['mounts']==[{'Type':'tmpfs','Source':'','Destination':'/var/lib/postgresql','Mode':'','RW':True,'Propagation':''}]
assert all(n['cleanup'][k]is True for k in ['attempted','ownedLabelVerified','removed','verified','absentAfterRemoval'])
assert n['engine']['number']=='180006' and n['engine']['sessionUser']==n['engine']['currentUser']=='postgres'
assert len(n['issuedQueries'])==4
for v in n['issuedQueries']:
 a=json.loads(v['artifact']);f=json.loads(v['frame']);report=v['report']
 for k in ['sourceRequestSha256','designationSha256','materializationBindingSha256']:assert f[k]==a[k]==report[k]
 assert hashlib.sha256(v['artifact'].encode()).hexdigest()==f['compiledArtifactSha256']==report['compiledArtifactSha256']
 assert hashlib.sha256(v['binding'].encode()).hexdigest()==f['materializationBindingSha256']
 assert hashlib.sha256(v['request'].encode()).hexdigest()==f['sourceRequestSha256']
 assert hashlib.sha256(v['frame'].encode()).hexdigest()==report['refinementInputSha256']
 assert report['matched']is True and report['authority']is False and report['securityReady']is False and report['nativeAdmission']=='required'
 assert f['scans'][0]['expectedRowCount']=='3' and [row['key']for row in f['scans'][0]['rows']]==['k0','k1','k2']
q=json.loads((e/'queryable-source.json').read_text());assert q==json.loads(z.read(idx[next(p for p in idx if p.endswith('umf-queryable-presence-source-final-20261016.json'))]['archive']))
for rel,h in q['sourcePins'].items():assert hashlib.sha256((repo/rel).read_bytes()).hexdigest()==h
assert n['optionalSourceRefusal']['sourceObservationSha256']==hashlib.sha256((e/'queryable-source.json').read_bytes()).hexdigest()
for kind in ['required','optional']:assert json.loads(n['optionalSourceRefusal'][kind+'Request' if kind=='optional'else'originalRequiredRequest'])==q[kind+'SourceRequest'] if kind=='required'else True
assert json.loads(n['optionalSourceRefusal']['request'])==q['optionalSourceRequest'] and n['optionalSourceRefusal']['nativeApplicationStatementsAdded']==0
(r/'archive-audit.json').write_text(json.dumps({'status':'passed','pins':rows,'observations':counts,'nativeQueries':4,'receiptAndArtifactFramePinsMatch':True,'tmpfsAndOwnedRemovalObserved':True,'queryableObservationCaptured':True,'queryableGeneratorOriginalClosureGap':'src/model/record-values.ts and separate relative imports were not captured by original generator/native receipt','qualifications':['Native receipts inspected, not independently executed against PostgreSQL.','Four descriptive presence observations are included in the 43 observation count.','External Bun/Ajv dependency runtime not historically pinned by original generator.']},indent=2)+'\n')
print(json.dumps({'inputs':len(rows),'observationTypes':counts,'issuedQueries':4}))
