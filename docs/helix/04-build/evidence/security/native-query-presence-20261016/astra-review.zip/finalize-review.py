from pathlib import Path
import hashlib,json,datetime
r=Path(__file__).resolve().parent;h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();e=r/'custody-r3/docs/helix/04-build/evidence/security/native-query-presence-20261016';n=json.loads((e/'native.json').read_text())
paths={
 'originalFrozenPacket':'/private/tmp/umf-native-presence-handoff-review-20261016.zip',
 'correctedFrozenPacket':'/private/tmp/umf-native-presence-custody-r3-review-20261016.zip',
 'nativeReceipt':e/'native.json','nativeSourceArchive':e/'native-sources.zip','queryableObservation':e/'queryable-source.json','handoff':e/'handoff.json','formalReceipt':e/'formal/formal.json','historicalAttempts':e/'earlier-attempts.zip','scopeReadme':e/'README.md','implementationPlan':r/'custody-r3/docs/helix/04-build/implementation-plan.md',
 'nativeOracle':r/'custody-r3/tools/security/pg18-current-presence-oracle.py','queryableGenerator':r/'custody-r3/tools/security/current-query-presence-source.ts','formalGenerator':r/'custody-r3/tools/security/prove-disclosure-carrier.py',
 'technicalDesign':r/'custody-r3/docs/helix/02-design/technical-designs/TD-056-security-bindings.md','testPlan':r/'custody-r3/docs/helix/03-test/test-plans/STP-056-security-bindings.md',
 'independentArchiveAudit':r/'archive-audit.json','independentCorrectionAudit':r/'correction-audit.json','independentImportClosure':r/'import-closure.json','independentFormalReplay':r/'formal-execution.json','independentIssuedCheckerControls':r/'issued-checker-controls.json','independentInspectorControls':r/'inspector-controls.json','independentCleanupControls':r/'cleanup-controls.json','independentQueryableReplay':r/'independent-queryable-r3.json','independentExternalRuntimePins':r/'independent-external-pins.json',
}
report={
 'reviewer':'Independent Astra Ultra review continuation',
 'reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'component-review-passed-after-source-custody-correction',
 'scope':'Frozen UMF optional-presence/disclosure-carrier prerequisite: source/receipt correspondence, conditional algebra, actual issued-object component controls, public data inspection, queryable successor model, evidence scope and cleanup. No native database campaign independently replayed.',
 'pins':{k:{'path':str(v),'sha256':h(v)}for k,v in paths.items()},
 'originalFinding':{
  'id':'PRESENCE-CUSTODY-001','priority':2,'status':'resolved-by-separate-fresh-R3-evidence',
  'title':'Original queryable-source execution omitted Record-validator source custody',
  'description':'The first native archive captured the disclosure inspector closure, but the queryable-source generator also executed src/model/record-values.ts and its separate dependencies. Original queryable-source sourcePins named only three JSON fixture inputs. Its validation observation therefore lacked exact original validator-execution byte pins.',
  'resolution':'R3 generator captures/rechecks its own complete relative import closure and records every source digest; native oracle independently captures the generator closure and compares its bytes to the observation pins. Fresh R3 queryable and PostgreSQL receipts replace the custody claim for this cohort. package.json, bun.lock and installed Ajv metadata are captured; Bun 1.4.2/Ajv 8.20.0 and non-hermetic external executable closure are explicitly qualified.',
  'verification':'57 native archive entries match all receipt digests; 34 generator input pins match those archived bytes; independent Bun parser finds all 28 runtime generator imports captured; independent generator execution reproduces the complete R3 JSON observation exactly. Superseded R1 five-file packet is byte-identical to the original reviewed packet. No retroactive original execution upgrade.'
 },
 'remainingFindings':[],
 'independentChecks':[
  {'kind':'archive-and-receipt-audit','result':'passed','details':'Original 50 and corrected 57 input digests, nested wheel/native/shim correspondence, exact request/binding/artifact/frame/report hashes, original and R3 receipt/handoff pointers, source snapshots and unchanged recorded query frames verified.'},
  {'kind':'formal-solver-replay','result':'passed','count':16,'sat':12,'unsat':4,'details':'All original generated SMT source hashes and outcomes match Z3 4.15.4. Algebra is conditional over abstract Null/Text/Integer; it does not constrain all UMF domains or prove concrete code.'},
  {'kind':'actual-captured-wheel-issued-object-controls','result':'passed','count':50,'details':'Four exact lowerer artifacts/reports reproduced. Captured NULL and independent hidden null/overbound/wrong-family, duplicate key, count/population, source/artifact hash and invented-result mutations refuse, including the combined WHERE FALSE/LIMIT 0 context. Required source prepares; optional source refuses availability. Wheel extracted from frozen native archive; exact native/shim pins verified before and after.'},
  {'kind':'actual-public-UMF-inspector-controls','result':'passed','count':35,'details':'Frozen native batch and each of its five declared outcomes validate with authority=false/complete=false; independent domain/revision/policy/transform/selection/shape/type/resource mutations refuse.'},
  {'kind':'modeled-cleanup-controls','result':'passed','count':12,'details':'Verified owned removal/already absent/no attempt, foreign or empty labels, inspection failure, wrong-name absence, removal failure, residual container, post-removal unknown and timeouts. These are modeled subprocess responses, not native deletion observations.'},
  {'kind':'queryable-source-generator-replay','result':'passed','count':1,'details':'Fresh isolated reconstructed R3 source produces byte-equivalent parsed JSON including every 34 source pin and the three absent/present-null/present-String Record observations. Source/runtime copies remain unchanged. Local copied external executable files are independently pinned for this replay, without upgrading historical external custody.'},
  {'kind':'runtime-import-parser-audit','result':'passed','details':'Independent Bun Transpiler reports 28 generator and 43 combined runtime inputs; all generator relative inputs captured. External node:crypto, node:path, Ajv and YAML remain explicitly outside the historical hermetic claim.'}
 ],
 'suppliedNativeEvidence':{
  'independentlyDatabaseReplayed':False,'engine':'PostgreSQL 18.6 (180006), aarch64, UTF8','principal':'session_user=current_user=postgres, excluded administrator fixture',
  'imageId':n['imageId'],'runId':n['runId'],'testedCheckoutBase':n['umfCommit'],
  'observations':43,'matchingChecks':30,'explicitRefusals':9,'descriptiveObservations':4,'issuedQueryExecutions':4,
  'queryQualification':'Four actual issued programs executed via psql/JSON transport over a declared three-row eligible fixture. Multiple contexts have no result rows; one combines WHERE FALSE with LIMIT 0. This is not a production Python-driver, authenticated complete source/caller/current-cut or guarded-release test.',
  'correctionRelation':'R3 observation, issued-query frames, SQL statements, disclosure cells and engine/mount observations match the original cohort semantically; only source-custody additions and separately identified run evidence change.',
  'cleanup':'Final R1/R2/R3 fixture explicitly mounts tmpfs at /var/lib/postgresql; final receipt observes exactly that mount and verifies exact run label, successful container removal and subsequent absence. Earlier first/R2/R3 attempts in earlier-attempts.zip used container-only cleanup; anonymous-volume cleanup is unverified. No arbitrary volume cleanup is asserted.'
 },
 'semanticAssessment':[
  'Distinct Original, Absent, Withheld and Transformed variants retain payload presence independently of JSON null; original and transformed null differ by exact disposition/provenance. SQL NULL and JSON null are observed separately. Bag key presence is a separate substrate observation, not a graph-backend codec.',
  'Original Field identity and source revision remain separate from transformed output-domain identity; selected policy indices and transform id/version are required for transformed cells. The nine-column representation preserves supplied declared outcomes. Public inspector establishes data/source correspondence only and always returns authority=false/complete=false.',
  'Queryable successor preserves all original Record memberships, changes only Token availability in the Core document and explicitly revises enclosing source identities. Its constraints correspond to the original s20 Token without equating nominal Field identities. Existing policy discloses salary, not Token; queryability implies no Token permission.',
  'Native required-only producer refuses the optional Token source before application SQL. Existing uniform-domain contexts remain unchanged. A distinct Weft-owned version/capability and explicit operator semantics remain future requirements.',
  'Formal inverse/injectivity checks establish the authored encoding algebra under its well-formedness predicate, including nonempty qualified identities and safe selection indices. Text/Integer payloads are abstract and not a theorem of concrete UTF8/SQL/JSON encoding, UMF domain validity, implementation, authentication or policy decision.',
  'Complete fixture capture precedes relational evaluation and independent result comparison, including hidden NULL refusal. Supplied rows and ordinal/private keys are not authorization or genuine source provenance.'
 ],
 'scopeClaimsReview':{
  'result':'appropriately-qualified',
  'readmeAndImplementationPlan':'Frozen R3 README/IP correctly retain original custody gap/correction history, failed attempts and cleanup distinction, candidate wheel versus published SDK distinction, conditional formal scope and no case promotion. Independent-review-pending text was accurate when frozen.',
  'requiredCases':'No promotion of pg-raw.P03/B07/B08, any graph case or complete US-056-AC6. The packet retains 45 implemented passing /158 required with 113 missing implementations; this review does not rerun the full gate.',
  'finalAcceptance':'No backend admission, authenticated owner selection, native transform execution, general presence-aware operator semantics, complete source/current-cut custody, guarded release, Truss native campaign, publication or full security acceptance.'
 },
 'limitations':[
  'Original native execution source pins are evidence of supplied executions; no independent PostgreSQL/native campaign was run for this review.',
  'External executable dependency custody of supplied observations is explicitly non-hermetic; manifest/lock/Ajv metadata pins do not prove every loaded dependency byte.',
  'The Python carrier decoder is an exercised fixed fixture component, not a public generic authenticated decoder. Its downstream UMF inspector supplies structural/domain correspondence, not actor selection authority.',
  'Independent controls and formal algebra are complementary evidence; passing bounded cases is not a proof of complete implementation or native authorization.'
 ],
 'reviewerHarnessHistory':{'retainedFailure':'inspector-first-failure.json','description':'Initial reviewer hash-report code passed ArrayBuffer directly to node:crypto after executing controls; corrected to Uint8Array and reran all 35 controls. No owner-source change.'},
 'sourceMutation':'No owner repository or frozen source packet modified; all reconstruction, controls and reports are under this review directory.'
}
(r/'review.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
files={str(p.relative_to(r)):h(p)for p in r.rglob('*')if p.is_file()and not p.is_symlink()and p.name!='review-evidence-manifest.json'and'/node_modules/'not in str(p)}
(r/'review-evidence-manifest.json').write_text(json.dumps({'reviewSha256':h(r/'review.json'),'files':files},indent=2)+'\n')
print(json.dumps({'review':str(r/'review.json'),'sha256':h(r/'review.json'),'remainingFindings':0,'independentControls':16+50+35+12+1,'manifestFiles':len(files)}))
