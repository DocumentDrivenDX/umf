"""Independent exact-helper report/custody controls; modeled native report producer."""
import ast,json,pathlib,hashlib,types,copy
root=pathlib.Path(__file__).resolve().parent;src=root/'source/packages/python/src/truss';namespace={'sha256':hashlib.sha256,'json':json}
def load(path,names):
 tree=ast.parse(path.read_text());nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name in names];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),namespace)
# The original bounded decoder imports are retained, while only its function is
# loaded, avoiding imports or operations from the host runtime.
exec(compile((src/'_owner_evidence_json.py').read_text(),str(src/'_owner_evidence_json.py'),'exec'),namespace)
load(src/'_current_query_evaluation.py',{'wire'});load(src/'_current_query_stage.py',{'_verify_current_rows'})
verify=namespace['_verify_current_rows'];checks=[];current=object();binding=b' {"binding":"original"} ';artifact=b'{"artifact":"original"}';scans=[{'scan':'s0','expectedRowCount':'1','rows':[{'key':'k1','cells':{'x':{'family':'string','value':'private-original'}}}]}];rows=[['public','private-carrier']]
sha=lambda x:hashlib.sha256(x).hexdigest()
def correct(frame):
 r={k:frame[k]for k in ['sourceRequestSha256','designationSha256','materializationBindingSha256','compiledArtifactSha256']};r.update(version='weft.current-query.refinement-result/0.1-candidate',matched=True,authority=False,securityReady=False,nativeAdmission='required',refinementInputSha256=sha(last['bytes']));return r
last={};calls=[];edit=lambda r:r;raw_edit=None
class NativeMethods:
 @staticmethod
 def check_postgresql_current_rows_candidate_json(obj,b,f):
  assert obj is current and b.encode()==binding
  last['bytes']=f.encode();frame=json.loads(f);calls.append(frame)
  assert frame['scans']==scans and frame['resultRows']==rows
  assert frame['materializationBindingSha256']==sha(binding)and frame['compiledArtifactSha256']==sha(artifact)
  r=edit(correct(frame));return raw_edit(r) if raw_edit else json.dumps(r)
native=types.SimpleNamespace(CurrentQueryPreparation=NativeMethods)
def invoke():return verify(native,current,binding,artifact,scans,rows,source_request_sha256='a'*64,designation_sha256='b'*64)
def check(label,should_pass):
 try:invoke();passed=True
 except (ValueError,TypeError,UnicodeError):passed=False
 assert passed==should_pass,label;checks.append({'id':label,'passed':True,'accepted':passed})
check('exact-report-and-original-byte-custody',True)
for key,variants in {'version':['old',None,1],'matched':[False,1,'true',None],'authority':[True,0,'false',None],'securityReady':[True,0,'false',None],'nativeAdmission':['optional',False,None],'sourceRequestSha256':['0'*64,None],'designationSha256':['0'*64,None],'materializationBindingSha256':['0'*64,None],'compiledArtifactSha256':['0'*64,None],'refinementInputSha256':['0'*64,None]}.items():
 for i,value in enumerate(variants):
  def edit(r,key=key,value=value):r[key]=value;return r
  check('wrong-report/'+key+'/'+str(i),False)
for key in list(correct(json.loads(last['bytes']))):
 def edit(r,key=key):r.pop(key);return r
 check('missing-report/'+key,False)
for key in ['future','proof','nativePermission','resultRows']:
 def edit(r,key=key):r[key]=True;return r
 check('extra-report/'+key,False)
edit=lambda r:r
for label,fn in [('duplicate-key',lambda r:json.dumps(r)[:-1]+',"matched":true}'),('malformed',lambda r:'{'),('null',lambda r:'null'),('array',lambda r:'[]'),('nonfinite',lambda r:json.dumps(r)[:-1]+',"future":NaN}'),('illformed-unicode',lambda r:json.dumps(r)[:-1]+',"future":"\\ud800"}')]:raw_edit=fn;check(label,False)
raw_edit=lambda r:json.dumps(dict(reversed(list(r.items()))),indent=2);check('report-key-order-not-authority',True)
raw_edit=None
class Refusal:
 @staticmethod
 def check_postgresql_current_rows_candidate_json(*args):raise ValueError('WFT-CURRENT-QUERY-REFINEMENT: Conditional current-query refinement refused')
native=types.SimpleNamespace(CurrentQueryPreparation=Refusal);check('native-checker-refusal-propagates',False)
result={'scope':'AST-loaded exact Truss helper and bounded decoder; modeled native checker output. No native/database admission or full pipeline execution.','sourceSha256':sha((src/'_current_query_stage.py').read_bytes()),'helperCallsWithOriginalBinding':len(calls),'controls':checks,'count':len(checks),'scriptSha256':sha(pathlib.Path(__file__).read_bytes())};(root/'report-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'controls':len(checks)}))
