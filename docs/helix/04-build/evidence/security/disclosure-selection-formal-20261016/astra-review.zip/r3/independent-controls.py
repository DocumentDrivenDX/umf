import z3,json,pathlib,hashlib
R=pathlib.Path(__file__).parent;j=json.loads((R/'original-receipt.json').read_text());fresh=json.loads((R/'fresh-receipt.json').read_text());assert [(q['id'],q['smt'],q['result']) for q in fresh['queries']]==[(q['id'],q['smt'],q['result']) for q in j['queries']]
replays=[]
for q in j['queries']:
 s=z3.Solver();s.set(timeout=20000);s.from_string(q['smt']);result=str(s.check());assert result==q['expected'];replays.append({'id':q['id'],'result':result,'smtSha256':hashlib.sha256(q['smt'].encode()).hexdigest()})
byid={q['id']:q for q in j['queries']};premises=[]
for q in j['queries']:
 if q['result']=='unsat':p=byid[q['id']+'-premises-nonvacuous'];assert p['result']=='sat';premises.append({'theorem':q['id'],'premise':p['id']})
n=z3.Int('n');q,r=z3.Ints('q r');active=z3.Function('a',z3.IntSort(),z3.BoolSort());kind=z3.Function('k',z3.IntSort(),z3.IntSort());identity=z3.Function('v',z3.IntSort(),z3.IntSort())
def inside(x):return z3.And(0<=x,x<n)
def c(x,t):return z3.And(inside(x),active(x),kind(x)==t)
w=z3.Exists(q,c(q,2));conflict=z3.Exists([q,r],z3.And(c(q,3),c(r,3),identity(q)!=identity(r)))
def first(x):return z3.Not(z3.Exists(q,z3.And(c(q,3),q<x)))
def chosen(x):return z3.And(z3.Not(w),z3.Not(conflict),c(x,3),first(x))
def last(x):return z3.And(z3.Not(w),z3.Not(conflict),c(x,3),z3.Not(z3.Exists(q,z3.And(c(q,3),q>x))))
def blind(x):return z3.And(z3.Not(w),z3.Not(conflict),inside(x),kind(x)==3,z3.Not(z3.Exists(q,z3.And(inside(q),kind(q)==3,q<x))))
def no_conflict(x):return z3.And(z3.Not(w),c(x,3),first(x))
def no_withheld(x):return z3.And(z3.Not(conflict),c(x,3),first(x))
controls=[('explicit-last-mutant',z3.And(n==2,c(0,3),c(1,3),identity(0)==identity(1),chosen(0),last(1),z3.Not(chosen(1)))),('explicit-active-blind-mutant',z3.And(n==2,z3.Not(active(0)),kind(0)==3,c(1,3),chosen(1),blind(0),z3.Not(chosen(0)))),('explicit-conflict-blind-mutant',z3.And(n==2,c(0,3),c(1,3),identity(0)!=identity(1),no_conflict(0),z3.Not(chosen(0)))),('explicit-withholding-blind-mutant',z3.And(n==2,c(0,2),c(1,3),no_withheld(1),z3.Not(chosen(1))))]
extra=[]
for name,formula in controls:
 s=z3.Solver();s.set(timeout=20000);s.add(n>=0,formula);assert s.check()==z3.sat;extra.append({'id':name,'expected':'sat','result':'sat','smt':s.sexpr(),'model':str(s.model())})
(R/'independent-controls.json').write_text(json.dumps({'status':'passed','solverVersion':z3.get_version_string(),'retainedFormulaReplays':replays,'allFreshFormulasByteIdentical':True,'nonvacuityPairs':premises,'explicitMutantWitnesses':extra},indent=2)+'\n');print('33 retained formulas replay;14 premise pairs checked;4 explicit mutant countermodels SAT')
