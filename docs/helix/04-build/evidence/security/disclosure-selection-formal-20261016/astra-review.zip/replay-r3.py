import pathlib,json,subprocess,hashlib,shutil
R=pathlib.Path(__file__).parent;C=R/'r3';C.mkdir(exist_ok=True);root=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf');p=pathlib.Path('/private/tmp/umf-disclosure-selection-formal-r3-20261016.json');receipt=json.loads(p.read_text());(C/'original-receipt.json').write_bytes(p.read_bytes());S=C/'frozen';script='tools/security/prove-disclosure-selection.py';python='/private/tmp/umf-security-proof-current-20261015/bin/python';h=lambda b:hashlib.sha256(b).hexdigest()
for n,pin in receipt['sourceDigests'].items():
 data=(root/n).read_bytes();assert h(data)==pin
 p=S/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
executions=[]
def run(name,source,cwd,out):
 cmd=[python,str(source),str(out)];p=subprocess.run(cmd,cwd=cwd,capture_output=True);(C/(name+'.log')).write_bytes(p.stdout+p.stderr);row={'id':name,'command':cmd,'cwd':str(cwd),'exitCode':p.returncode,'receiptWritten':out.exists()};executions.append(row);return p
p=run('exact-replay',S/script,S,C/'fresh-receipt.json');assert p.returncode==0
text=(S/script).read_text();mutations={
 'withheld-active-guard-removed':text.replace('withheld=z3.Exists(i,contributes(i,2))','withheld=z3.Exists(i,z3.And(inside(i),kind(i)==2))'),
 'both-withheld-active-guards-removed':text.replace('withheld=z3.Exists(i,contributes(i,2))','withheld=z3.Exists(i,z3.And(inside(i),kind(i)==2))').replace('changed_withheld=z3.Exists(i,changed_contributes(i,2))','changed_withheld=z3.Exists(i,z3.And(inside(i),changed_kind(i)==2))'),
 'choose-last':text.replace('contributes(i,3),i<x','contributes(i,3),i>x'),
}
for name,changed in mutations.items():
 dest=C/name;shutil.copytree(S,dest);(dest/script).write_text(changed);p=run(name,dest/script,dest,C/(name+'-receipt.json'));assert p.returncode==1 and not (C/(name+'-receipt.json')).exists()
# Actual copied tool outside the required relative path cannot pin a different file.
alt=C/'alternate-tool.py';alt.write_text(text);p=run('alternate-path-guard',alt,S,C/'alternate-path-receipt.json');assert p.returncode==1 and b'Execute the exact repository proof source' in p.stderr and not (C/'alternate-path-receipt.json').exists()
(C/'executions.json').write_text(json.dumps({'status':'passed','executions':executions},indent=2)+'\n');print(json.dumps(executions,indent=2))
