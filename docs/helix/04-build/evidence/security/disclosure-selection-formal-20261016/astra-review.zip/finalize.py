import pathlib,json,hashlib,subprocess
R=pathlib.Path(__file__).parent;C=R/'r3';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();initial=json.loads((R/'review-initial.json').read_text());rec=json.loads((C/'original-receipt.json').read_text());assert h(R/'review-initial.json')=='b2bd7decae7fcf8680297e049d20da108cafca577be366a5001db101eceaee79';assert h(R/'manifest-initial.json')=='de5be1ad937c667a46fff0388099a6dcf498bf18e61b14f22809ea3f2c39abb9'
report={
 'version':'independent-formal-review/1','reviewer':'Astra Ultra independent review','date':'2026-10-16','status':'complete','cohort':'R3 final; original findings retained separately','verdict':'No remaining actionable finding in the corrected conditional occurrence algebra. Both initial evidence findings are resolved. This is not a TypeScript refinement proof or native acceptance.','findings':[],
 'sourcePins':rec['sourceDigests'],'finalReceiptSha256':h(C/'original-receipt.json'),'frozenSources':'r3/frozen','producerCommit':'4d04c0f4593ea1764c165acc96eff1da5439e40e','runtime':{'python':'/private/tmp/umf-security-proof-current-20261015/bin/python','solverVersion':rec['solverVersion'],'externalExecutableClosureHermetic':False},
 'retainedInitialReview':{'path':'review-initial.json','sha256':h(R/'review-initial.json'),'manifestSha256':h(R/'manifest-initial.json'),'sourceSha256':initial['sourceDigests']['tools/security/prove-disclosure-selection.py'],'queries':17,'unsat':12,'sat':5,'qualification':'The original 17 checks pass even after removing active filtering from withholding; original mutated receipt and explicit inactive-withheld suppression countermodel are retained. No later correction is credited to that cohort.'},
 'resolvedFindings':[
  {'id':'DISCLOSURE-ALGEBRA-001','originalPriority':2,'resolution':'The tautological inactive-withheld check is replaced by exact alternate-population contributor equivalence and both directions of chosen-occurrence preservation under arbitrary kind/identity changes at one inactive position. The original active-blind suppression mutant now fails. Independently removing the guard in both original and alternate withholding predicates also fails, so the correction is not only an asymmetry check. Every one of the 14 UNSAT properties now has separately SAT-checked premises.','evidence':['r3/independent-controls.json','r3/withheld-active-guard-removed.log','r3/both-withheld-active-guards-removed.log']},
  {'id':'DISCLOSURE-ALGEBRA-002','originalPriority':3,'resolution':'The duplicate case is renamed duplicate-identity-positions-are-compatible; receipt and README explicitly say no retained-output collection preservation is proved. This accurately describes the SAT witness.','evidence':['r3/original-receipt.json','r3/supplied-packet/README.md']}
 ],
 'independentExecution':{
  'exactSourceReexecution':{'exitCode':0,'queries':33,'unsat':14,'sat':19,'receipt':'r3/fresh-receipt.json','log':'r3/exact-replay.log'},
  'retainedSmtReplay':{'queries':33,'allExpectedResultsMatch':True,'allFreshFormulaBytesMatchOriginalReceipt':True,'nonvacuityPairs':14,'receipt':'r3/independent-controls.json'},
  'explicitIndependentMutantCountermodels':{'count':4,'allSat':True,'description':'Separately defined last-element, activity-blind candidate, conflict-blind and withholding-blind chooser predicates are asserted to produce the wrong selected outcome on the corresponding two-position witnesses. This makes the supplied SAT witness interpretation explicit.','receipt':'r3/independent-controls.json'},
  'actualSourceMutationReplays':[
   {'mutation':'Remove active guard only from original withholding predicate','exitCode':1,'receiptWritten':False,'failedCheck':'inactive-update-cannot-create-selection: sat'},
   {'mutation':'Remove active guards from both original and alternate withholding predicates','exitCode':1,'receiptWritten':False,'failedCheck':'inactive-update-preserves-selected-occurrence: sat'},
   {'mutation':'Choose last active transform by reversing the order comparison','exitCode':1,'receiptWritten':False,'failedCheck':'chosen-source-is-first-active-transform: sat'}
  ],
  'custodyNegativeControls':[
   {'control':'Execute copied proof outside the pinned repository-relative path','exitCode':1,'receiptWritten':False,'log':'r3/alternate-path-guard.log'},
   {'control':'Attempt to write to existing receipt','exitCode':1,'existingReceiptBytesUnchanged':True,'log':'r3/existing-output-refusal.log'}
  ],
  'mutationCustody':'All mutations run in separate reviewer-owned reconstructed roots with the exact required relative tool path and two unchanged pinned source dependencies. The final repository source and retained initial sources are untouched.'
 },
 'mathematicalAssessment':[
  'The population [0,n) is finite for each nonnegative integer n, with arbitrary size and no fixed bound. This is an unbounded-size family of finite populations, not an infinite-population model.',
  'The chooser is a relational definition: inside population, active transformed occurrence, no active withholding, no conflicting active transform identities, and no earlier active transform. Membership/firstness and several safety results are definitional consequences; uniqueness additionally uses integer total order. These are correct conditional algebraic properties, not evidence that an implementation computes that relation.',
  'The alternate population uses point updates If(x==j,replacement,original) for kind and identity while eligibility and population size remain fixed and j is inactive. This represents an arbitrary metadata change at exactly one inactive position. Contributor-set equivalence quantifies positions and kinds. The two selected-occurrence implications together establish equivalence, without assuming both chooser outcomes in the premises.',
  'All 14 theorem premises are independently satisfiable. The corrected invariance controls distinguish the active-filter omission demonstrated in the initial review. The five non-premise SAT queries provide consistency and small countermodel witnesses; they are not universal preservation proofs.',
  'The retained SMT formulas were replayed with the same pinned Z3 4.15.4 runtime, not a second solver or an independently checked proof certificate. This review combines source inspection, exact SMT replay, explicit countermodels and mutation sensitivity.'
 ],
 'relationshipToProducerAndRequirements':[
  'The canonical runtime hash 03b9bd3298443bfa4ac2306950e2e4b030c42e3708db0d7871724b248c74aab5 is unchanged from the separately reviewed empirical Bun/Chromium producer. The new tool hashes that source for attribution but never parses, translates or proves refinement of its TypeScript.',
  'Faithful complete flattening of (ruleIndex, disclosureIndex) into distinct ordered positions, exact transform identity equality, correct scoped/true-permit eligibility, base row permission and protected-field obligation admission are explicit premises. The analysis does not establish those premises for a native cut.',
  'US-056-AC6 is supported only by a conditional selection sub-obligation. There is no faithful shared-bag native disclosure admission, rendered output/domain validation, original-fallback construction, payload privacy proof or retained-source collection theorem.',
  'US-056-AC10 is supported by precise source/solver pins, retained formulas, satisfiable premises, initial failures, correction cohorts and qualified replay evidence. Neither complete acceptance criterion is closed.'
 ],
 'supplementalCustody':{
  'receipt':'r3/supplemental-audit.json','checks':586,'allPassed':True,'exactFinalSourceInputs':3,'initialArchiveUnchanged':True,'r2ToolMatchesIntermediateReceipt':True,'r2AndR3FormulaBytesIdentical':True,
  'priorAcceptanceSha256':'f957114604520352d05adbb804ec5d873ce18cd70d666636206cd02753aba4d7','uniqueExistingGateSourceFingerprints':570,'fingerprintOccurrences':2178,'allCurrent':True,'planAndGateToolingUnchanged':True,'implementedAccepted':45,'requiredCases':158,'missingImplementations':113,
  'qualification':'The existing gate receipt remains byte-identical. This is current endpoint source/fingerprint comparison, not a new native replay or held-file/ABA provenance theorem. No case or criterion is promoted.'
 },
 'remainingScopeLimits':[
  'No least-element construction or termination theorem, TypeScript refinement, full disclosure representation theorem, transform-value proof, compiler/.4 composition, wire admission, native caller/source/current-cut authentication, operator permission or guarded-release proof.',
  'No product code was changed or native database campaign run by this reviewer. Initial and corrected cohorts remain separately pinned. External Python/Z3 closure is non-hermetic.'
 ],
 'evidenceManifest':'evidence-manifest.json'
}
(R/'review.json').write_text(json.dumps(report,indent=2)+'\n')
# Record actual runtime package and binary files, without asserting hermeticity.
code="import z3,pathlib,sys,json;print(json.dumps({'python':str(pathlib.Path(sys.executable).resolve()),'package':str(pathlib.Path(z3.__file__).parent),'pythonVersion':sys.version,'solverVersion':z3.get_version_string()}))"
runtime=json.loads(subprocess.check_output(['/private/tmp/umf-security-proof-current-20261015/bin/python','-c',code]));ext={runtime['python']:h(pathlib.Path(runtime['python']))};ext.update({str(p):h(p) for p in pathlib.Path(runtime['package']).rglob('*') if p.is_file()});(R/'runtime.json').write_text(json.dumps({**runtime,'filesSha256':ext,'hermetic':False},indent=2)+'\n')
artifacts={str(p.relative_to(R)):h(p) for p in R.rglob('*') if p.is_file() and p.name!='evidence-manifest.json'};(R/'evidence-manifest.json').write_text(json.dumps({'reviewSha256':h(R/'review.json'),'filesSha256':artifacts,'externalClosureHermetic':False},indent=2)+'\n');print(json.dumps({'reviewSha256':h(R/'review.json'),'manifestSha256':h(R/'evidence-manifest.json'),'finalToolSha256':rec['sourceDigests']['tools/security/prove-disclosure-selection.py'],'finalReceiptSha256':h(C/'original-receipt.json'),'artifacts':len(artifacts)},indent=2))
