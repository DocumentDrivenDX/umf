import z3,json,pathlib,hashlib
R=pathlib.Path(__file__).parent;receipt=json.loads((R/'original-receipt.json').read_text());queries=[]
for q in receipt['queries']:
 s=z3.Solver();s.set(timeout=20000);s.from_string(q['smt']);actual=str(s.check());assert actual==q['expected'];queries.append({'id':q['id'],'smtSha256':hashlib.sha256(q['smt'].encode()).hexdigest(),'expected':q['expected'],'actual':actual})
fresh=json.loads((R/'fresh-original-receipt.json').read_text());assert [(q['id'],q['smt'],q['result']) for q in fresh['queries']]==[(q['id'],q['smt'],q['result']) for q in receipt['queries']]
n=z3.Int('n');x,y=z3.Ints('x y');active=z3.Function('active',z3.IntSort(),z3.BoolSort());kind=z3.Function('kind',z3.IntSort(),z3.IntSort());identity=z3.Function('identity',z3.IntSort(),z3.IntSort())
def inside(v):return z3.And(0<=v,v<n)
def c(v,t):return z3.And(inside(v),active(v),kind(v)==t)
w=z3.Exists(x,c(x,2));badw=z3.Exists(x,z3.And(inside(x),kind(x)==2));conflict=z3.Exists([x,y],z3.And(c(x,3),c(y,3),identity(x)!=identity(y)))
def chosen(v,withheld):return z3.And(z3.Not(withheld),z3.Not(conflict),c(v,3),z3.Not(z3.Exists(x,z3.And(c(x,3),x<v))))
form=z3.And(n==2,z3.Not(active(0)),kind(0)==2,c(1,3),chosen(1,w),z3.Not(chosen(1,badw)))
s=z3.Solver();s.add(form);assert s.check()==z3.sat
counter={'id':'inactive-withheld-mutant-suppresses-valid-transform','result':'sat','smt':s.sexpr(),'model':str(s.model()),'interpretation':'Position 0 is an inactive withheld directive; position 1 is the sole active transform. Correct chosen(1) holds, while the active-blind withholding mutant refuses it.'}
(R/'independent-controls.json').write_text(json.dumps({'status':'passed','solverVersion':z3.get_version_string(),'originalFormulaReplays':queries,'freshFormulaBytesIdentical':True,'counterexample':counter},indent=2)+'\n');print('17 exact formulas replayed; explicit suppression countermodel SAT')
