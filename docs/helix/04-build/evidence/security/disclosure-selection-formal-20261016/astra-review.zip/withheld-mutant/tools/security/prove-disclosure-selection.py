"""Conditional occurrence-selection algebra. Not a source-code refinement proof."""
import argparse, hashlib, json
from pathlib import Path
import z3
p=argparse.ArgumentParser();p.add_argument('output');args=p.parse_args()
out=Path(args.output)
if out.exists(): raise RuntimeError('Fresh receipt path required')
root=Path.cwd()
paths=['tools/security/prove-disclosure-selection.py','src/extensions/security/catalog-runtime-candidate.ts','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md']
sources={s:hashlib.sha256((root/s).read_bytes()).hexdigest() for s in paths}
# Original ordered disclosure positions are flattened to distinct natural-number
# ranks. Faithfulness of that flattening, identity equality and rule eligibility
# to real sources is a premise. This proof does not parse/translate TypeScript.
i,j,k=z3.Ints('i j k'); n=z3.Int('population_size'); selected=z3.Int('selected')
active=z3.Function('active',z3.IntSort(),z3.BoolSort())
kind=z3.Function('kind',z3.IntSort(),z3.IntSort())
identity=z3.Function('identity',z3.IntSort(),z3.IntSort())
def inside(x):return z3.And(x>=0,x<n)
def contributes(x,t):return z3.And(inside(x),active(x),kind(x)==t)
# kind original=1, withheld=2, transformed=3. Non-contributors may have any kind.
withheld=z3.Exists(i,z3.And(inside(i),kind(i)==2))
conflict=z3.Exists([i,j],z3.And(contributes(i,3),contributes(j,3),identity(i)!=identity(j)))
transformed=z3.Exists(i,contributes(i,3))
# Base row permit and no missing protected obligation are assumed. The
# selection predicate is deliberately relational: total construction of the
# least element by the implementation is not proved here.
render_transform=z3.And(z3.Not(withheld),z3.Not(conflict),transformed)
def chosen(x):return z3.And(render_transform,contributes(x,3),z3.Not(z3.Exists(i,z3.And(contributes(i,3),i<x))))
base=[n>=0];queries=[]
def check(name,formula,expected):
 s=z3.Solver();s.set(timeout=20000);s.add(*base,formula);smt=s.sexpr();actual=str(s.check())
 if actual!=expected:raise RuntimeError(name+': '+actual)
 replay=z3.Solver();replay.set(timeout=20000);replay.from_string(smt)
 if str(replay.check())!=expected:raise RuntimeError('Replay differs: '+name)
 queries.append({'id':name,'expected':expected,'result':actual,'smt':smt,'model':str(s.model()) if actual=='sat' else None})
check('chosen-source-is-active-transform',z3.And(chosen(selected),z3.Not(contributes(selected,3))),'unsat')
check('chosen-source-is-in-original-population',z3.And(chosen(selected),z3.Not(inside(selected))),'unsat')
check('chosen-source-is-first-active-transform',z3.And(chosen(selected),contributes(j,3),j<selected),'unsat')
check('selected-occurrence-unique',z3.And(chosen(j),chosen(k),j!=k),'unsat')
check('every-active-transform-has-selected-identity',z3.And(chosen(selected),contributes(j,3),identity(j)!=identity(selected)),'unsat')
check('inactive-withheld-cannot-suppress-selection',z3.And(chosen(selected),inside(j),z3.Not(active(j)),kind(j)==2,withheld),'unsat')
check('active-withheld-prevents-selection',z3.And(chosen(selected),contributes(j,2)),'unsat')
check('distinct-active-identities-prevent-selection',z3.And(chosen(selected),contributes(j,3),contributes(k,3),identity(j)!=identity(k)),'unsat')
check('original-source-cannot-be-selected-transform',z3.And(chosen(selected),kind(selected)==1),'unsat')
check('empty-population-has-no-selection',z3.And(n==0,chosen(selected)),'unsat')
check('source-contributors-exclude-inactive-positions',z3.And(contributes(j,3),z3.Not(active(j))),'unsat')
check('source-contributors-preserve-duplicate-identity-positions',z3.And(chosen(j),contributes(k,3),j!=k,identity(j)==identity(k)),'sat')
# Explicit small countermodels show why weakened source selection is unsafe.
check('choose-last-mutant-changes-source-position',z3.And(n==2,contributes(0,3),contributes(1,3),identity(0)==identity(1),chosen(0),z3.Not(chosen(1))),'sat')
check('ignore-active-mutant-chooses-inactive-earlier-position',z3.And(n==2,z3.Not(active(0)),kind(0)==3,contributes(1,3),chosen(1)),'sat')
check('drop-identity-conflict-mutant-would-select',z3.And(n==2,contributes(0,3),contributes(1,3),identity(0)!=identity(1),z3.Not(withheld),z3.Not(chosen(0))),'sat')
check('drop-withheld-dominance-mutant-would-select',z3.And(n==2,contributes(0,2),contributes(1,3),z3.Not(conflict),z3.Not(chosen(1))),'sat')
check('out-of-range-metadata-cannot-be-selected',z3.And(chosen(selected),selected>=n),'unsat')
for name,h in sources.items():
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=h:raise RuntimeError('Source changed: '+name)
receipt={'version':'umf.security.disclosure-selection-algebra/0.1-candidate','status':'conditional-proof-passed','authority':False,'complete':False,'solverVersion':z3.get_version_string(),'sourceDigests':sources,'covers':['US-056-AC6','US-056-AC10'],'queries':queries,'scope':'Conditional unbounded ordered occurrence algebra for one field after base policy permit and protected-obligation admission. Faithful complete source flattening, exact transform identity and active rule contributions are premises. Establishes uniqueness, earliest eligible source, active/scope population membership, consensus, withholding/conflict refusal and preservation of duplicate contributors. SAT controls expose later/inactive/wrong-identity/withholding mutants. Does not prove least-element construction/termination, TypeScript refinement, compiler or native behavior, authenticated source/current cut, transform values, wire admission, operator permission or guarded release.'}
out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'queries':len(queries),'unsat':sum(q['result']=='unsat' for q in queries),'sat':sum(q['result']=='sat' for q in queries)}))
