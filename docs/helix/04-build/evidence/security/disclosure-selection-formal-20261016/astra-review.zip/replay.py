import json,pathlib,hashlib,subprocess,shutil
R=pathlib.Path('/private/tmp/umf-disclosure-selection-formal-astra-20261016');root=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf');rpath=pathlib.Path('/private/tmp/umf-disclosure-selection-formal-20261016.json');receipt=json.loads(rpath.read_text());(R/'original-receipt.json').write_bytes(rpath.read_bytes());S=R/'frozen';M=R/'withheld-mutant';h=lambda b:hashlib.sha256(b).hexdigest()
for n,p in receipt['sourceDigests'].items():
 b=(root/n).read_bytes();assert h(b)==p,n
 for d in [S,M]:q=d/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
python='/private/tmp/umf-security-proof-current-20261015/bin/python';script='tools/security/prove-disclosure-selection.py'
r=subprocess.run([python,script,str(R/'fresh-original-receipt.json')],cwd=S,capture_output=True);(R/'original-replay.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
p=M/script;text=p.read_text();assert text.count('withheld=z3.Exists(i,contributes(i,2))')==1;p.write_text(text.replace('withheld=z3.Exists(i,contributes(i,2))','withheld=z3.Exists(i,z3.And(inside(i),kind(i)==2))'))
r2=subprocess.run([python,script,str(R/'withheld-mutant-receipt.json')],cwd=M,capture_output=True);(R/'withheld-mutant.log').write_bytes(r2.stdout+r2.stderr)
(R/'execution.json').write_text(json.dumps({'originalExit':r.returncode,'mutantExit':r2.returncode,'python':python,'mutation':'Remove active(i) only from withholding suppression predicate. Original expected results and all 17 queries unchanged.'},indent=2)+'\n');print(r.stdout.decode(),r2.stdout.decode());print('mutant exit',r2.returncode)
