import ast,json,hashlib,subprocess
from fractions import Fraction
from pathlib import Path
ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');OUT=Path(__file__).parent
source=ROOT/'tests/security/native/pg18-projection-expressions.py';tree=ast.parse(source.read_text())
loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.iter,ast.Call) and isinstance(n.iter.func,ast.Name) and n.iter.func.id=='enumerate' and isinstance(n.iter.args[0],ast.Name) and n.iter.args[0].id=='observed')
code=compile(ast.Module(body=[loop],type_ignores=[]),'current-observation-loop','exec')
receipt=json.loads(Path('/private/tmp/pg18-expressions-receipt.json').read_text());vs=receipt['vectors'];valid=[json.dumps([i,v['expected']]) for i,v in enumerate(vs)]
rows=[]
def observation(name,lines,accept):
 scope={'observed':lines,'vectors':vs,'observations':[],'json':json,'Fraction':Fraction}
 try:exec(code,scope);ok=True;error=None
 except Exception as e:ok=False;error=type(e).__name__+': '+str(e)[:120]
 rows.append({'id':name,'pass':ok==accept,'accepted':ok,'error':error})
observation('valid-all-vectors',valid,True)
observation('duplicate-first-row',[valid[0]]*len(valid),False)
for name,bad in [('boolean-index',[False,vs[0]['expected']]),('negative-index',[-1,vs[0]['expected']]),('string-index',['0',vs[0]['expected']]),('fractional-index',[0.0,vs[0]['expected']]),('extra-slot',[0,vs[0]['expected'],1]),('missing-slot',[0]),('object',{'0':0,'1':vs[0]['expected']}),('number-value',[0,42]),('bool-value',[0,True]),('object-value',[0,{}]),('changed-value',[0,'WRONG'])]:observation(name,[json.dumps(bad)]+valid[1:],False)
body=next(n for n in tree.body if isinstance(n,ast.Try)).finalbody
cleanup=compile(ast.Module(body=body,type_ignores=[]),'current-cleanup','exec')
req=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='require')
for mode in ['valid','foreign-label','shared-volume','container-remains','volume-remains']+[f'failure-{i}' for i in range(1,7)]:
 calls=[]
 def command(args,**kw):
  calls.append(args);n=len(calls)
  if mode==f'failure-{n}':return subprocess.CompletedProcess(args,1,'','daemon unavailable')
  if n==1:out='abcdef owned\n'
  elif n==2:out=json.dumps([{'Id':'abcdef123456','Config':{'Labels':{'umf.security.expression':'wrong' if mode=='foreign-label' else 'nonce'}},'Mounts':[{'Type':'volume','Name':'owned-volume'}]}])
  elif n==3:out='abcdef\n'+('foreign\n' if mode=='shared-volume' else '')
  elif n==4:out='abcdef\n'
  elif n==5:out='owned\n' if mode=='container-remains' else ''
  elif n==6:out='owned-volume\n' if mode=='volume-remains' else ''
  else:raise AssertionError('unexpected command')
  return subprocess.CompletedProcess(args,0,out,'')
 env={'created':True,'container':'abcdef','name':'owned','run':'nonce','volumes':['owned-volume'],'command':command,'json':json}
 exec(compile(ast.Module(body=[req],type_ignores=[]),'require','exec'),env)
 try:exec(cleanup,env);ok=True;error=None
 except Exception as e:ok=False;error=type(e).__name__+': '+str(e)
 rows.append({'id':'cleanup-'+mode,'pass':ok==(mode=='valid'),'accepted':ok,'error':error,'mockCommands':len(calls)})
result={'scope':'Exact source-extracted Python observation and cleanup logic, mocked process results; no Docker/native execution','sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'count':len(rows),'passed':sum(r['pass'] for r in rows),'rows':rows}
(OUT/'receipt-fault-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'}));assert all(r['pass'] for r in rows)
