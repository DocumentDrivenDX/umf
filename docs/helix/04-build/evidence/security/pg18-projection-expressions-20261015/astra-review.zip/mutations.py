from pathlib import Path
import subprocess,json,hashlib
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');D=Path(__file__).parent;src=(R/'tools/security/protection-pg18-expressions.ts').read_text(); ctl=(D/'controls.ts').read_text();out=[]
mutations=[('regex-guard',"if(pattern!=='[0-9]+'&&(!pattern||/[.\\\\^$*+?()[\\]{}|]/.test(pattern)))",'if(false)'),('hash-equality',"p.retainedEquality!==true||",''),('count-cap','value>4096','value>8192'),('concat-qualification','OPERATOR(pg_catalog.||)','||')]
for name,old,new in mutations:
 count=src.count(old)
 assert count>=1,(name,'selector not found')
 work=D/'mutations'/name;work.mkdir(parents=True,exist_ok=True)
 mutated=src.replace(old,new)
 mutated=mutated.replace("'../../src/model/json'",repr(str(R/'src/model/json')))
 file=work/'compiler.ts';file.write_text(mutated)
 run=work/'controls.ts';run.write_text(ctl.replace(str(R/'tools/security/protection-pg18-expressions'),str(file)))
 proc=subprocess.run(['/opt/homebrew/bin/bun',str(run),str(work/'results.json')],text=True,capture_output=True,timeout=15)
 (work/'run.log').write_text(proc.stdout+proc.stderr)
 result=json.loads((work/'results.json').read_text());failed=[r['id'] for r in result['rows'] if not r['pass']]
 assert proc.returncode==1 and failed,(name,proc.returncode,proc.stderr)
 out.append({'name':name,'sourceSha256':hashlib.sha256(mutated.encode()).hexdigest(),'replacementCount':count,'old':old,'new':new,'failedRows':failed,'exit':proc.returncode})
(D/'mutations.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
