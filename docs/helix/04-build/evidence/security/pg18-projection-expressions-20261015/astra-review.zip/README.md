Read-only P02 design review at 7a74b77a284940e08756384f3a7c1f30e40effd7.

The expression compiler is a useful prerequisite. The unchanged P02 assertion remains unqualified until the source-to-view-to-native-result-to-transport chain and no-base-read evidence execute together. See design-review.json for exact source pins and requirements. No native run is claimed.
