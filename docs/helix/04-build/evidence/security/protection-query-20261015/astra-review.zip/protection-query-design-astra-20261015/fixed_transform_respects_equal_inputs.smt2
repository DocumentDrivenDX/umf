; benchmark generated from python API
(set-info :status unknown)
(declare-fun canonical_y () Int)
(declare-fun canonical_x () Int)
(declare-fun fixed_transform (Int) Int)
(assert
 (= canonical_x canonical_y))
(assert
 (let ((?x9 (fixed_transform canonical_y)))
(let ((?x8 (fixed_transform canonical_x)))
(and (distinct ?x8 ?x9) true))))
(check-sat)
