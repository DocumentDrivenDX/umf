; benchmark generated from python API
(set-info :status unknown)
(declare-fun canonical_y () Int)
(declare-fun canonical_x () Int)
(declare-fun other_transform_scope (Int) Int)
(declare-fun fixed_transform (Int) Int)
(assert
 (= canonical_x canonical_y))
(assert
 (let ((?x42 (other_transform_scope canonical_y)))
(let ((?x41 (fixed_transform canonical_x)))
(and (distinct ?x41 ?x42) true))))
(check-sat)
