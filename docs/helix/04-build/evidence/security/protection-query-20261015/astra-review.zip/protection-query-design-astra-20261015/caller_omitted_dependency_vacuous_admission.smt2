; benchmark generated from python API
(set-info :status unknown)
(declare-fun owner_needs_property () Bool)
(declare-fun caller_claims_need () Bool)
(declare-fun retained_property () Bool)
(assert
 owner_needs_property)
(assert
 (not caller_claims_need))
(assert
 (not retained_property))
(assert
 (=> caller_claims_need retained_property))
(check-sat)
