; benchmark generated from python API
(set-info :status unknown)
(declare-fun canonical_y () Int)
(declare-fun canonical_x () Int)
(declare-fun fixed_transform (Int) Int)
(assert
 (and (distinct canonical_x canonical_y) true))
(assert
 (= (fixed_transform canonical_x) (fixed_transform canonical_y)))
(check-sat)
