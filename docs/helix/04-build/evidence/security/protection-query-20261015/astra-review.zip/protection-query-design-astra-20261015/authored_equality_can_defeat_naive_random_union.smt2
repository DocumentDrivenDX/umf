; benchmark generated from python API
(set-info :status unknown)
(declare-fun random_token () Bool)
(declare-fun authored_equality () Bool)
(declare-fun implied_equality () Bool)
(declare-fun disclosed () Bool)
(declare-fun join () Bool)
(declare-fun group () Bool)
(assert
 random_token)
(assert
 authored_equality)
(assert
 (not implied_equality))
(assert
 disclosed)
(assert
 join)
(assert
 (not group))
(assert
 (let (($x21 (or join group)))
(let (($x16 (or authored_equality implied_equality)))
(and disclosed $x16 $x21))))
(check-sat)
