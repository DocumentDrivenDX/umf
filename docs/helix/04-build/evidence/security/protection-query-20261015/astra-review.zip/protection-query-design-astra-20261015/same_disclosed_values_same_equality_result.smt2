; benchmark generated from python API
(set-info :status unknown)
(declare-fun after_left () Int)
(declare-fun before_left () Int)
(declare-fun after_right () Int)
(declare-fun before_right () Int)
(assert
 (= before_left after_left))
(assert
 (= before_right after_right))
(assert
 (let (($x7 (= after_left after_right)))
(let (($x16 (= before_left before_right)))
(and (distinct $x16 $x7) true))))
(check-sat)
