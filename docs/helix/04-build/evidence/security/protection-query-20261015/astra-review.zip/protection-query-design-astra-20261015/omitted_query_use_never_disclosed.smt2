; benchmark generated from python API
(set-info :status unknown)
(declare-fun disclosed () Bool)
(declare-fun group () Bool)
(declare-fun join () Bool)
(declare-fun random_token () Bool)
(declare-fun implied_equality () Bool)
(declare-fun authored_equality () Bool)
(assert
 (not disclosed))
(assert
 (let (($x19 (not (and random_token (or join group)))))
(let (($x21 (or join group)))
(let (($x16 (or authored_equality implied_equality)))
(let (($x10 (and disclosed $x16 $x21)))
(and $x10 $x19))))))
(check-sat)
