; benchmark generated from python API
(set-info :status unknown)
(declare-fun randomized_transform (Int Int) Int)
(declare-fun coin1 () Int)
(declare-fun canonical_x () Int)
(assert
 (let ((?x42 (randomized_transform canonical_x coin1)))
(= ?x42 ?x42)))
(check-sat)
