; benchmark generated from python API
(set-info :status unknown)
(declare-fun coin2 () Int)
(declare-fun coin1 () Int)
(declare-fun randomized_transform (Int Int) Int)
(declare-fun canonical_x () Int)
(assert
 (and (distinct coin1 coin2) true))
(assert
 (let ((?x24 (randomized_transform canonical_x coin2)))
(let ((?x43 (randomized_transform canonical_x coin1)))
(and (distinct ?x43 ?x24) true))))
(check-sat)
