; benchmark generated from python API
(set-info :status unknown)
(declare-fun random_token () Bool)
(declare-fun authored_equality () Bool)
(declare-fun implied_equality () Bool)
(declare-fun disclosed () Bool)
(declare-fun join () Bool)
(declare-fun group () Bool)
(assert
 (not random_token))
(assert
 (not authored_equality))
(assert
 implied_equality)
(assert
 disclosed)
(assert
 join)
(assert
 (not group))
(assert
 (let (($x19 (not (and random_token (or join group)))))
(let (($x21 (or join group)))
(let (($x16 (or authored_equality implied_equality)))
(let (($x10 (and disclosed $x16 $x21)))
(and $x10 $x19))))))
(check-sat)
