# B-SFP-003 semantic design review

Reviewed clean UMF main d6fdb743e7e3d9b5caaa156bb47ee7d7fa87b2f6, read only. This is design/countermodel evidence, not approval of an implementation that does not yet exist.

## Concrete ambiguities requiring clarification

1. CONTRACT-062's “equality classes survive” must not mean reflection or injectivity. Within one fixed transform, typed parameter, key/configuration and canonical-domain scope, determinism gives x =D y ⇒ T(x) =E T(y); the converse is false for constant masks, buckets and collisions. Report this conservative stable disclosed partition/linkability property without claiming recovery of original equality. It must respect original typed equality, not merely equal lexical carriers.
2. The authored-properties union permits a random tokenizer to author equality and pass a naive join/group check. S17 explicitly requires refusal. Add the hard random-token disclosed join/group exclusion even when equality is authored, or reject the inconsistent declaration before comparison. This is a conservative admission/stability rule: actual random output values still possess ordinary output-domain equality.
3. Existing S08 admits a constant disclosed mask for all five operator kinds. Thus disclosed operations apply to the disclosed representation and its output domain; they do not promise an equivalent predicate/join/order/aggregate over original values. A compiler rewrite to canonical values needs separately qualified owner laws/authorization and existing profile lineage. Never infer those from determinism or a property label.

## S16 conditional semantic qualification

S16 is a shared semantic-layer case, not B08. It need not wait for native Weft derivation if an independently authored oracle tests the unchanged conditional property rule in Bun and Chromium. A helper returning compatible-properties with authority:false can be the semantic component; it must retain the selected dependencies as unverified assumptions and attest neither their derivation nor executable-query admission. B08 remains closed until the existing owner derives and binds actual query dependencies.

A generic arbitrary-set inclusion helper is not the complete S16 oracle. Exercise exact catalog/transform and applicable policy selection, all five operator paths, omitted queryUse→prohibited, missing required-property refusal, implied equality reporting, and S17's unconditional random-token join/group guard. Inject mandatory equality for join/group and order for ordering. Equality-predicate controls must independently fix equality as their actual dependency. An operator:'predicate' plus nonempty required array alone cannot distinguish equality from another predicate; labels in a test cannot substitute for that premise. Predicate/aggregate empty dependencies must refuse in this bounded API. No assertion that required:['order'] represents an actual equality predicate is admitted. The future original compiler must refuse dependency omission/substitution; no new profile/IR designation is needed here.

For property comparisons, a returned compatible status means only the declared dependency relation holds under the explicit owner-input premise. It does not turn original-authorized into disclosed, grant an action, authorize a query, execute a transform, or complete requireProtectionInterpretation.

## Applicability and resource prerequisites

Use original qualified core Field definitions and original checkSchemaLiteral/literalIdentity. Exact qualified domain identity includes the pinned revision; scalarType equality alone is insufficient. Validate every parameter/bucket against its own Field before comparing its typed identity; retain original lexical source. Equivalent numeric/binary spellings can match within that domain. Distinct domains and different parameter/key scopes do not imply equivalence. No prefix-length/range entailment is implied without an explicit owner law. Unsupported null/container/temporal/float equality must refuse rather than fall back to JSON equality.

Before transform interpretation, specify and enforce function-specific parameter names, arities, required/forbidden fields and domain relationships. Current name-only declarations do not define Unicode length units, regex engine/replacement behavior, negative bucket rounding/anchor, date truncation domain, required nullability or output range. These remain real work for B003/B004; domain resolution and property compatibility cannot claim it complete. Authored determinism is a claim to qualify, not a preference which can suppress known deterministic leakage.

Keep exact 256/32/4096 canonical UTF-16 limits, positive-at-bound and one-over controls, no trimming, source preservation. Add cumulative work/normalized identity payload limits before retaining expanded identities. A short exponent token may normalize far beyond its serialized bound. Original core normalization can allocate scratch before that charge, so this is not a total heap/CPU theorem. New component private bounds must not be weakened by mutating exported core LIMITS.

## Evidence and limits

Independently ran and replayed 13 retained Z3 4.15.4 queries: 5 UNSAT, 8 SAT. They distinguish determinism from injectivity, constant original-vs-disclosed equality, same output query behavior, cross-scope transforms, random coin variation, ordinary random-output equality, naive union bypass, explicit random guard, implied-property positive, prohibited default, vacuous caller dependency omission, and owner-derived missing-property refusal.

The models use abstract exact scalar equality. They prove no SQL NULL/collation/native operator behavior, probability or cryptographic leakage bound, compiler extraction, TypeScript refinement, source authentication, backend admission or acceptance-case execution. Supplied source files were inspected and copied/pinned; no native/browser/library test suite was rerun for this design task. Existing S08 source is supporting precedent, not a new execution receipt. No repository source was changed.

## Concurrent clarification addendum

At receipt capture the parent had edited CONTRACT-062 and added untracked literals.ts/parameters.ts. The retained current contract diff was inspected: it resolves the two equality/random-token ambiguities and explicitly separates conditional property compatibility from real dependency derivation and full function interpretation. The new modules were not reviewed in this design task. The clean main baseline contract is retained separately; countermodels pin that baseline. Source indices in the proposed helper select an actual retained policy disposition, and unknown use members/nonempty bounded requirements are expressly required. The newly stated pre-expansion ledger behavior is a design obligation, not verified implementation evidence here.
