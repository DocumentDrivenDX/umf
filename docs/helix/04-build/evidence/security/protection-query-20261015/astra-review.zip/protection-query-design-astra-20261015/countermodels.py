"""Conditional design laws/counterexamples, not implementation or probabilistic proofs."""
import json,hashlib,pathlib,z3
out=pathlib.Path(__file__).parent;root=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf');rows=[]
def query(name,formula,want):
 s=z3.Solver();s.add(*formula);observed=str(s.check());assert observed==want,(name,observed)
 smt=s.to_smt2();(out/(name+'.smt2')).write_text(smt);r=z3.Solver();r.from_string(smt);assert str(r.check())==want
 rows.append({'id':name,'expected':want,'observed':observed,'witness':str(s.model()) if want=='sat' else None})
x,y=z3.Ints('canonical_x canonical_y');T=z3.Function('fixed_transform',z3.IntSort(),z3.IntSort())
query('fixed_transform_respects_equal_inputs',[x==y,T(x)!=T(y)],'unsat')
query('determinism_does_not_imply_injectivity',[x!=y,T(x)==T(y)],'sat')
# Constant is an actual semantic counterexample to equality reflection.
constant=lambda x:z3.IntVal(7)
query('constant_original_vs_disclosed_equality',[x==1,y==2,(x==y)!=(constant(x)==constant(y))],'sat')
a,b,c,d=z3.Ints('before_left before_right after_left after_right')
query('same_disclosed_values_same_equality_result',[a==c,b==d,(a==b)!=(c==d)],'unsat')
# Different keys/parameters select different functions. One function's congruence says nothing about another.
U=z3.Function('other_transform_scope',z3.IntSort(),z3.IntSort())
query('different_transform_scopes_need_no_equal_outputs',[x==y,T(x)!=U(y)],'sat')
R=z3.Function('randomized_transform',z3.IntSort(),z3.IntSort(),z3.IntSort());r1,r2=z3.Ints('coin1 coin2')
query('randomized_same_input_may_split',[r1!=r2,R(x,r1)!=R(x,r2)],'sat')
query('random_output_still_has_ordinary_equality',[R(x,r1)==R(x,r1)],'sat')
randomToken,authoredEq,impliedEq,disclosed,join,group=z3.Bools('random_token authored_equality implied_equality disclosed join group')
effectiveEq=z3.Or(authoredEq,impliedEq)
weak=z3.And(disclosed,effectiveEq,z3.Or(join,group))
query('authored_equality_can_defeat_naive_random_union',[randomToken,authoredEq,z3.Not(impliedEq),disclosed,join,z3.Not(group),weak],'sat')
strong=z3.And(weak,z3.Not(z3.And(randomToken,z3.Or(join,group))))
query('explicit_random_join_group_guard',[randomToken,strong],'unsat')
query('deterministic_implied_equality_positive',[z3.Not(randomToken),z3.Not(authoredEq),impliedEq,disclosed,join,z3.Not(group),strong],'sat')
query('omitted_query_use_never_disclosed',[z3.Not(disclosed),strong],'unsat')
# Dependency completeness is an original compiler/semantic-owner premise, not caller data.
ownerNeeds,callerNeeds,retained=z3.Bools('owner_needs_property caller_claims_need retained_property')
query('caller_omitted_dependency_vacuous_admission',[ownerNeeds,z3.Not(callerNeeds),z3.Not(retained),z3.Implies(callerNeeds,retained)],'sat')
query('owner_derived_dependency_missing_refuses',[ownerNeeds,z3.Not(retained),z3.Implies(ownerNeeds,retained)],'unsat')
paths=['docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md','docs/helix/03-test/security/cases.json','src/extensions/security/evaluate.ts','tests/security/acceptance-case.ts','tools/security/prove-mask-query.py','src/model/schema-literals.ts','docs/helix/04-build/security-field-protection-plan.md']
receipt={'status':'conditional-design-countermodels-passed','solver':z3.get_version_string(),'queries':rows,'sourceDigests':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},'scriptSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'limits':['Abstract exact scalar equality with no SQL NULL/absence/collation/operator implementation theorem.','Randomized function is a function of input plus explicit coins; SAT witnesses are possibilities, not probability/security bounds.','Fixed transform scope and honest owner-derived dependencies are premises.','No implementation changes, compiler profile, transform authenticity, native behavior or case qualification.']}
(out/'countermodels.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'queries':len(rows),'unsat':sum(x['observed']=='unsat' for x in rows),'sat':sum(x['observed']=='sat' for x in rows)}))
