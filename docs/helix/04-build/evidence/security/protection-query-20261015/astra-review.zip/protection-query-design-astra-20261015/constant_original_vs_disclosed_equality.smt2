; benchmark generated from python API
(set-info :status unknown)
(declare-fun canonical_x () Int)
(declare-fun canonical_y () Int)
(assert
 (= canonical_x 1))
(assert
 (= canonical_y 2))
(assert
 (let (($x9 (= canonical_x canonical_y)))
(and (distinct $x9 (= 7 7)) true)))
(check-sat)
