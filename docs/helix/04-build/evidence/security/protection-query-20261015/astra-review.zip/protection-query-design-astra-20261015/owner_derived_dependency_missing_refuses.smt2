; benchmark generated from python API
(set-info :status unknown)
(declare-fun owner_needs_property () Bool)
(declare-fun retained_property () Bool)
(assert
 owner_needs_property)
(assert
 (not retained_property))
(assert
 (=> owner_needs_property retained_property))
(check-sat)
