from pathlib import Path
import re,json,subprocess,hashlib
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/query-route-activation-astra-20261015');H=R/'src/extensions/security/query-value-route-evaluation-candidate.ts';K=R/'src/extensions/security/catalog-runtime-candidate.ts'
def relocate(p):return re.sub(r"(from\s+['\"])(\.[^'\"]+)(['\"])",lambda m:m[1]+str((p.parent/m[2]).resolve())+m[3],p.read_text())
h,k=relocate(H),relocate(K);oracle=(O/'oracle.ts').read_text()
variants={
'empty-initial-retention-guard-omitted':('helper',[("  if(retained>4000000)throw Error('Retained route result bound');\n  const actual=","  const actual=")]),
'result-framing-charge-omitted':('helper',[("JSON.stringify({status:'evaluated',complete:false,authority:false,plan,rows:[]}).length","JSON.stringify(plan).length")]),
'ignore-read-permit':('helper',[("const active=row.decision==='permit'?","const active=true?")]),
'false-contributors-active':('helper',[("truth.get(s.ruleIndex)==='T'","truth.has(s.ruleIndex)")]),
'exclusions-ignored':('helper',[("b.guard.noActiveGroups.every((i:number)=>!groups[i])","true")]),
'unknown-truth-coerced':('kernel',[("truth:r.truth}))","truth:r.truth==='U'?'T':r.truth}))")]),
'row-permission-forced':('kernel',[("if(ruleTrace){\n   const trace=","if(ruleTrace){\n   decision='permit';const trace=")]),
'population-truncated':('kernel',[("const traces:any[]=[];const rows:any[]=[];", "if(ruleTrace)resources.splice(1);const traces:any[]=[];const rows:any[]=[];")]),
'original-rule-index-lost':('kernel',[("ruleIndex:r.ruleIndex,truth:r.truth","ruleIndex:0,truth:r.truth")]),
'per-trace-literal-reset':('kernel',[("budget.step(encoded.length);budget.reserveText(encoded.length+1)","new CandidateSecurityOperationBudget(1000000).literal.step(encoded.length);new CandidateSecurityOperationBudget(1000000).literal.reserveText(encoded.length+1)")]),
'late-budget-prefix-escape':('kernel',[("const pending:any[]=[trace];while(pending.length)","try{const pending:any[]=[trace];while(pending.length)"),("traces.push(trace);\n  }","traces.push(trace);}catch{return freeze({status:'evaluated',complete:false,authority:false,rows:traces});}\n  }")]),
'empty-dependencies-skipped':('kernel',[("for(const target of request.targets)for(const condition of scoped(target))preflight(condition.condition.expression,target,new Map());","if(!ruleTrace||resources.length)for(const target of request.targets)for(const condition of scoped(target))preflight(condition.condition.expression,target,new Map());")]),
}
results=[]
for name,(target,changes) in variants.items():
 d=O/'mutants'/name;d.mkdir(parents=True,exist_ok=True);s=h if target=='helper' else k
 for old,new in changes:
  if s.count(old)!=1:raise RuntimeError((name,'selector',s.count(old),old))
  s=s.replace(old,new)
 helper=s if target=='helper' else h.replace(str(K.with_suffix('')),str(d/'kernel'))
 if target=='kernel':(d/'kernel.ts').write_text(s)
 (d/'helper.ts').write_text(helper)
 text=oracle.replace("'./base-fixture.json'",repr(str(O/'base-fixture.json'))).replace(str(H.with_suffix('')),str(d/'helper'))
 if target=='kernel':text=text.replace(str(K.with_suffix('')),str(d/'kernel'))
 (d/'oracle.ts').write_text(text);(d/'run.ts').write_text("import {runOracle} from './oracle';const rows=runOracle();await Bun.write(import.meta.dir+'/result.json',JSON.stringify({controls:rows.length,failures:rows.filter(x=>!x.passed),observations:rows},null,2)+'\\n');console.log(JSON.stringify({controls:rows.length,failed:rows.filter(x=>!x.passed)}));")
 p=subprocess.run(['/opt/homebrew/bin/bun',str(d/'run.ts')],cwd=R,text=True,capture_output=True);(d/'run.log').write_text(p.stdout+p.stderr);j=json.loads((d/'result.json').read_text()) if (d/'result.json').exists() else None
 result={'name':name,'target':target,'exit':p.returncode,'sourceSha256':hashlib.sha256(s.encode()).hexdigest(),'controls':j and j['controls'],'failures':j and [x['id'] for x in j['failures']],'errors':j and [x for x in j['failures'] if x['error']],'detected':p.returncode==0 and bool(j and j['failures'])};results.append(result);print(json.dumps(result),flush=True)
(O/'mutation-results.json').write_text(json.dumps({'helperSha256':hashlib.sha256(H.read_bytes()).hexdigest(),'kernelSha256':hashlib.sha256(K.read_bytes()).hexdigest(),'variants':results},indent=2)+'\n')
if not all(x['detected'] for x in results):raise SystemExit(1)
