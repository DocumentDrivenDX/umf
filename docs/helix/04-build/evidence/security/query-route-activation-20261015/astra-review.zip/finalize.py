from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/query-route-activation-astra-20261015');sha=lambda b:hashlib.sha256(b).hexdigest()
pins=json.loads((O/'source-pins-before-final-runs.json').read_text());assert all(sha((R/p).read_bytes())==h for p,h in pins.items());(O/'final-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
assert subprocess.check_output(['git','show','c57d283e:docs/helix/03-test/security/cases.json'],cwd=R)==(R/'docs/helix/03-test/security/cases.json').read_bytes()
assert 'evaluateCandidateQueryValueRoutes' not in (R/'src/index.ts').read_text() and 'evaluateCandidateCatalogReadRuleScan' not in (R/'src/index.ts').read_text()
b=json.loads((O/'browser-result.json').read_text());m=json.loads((O/'mutation-results.json').read_text());f=json.loads((O/'formal/receipt.json').read_text())
assert b['parity'] and not b['pageErrors'] and not b['externalRequests'] and len(b['results'])==13
assert len(b['results'][0]['rows'])==121 and all(r['passed'] for r in b['results'][0]['rows'])
assert len(m['variants'])==12 and all(x['detected'] and x['exit']==0 and not x['errors'] for x in m['variants'])
for v in b['results']:
 assert all(t=='undefined' for t in v['globals'].values())
 if v['name']!='original':assert [r['id'] for r in v['rows'] if not r['passed']]==next(x['failures'] for x in m['variants'] if x['name']==v['name'])
assert m['helperSha256']==pins['src/extensions/security/query-value-route-evaluation-candidate.ts'] and m['kernelSha256']==pins['src/extensions/security/catalog-runtime-candidate.ts']
assert len(f['checks'])==12 and sum(x['observed']=='unsat' for x in f['checks'])==8 and all(x['freshContextReplay']==x['expected']==x['observed'] for x in f['checks'])
assert f['proofSourceSha256']==pins['tools/security/prove-query-route-activation.py']
assert all(pins[p]==h for p,h in f['selectedSourceDigests'].items())
assert '481 expect() calls' in (O/'root-focused-test.log').read_text()
r=json.loads((O/'existing-behavior-regression.json').read_text());assert [len(x['rows']) for x in r]==[112,49] and all(y['passed'] for x in r for y in x['rows'])
P=R/'docs/helix/04-build/evidence/security/query-route-activation-20261015'
assert sha((P/'browser.json').read_bytes())==f['inputSha256']
for name in ['browser.json','browser-before-empty-retention-fix.json','browser-before-final-build.json','README.md','verification-commands.json','formal-before-context-isolation/receipt.json','formal-before-empty-retention-fix/receipt.json','formal-before-final-build/receipt.json']:
 p=O/'parent-evidence'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/name,p)
selected=list(json.loads(Path('/private/tmp/query-value-routes-astra-20261015/final-source-pins.json').read_text()))+['src/extensions/security/query-value-route-evaluation-candidate.ts','tests/security/query-value-route-evaluation-corpus.ts','tests/security/query-value-route-evaluation.test.ts','tools/security/query-value-route-evaluation-browser.ts','tools/security/prove-query-route-activation.py']
selected=set(selected)|set(f['selectedSourceDigests']);(O/'copied-source-selection.json').write_text(json.dumps(sorted(selected),indent=2)+'\n')
review={
 'kind':'independent-astra-security-review','date':'2026-10-15','base':'c57d283ece30326bcb06607ca5d2384fc69ddef4',
 'scope':'Private source-derived route activation using the original logical kernel read-rule trace on a supplied complete typed population. Includes the new trace mode and focused existing-runtime regression; no scalar operands, query execution, compiler designation or native authority.',
 'disposition':'No remaining blocking finding within this component scope. One independently reproduced retention-bound defect was fixed and checked at exact boundaries before final capture.',
 'resolvedFindings':[{'id':'R1','priority':2,'issue':'Empty-population activation checked neither the retained source-plan bound nor final result framing. A valid inspected plan of 4002460 UTF16 units returned evaluated with zero rows and a 4002535-unit result. Nonempty paths also omitted framing from their accounting.','fix':'Check exact empty evaluated-result framing plus the retained plan before the trace scan; charge each serialized row and only intervening commas before retaining it.','evidence':['before-empty-retention-fix.ts','empty-retention-probe.ts','empty-retention-probe.json','retention-boundary-calibration.json','oracle.ts','mutants/empty-initial-retention-guard-omitted/result.json','mutants/result-framing-charge-omitted/result.json'],'verification':'Independent empty result 3999999 and4000000 accepted;4000001 refused. Separate empty/one-/two-row exact4000000 controls pass and each +1 refuses. Actual source inspection succeeds before each activation.','limit':'Resource-contract defect, not an authorization bypass or total heap/CPU bound.'}],
 'sourceAssessment':{
  'custody':'The helper snapshots owner/cut/use, reconstructs the source route plan from the original WeakMap-issued program and whole owner, and asks the original kernel for a type-only complete-population read trace. It accepts no caller guard, rule truth, mode, action or resource subset. All results are detached/frozen; source/cut/shape/budget errors erase plan and rows.',
  'trace':'Original scoped rule indices and F/T/U truth are retained for every validated target Record, including denied rows. Existing source/cut/member/graph/coverage preflight is reused, including empty populations. Trace traversal and encoded retention share the condition operation and literal/work/text ledgers; failures release no prefix. Existing action/collection return shapes remain unchanged.',
  'activation':'Only actual field-free read permit can activate a branch. Any true original contributor activates its group; exclusions preserve withheld priority, distinct-transform conflict and original/missing fallback. Require/forbid and unknown read outcomes remain distinct. All scoped source conditions must have corresponding original trace entries. No branch truth is assumed from source metadata.',
  'resultMeaning':'Selected means an actual source alternative was chosen. It can still have prohibited/conflicting mode constraints, missing properties, unresolved public projection, or separate original-action duties. Field-free eligibility is distinct from selected Field disclosure. Denied-row selectors and rule truth are private host diagnostics, not safe public read output.',
  'domains':'This increment returns no scalar value or absence encoding. Canonical stored tokens are not replaced with pre-storage plaintext; hidden original-use alternatives do not unmask public projection. Exact Weft occurrence/designation, scalar presence/domain, paired runtime/key scope and current native permission remain integration requirements.',
  'bounds':'Source-plan preparation and trace evaluation retain separate bounded costs; no whole-query cumulative ledger is claimed. Final serialized retained-result size includes framing and commas. The finite branch/source limits and supplied-cut limits do not establish total allocation/CPU bounds.',
  'apiBoundary':'No public root export, native call, new compiler owner, permission designation or acceptance case was introduced.'
 },
 'independentExecution':{
  'oracle':{'controls':121,'bun':'1.4.2','chromium':b['browser'],'fullParity':True,'pageErrors':0,'externalRequests':0,'hostGlobals':'Bun/process undefined','provenance':'Previously independently authored Person/Asset/Link core and flat/graph fixtures, new independent expected route truths/selections. No repository fixture helper imported by oracle.ts.','coverage':'All64 literal-truth combinations; equivalent/distinct masks; require/forbid/unknown/null; protected missing projection; canonical stored token; flat/Record/opaque graph membership; complete order and late outcomes; empty preflight; source/cut/owner/shape/getter/forgery refusals; shared trace budgets; exact framing bounds.','receipt':'browser-result.json'},
  'mutations':{'variants':12,'allDetectedBothRuntimes':True,'errorsCountedAsDetection':False,'ids':[x['name'] for x in m['variants']],'receipt':'mutation-results.json','isolatedBudgetWitness':'At300rows original refuses atomically; per-trace literal-reset evaluates300, while deliberate late-prefix escape evaluates211. The frozen control detects both separately.'},
  'existingBehaviorRegression':{'sourceRoutes':112,'mixedOperations':49,'runtime':'Bun1.4.2','allPassed':True,'receipt':'existing-behavior-regression.json'},
  'repositoryFocusedTest':{'tests':1,'assertions':481,'allPassed':True,'receipt':'root-focused-test.log'},
  'formal':{'queries':12,'unsat':8,'sat':4,'solver':'4.15.4','freshDistinctContexts':True,'receipt':'formal/receipt.json','scope':'Exact retained64-state observation relation against independently authored finite Boolean fold, with coverage/uniqueness and weakened exclusions/contributor/value-admission countermodels. Not arbitrary condition, TypeScript, SQL, source authentication or native authorization refinement.'}
 },
 'historicalEvidence':[
  'The original oversized empty-result witness and helper preimage are retained. Parent475 browser/formal receipts before the fix are preserved separately from current481 evidence.',
  'The initial500row shared-budget negative failed upstream in original and both reset/prefix mutants, so it did not distinguish the targeted guards. Calibration retained25..500 rows; the final oracle freezes300 with independent small-positive control. Initial masked mutation results remain historical and are not counted as successful sensitivity.',
  'Parent initial formal replay used a new Solver in the same Context; current proof uses a distinct z3.Context. The historical receipt remains, not labeled as a fresh-context replay.',
  'The first parent full gate ran against the pre-fix generated build and is retained by parent. Final review Bun/Chromium/mutations and selected regressions ran after regenerated action plan identity; all captured source hashes remain unchanged.',
  'Parent build/strict-type/broad346test and full158gate work is separate. The focused481 assertions,121 both-runtime controls,12 both-runtime mutations,161 prior controls and12 proof queries listed above were executed independently. Final parent full gate is pending at this receipt.'
 ],
 'qualificationLimits':[
  'Trusted supplied cut completeness/currentness and program/owner custody are premises, not credentials.',
  'Actual branch selection does not establish scalar availability, query-use permission, original-action authorization, read projection admission, paired transform/key scope or guarded native release.',
  'The trace is private and includes denied Record keys/policy truth. No public disclosure safety claim applies to this diagnostic data.',
  'Finite source/graph/Boolean controls and selected regressions do not establish universal expression/kernel refinement.',
  'All158 original case definitions are byte-identical to basec57d283e; no assertions, criteria, timeouts, runner bindings or statuses were promoted.',
  f'{len(pins)} selected/static-relative file hashes include the root barrel dependency reach and final generated identity, but not a hermetic dynamic/package/runtime provenance theorem. The compact archive contains118 focused selected source copies and a complete{len(pins)}-entry endpoint hash map.'
 ],
 'selectedSources':{'count':len(pins),'copiedFocusedSources':len(selected),'endpointStable':True,'pins':'final-source-pins.json','helperSha256':pins['src/extensions/security/query-value-route-evaluation-candidate.ts'],'runtimeSha256':pins['src/extensions/security/catalog-runtime-candidate.ts'],'generatedIdentitySha256':pins['src/extensions/actions/plan-identity.ts']},
 'acceptanceCasesPromoted':[],'rootSourcesEditedByReviewer':False
}
# Keep archive-copy count exact rather than an incidental prose estimate.
review['qualificationLimits'][-1]=review['qualificationLimits'][-1].replace('contains118 focused',f'contains{len(selected)} focused')
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(O/'review.md').write_text('''# Independent route activation review\n\nNo remaining blocker in this private logical diagnostic scope. One reproduced retention defect was fixed: exact result framing and the empty-population bound are now checked before trace evaluation. Empty, one-row and two-row results pass at4000000 UTF16 units and refuse at+1.\n\n121 independent controls pass with exact Bun/Chromium parity;12 focused source mutations are detected in both runtimes.481 focused repository assertions and161 prior controls pass.12 finite proof queries replay8UNSAT/4SAT in distinct contexts. Final build/source pins are stable.\n\nSelected routes are not permission or scalar operands. Denied keys/rule truth remain private diagnostics; current cut custody, exact compiler designation, separate action duties and native release are unresolved integration work. All158 acceptance definitions are unchanged. Final parent full gate is pending. Exact failures, calibrations, controls, source hashes and limits are retained in review.json.\n''')
assert all(sha((R/p).read_bytes())==h for p,h in pins.items())
files=[]
for p in sorted(O.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(O)
 if any(x in ['node_modules','__pycache__'] for x in rel.parts) or rel.name in ['archive.zip','manifest.json','archive-summary.json']:continue
 if rel.parts[0]=='reviewed-sources' and str(Path(*rel.parts[1:])) not in selected:continue
 files.append(p)
manifest={'reviewSha256':sha((O/'review.json').read_bytes()),'files':[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in files],'scope':'Compact selected source copies, all endpoint pins, independent fixtures/oracles, focused altered modules/runners, failures/calibrations/receipts. No node_modules, full mutant repositories or unrelated source tree.'};(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(O/'manifest.json')
with zipfile.ZipFile(O/'archive.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in files:z.write(p,str(p.relative_to(O)))
summary={'review':str(O/'review.json'),'reviewSha256':sha((O/'review.json').read_bytes()),'archive':str(O/'archive.zip'),'archiveSha256':sha((O/'archive.zip').read_bytes()),'bytes':(O/'archive.zip').stat().st_size,'files':len(files),'sourcePins':len(pins),'focusedSourceCopies':len(selected)};(O/'archive-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
