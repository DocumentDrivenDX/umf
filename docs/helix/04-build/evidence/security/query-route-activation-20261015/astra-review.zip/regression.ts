import {runOracle as routes} from '/private/tmp/query-value-routes-astra-20261015/oracle';
import {runOracle as mixed} from '/private/tmp/catalog-operation-batch-astra-20261015/oracle';
const results=[{name:'prior-source-routes',rows:routes()},{name:'prior-mixed-operation',rows:mixed()}];await Bun.write(import.meta.dir+'/existing-behavior-regression.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results.map(x=>({name:x.name,controls:x.rows.length,failures:x.rows.filter(r=>!r.passed)}))));if(results.some(x=>x.rows.some(r=>!r.passed)))process.exitCode=1;
