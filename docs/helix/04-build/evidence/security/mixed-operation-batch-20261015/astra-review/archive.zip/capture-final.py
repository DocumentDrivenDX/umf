from pathlib import Path
import json,re,hashlib,shutil
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/catalog-operation-batch-astra-20261015')
selected=set(json.loads((O/'initial-source-pins.json').read_text()));selected.update(['tools/security/prove-mixed-operation-batch.py','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md','docs/helix/02-design/technical-designs/TD-079-security-semantics.md','docs/helix/03-test/test-plans/STP-079-security-semantics.md','tests/security/protection/query-value-modes-source.json','tests/security/catalog-runtime-fixture.ts','src/extensions/security/catalog-program-candidate.ts','bun.lock','package.json'])
queue=list(selected);done=set()
while queue:
 p=queue.pop()
 if p in done:continue
 done.add(p);file=R/p
 if file.suffix not in ['.ts','.js']:continue
 for rel in re.findall(r"(?:from\s*|import\s*)['\"](\.[^'\"]+)['\"]",file.read_text()):
  base=file.parent/rel;candidates=[base,Path(str(base)+'.ts'),Path(str(base)+'.json'),base/'index.ts'];chosen=next((x for x in candidates if x.is_file()),None)
  if chosen:
   try:q=str(chosen.resolve().relative_to(R.resolve()))
   except ValueError:continue
   if q not in selected:selected.add(q);queue.append(q)
pins={}
for p in sorted(selected):
 b=(R/p).read_bytes();pins[p]=hashlib.sha256(b).hexdigest();dest=O/'final-sources'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
(O/'final-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
parent=R/'docs/helix/04-build/evidence/security/mixed-operation-batch-20261015';dst=O/'parent-evidence';dst.mkdir(exist_ok=True)
for name in ['formal-initial-unknown.py.gz','corpus-before-frozen-work-limit.ts.gz','parent-work-calibration-pins.json','parent-work-calibration.log','browser.json','verification-commands.json','broad-regression-observation.json']:
 if (parent/name).is_file():shutil.copy2(parent/name,dst/name)
if (parent/'formal-initial-unknown').exists():shutil.copytree(parent/'formal-initial-unknown',dst/'formal-initial-unknown',dirs_exist_ok=True)
print(json.dumps({'pins':len(pins),'generatedIdentityIncluded':'src/extensions/actions/plan-identity.ts' in pins}))
# Parent frozen1609 sensitivity: use same fixture and exact source, changing only batch implementation target.
p=R/'tests/security/catalog-operation-batch-corpus.ts';s=p.read_text();s=re.sub(r"(from\s+['\"])(\.[^'\"]+)(['\"])",lambda m:m[1]+str((p.parent/m[2]).resolve())+m[3],s);needle=str(R/'src/extensions/security/catalog-operation-batch-candidate');assert s.count(needle)==1;s=s.replace(needle,str(O/'mutants/work-reset/batch.ts'))
(O/'parent-frozen-work-mutant.ts').write_text(s+"\nconst rows=runCatalogOperationBatchCorpus();await Bun.write(import.meta.dir+'/parent-frozen-work-sensitivity.json',JSON.stringify({controls:rows.length,failures:rows.filter(r=>!r.passed)},null,2)+'\\n');\n")
