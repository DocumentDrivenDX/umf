from pathlib import Path
import hashlib,json,subprocess,zipfile
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/catalog-operation-batch-astra-20261015');sha=lambda b:hashlib.sha256(b).hexdigest()
pins=json.loads((O/'final-source-pins.json').read_text());assert all(sha((R/p).read_bytes())==h for p,h in pins.items())
case='docs/helix/03-test/security/cases.json';old=subprocess.check_output(['git','show','92f228e2:'+case],cwd=R);new=(R/case).read_bytes();assert old==new;pins[case]=sha(new);dest=O/'final-sources'/case;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(new)
(O/'final-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(O/'case-inventory-audit.json').write_text(json.dumps({'base':'92f228e2','path':case,'byteIdentical':True,'sha256':sha(new),'casePromotions':[]},indent=2)+'\n')
initial=json.loads((O/'initial-source-pins.json').read_text());assert initial['src/extensions/security/catalog-operation-batch-candidate.ts']==pins['src/extensions/security/catalog-operation-batch-candidate.ts'];assert initial['src/extensions/security/catalog-runtime-candidate.ts']==pins['src/extensions/security/catalog-runtime-candidate.ts']
bun=json.loads((O/'bun-results.json').read_text());assert len(bun['rows'])==49 and all(x['passed'] for x in bun['rows'])
browser=json.loads((O/'browser-result.json').read_text());assert browser['parity'] and not browser['pageErrors'] and not browser['externalRequests'];assert len(browser['results'])==9
assert all(v=='undefined' for result in browser['results'] for v in result['globals'].values())
assert all(x['passed'] for x in browser['results'][0]['rows']);assert all(any(not r['passed'] for r in x['rows']) for x in browser['results'][1:])
mutants=json.loads((O/'mutation-results.json').read_text());assert len(mutants)==8 and all(m['detected'] and m['exitCode']==0 for m in mutants)
for name,control in [('work-reset','shared-work-positive-leaves-refused-batch'),('text-reset','shared-text-positive-leaves-refused-batch'),('literal-reset','shared-literal-positive-leaves-refused-batch')]:assert [f['id'] for f in next(m for m in mutants if m['id']==name)['failures']]==[control]
formal=json.loads((O/'formal-final/receipt.json').read_text());assert len(formal['checks'])==12 and sum(c['observed']=='unsat' for c in formal['checks'])==6 and formal['sourcesUnchanged'];assert all(sha((R/p).read_bytes())==h for p,h in formal['selectedSourceDigests'].items())
parentSensitivity=json.loads((O/'parent-frozen-work-sensitivity.json').read_text());assert parentSensitivity['controls']==50 and [r['id'] for r in parentSensitivity['failures']]==['shared-mixed-work-budget']
review={
 'kind':'independent-astra-security-review','date':'2026-10-15','base':'92f228e2','headObserved':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
 'scope':'Private atomic supplied mixed logical scan/action batch and private runtime scan-with-shared-operation leaf; existing original issued program, owner/cut and operation completeness are premises.',
 'disposition':'No remaining blocking correctness issue in the stated component scope. No production source fix was required by this review. One work-limit test-sensitivity gap was corrected and independently verified.',
 'sourceReview':{
  'custody':'Original program handle is required before one detached JSON packet captures owner, cut and all operations. Accessors refuse without invocation; each runtime leaf sees the private snapshot and same operation ledger. Results are recursively frozen and detached.',
  'atomicity':'All closed operation shapes and aggregate inventory charges are checked before execution. Each refused leaf or thrown structural/resource error returns operations:[]; no completed prefix is returned.',
  'budgets':'One private CandidateSecurityOperationBudget carries cumulative work, snapshot text and ProtectionLiteralBudget. Aggregate facts charge the inventory once plus all scan population visits and explicit action resource selectors; graph facts remain in the inventory charge. Independent reset and omission weakenings are detected.',
  'meaning':'completed means diagnostic evaluation finished. It may retain deny, indeterminate or conflict action decisions, and an empty action resource set supplies no per-row permit witness. Scan rendering still filters denied rows and refuses unresolved render decisions. Action completion cannot reveal originals or rewrite read Cells.',
  'apiDelta':'Existing runtime code changes only by adding the private scanWithinOperation leaf; no public root export or schema/case semantic change. Internal shared-ledger leaf is a composition mechanism, not a native authority boundary.'},
 'independentExecution':{
  'oracle':{'controls':49,'fixture':'base-fixture.json','fixtureProvenance':'Reused independently authored Person/Asset/Link core0.8 and logical source fixture; current mixed scenarios and exact expectations authored for this review, not copied from repository helper outputs.','bun':'1.4.2','chromium':browser['browser'],'parity':True,'pageErrors':0,'externalRequests':0,'receipts':['bun-results.json','browser-result.json']},
  'sourceMutations':{'variants':8,'allDetectedInBunAndChromium':True,'result':'mutation-results.json','ids':[m['id'] for m in mutants]},
  'focusedRepositoryTest':{'command':'bun test tests/security/catalog-operation-batch.test.ts','tests':1,'assertions':50,'result':'root-focused-test.log'},
  'parentFrozenWorkSensitivity':{'originalMinimum':1610,'fixedNegative':1609,'controls':50,'detectedFailure':'shared-mixed-work-budget','result':'parent-frozen-work-sensitivity.json'},
  'formal':{'queries':12,'unsat':6,'sat':6,'solver':formal['solverVersion'],'freshSmtContexts':True,'result':'formal-final/receipt.json','limits':'Conditional bounded operation count and integer cost/cut abstraction. Faithful costs, complete duty enumeration, genuine cut snapshot and faithful completion/permission are assumed. Per-step nonnegative recurrence is proved; no TypeScript/kernel/native refinement or general induction claim.'}},
 'reviewCorrections':[
  {'id':'C1-adaptive-work-threshold','status':'fixed','finding':'Searching for minimal completion against the same implementation under test can adapt to a reset mutant and therefore does not demonstrate cumulative work accounting.','resolution':'Measured original repository fixture minimum1610, froze negative1609; actual reset mutant now fails the named work control. Independent fixture separately froze minimum1262/negative1261.','evidence':['parent-work-calibration-pins.json','parent-work-calibration.log','parent-frozen-work-sensitivity.json','oracle-work-calibration.log']}
 ],
 'calibrationsAndFailedAttempts':[
  'Initial independent oracle incorrectly expected typed canonical null comparison to be unknown, and a true forbid to be disclosure conflict. Corrected the controls to explicit known absence and actual conflicting transformed disclosures after checking governing semantics; no production bug claim. Original source/log/results retained.',
  'A temporary line-comment placement in the private frozen-work oracle caused a parser setup error. All affected mutation runs were classified detected:false/exit1 and were not counted; fixed block comment and fresh-result deletion precede final successful runs. Failure logs retained.',
  'Parent initial arbitrary-prefix quantified monotonicity query timed out as unknown after10s. Original partial formulas/source remain under parent-evidence/formal-initial-unknown; final exact next-step recurrence laws are separately scoped.'
 ],
 'qualificationLimits':[
  'Supplied program/owner/cut correctness, trusted completeness, operation enumeration and intended target set remain external premises. This API does not derive Weft designation or attest supplied action duties.',
  'No aggregate or query execution, operator-value origin selection, property-mode conjunction, paired scope, source authentication/current authority, native credentials, release custody, P03/B08 or whole security-goal promotion.',
  'A completed batch with zero action rows or denied/unknown/conflicting decisions is not a permit. Future consumers must enforce each actual duty and protect the final release.',
  'Resource checks are selected cumulative operation ledgers after bounded snapshots, not a total heap/CPU theorem or a bound on all original source validation.',
  'All158 original case definitions remain byte-identical to92f228e2; no runner/assertion/timeout/criteria promotion in this review.',
  'Selected static relative-import pins include regenerated actions/plan-identity.ts after the build; this is not a hermetic runtime/dependency closure.',
  'Full gate and broad unit/build/browser suites are parent-owned. Parent reports final344tests4110assertions and earlier420tests5793assertions; those are not independently rerun here. Full158 gate is pending at review finalization.'
 ],
 'selectedSources':{'count':len(pins),'pins':'final-source-pins.json','beforeAfterStable':True,'generatedPlanIdentitySha256':pins.get('src/extensions/actions/plan-identity.ts'),'newBatchSha256':pins['src/extensions/security/catalog-operation-batch-candidate.ts'],'runtimeSha256':pins['src/extensions/security/catalog-runtime-candidate.ts']},
 'casePromotions':[],'rootSourceEditedByReviewer':False
}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n');(O/'review.md').write_text('''# Independent mixed-operation review\n\nNo remaining blocker within this private logical component.49 independent controls pass in Bun and Chromium153;8 actual-source weakenings are detected in both. Work, text and literal resets each fail their isolated control. The current repository test passes50 expectations; its frozen1609 work case detects a reset mutant.12 conditional SMT queries replay6UNSAT/6SAT.\n\nCompleted remains diagnostic, including deny, indeterminate or conflict outcomes. Structural/refusal/budget failures erase the entire operation result. No Weft duty designation, query/native authority or case promotion follows. Full gate is parent-owned and pending. See review.json for exact limitations and retained calibration failures.\n''')
assert all(sha((R/p).read_bytes())==h for p,h in pins.items())
files=[]
for p in sorted(O.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(O)
 if any(x in ['node_modules','__pycache__'] for x in rel.parts) or rel.name in ['archive.zip','manifest.json','archive-summary.json']:continue
 files.append(p)
manifest={'reviewSha256':sha((O/'review.json').read_bytes()),'files':[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files],'scope':'Private review artifacts, focused mutant modules/runners, selected sources and exact evidence; no dependency trees or generated browser bundles.'};(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(O/'manifest.json')
with zipfile.ZipFile(O/'archive.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(O)))
summary={'review':str(O/'review.json'),'reviewSha256':sha((O/'review.json').read_bytes()),'archive':str(O/'archive.zip'),'archiveSha256':sha((O/'archive.zip').read_bytes()),'bytes':(O/'archive.zip').stat().st_size,'files':len(files),'sourcePins':len(pins)};(O/'archive-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
