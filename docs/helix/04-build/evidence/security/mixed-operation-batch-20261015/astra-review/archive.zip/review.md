# Independent mixed-operation review

No remaining blocker within this private logical component.49 independent controls pass in Bun and Chromium153;8 actual-source weakenings are detected in both. Work, text and literal resets each fail their isolated control. The current repository test passes50 expectations; its frozen1609 work case detects a reset mutant.12 conditional SMT queries replay6UNSAT/6SAT.

Completed remains diagnostic, including deny, indeterminate or conflict outcomes. Structural/refusal/budget failures erase the entire operation result. No Weft duty designation, query/native authority or case promotion follows. Full gate is parent-owned and pending. See review.json for exact limitations and retained calibration failures.
