from pathlib import Path
import re,json,hashlib,subprocess
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/catalog-operation-batch-astra-20261015');path=R/'src/extensions/security/catalog-operation-batch-candidate.ts';source=path.read_text();template=(O/'oracle-template.ts').read_text()
def relocate(text,path):return re.sub(r"(from\s+['\"])(\.[^'\"]+)(['\"])",lambda m:m[1]+str((path.parent/m[2]).resolve())+m[3],text)
def change(a,b):
 assert source.count(a)==1,(a,source.count(a));return source.replace(a,b)
resultDecl="const results:CandidateCatalogOperationBatchResult['operations'][number][]=[];"
prefix=change(resultDecl,'')
prefix=prefix.replace(' const refused='," const results:CandidateCatalogOperationBatchResult['operations'][number][]=[];\n const refused=",1).replace(' }catch{return refused();}'," }catch{return results.length?freeze({status:'completed',complete:false,authority:false,operations:results}):refused();}")
mutants={
 'prefix-escape':prefix,
 'work-reset':change('  for(const op of operations){\n   if(op.kind',"  for(const op of operations){\n   (ledger as any).work=0;\n   if(op.kind"),
 'text-reset':change('  for(const op of operations){\n   if(op.kind',"  for(const op of operations){\n   (ledger as any).text=0;\n   if(op.kind"),
 'literal-reset':change('  for(const op of operations){\n   if(op.kind',"  for(const op of operations){\n   (ledger as any).literal=new CandidateSecurityOperationBudget(cut.maxSteps).literal;\n   if(op.kind"),
 'omit-scan-visits':change('if(ref(fact.type)===type)population++;','if(ref(fact.type)===type)population+=0;'),
 'omit-action-visits':change('population+=op.request.resources.length;','population+=0;'),
 'omit-graph-population':change('let population=cut.facts.length+cut.graphs.length;','let population=cut.facts.length;'),
 'completed-to-permit':change("results.push({id:op.id,kind:'action',outcome});","results.push({id:op.id,kind:'action',outcome:{...outcome,rows:outcome.rows.map(row=>({...row,decision:'permit' as const}))}});")
}
rows=[]
for name,code in mutants.items():
 d=O/'mutants'/name;d.mkdir(parents=True,exist_ok=True);(d/'batch.ts').write_text(relocate(code,path));(d/'oracle.ts').write_text(template.replace("'./base-fixture.json'",repr(str(O/'base-fixture.json'))).replace('__BATCH__',str(d/'batch.ts')))
 (d/'run.ts').write_text("import {runOracle} from './oracle';const rows=runOracle();await Bun.write(import.meta.dir+'/result.json',JSON.stringify({rows},null,2)+'\\n');console.log(JSON.stringify({controls:rows.length,failures:rows.filter(r=>!r.passed)}));\n")
 (d/'result.json').unlink(missing_ok=True)
 run=subprocess.run(['/opt/homebrew/bin/bun',str(d/'run.ts')],capture_output=True,text=True,cwd=R,timeout=60);(d/'run.log').write_text(run.stdout+run.stderr)
 result=json.loads((d/'result.json').read_text()) if run.returncode==0 and (d/'result.json').exists() else None
 failures=[r for r in result['rows'] if not r['passed']] if result else []
 rows.append({'id':name,'exitCode':run.returncode,'detected':run.returncode==0 and bool(failures),'failures':failures,'sourceSha256':hashlib.sha256((d/'batch.ts').read_bytes()).hexdigest()})
print(json.dumps(rows,indent=2));(O/'mutation-results.json').write_text(json.dumps(rows,indent=2)+'\n')
