import json,shutil,subprocess,hashlib
from pathlib import Path
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent;dest=out/'mutants';dest.mkdir(exist_ok=True)
base=dest/'base'
for directory in ['src','spec']:
 if not (base/directory).exists():shutil.copytree(root/directory,base/directory)
(base/'node_modules').symlink_to(root/'node_modules') if not (base/'node_modules').exists() else None
variants=[('original',None,None,None),
('omit-compiler-literal-meter','src/extensions/security/entity-terms-candidate.ts','if(scope.literalBudget)scope.literalBudget.check(source.document,source.field,value.value);else checkSchemaLiteral(source.document,source.field,value.value);','checkSchemaLiteral(source.document,source.field,value.value);'),
('reset-literal-meter-per-target','src/extensions/security/entity-terms-candidate.ts','scopes.get(result as object).literalBudget=budget;','scopes.get(result as object).literalBudget=new ProtectionLiteralBudget();'),
('reset-recipe-meter-per-definition','src/extensions/security/protection/functions.ts','{parameters,budget,fields:fields!}','{parameters,budget:new ProtectionLiteralBudget(),fields:fields!}'),
('skip-all-definition-applicability','src/extensions/security/protection/functions.ts',"if(!['mask','generalize'].includes(transform.kind))continue;",'if(true)continue;'),
('omit-live-target-membership','src/extensions/security/catalog-program-candidate.ts',"if(!entity.fields.some((f:any)=>id(f.ref)===id(disclosure.field)))fail('Disclosure input must be a live target Field');", "if(false)fail('Disclosure input must be a live target Field');"),
('omit-binding-retention','src/extensions/security/catalog-program-candidate.ts','obligations,bindings:packet.bindings,conditions','obligations,conditions'),
('omit-expanded-descriptor-bound','src/extensions/security/catalog-program-candidate.ts',"if(!Number.isSafeInteger(expandedText)||expandedText>64_000_000)fail('Expanded condition/descriptor text budget exhausted');", "if(false)fail('Expanded condition/descriptor text budget exhausted');")]
results=[]
for name,path,old,new in variants:
 d=dest/name
 for directory in ['src','spec']:shutil.copytree(base/directory,d/directory,dirs_exist_ok=True)
 if not (d/'node_modules').exists():(d/'node_modules').symlink_to(root/'node_modules')
 if path:
  p=d/path;s=p.read_text();assert s.count(old)==1,(name,s.count(old));p.write_text(s.replace(old,new))
 
 for fixture in ['regressions/typing-controls/fixtures.json','obligation-fixtures.json']:
  dst=d/fixture;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(out/fixture,dst)
 source=(out/'oracle.ts').read_text().replace(str(root),str(d));(d/'oracle.ts').write_text(source)
 (d/'run.ts').write_text("import{runOracle}from './oracle';const rows=runOracle();await Bun.write(import.meta.dir+'/results.json',JSON.stringify({rows},null,2)+'\\n');console.log(JSON.stringify({count:rows.length,failed:rows.filter(r=>!r.passed).map(r=>r.id)}));")
 r=subprocess.run(['/opt/homebrew/bin/bun',str(d/'run.ts')],cwd=d,text=True,capture_output=True,timeout=45);(d/'run.log').write_text(r.stdout+r.stderr)
 if r.returncode!=0:raise RuntimeError((name,r.returncode,r.stdout,r.stderr))
 rows=json.loads((d/'results.json').read_text())['rows'];failed=[x['id'] for x in rows if not x['passed']]
 result={'variant':name,'count':len(rows),'failed':failed,'changedSource':path,'sha256':hashlib.sha256((d/path).read_bytes()).hexdigest()if path else None};results.append(result);print(json.dumps(result),flush=True)
 assert bool(failed)==(name!='original'),(name,failed)
(out/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
