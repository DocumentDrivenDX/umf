import{runOracle as compiler}from './oracle';
import{runOracle as prior}from './regressions/shared-source-controls/all-oracle';
import{runOracle as functions}from './regressions/functions/oracle';
export async function runOracle(){const f=await functions();return [...compiler().map(x=>({suite:'compiler',...x})),...prior().map(x=>({suite:'source-scope-regression',...x})),...f.rows.map((x:any)=>({suite:'pure-function-regression',...x,passed:x.pass}))];}
