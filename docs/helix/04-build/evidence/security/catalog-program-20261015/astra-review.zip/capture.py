import json,re,hashlib,shutil,sys
from pathlib import Path
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent
files=set(json.loads(Path('/private/tmp/security-v2-logical-review-20261015/shared-source-controls/source-pins-after.json').read_text()))
queue=['src/extensions/security/catalog-program-candidate.ts','src/extensions/security/protection/functions.ts']
visited=set()
while queue:
 name=queue.pop()
 if name in visited:continue
 visited.add(name);files.add(name);p=root/name
 if p.suffix!='.ts':continue
 for spec in re.findall(r'(?:from\s*|import\s*)[\'\"]([^\'\"]+)[\'\"]',p.read_text()):
  if not spec.startswith('.'):continue
  base=p.parent/spec
  found=next((x for x in [base,Path(str(base)+'.ts'),Path(str(base)+'.json'),base/'index.ts'] if x.is_file()),None)
  if found:queue.append(str(found.resolve().relative_to(root.resolve())))
files.update(['tests/security/catalog-program.test.ts','spec/extensions/security-v0.2/schema.json','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md','docs/helix/04-build/evidence/security/catalog-program-20261015/formal.py'])
for pattern in ['docs/helix/02-design/technical-designs/TD-079*.md','docs/helix/03-test/test-plans/STP-079*.md']:
 for p in root.glob(pattern):files.add(str(p.relative_to(root)))
pins={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(files)}
label=sys.argv[1] if len(sys.argv)>1 else 'before'
(out/('source-pins-'+label+'.json')).write_text(json.dumps(pins,indent=2)+'\n')
if label=='before':
 for name in pins:
  target=out/'captured-sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,target)
 print('captured',len(pins))
else:
 before=json.loads((out/'source-pins-before.json').read_text());changed=[k for k in set(before)|set(pins) if before.get(k)!=pins.get(k)];print(json.dumps({'count':len(pins),'changed':changed}));assert not changed
