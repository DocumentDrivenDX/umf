import json
from pathlib import Path
out=Path(__file__).parent
expected={
'original':[],
'omit-compiler-literal-meter':['numeric-expansion-before-normalization','inline-numeric-expansion-before-normalization','one-over-shared-literal-text100000','cross-target-literal-ledger','cross-rule-inline-literal-ledger','allowedValues-comparison-work-ledger'],
'reset-literal-meter-per-target':['cross-target-literal-ledger'],
'reset-recipe-meter-per-definition':['catalog-whole-definition-shared-ledger'],
'skip-all-definition-applicability':['catalog-unused-regex','catalog-false-regex','catalog-empty-rules-regex','catalog-missing-parameter','catalog-extra-parameter','catalog-random-pure','known-regex-wire-positive-definition-refusal','unused-recipe-zero-bucket-width','catalog-whole-definition-shared-ledger'],
'omit-live-target-membership':['disclosure-not-live','multi-target-disclosure-not-shared'],
'omit-binding-retention':['program-captured-bindings','program-caller-mutation-isolated'],
'omit-expanded-descriptor-bound':['descriptor-text-precharge-refusal']}
rows=json.loads((out/'mutation-results.json').read_text());assert len(rows)==len(expected)
for r in rows:assert r['count']==111 and r['failed']==expected[r['variant']],r
(out/'mutation-exact-discrimination.json').write_text(json.dumps({'status':'pass','original':1,'mutants':7,'expectedFailureSets':expected,'qualification':'Each selected weakening changes exactly these independently expected compiler observations; no import/setup errors counted as discrimination.'},indent=2)+'\n')
print('8 variants exact expected failure sets pass')
