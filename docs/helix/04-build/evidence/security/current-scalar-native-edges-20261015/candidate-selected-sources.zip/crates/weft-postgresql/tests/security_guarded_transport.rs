#[jsonschema::validator(path="../../docs/helix/02-design/contracts/security-guarded-candidate-v0.1-candidate.schema.json")]
struct CandidateSchema;
#[jsonschema::validator(path="../../docs/helix/02-design/contracts/security-guarded-result-output-v0.1-candidate.schema.json")]
struct ResultSchema;
use serde_json::{json, Value};
use weft_core::{ir::ModelPin, json::sha256, model::ModuleInput};
use weft_postgresql::{
    security_graph_binding::GraphSource,
    security_guarded_transport::{inspect_guarded_graph_result, prepare_guarded_graph_candidate},
};
const FIXTURE: &str =
    include_str!("../../../docs/helix/03-test/fixtures/security-graph-source/mapping-request.json");
fn request(sql: &str) -> String {
    let mut request: Value = serde_json::from_str(FIXTURE).unwrap();
    let physical =
        include_str!("../../../docs/helix/03-test/fixtures/security-graph-source/adoc.json");
    let source=GraphSource{version:"weft.truss.security.graph-source/0.1-candidate".into(),native_schema_revision:"1".into(),physical_module:ModuleInput{document_json:physical.into(),pin:ModelPin{document_id:"adoc".into(),revision:"r1".into(),umf_version:"0.8.0".into(),sha256:sha256(physical.as_bytes())},selected_module_ids:vec!["m".into()]},inventory_json:include_str!("../../../docs/helix/03-test/fixtures/security-graph-source/native-inventory.json").into(),correspondence_json:include_str!("../../../docs/helix/03-test/fixtures/security-graph-source/binding-correspondence.json").into(),logical_resolution_json:include_str!("../../../docs/helix/03-test/fixtures/security-graph-source/resolution.json").into(),logical_transport_json:include_str!("../../../docs/helix/03-test/fixtures/security-graph-source/transport.json").into()};
    let binding = serde_json::to_string(&source).unwrap();
    request["bindingJson"] = json!(binding);
    request["sql"] = json!(sql);
    let mut profile: Value =
        serde_json::from_str(request["queryProfileJson"].as_str().unwrap()).unwrap();
    profile["binding"]["sha256"] = json!(sha256(binding.as_bytes()));
    request["queryProfileJson"] = json!(profile.to_string());
    request.to_string()
}
fn inspection(raw: &str, output: &str, batch: Value) -> Value {
    json!({"version":"weft.truss.security.guarded-result/0.1-candidate","sourceRequestJson":raw,"sourceOutputJson":output,"batchJson":batch.to_string()})
}
#[test]
fn guarded_handoff_keeps_source_query_parameter_and_subject_channels_distinct() {
    let raw = request("SELECT r.resourceId, r.salary FROM Resource r");
    let candidate = prepare_guarded_graph_candidate(&raw).unwrap();
    let wire: Value = serde_json::from_str(candidate.json()).unwrap();
    assert!(CandidateSchema::is_valid(&wire));
    assert!(candidate.json().ends_with('\n'));
    assert_eq!(
        wire["version"],
        "weft.truss.security.guarded-candidate/0.1-candidate"
    );
    assert_eq!(wire["securityReady"], false);
    assert_eq!(wire["nativeAdmission"], "required");
    assert_eq!(wire["sourceRequestSha256"], sha256(raw.as_bytes()));
    assert_eq!(wire["sourceContextSha256"], candidate.source().sha256());
    assert_eq!(wire["sourceContextJson"], candidate.source().json());
    assert_eq!(wire["queryContextSha256"], candidate.query_context_sha256());
    assert_eq!(wire["policyParameterBindings"][0]["ordinal"], 1);
    assert_eq!(
        wire["policyParameterBindings"][0]["physicalCodec"],
        "boolean"
    );
    assert_eq!(wire["subjectParameterBinding"]["ordinal"], 2);
    assert_eq!(
        wire["subjectParameterBinding"]["logicalKeyFields"][0]["elementId"],
        "staffId"
    );
    for forbidden in ["value", "principal", "epoch", "permit"] {
        assert!(wire["subjectParameterBinding"].get(forbidden).is_none());
    }
    let other =
        prepare_guarded_graph_candidate(&request("SELECT r.salary, r.resourceId FROM Resource r"))
            .unwrap();
    assert_eq!(candidate.source().json(), other.source().json());
    assert_ne!(
        candidate.query_context_sha256(),
        other.query_context_sha256()
    );
    assert_ne!(candidate.json(), other.json());
}
#[test]
fn original_result_batch_passes_correspondence_without_granting_a_release_permit() {
    let raw = request("SELECT r.resourceId, r.salary FROM Resource r");
    let candidate = prepare_guarded_graph_candidate(&raw).unwrap();
    let batch = json!({"version":"weft.security.cells/0.1.0","resultContractSha256":candidate.query().value()["resultContractSha256"],"rows":[[{"outcomeId":"original","disposition":"original","value":{"string":"RA"}},{"outcomeId":"withheld","disposition":"withheld"}]]});
    let checked: Value = serde_json::from_str(
        &inspect_guarded_graph_result(
            &inspection(&raw, candidate.json(), batch.clone()).to_string(),
        )
        .unwrap(),
    )
    .unwrap();
    assert!(ResultSchema::is_valid(&checked));
    assert_eq!(checked["status"], "inspected");
    assert_eq!(checked["securityReady"], false);
    assert_eq!(
        checked["sourceOutputSha256"],
        sha256(candidate.json().as_bytes())
    );
    assert_eq!(checked["batchSha256"], sha256(batch.to_string().as_bytes()));
    let mut empty = batch;
    empty["rows"] = json!([]);
    assert!(
        inspect_guarded_graph_result(&inspection(&raw, candidate.json(), empty).to_string())
            .is_ok()
    );
}
#[test]
fn complete_guarded_result_refuses_changed_producer_source_or_later_withheld_value() {
    let raw = request("SELECT r.resourceId, r.salary FROM Resource r");
    let candidate = prepare_guarded_graph_candidate(&raw).unwrap();
    let batch = json!({"version":"weft.security.cells/0.1.0","resultContractSha256":candidate.query().value()["resultContractSha256"],"rows":[[{"outcomeId":"original","disposition":"original","value":{"string":"RA"}},{"outcomeId":"withheld","disposition":"withheld"}]]});
    let positional=json!(["weft.truss.security.guarded-result/0.1-candidate",raw,candidate.json(),batch.to_string()]);
    assert!(inspect_guarded_graph_result(&positional.to_string()).is_err());
    for mutation in 0..9 {
        let mut input = inspection(&raw, candidate.json(), batch.clone());
        match mutation {
            0 => input["sourceOutputJson"] = json!(candidate.json().trim_end()),
            1 => {
                let mut changed: Value = serde_json::from_str(candidate.json()).unwrap();
                changed["query"]["execution"]["sql"] = json!("SELECT 1");
                input["sourceOutputJson"] = json!(format!("{changed}\n"));
            }
            2 => {
                let mut changed: Value = serde_json::from_str(candidate.json()).unwrap();
                changed["policyParameterBindings"][0]["ordinal"] = json!(2);
                input["sourceOutputJson"] = json!(format!("{changed}\n"));
            }
            3 => {
                let mut changed: Value = serde_json::from_str(candidate.json()).unwrap();
                changed["sourceContextJson"] = json!("{}");
                input["sourceOutputJson"] = json!(format!("{changed}\n"));
            }
            4 => input["sourceRequestJson"] = json!(format!("{raw} ")),
            5 => {
                let mut corrupt = batch.clone();
                let mut row = corrupt["rows"][0].clone();
                row[1]["value"] = json!({"integerToken":"100"});
                corrupt["rows"].as_array_mut().unwrap().push(row);
                input["batchJson"] = json!(corrupt.to_string());
            }
            6 => input["permit"] = json!(true),
            7 => input["version"] = json!("weft.truss.security.graph-result/0.1-candidate"),
            _ => {
                let mut changed: Value = serde_json::from_str(candidate.json()).unwrap();
                changed["subjectParameterBinding"]["value"] = json!(1);
                input["sourceOutputJson"] = json!(format!("{changed}\n"));
            }
        };
        assert!(
            inspect_guarded_graph_result(&input.to_string()).is_err(),
            "mutation {mutation}"
        );
    }
}
#[test]
fn unsupported_queries_and_injected_authority_inputs_cannot_prepare_handoff() {
    for sql in [
        "SELECT COUNT(*) FROM Resource r",
        "SELECT r.resourceId FROM Resource r WHERE r.resourceId='RA'",
        "SELECT r.resourceId FROM Resource r ORDER BY r.resourceId",
    ] {
        assert!(prepare_guarded_graph_candidate(&request(sql)).is_err());
    }
    for injected in ["subject", "epoch", "permit", "nativeAdmission"] {
        let mut raw: Value =
            serde_json::from_str(&request("SELECT r.resourceId FROM Resource r")).unwrap();
        raw[injected] = json!(true);
        assert!(prepare_guarded_graph_candidate(&raw.to_string()).is_err());
    }
    let candidate =
        prepare_guarded_graph_candidate(&request("SELECT r.resourceId FROM Resource r")).unwrap();
    assert!(
        weft_core::security_backend::validate_security_manifest_json(candidate.json()).is_err()
    );
    assert!(weft_core::backend::validate_manifest_json(candidate.json()).is_err());
    let refused: Value = serde_json::from_str(
        &weft_core::compile::Compiler::default().compile_json(candidate.json()),
    )
    .unwrap();
    assert_eq!(refused["status"], "blocked");
    assert!(refused.get("sql").is_none());
}
fn query_use_request(sql:&str,mode:Option<&str>,grant:bool)->String {
 let mut request:Value=serde_json::from_str(&request(sql)).unwrap();
 if let Some(mode)=mode {
  let mut ontology:Value=serde_json::from_str(request["ontologyJson"].as_str().unwrap()).unwrap();let resource=ontology["entities"].as_array_mut().unwrap().iter_mut().find(|e|e["type"]["elementId"]=="Resource").unwrap();let salary=resource["fields"].as_array_mut().unwrap().iter_mut().find(|f|f["ref"]["elementId"]=="salary").unwrap();
  salary["queryUse"]=json!({"predicate":mode,"order":mode,"group":mode,"join":mode,"aggregate":mode});
  let mut policy:Value=serde_json::from_str(request["policyJson"].as_str().unwrap()).unwrap();
  let mut profile:Value=serde_json::from_str(request["queryProfileJson"].as_str().unwrap()).unwrap();
  if mode=="original-authorized" {
   ontology["actions"].as_array_mut().unwrap().push(json!("query-original"));
   if grant {policy["rules"].as_array_mut().unwrap().push(json!({"id":"original-access","effect":"permit","actions":["query-original"],"target":[{"documentId":"domain","moduleId":"m","elementId":"Resource"}],"condition":{"op":"literal","value":true}}));}
   profile["bindings"]=json!(["predicate","order","group","join","aggregate"].into_iter().map(|op|json!({"target":{"documentId":"domain","moduleId":"m","elementId":"Resource"},"field":{"documentId":"domain","moduleId":"m","elementId":"salary"},"operator":op,"originalAction":"query-original"})).collect::<Vec<_>>());
  }
  let mut source:GraphSource=serde_json::from_str(request["bindingJson"].as_str().unwrap()).unwrap();let mut resolution:Value=serde_json::from_str(&source.logical_resolution_json).unwrap();resolution["ontology"]=ontology.clone();source.logical_resolution_json=resolution.to_string();
  let ontology_bytes=ontology.to_string();let policy_bytes=policy.to_string();request["ontologyJson"]=json!(ontology_bytes);request["policyJson"]=json!(policy_bytes);
  let mut correspondence:Value=serde_json::from_str(&source.correspondence_json).unwrap();correspondence["logicalSourceDigests"]["resolution"]=json!(sha256(source.logical_resolution_json.as_bytes()));correspondence["logicalSourceDigests"]["policy"]=json!(sha256(policy_bytes.as_bytes()));source.correspondence_json=correspondence.to_string();let binding=serde_json::to_string(&source).unwrap();request["bindingJson"]=json!(binding);
  profile["ontologySha256"]=json!(sha256(ontology_bytes.as_bytes()));profile["policySha256"]=json!(sha256(policy_bytes.as_bytes()));profile["binding"]["sha256"]=json!(sha256(binding.as_bytes()));request["queryProfileJson"]=json!(profile.to_string());
 }
 request.to_string()
}
#[test]
fn query_use_guards_keep_all_five_operators_and_both_join_scan_occurrences() {
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_ir::QueryOperator};
 use weft_postgresql::security_query_use_guards::prepare_graph_query_use_guards;
 let raw=query_use_request("SELECT r.salary, SUM(s.salary) FROM Resource r JOIN Resource s ON r.salary=s.salary WHERE r.salary=100 GROUP BY r.salary ORDER BY r.salary",Some("disclosed"),false);
 with_security_mapping_context(&raw,|ctx|{
  let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let guards=prepare_graph_query_use_guards(ctx,&source)?;assert_eq!(guards.scans().len(),2);assert_eq!(guards.context_sha256(),ctx.execution_query_context_sha256());
  let ops=guards.scans().iter().flat_map(|s|s.uses()).map(|u|u.operator()).collect::<std::collections::BTreeSet<_>>();assert_eq!(ops,std::collections::BTreeSet::from([QueryOperator::Predicate,QueryOperator::Order,QueryOperator::Group,QueryOperator::Join,QueryOperator::Aggregate]));
  for scan in guards.scans(){assert!(scan.uses().iter().any(|u|u.operator()==QueryOperator::Join));assert!(scan.refusal_expression().contains("IN ('original','transformed','absent')) IS NOT TRUE"));assert!(scan.refusal_expression().contains("WHEN"));assert_eq!(scan.rule_truths().len(),2);}
  assert_ne!(guards.scans()[0].scan(),guards.scans()[1].scan());Ok(())
 }).unwrap();
}
#[test]
fn original_query_action_is_exact_and_missing_grant_refuses_before_query_filters() {
 use weft_core::security_mapping_transport::with_security_mapping_context;
 use weft_postgresql::security_query_use_guards::prepare_graph_query_use_guards;
 for granted in [false,true] {
  let raw=query_use_request("SELECT r.resourceId FROM Resource r WHERE r.salary=100",Some("original-authorized"),granted);
  with_security_mapping_context(&raw,|ctx|{
   let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let guards=prepare_graph_query_use_guards(ctx,&source)?;let scan=&guards.scans()[0];assert!(scan.actions().iter().any(|a|a=="query-original"));assert_eq!(scan.uses()[0].original_action(),Some("query-original"));
   if granted {assert_eq!(scan.rule_truths().len(),3);assert!(scan.refusal_expression().contains("IS DISTINCT FROM 'permit'"));}else{assert_eq!(scan.rule_truths().len(),2);assert!(scan.refusal_expression().contains("THEN (TRUE)"));}
   // Guard derivation cannot activate the still-unsupported relational candidate.
   assert!(prepare_guarded_graph_candidate(&raw).is_err());Ok(())
  }).unwrap();
 }
}
#[test]
fn prohibited_and_foreign_sources_never_produce_query_use_guards() {
 use weft_core::security_mapping_transport::with_security_mapping_context;
 use weft_postgresql::security_query_use_guards::prepare_graph_query_use_guards;
 let prohibited=query_use_request("SELECT r.resourceId FROM Resource r WHERE r.salary=100",None,false);assert!(with_security_mapping_context(&prohibited,|_|Ok(())).is_err());
 let raw=query_use_request("SELECT r.resourceId FROM Resource r WHERE r.resourceId='RA'",None,false);
 with_security_mapping_context(&raw,|ctx|{let mut source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();source.native_schema_revision="2".into();assert!(prepare_graph_query_use_guards(ctx,&source).is_err());Ok(())}).unwrap();
}
fn aggregate_contract(ctx:&weft_core::security_backend::SecurityBackendContext<'_>)->weft_core::security_lowering::SecurityResultContract {
 use weft_core::{application_ir::Expression,security_lowering::*};
 SecurityResultContract{version:weft_core::security_aggregate_results::VERSION.into(),encoding:"weft.security.cells/0.2-candidate".into(),columns:ctx.requirements().outputs().iter().map(|output|{
 if let Expression::Field{identity,..}=&output.output().expression {
 let identity=SecurityIdentity{document_id:identity.document_id.clone(),revision:identity.revision.clone(),module:identity.module.clone(),element:identity.element.clone()};
 return SecurityResultColumn{position:output.position(),output_name:output.output().name.clone(),source_fields:vec![identity.clone()],outcomes:vec![SecurityResultOutcome::Original{id:"original".into(),domain:SecurityResultDomain::Model{field:identity}}]};
 }
 let (t,source)=match &output.output().expression{Expression::Count{logical_type}=>(logical_type,None),Expression::Sum{argument,logical_type}=>(logical_type,Some(&argument.identity)),_=>panic!("aggregate fixture")};
 SecurityResultColumn{position:output.position(),output_name:output.output().name.clone(),source_fields:source.into_iter().map(|i|SecurityIdentity{document_id:i.document_id.clone(),revision:i.revision.clone(),module:i.module.clone(),element:i.element.clone()}).collect(),outcomes:vec![SecurityResultOutcome::Computed{id:"computed".into(),domain:SecurityResultDomain::Scalar{r#type:weft_core::security_aggregate_results::aggregate_result_type(ctx,output.output()).unwrap()}}]}
 }).collect()}
}
#[test]
fn aggregate_result_candidate_preserves_derived_domains_and_old_contract_refusals(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_aggregate_results::*,security_lowering::*};
 let raw=query_use_request("SELECT COUNT(*), SUM(r.salary) FROM Resource r",Some("original-authorized"),true);
 with_security_mapping_context(&raw,|ctx|{
 let mut contract=aggregate_contract(ctx);check_aggregate_result_declaration(ctx,&contract)?;
 assert!(ctx.check_result_declaration(&contract).is_err());
 let text=serde_json::to_string(&contract).unwrap();let hash=sha256(text.as_bytes());
 let batch=|count:Value,sum:Value|json!({"version":"weft.security.cells/0.2-candidate","resultContractSha256":hash,"rows":[[{"outcomeId":"computed","disposition":"computed","value":count},{"outcomeId":"computed","disposition":"computed","value":sum}]]}).to_string();
 for (count,sum) in [(json!({"integerToken":"0"}),Value::Null),(json!({"integerToken":"123456789012345678901234567890"}),json!({"integerToken":"-100000000000000000000000000000"}))]{let batch=batch(count,sum);check_aggregate_result_cells(ctx,&contract,&text,&hash,&batch)?;assert!(ctx.check_result_cells(&contract,&text,&hash,&batch).is_err());}
 for (count,sum) in [(json!({"integerToken":"-1"}),Value::Null),(Value::Null,Value::Null),(json!({"integerToken":"1.5"}),Value::Null),(json!({"integerToken":"1"}),json!({"decimalToken":"1"})),(json!({"integerToken":"1"}),json!({"integerToken":"1","extra":true}))]{assert!(check_aggregate_result_cells(ctx,&contract,&text,&hash,&batch(count,sum)).is_err());}
 contract.version="weft.security.result-contract/0.1.0".into();assert!(check_aggregate_result_declaration(ctx,&contract).is_err());assert!(ctx.check_result_declaration(&contract).is_err());
 contract.version=VERSION.into();if let SecurityResultOutcome::Computed{domain:SecurityResultDomain::Scalar{r#type:t},..}=&mut contract.columns[1].outcomes[0]{t.facets=json!({"range":{"min":{"integerToken":"0"}}});}assert!(check_aggregate_result_declaration(ctx,&contract).is_err());Ok(())
 }).unwrap();
}
#[test]
fn grouped_sum_rejects_null_and_changed_input_lineage(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_aggregate_results::*};
 let raw=query_use_request("SELECT SUM(r.salary) FROM Resource r GROUP BY r.resourceId",Some("original-authorized"),true);
 with_security_mapping_context(&raw,|ctx|{
 let mut contract=aggregate_contract(ctx);check_aggregate_result_declaration(ctx,&contract)?;let text=serde_json::to_string(&contract).unwrap();let hash=sha256(text.as_bytes());
 let batch=json!({"version":"weft.security.cells/0.2-candidate","resultContractSha256":hash,"rows":[[{"outcomeId":"computed","disposition":"computed","value":null}]]}).to_string();assert!(check_aggregate_result_cells(ctx,&contract,&text,&hash,&batch).is_err());
 contract.columns[0].source_fields[0].element="resourceId".into();assert!(check_aggregate_result_declaration(ctx,&contract).is_err());Ok(())
 }).unwrap();
}

#[test]
fn mixed_aggregate_contract_keeps_direct_disclosure_and_computed_outputs_distinct(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_aggregate_results::*};
 let raw=query_use_request("SELECT r.resourceId, COUNT(*) FROM Resource r GROUP BY r.resourceId",None,false);
 with_security_mapping_context(&raw,|ctx|{
 let contract=aggregate_contract(ctx);check_aggregate_result_declaration(ctx,&contract)?;let text=serde_json::to_string(&contract).unwrap();let hash=sha256(text.as_bytes());
 let mut batch=json!({"version":ENCODING,"resultContractSha256":hash,"rows":[[{"outcomeId":"original","disposition":"original","value":{"string":"RA"}},{"outcomeId":"computed","disposition":"computed","value":{"integerToken":"1"}}]]});
 check_aggregate_result_cells(ctx,&contract,&text,&hash,&batch.to_string())?;
 batch["rows"][0][0]["disposition"]=json!("computed");assert!(check_aggregate_result_cells(ctx,&contract,&text,&hash,&batch.to_string()).is_err());
 batch["rows"][0][0]["disposition"]=json!("original");batch["rows"][0][1]["outcomeId"]=json!("original");assert!(check_aggregate_result_cells(ctx,&contract,&text,&hash,&batch.to_string()).is_err());Ok(())
 }).unwrap();
}
#[test]
fn relational_parameters_keep_repeated_named_values_distinct_from_policy_and_subject(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,application_ir::Value as QueryValue};
 use weft_postgresql::security_relational_parameters::*;
 let mut raw:Value=serde_json::from_str(&query_use_request("SELECT r.resourceId FROM Resource r WHERE r.resourceId=:id AND r.resourceId=:id",None,false)).unwrap();
 let hostile="RA'; SELECT secret FROM private_table; --";
 raw["parameters"]=json!({"id":{"family":"string","value":hostile}});
 with_security_mapping_context(&raw.to_string(),|ctx|{
 let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let bindings=prepare_relational_graph_parameters(ctx,&source)?;bindings.require_context(ctx)?;
 assert_eq!(bindings.graph().policy().len(),1);assert_eq!(bindings.policy_values(),&[json!(true)]);assert_eq!(bindings.graph().subject().ordinal(),2);assert_eq!(bindings.query().len(),2);
 for (i,p) in bindings.query().iter().enumerate(){assert_eq!(p.ordinal(),3+i);assert_eq!(p.codec(),RelationalQueryParameterCodec::Text);assert_eq!(p.source_path(),format!("filters/{i}/right"));assert!(matches!(p.value(),QueryValue::Parameter{name,value,..} if name=="id"&&value==hostile));}
 // Old direct graph producer still refuses query slots, not reclassifying them.
 assert!(prepare_guarded_graph_candidate(&raw.to_string()).is_err());
 with_security_mapping_context(&raw.to_string(),|other|{assert!(bindings.require_context(other).is_err());Ok(())})?;
 Ok(())
 }).unwrap();
}
#[test]
fn relational_parameters_preserve_numeric_literals_keyset_order_and_join_occurrences(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,application_ir::Value as QueryValue};use weft_postgresql::security_relational_parameters::*;
 let raw=query_use_request("SELECT r.resourceId FROM Resource r JOIN Resource s ON r.salary=s.salary WHERE r.salary=100 AND s.salary=200",Some("original-authorized"),true);
 with_security_mapping_context(&raw,|ctx|{
 let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let p=prepare_relational_graph_parameters(ctx,&source)?;assert_eq!(p.query().len(),2);
 for (binding,path,value) in [( &p.query()[0],"filters/0/right","100"),(&p.query()[1],"filters/1/right","200")]{assert_eq!(binding.codec(),RelationalQueryParameterCodec::Numeric);assert_eq!(binding.source_path(),path);assert!(matches!(binding.value(),QueryValue::Literal{value:v,..} if v==value));}Ok(())
 }).unwrap();
 let raw=query_use_request("SELECT r.resourceId FROM Resource r WHERE (r.resourceId)>('RA') ORDER BY r.resourceId LIMIT 1",None,false);
 with_security_mapping_context(&raw,|ctx|{let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let p=prepare_relational_graph_parameters(ctx,&source)?;assert_eq!(p.query()[0].source_path(),"filters/0/values/0");assert_eq!(p.query()[0].ordinal(),3);Ok(())}).unwrap();
}
#[test]
fn relational_parameters_refuse_foreign_graph_sources_without_binding_native_subject(){
 use weft_core::security_mapping_transport::with_security_mapping_context;use weft_postgresql::security_relational_parameters::*;
 let raw=query_use_request("SELECT COUNT(*) FROM Resource r",None,false);
 with_security_mapping_context(&raw,|ctx|{let mut source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let p=prepare_relational_graph_parameters(ctx,&source)?;assert!(p.query().is_empty());assert_eq!(p.graph().subject().ordinal(),2);source.native_schema_revision="2".into();assert!(prepare_relational_graph_parameters(ctx,&source).is_err());Ok(())}).unwrap();
}
#[test]
fn relational_sql_emits_all_owner_stages_with_pre_query_guards_and_computed_lineage(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_ir::QueryOperator};use weft_postgresql::security_relational_sql::prepare_relational_graph_sql;
 let raw=query_use_request("SELECT r.salary, SUM(s.salary), COUNT(*) FROM Resource r JOIN Resource s ON r.salary=s.salary WHERE r.salary=100 GROUP BY r.salary ORDER BY r.salary LIMIT 1",Some("original-authorized"),true);
 with_security_mapping_context(&raw,|ctx|{
 let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let plan=prepare_relational_graph_sql(ctx,&source)?;
 for fragment in ["AS MATERIALIZED","JOIN a1 ON","WHERE (","GROUP BY","pg_catalog.sum(","pg_catalog.count(*)","ORDER BY","LIMIT 1","'computed'"]{assert!(plan.sql().contains(fragment),"{fragment}");}
 assert!(plan.checks().iter().filter(|c|c["failureCode"]=="WFT-SECURITY-QUERY-USE").count()==2);
 assert!(plan.checks().iter().any(|c|c["failureCode"]=="WFT-SECURITY-GROUP-DISCLOSURE"));
 let ops=plan.operand_demands().iter().map(|o|serde_json::from_value::<QueryOperator>(o["operator"].clone()).unwrap()).collect::<std::collections::BTreeSet<_>>();assert_eq!(ops.len(),5);
 assert_eq!(plan.result_contract().version,weft_core::security_aggregate_results::VERSION);assert_eq!(plan.result_contract().columns.len(),3);
 assert_eq!(plan.parameters().query().len(),1);assert_eq!(plan.parameters().query()[0].ordinal(),3);assert!(plan.sql().contains("$3::pg_catalog.numeric"));
 assert!(ctx.check_result_declaration(plan.result_contract()).is_err());assert!(prepare_guarded_graph_candidate(&raw).is_err());Ok(())
 }).unwrap();
}
#[test]
fn relational_sql_keeps_named_input_out_of_sql_and_retains_query_only_operand_guards(){
 use weft_core::security_mapping_transport::with_security_mapping_context;use weft_postgresql::security_relational_sql::prepare_relational_graph_sql;
 let mut raw:Value=serde_json::from_str(&query_use_request("SELECT r.resourceId FROM Resource r WHERE r.resourceId=:id ORDER BY r.resourceId LIMIT 2",None,false)).unwrap();let hostile="RA';SELECT private_password;--";raw["parameters"]=json!({"id":{"family":"string","value":hostile}});
 with_security_mapping_context(&raw.to_string(),|ctx|{let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let plan=prepare_relational_graph_sql(ctx,&source)?;assert!(!plan.sql().contains(hostile));assert!(plan.sql().contains("$3::pg_catalog.text"));assert_eq!(plan.result_contract().columns.len(),1);assert_eq!(plan.operand_demands().len(),2);assert_eq!(plan.result_contract().version,"weft.security.result-contract/0.1.0");ctx.check_result_declaration(plan.result_contract())?;assert!(plan.checks().iter().all(|c|c["sql"].as_str().unwrap().contains("parameter_types AS")));Ok(())}).unwrap();
}
#[test]
fn relational_sql_count_preserves_subject_and_rule_checks_without_fabricated_field_operands(){
 use weft_core::security_mapping_transport::with_security_mapping_context;use weft_postgresql::security_relational_sql::prepare_relational_graph_sql;
 let raw=query_use_request("SELECT COUNT(*) FROM Resource r",None,false);
 with_security_mapping_context(&raw,|ctx|{let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let plan=prepare_relational_graph_sql(ctx,&source)?;assert!(plan.operand_demands().is_empty());assert!(plan.parameters().query().is_empty());assert!(plan.result_contract().columns[0].source_fields.is_empty());assert!(plan.checks().iter().any(|c|c["failureCode"]=="WFT-SECURITY-SUBJECT"));assert!(plan.checks().iter().any(|c|c["failureCode"]=="WFT-SECURITY-QUERY-USE"));assert!(!plan.sql().contains("GROUP BY"));Ok(())}).unwrap();
}
#[test]
fn relational_boolean_group_order_uses_bool_or_and_keeps_absence_key(){
 use weft_core::security_mapping_transport::with_security_mapping_context;use weft_postgresql::security_relational_sql::prepare_relational_graph_sql;
 let mut raw:Value=serde_json::from_str(&query_use_request("SELECT a.active,COUNT(*) FROM Assignment a GROUP BY a.active ORDER BY a.active",None,false)).unwrap();
 let assignment=json!({"documentId":"domain","moduleId":"m","elementId":"Assignment"});let mut policy:Value=serde_json::from_str(raw["policyJson"].as_str().unwrap()).unwrap();policy["rules"]=json!([{"id":"read-assignment","effect":"permit","actions":["read"],"target":[assignment],"condition":{"op":"literal","value":true}}]);raw["policyJson"]=json!(policy.to_string());
 let mut source:GraphSource=serde_json::from_str(raw["bindingJson"].as_str().unwrap()).unwrap();let mut correspondence:Value=serde_json::from_str(&source.correspondence_json).unwrap();correspondence["logicalSourceDigests"]["policy"]=json!(sha256(policy.to_string().as_bytes()));source.correspondence_json=correspondence.to_string();raw["bindingJson"]=json!(serde_json::to_string(&source).unwrap());
 let mut profile:Value=serde_json::from_str(raw["queryProfileJson"].as_str().unwrap()).unwrap();profile["targets"]=json!([assignment]);profile["policySha256"]=json!(sha256(policy.to_string().as_bytes()));profile["binding"]["sha256"]=json!(sha256(raw["bindingJson"].as_str().unwrap().as_bytes()));raw["queryProfileJson"]=json!(profile.to_string());
 with_security_mapping_context(&raw.to_string(),|ctx|{let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let p=prepare_relational_graph_sql(ctx,&source)?;assert!(p.sql().contains("ROW(("));assert!(p.sql().contains("ORDER BY pg_catalog.bool_or("));assert!(!p.sql().contains("pg_catalog.min("));assert!(p.checks().iter().find(|c|c["failureCode"]=="WFT-SECURITY-GROUP-DISCLOSURE").unwrap()["sql"].as_str().unwrap().contains("IS NULL"));Ok(())}).unwrap();
}
#[test]
fn relational_disclosed_cross_family_transform_refuses_before_silent_null_conversion(){
 use weft_core::security_mapping_transport::with_security_mapping_context;use weft_postgresql::security_relational_sql::prepare_relational_graph_sql;
 let mut raw:Value=serde_json::from_str(&query_use_request("SELECT COUNT(*) FROM Resource r WHERE r.salary=100",Some("disclosed"),false)).unwrap();let mut policy:Value=serde_json::from_str(raw["policyJson"].as_str().unwrap()).unwrap();policy["rules"][0]["disclosure"][0]["disposition"]=json!({"kind":"transformed","transform":"constant","version":"0.1.0","field":{"documentId":"domain","moduleId":"m","elementId":"resourceId"},"value":{"string":"redacted"}});raw["policyJson"]=json!(policy.to_string());
 let mut source:GraphSource=serde_json::from_str(raw["bindingJson"].as_str().unwrap()).unwrap();let mut correspondence:Value=serde_json::from_str(&source.correspondence_json).unwrap();correspondence["logicalSourceDigests"]["policy"]=json!(sha256(policy.to_string().as_bytes()));source.correspondence_json=correspondence.to_string();raw["bindingJson"]=json!(serde_json::to_string(&source).unwrap());
 let mut profile:Value=serde_json::from_str(raw["queryProfileJson"].as_str().unwrap()).unwrap();profile["policySha256"]=json!(sha256(policy.to_string().as_bytes()));profile["binding"]["sha256"]=json!(sha256(raw["bindingJson"].as_str().unwrap().as_bytes()));raw["queryProfileJson"]=json!(profile.to_string());
 with_security_mapping_context(&raw.to_string(),|ctx|{let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();assert!(prepare_relational_graph_sql(ctx,&source).is_err());Ok(())}).unwrap();
}
#[test]
fn operand_values_refuse_invalid_later_rows_missing_occurrences_and_foreign_context(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_operand_values::*};use weft_postgresql::security_relational_sql::prepare_relational_graph_sql;
 let raw=query_use_request("SELECT COUNT(*) FROM Resource r WHERE r.salary=999",Some("original-authorized"),true);
 with_security_mapping_context(&raw,|ctx|{
 let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let plan=prepare_relational_graph_sql(ctx,&source)?;assert_eq!(plan.operand_reads().len(),1);let sql=plan.operand_reads()[0]["sql"].as_str().unwrap();assert!(sql.contains("LIMIT 4097"));assert!(!sql.contains("integerToken')::pg_catalog.numeric"));
 let mut batch=json!({"version":VERSION,"contextSha256":ctx.execution_query_context_sha256(),"scans":[{"scan":"s0","rows":[{"nativeRowId":"2","operands":[{"index":0,"cell":{"disposition":"original","value":{"integerToken":"100"}}}]}]}]});
 let checked=check_operand_values(ctx,&batch.to_string())?;assert_eq!(checked.counts()["s0"],1);
 let mut large=batch.clone();large["scans"][0]["rows"][0]["operands"][0]["cell"]["value"]=json!({"integerToken":"9223372036854775808"});check_operand_values(ctx,&large.to_string())?;
 for value in [json!({"integerToken":"not a number"}),json!({"integerToken":"1.5"}),Value::Null]{let mut bad=batch.clone();bad["scans"][0]["rows"].as_array_mut().unwrap().push(json!({"nativeRowId":"3","operands":[{"index":0,"cell":{"disposition":"original","value":value}}]}));assert!(check_operand_values(ctx,&bad.to_string()).is_err());}
 for mutation in 0..6{let mut bad=batch.clone();match mutation{0=>bad["scans"][0]["rows"][0]["operands"]=json!([]),1=>bad["scans"][0]["rows"][0]["operands"][0]["index"]=json!(1),2=>bad["contextSha256"]=json!("0".repeat(64)),3=>bad["nativeAdmission"]=json!(true),4=>bad["scans"][0]["rows"][0]["operands"][0]["cell"]=json!({"disposition":"absent"}),_=>{let row=bad["scans"][0]["rows"][0].clone();bad["scans"][0]["rows"].as_array_mut().unwrap().push(row)}};assert!(check_operand_values(ctx,&bad.to_string()).is_err());}
 batch["scans"][0]["rows"]=json!([]);assert_eq!(check_operand_values(ctx,&batch.to_string())?.counts()["s0"],0);
 Ok(())
 }).unwrap();
}
#[test]
fn operand_value_checks_cover_every_operator_occurrence_on_both_scans(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_operand_values::*};
 let raw=query_use_request("SELECT SUM(s.salary) FROM Resource r JOIN Resource s ON r.salary=s.salary WHERE r.salary=100 GROUP BY r.salary ORDER BY r.salary",Some("original-authorized"),true);
 with_security_mapping_context(&raw,|ctx|{
 let scans=ctx.requirements().scans().iter().map(|scan|{let cells=ctx.requirements().operators().iter().enumerate().filter(|(_,o)|o.usage().scan==scan.inventory().scan()).map(|(i,_)|json!({"index":i,"cell":{"disposition":"original","value":{"integerToken":"100"}}})).collect::<Vec<_>>();json!({"scan":scan.inventory().scan(),"rows":[{"nativeRowId":"2","operands":cells}]})}).collect::<Vec<_>>();
 let mut batch=json!({"version":VERSION,"contextSha256":ctx.execution_query_context_sha256(),"scans":scans});assert_eq!(check_operand_values(ctx,&batch.to_string())?.counts().len(),2);batch["scans"][1]["rows"][0]["operands"].as_array_mut().unwrap().pop();assert!(check_operand_values(ctx,&batch.to_string()).is_err());Ok(())
 }).unwrap();
}
#[test]
fn operand_transform_values_require_original_constant_rule_and_exact_domain(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_operand_values::*};use weft_postgresql::security_relational_sql::prepare_relational_graph_sql;
 let mut raw:Value=serde_json::from_str(&query_use_request("SELECT COUNT(*) FROM Resource r WHERE r.salary=7",Some("disclosed"),false)).unwrap();let mut policy:Value=serde_json::from_str(raw["policyJson"].as_str().unwrap()).unwrap();let rule=policy["rules"][0]["id"].as_str().unwrap().to_string();policy["rules"][0]["disclosure"][0]["disposition"]=json!({"kind":"transformed","transform":"constant","version":"0.1.0","field":{"documentId":"domain","moduleId":"m","elementId":"salary"},"value":{"integerToken":"7"}});raw["policyJson"]=json!(policy.to_string());
 let mut source:GraphSource=serde_json::from_str(raw["bindingJson"].as_str().unwrap()).unwrap();let mut correspondence:Value=serde_json::from_str(&source.correspondence_json).unwrap();correspondence["logicalSourceDigests"]["policy"]=json!(sha256(policy.to_string().as_bytes()));source.correspondence_json=correspondence.to_string();raw["bindingJson"]=json!(serde_json::to_string(&source).unwrap());let mut profile:Value=serde_json::from_str(raw["queryProfileJson"].as_str().unwrap()).unwrap();profile["policySha256"]=json!(sha256(policy.to_string().as_bytes()));profile["binding"]["sha256"]=json!(sha256(raw["bindingJson"].as_str().unwrap().as_bytes()));raw["queryProfileJson"]=json!(profile.to_string());
 with_security_mapping_context(&raw.to_string(),|ctx|{let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let plan=prepare_relational_graph_sql(ctx,&source)?;assert!(plan.operand_reads()[0]["sql"].as_str().unwrap().contains("'ruleId'"));let batch=json!({"version":VERSION,"contextSha256":ctx.execution_query_context_sha256(),"scans":[{"scan":"s0","rows":[{"nativeRowId":"2","operands":[{"index":0,"cell":{"disposition":"transformed","ruleId":rule,"value":{"integerToken":"7e0"}}}]}]}]});check_operand_values(ctx,&batch.to_string())?;
 for mutation in 0..4{let mut bad=batch.clone();let cell=&mut bad["scans"][0]["rows"][0]["operands"][0]["cell"];match mutation{0=>cell["value"]=json!({"integerToken":"8"}),1=>cell["ruleId"]=json!("foreign"),2=>cell["disposition"]=json!("withheld"),_=>cell["nativePermit"]=json!(true)}assert!(check_operand_values(ctx,&bad.to_string()).is_err());}Ok(())}).unwrap();
}
#[test]
fn separate_relational_handoff_checks_original_operands_results_and_rejects_old_versions(){
 use weft_core::security_mapping_transport::with_security_mapping_context;use weft_postgresql::security_relational_transport::*;
 let raw=query_use_request("SELECT COUNT(*), SUM(r.salary) FROM Resource r WHERE r.salary=100",Some("original-authorized"),true);let candidate=prepare_guarded_relational_candidate(&raw).unwrap();let wire:Value=serde_json::from_str(candidate.json()).unwrap();assert_eq!(wire["version"],"weft.truss.security.relational-candidate/0.2-candidate");assert_eq!(wire["securityReady"],false);assert!(candidate.json().ends_with('\n'));assert_eq!(wire["parameters"][1]["channel"],"subject");assert!(wire["parameters"][1].get("value").is_none());assert_eq!(wire["parameters"][2]["channel"],"query");
 let operands=json!({"version":"weft.security.operand-values/0.1-candidate","contextSha256":wire["queryContextSha256"],"scans":[{"scan":"s0","rows":[{"nativeRowId":"2","operands":[{"index":0,"cell":{"disposition":"original","value":{"integerToken":"100"}}},{"index":1,"cell":{"disposition":"original","value":{"integerToken":"100"}}}]}]}]});
 let batch=json!({"version":"weft.security.cells/0.2-candidate","resultContractSha256":wire["resultContractSha256"],"rows":[[{"outcomeId":"computed","disposition":"computed","value":{"integerToken":"1"}},{"outcomeId":"computed","disposition":"computed","value":{"integerToken":"100"}}]]});
 let input=json!({"version":"weft.truss.security.relational-result/0.2-candidate","sourceRequestJson":raw,"sourceOutputJson":candidate.json(),"operandBatchJson":operands.to_string(),"batchJson":batch.to_string()});let inspected=inspect_guarded_relational_result(&input.to_string()).unwrap();assert_eq!(inspected["securityReady"],false);assert_eq!(inspected["operandCounts"]["s0"],1);
 assert!(inspect_guarded_graph_result(&input.to_string()).is_err());assert!(weft_core::security_backend::validate_security_manifest_json(candidate.json()).is_err());
 with_security_mapping_context(&raw,|ctx|{let contract=weft_postgresql::security_relational_sql::prepare_relational_graph_sql(ctx,&serde_json::from_str(ctx.binding_json()).unwrap())?;assert!(ctx.check_result_declaration(contract.result_contract()).is_err());Ok(())}).unwrap();
 for mutation in 0..8{let mut bad=input.clone();match mutation{0=>{let mut altered=wire.clone();altered["executionSql"]=json!("SELECT secret");bad["sourceOutputJson"]=json!(altered.to_string()+"\n");},1=>bad["sourceOutputJson"]=json!(candidate.json().trim_end()),2=>bad["sourceRequestJson"]=json!(raw.clone()+" "),3=>bad["nativeAdmission"]=json!(true),4=>bad["version"]=json!("weft.truss.security.guarded-result/0.1-candidate"),5=>{let mut altered=operands.clone();altered["scans"][0]["rows"][0]["operands"][1]["cell"]["value"]=json!({"integerToken":"bad"});bad["operandBatchJson"]=json!(altered.to_string());},6=>{let mut altered=batch.clone();altered["rows"][0][1]["value"]=json!({"decimalToken":"100"});bad["batchJson"]=json!(altered.to_string());},_=>{let mut altered=wire.clone();altered["parameters"][1]["value"]=json!(1);bad["sourceOutputJson"]=json!(altered.to_string()+"\n");}}assert!(inspect_guarded_relational_result(&bad.to_string()).is_err(),"mutation {mutation}");}
 assert!(inspect_guarded_relational_result(&json!([input["version"],input["sourceRequestJson"],input["sourceOutputJson"],input["operandBatchJson"],input["batchJson"]]).to_string()).is_err());
}
#[test]
fn postgresql_codec_checks_refuse_nul_and_native_numeric_overflow_without_narrowing_umf(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_operand_values::*};use weft_postgresql::security_native_codecs::*;
 for value in ["雪'","x\0y"]{let mut raw:Value=serde_json::from_str(&query_use_request("SELECT r.resourceId FROM Resource r WHERE r.resourceId=:id",None,false)).unwrap();raw["parameters"]=json!({"id":{"family":"string","value":value}});let result=with_security_mapping_context(&raw.to_string(),|ctx|{let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();check_postgresql_parameter_codecs(ctx,&source)?;Ok(())});assert_eq!(result.is_ok(),!value.contains('\0'));}
 let raw=query_use_request("SELECT COUNT(*) FROM Resource r WHERE r.salary=100",Some("original-authorized"),true);
 with_security_mapping_context(&raw,|ctx|{let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let batch=|token:&str|json!({"version":VERSION,"contextSha256":ctx.execution_query_context_sha256(),"scans":[{"scan":"s0","rows":[{"nativeRowId":"2","operands":[{"index":0,"cell":{"disposition":"original","value":{"integerToken":token}}}]}]}]}).to_string();
 for (token,native) in [("9223372036854775808",true),("1e131071",true),("1e131072",false)]{let raw=batch(token);check_operand_values(ctx,&raw)?;assert_eq!(check_postgresql_operand_codecs(ctx,&source,&raw).is_ok(),native);}
 Ok(())}).unwrap();
}
fn nullable_salary_request(raw:&str)->String{
 let mut r:Value=serde_json::from_str(raw).unwrap();let mut doc:Value=serde_json::from_str(r["modules"][0]["documentJson"].as_str().unwrap()).unwrap();let salary=doc["modules"][0]["elements"].as_array_mut().unwrap().iter_mut().find(|e|e["id"]=="salary").unwrap();salary["nullability"]=json!("absent-allowed");r["modules"][0]["documentJson"]=json!(doc.to_string());r["modules"][0]["pin"]["sha256"]=json!(sha256(doc.to_string().as_bytes()));let mut profile:Value=serde_json::from_str(r["queryProfileJson"].as_str().unwrap()).unwrap();profile["modelPins"]=json!(r["modules"].as_array().unwrap().iter().map(|m|m["pin"].clone()).collect::<Vec<_>>());r["queryProfileJson"]=json!(profile.to_string());r.to_string()
}
#[test]
fn grouped_sum_of_nullable_original_values_preserves_null_result_domain(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_aggregate_results::*,security_lowering::*};
 let raw=nullable_salary_request(&query_use_request("SELECT SUM(r.salary) FROM Resource r GROUP BY r.resourceId",Some("original-authorized"),true));
 with_security_mapping_context(&raw,|ctx|{let mut c=aggregate_contract(ctx);let t=aggregate_result_type(ctx,ctx.requirements().outputs()[0].output())?;assert!(t.nullable);check_aggregate_result_declaration(ctx,&c)?;let text=serde_json::to_string(&c).unwrap();let hash=sha256(text.as_bytes());let batch=json!({"version":ENCODING,"resultContractSha256":hash,"rows":[[{"outcomeId":"computed","disposition":"computed","value":null}]]}).to_string();check_aggregate_result_cells(ctx,&c,&text,&hash,&batch)?;
 if let SecurityResultOutcome::Computed{domain:SecurityResultDomain::Scalar{r#type:t},..}=&mut c.columns[0].outcomes[0]{t.nullable=false;}assert!(check_aggregate_result_declaration(ctx,&c).is_err());let copy=ctx.requirements().outputs()[0].output().clone();assert!(aggregate_result_type(ctx,&copy).is_err());Ok(())}).unwrap();
}
#[test]
fn grouped_sum_disclosed_null_transform_retains_nullable_output(){
 use weft_core::{security_mapping_transport::with_security_mapping_context,security_aggregate_results::*};
 let mut raw:Value=serde_json::from_str(&nullable_salary_request(&query_use_request("SELECT SUM(r.salary) FROM Resource r GROUP BY r.resourceId",Some("disclosed"),false))).unwrap();let mut policy:Value=serde_json::from_str(raw["policyJson"].as_str().unwrap()).unwrap();policy["rules"][0]["disclosure"][0]["disposition"]=json!({"kind":"transformed","transform":"constant","version":"0.1.0","field":{"documentId":"domain","moduleId":"m","elementId":"salary"},"value":null});raw["policyJson"]=json!(policy.to_string());let mut profile:Value=serde_json::from_str(raw["queryProfileJson"].as_str().unwrap()).unwrap();profile["policySha256"]=json!(sha256(policy.to_string().as_bytes()));raw["queryProfileJson"]=json!(profile.to_string());
 with_security_mapping_context(&raw.to_string(),|ctx|{let c=aggregate_contract(ctx);assert!(aggregate_result_type(ctx,ctx.requirements().outputs()[0].output())?.nullable);check_aggregate_result_declaration(ctx,&c)?;Ok(())}).unwrap();
}

#[test]
fn relational_guard_stages_keep_operand_evaluation_after_capture_validation(){
 use weft_core::security_mapping_transport::with_security_mapping_context;use weft_postgresql::{security_relational_sql::prepare_relational_graph_sql,security_relational_transport::*};
 let raw=query_use_request("SELECT r.salary,SUM(r.salary) FROM Resource r GROUP BY r.salary ORDER BY r.salary",Some("original-authorized"),true);
 with_security_mapping_context(&raw,|ctx|{let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();let program=prepare_relational_graph_sql(ctx,&source)?;for check in program.checks(){assert_eq!(check["stage"],if check["failureCode"]=="WFT-SECURITY-GROUP-DISCLOSURE"{"afterOperandValidation"}else{"beforeOperandCapture"});}assert!(program.checks().iter().any(|c|c["stage"]=="afterOperandValidation"));Ok(())}).unwrap();
 let prepared=prepare_guarded_relational_candidate(&raw).unwrap();let mut changed:Value=serde_json::from_str(prepared.json()).unwrap();let check=changed["checks"].as_array_mut().unwrap().iter_mut().find(|c|c["stage"]=="afterOperandValidation").unwrap();check["stage"]=json!("beforeOperandCapture");let input=json!({"version":"weft.truss.security.relational-result/0.2-candidate","sourceRequestJson":raw,"sourceOutputJson":changed.to_string()+"\n","operandBatchJson":"{}","batchJson":"{}"});assert!(inspect_guarded_relational_result(&input.to_string()).is_err());
}

#[test]
fn security_descending_order_retains_guarded_selection_and_old_registration_refusal(){
 use weft_core::security_mapping_transport::with_security_mapping_context;
 use weft_postgresql::security_relational_sql::prepare_relational_graph_sql;
 for sql in ["SELECT r.resourceId FROM Resource r ORDER BY r.resourceId DESC LIMIT 1",
 "SELECT r.salary,SUM(r.salary) FROM Resource r GROUP BY r.salary ORDER BY r.salary DESC LIMIT 1"] {
  let raw=query_use_request(sql,Some("original-authorized"),true);
  with_security_mapping_context(&raw,|ctx|{
   assert_eq!(ctx.query().order_descending(),&[true]);
   assert!(ctx.query().application_plan().required_capabilities.iter().any(|c|c=="order.desc"));
   let source:GraphSource=serde_json::from_str(ctx.binding_json()).unwrap();
   let plan=prepare_relational_graph_sql(ctx,&source)?;
   assert!(plan.sql().contains("DESC NULLS FIRST LIMIT 1"));
   assert!(plan.sql().contains("AS MATERIALIZED"));
   assert!(plan.checks().iter().any(|c|c["failureCode"]=="WFT-SECURITY-QUERY-USE"));
   Ok(())
  }).unwrap();
  assert!(prepare_guarded_graph_candidate(&raw).is_err());
 }
}

#[test]
fn relationship_candidate_keeps_source_observation_terminal_and_closed_old_protocols(){
 use weft_postgresql::security_relational_transport::*;
 for raw in [include_str!("security-public-relationship/compiler-request.json"),include_str!("security-public-relationship/compiler-request-observation-denied.json")] {
  assert!(prepare_guarded_relational_candidate(raw).is_err());assert!(prepare_guarded_graph_candidate(raw).is_err());
  let candidate=prepare_guarded_relationship_candidate(raw).unwrap();let wire:Value=serde_json::from_str(candidate.json()).unwrap();
  assert_eq!(wire["version"],"weft.truss.security.relational-candidate/0.2-candidate");assert_eq!(wire["securityReady"],false);
  for key in ["nativeAdmission","nativeCodecAdmission","nativePopulationAndSelection","releaseProtection"]{assert_eq!(wire[key],"required");}
  let sql=wire["executionSql"].as_str().unwrap();assert!(sql.contains("EXISTS (SELECT 1 FROM truss.edge public_edge"));assert!(sql.contains("observation_0 IS TRUE"));assert!(sql.contains("public_edge.source_type=5 AND public_edge.target_type=5"));
  assert_eq!(wire["operandReads"].as_array().unwrap().iter().map(|s|s["scan"].as_str().unwrap()).collect::<Vec<_>>(),vec!["s0","t0"]);
  assert!(wire["checks"].as_array().unwrap().iter().any(|c|c["failureCode"]=="WFT-SECURITY-PUBLIC-RELATIONSHIP-INTEGRITY"));
  assert!(wire["checks"].as_array().unwrap().iter().any(|c|c["failureCode"]=="WFT-SECURITY-RELATIONSHIP-OBSERVATION"));
  let operands=json!({"version":"weft.security.operand-values/0.1-candidate","contextSha256":wire["queryContextSha256"],"scans":[{"scan":"s0","rows":[]},{"scan":"t0","rows":[]}]});
  let batch=json!({"version":"weft.security.cells/0.1.0","resultContractSha256":wire["resultContractSha256"],"rows":[]});
  let input=json!({"version":"weft.truss.security.relational-result/0.2-candidate","sourceRequestJson":raw,"sourceOutputJson":candidate.json(),"operandBatchJson":operands.to_string(),"batchJson":batch.to_string()});
  let inspected=inspect_guarded_relationship_result(&input.to_string()).unwrap();assert_eq!(inspected["securityReady"],false);assert_eq!(inspected["nativeAdmission"],"required");
  assert!(inspect_guarded_relational_result(&input.to_string()).is_err());assert!(inspect_guarded_graph_result(&input.to_string()).is_err());
  let mut changed=input.clone();changed["sourceOutputJson"]=json!(candidate.json().trim_end());assert!(inspect_guarded_relationship_result(&changed.to_string()).is_err());
  changed=input.clone();let mut bad=wire.clone();bad["executionSql"]=json!("SELECT secret");changed["sourceOutputJson"]=json!(bad.to_string()+"\n");assert!(inspect_guarded_relationship_result(&changed.to_string()).is_err());
 }
}
