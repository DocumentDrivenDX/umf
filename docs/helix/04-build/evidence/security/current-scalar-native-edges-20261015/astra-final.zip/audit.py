from pathlib import Path
import ast,hashlib,json,zipfile
BASE=Path('/private/tmp/umf-current-scalar-edge-20261015')
ATTEMPT=BASE/'attempts/9158a990-f888-4016-8b36-0ec74783481b'
OUT=Path('/private/tmp/current-scalar-edge-astra-20261015-corrections')
receipt=json.loads((ATTEMPT/'receipt.json').read_text())
oracle=json.loads((ATTEMPT/'oracle.json').read_text())
prior=json.loads(Path('/private/tmp/current-scalar-edge-astra-20261015/receipt.json').read_text())
assert receipt['runId']==ATTEMPT.name and len(receipt['checks'])==17 and len(receipt['refusals'])==4
wanted={c['id']:c for c in oracle['cases']};old={c['id']:c for c in prior['checks']}
assert len(wanted)==17 and len({c['id'] for c in receipt['checks']})==17
assert {c['id'] for c in receipt['checks']}==set(wanted)
for actual in receipt['checks']:
 expected=wanted[actual['id']];normalize=sorted if expected['unordered'] else lambda x:x
 assert actual['expectedRows']==expected['expectedRows']
 assert normalize(actual['observedRows'])==normalize(expected['expectedRows'])==normalize(old[actual['id']]['observedRows'])
 assert all(type(v) is str for row in actual['observedRows'] for v in row)
assert {r['id'] for r in receipt['refusals']}=={r['id'] for r in oracle['refusals']}
for row in receipt['refusals']:
 assert row['originalBoundary']=='prepare-application-lineage'
 assert row['diagnosticCode']==row['expectedDiagnosticCode']==('WFT-PARAMETER' if row['id']=='text-nul-even-empty' else 'WFT-NUMERIC-DOMAIN')
cleanup=receipt['cleanup'];assert cleanup['runId']==ATTEMPT.name and cleanup['containerAbsent'] and cleanup['ownedVolumesAbsent'] and cleanup['sharedVolumeUsersBeforeRemoval']==[] and cleanup['removalExitCode']==0
assert cleanup['initialMounts']==json.loads((ATTEMPT/'initial-mounts.json').read_text())['mounts']
for path,h in receipt['harnessSourcesUnchangedThroughCleanup'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
assert (ATTEMPT/'run.py').read_bytes()==(BASE/'run.py').read_bytes()
with zipfile.ZipFile('/private/tmp/weft-current-scalar-wheels/weft_sql-0.4.32-cp39-abi3-macosx_11_0_arm64.whl') as wheel:
 assert hashlib.sha256(wheel.read('weft/__init__.py')).hexdigest()==receipt['importShimSha256']
 assert hashlib.sha256(wheel.read('weft/weft.abi3.so')).hexdigest()==receipt['moduleSha256']
assert hashlib.sha256(Path(receipt['loadedNativeOrigin']).read_bytes()).hexdigest()==receipt['moduleSha256']
# Execute only the two isolated exception helpers, never the original harness/module.
tree=ast.parse((ATTEMPT/'run.py').read_text());nodes=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in ('NativeRefusal','invoke')]
ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),'isolated-refusal-helpers','exec'),ns)
NativeRefusal=ns['NativeRefusal'];invoke=ns['invoke']
def error(text):raise ValueError(text)
def accepted(e):return isinstance(e,NativeRefusal) and e.stage=='prepare-application-lineage' and e.code=='WFT-NUMERIC-DOMAIN'
faults=[]
for stage,code,expect in [('prepare-application-lineage','WFT-NUMERIC-DOMAIN',True),('lower-postgresql-scalar','WFT-NUMERIC-DOMAIN',False),('prepare-application-lineage','UNRELATED',False)]:
 try:invoke(stage,lambda:error(code+': synthetic'))
 except NativeRefusal as e:assert accepted(e)==expect;faults.append({'stage':stage,'code':code,'acceptedAsExpectedRefusal':accepted(e),'passed':True})
try:json.loads('{malformed')
except json.JSONDecodeError as e:assert not isinstance(e,NativeRefusal);faults.append({'name':'malformed-producer-json-not-native-refusal','passed':True})
full=cleanup['ownedContainer'];assert not(set([full])<=set([full[:12]])) and set([full])<=set([full])
assert "'-a','--no-trunc','--format','{{.ID}} {{.Names}}'" in (ATTEMPT/'run.py').read_text()
result={'attempt':str(ATTEMPT),'positiveRowsVerifiedAgainstPriorIndependentOracle':17,'exactRefusalStagesAndCodes':4,'isolatedRefusalControls':faults,'sourcePinsMatchCurrent':True,'recoveryFullIdSourceFixVerified':True,'cleanupReceiptConsistent':True,'nativeOrDockerCalls':0,'actualCompilerImported':False}
(OUT/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
for f in ATTEMPT.iterdir():
 if f.is_file():(OUT/f.name).write_bytes(f.read_bytes())
(OUT/'historical-volume-cleanup.json').write_bytes((BASE/'historical-volume-cleanup.json').read_bytes())
(OUT/'earlier-correction-attempt-receipt.json').write_bytes((BASE/'attempts/1af58a7e-bec9-48ab-81d9-2fc86db8c46a/receipt.json').read_bytes())
(OUT/'earlier-correction-attempt-run.py').write_bytes((BASE/'attempts/1af58a7e-bec9-48ab-81d9-2fc86db8c46a/run.py').read_bytes())
(OUT/'audit-capture-note.json').write_text(json.dumps({'earlierCheck':'Receipt-vs-current-runner assertion refused during capture because parent had already applied --no-trunc recovery fix and rerun.','classification':'Expected source-stage advancement, not a native/oracle failure.','historicalAttempt':'1af58a7e-bec9-48ab-81d9-2fc86db8c46a','finalAttempt':ATTEMPT.name},indent=2)+'\n')
print(json.dumps(result))
