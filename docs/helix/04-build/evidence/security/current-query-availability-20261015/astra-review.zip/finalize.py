import datetime,hashlib,json,pathlib,shutil,zipfile
base=pathlib.Path(__file__).resolve().parent
umf=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
evidence=umf/'docs/helix/04-build/evidence/security/current-query-availability-20261015'
sha=lambda b:hashlib.sha256(b).hexdigest()
# Retain inspected parent receipts as attributed evidence, separate from independent runs.
for rel in ['README.md','weft-committed-pins.json','weft-owner-replay.json','required-byte-compatibility.json','formal-scope.md']:
 if (evidence/rel).exists():
  dest=base/'parent-final'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(evidence/rel,dest)
paths=[umf/'tools/security/current-query-absence.py',umf/'tests/security/protection/current-query-source.json']
weft=pathlib.Path('/private/tmp/weft-lineage-availability-fix')
for p in (base/'weft-final').rglob('*'):
 if p.is_file():paths.append(weft/p.relative_to(base/'weft-final'))
for p in sorted(evidence.glob('*')):
 if p.is_file() and p.name in ['README.md','formal-scope.md','weft-committed-pins.json','weft-owner-replay.json','required-byte-compatibility.json']:paths.append(p)
paths += [pathlib.Path('/private/tmp/weft-lineage-availability-final-r1/application_lineage'),pathlib.Path('/private/tmp/weft-lineage-availability-final-r1/security_query_properties'),pathlib.Path('/private/tmp/weft-application-lineage-current-source-r1/application_lineage')]
pins=[dict(path=str(p),sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in paths]
# Assert the exact final upstream runner/fixture and reviewed snapshot remain unchanged.
for rel in ['tools/security/current-query-absence.py','tests/security/protection/current-query-source.json']:
 assert (umf/rel).read_bytes()==(base/'umf-final'/rel).read_bytes()
for p in (base/'weft-final').rglob('*'):
 if p.is_file():assert p.read_bytes()==(weft/p.relative_to(base/'weft-final')).read_bytes()
(base/'final-source-pins.json').write_text(json.dumps(dict(timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(),pins=pins,sourceUnchanged=True),indent=2)+'\n')
ind=json.loads((base/'independent-fixed.json').read_text());old=json.loads((base/'independent-old-sensitivity.json').read_text());current=json.loads((base/'final-12-replay.json').read_text());owner=json.loads((base/'owner-check.stdout.json').read_text());byte=json.loads((base/'required-byte-replay.json').read_text())
assert len(ind['observations'])==20 and all(r['passed'] for r in ind['observations'])
assert sum(not r['passed'] for r in old['observations'])==11
assert len(current['observations'])==12 and all(r['passed'] for r in current['observations'])
assert len(owner['observations'])==10 and all(r['passed'] for r in owner['observations'])
review={
 'status':'no-blocking-finding-within-reviewed-scope',
 'acceptanceReceipt':False,
 'scope':'Selected Field availability refusal in actual source-only Weft application-lineage/0.1-candidate and legacy security_query_properties reports. No native execution, policy permission, general optional-value support, or backend acceptance.',
 'reviewedWeftCommit':'84bc26c1f38f989e492abd5fbed07122eb1668bb',
 'baselineWeftCommit':'05b68633ee082509f956fb67b8b3e012692048b5',
 'binaries':{'application_lineage':'6069d58a2009ca2d5f5d65557e5a7d71900c1343ad3ef792f4e3f375e6a3fc65','security_query_properties':'5e20086e913f59ab4fe77ba55113567df2f0e76e8773cd08c0a98d249111d593','old_application_lineage':'8d2ff86173efe81aafd17cb14cad06d880c55802fc39fc361802d520307487a1'},
 'independentExecution':{
  'originalEightCaseRegression':{'passed':2,'failed':6,'expectedPreFixFailure':True,'file':'independent-before.json'},
  'finalTwelveCaseRegression':{'passed':12,'failed':0,'file':'final-12-replay.json','oracleAuthor':'parent; independently executed'},
  'additionalControls':{'passed':20,'failed':0,'file':'independent-fixed.json','oracleAuthor':'reviewer'},
  'oldBinarySensitivity':{'passed':9,'failed':11,'expectedPreFixFailure':True,'file':'independent-old-sensitivity.json','meaning':'All 11 required refusal cases were actually admitted by the old producer; all are refused by the fixed producer.'},
  'ownerCurrentAndLegacyReplay':{'passed':10,'failed':0,'file':'owner-check.stdout.json','oracleAuthor':'Weft owner; independently executed, includes genuine legacy prior acceptance witness and fixed refusal'},
  'requiredReportByteCompatibility':{'passed':5,'failed':0,'file':'required-byte-replay.json','meaning':'Actual old/new binaries emitted identical bytes for five original required-field requests.'},
  'committedBlobCorrespondence':{'passed':11,'file':'committed-source-checks.json','meaning':'Eight changed source/witness paths plus three reviewed resolver/model/IR dependencies match actual committed git blobs.'}
 },
 'sourceReview':[
  'The guard resolves each dependency through its original scan owner and original exact member identity, then checks the selected descriptor availability is exactly required. It does not infer availability from logicalType.nullable.',
  'The shared dependency traversal covers both sides of equality, every lexicographic column and Field value, every join/filter/group/order dependency, SUM arguments, and HasRelated terminal authored Key fields. Plain Field outputs receive a separate pass.',
  'Same-named Fields in different Records resolve by owner and qualified identity. The independent controls include required Other.token alongside optional Resource.token and both accepted/refused owner-sensitive queries.',
  'HasRelated Field-valued key operands already refuse in application_scope; original authored_key uses scalar_type, which requires required availability. Terminal-key handling was source-reviewed, not a newly executed terminal-key test.',
  'Field-free COUNT retains the original scan without selecting unrelated members. Unselected optional Fields do not cause blanket refusal. Required SUM still retains unsupported property semantics.',
  'Both current application_lineage and legacy security_query_properties call the common guard before returning their report. Refusals produce the intended WFT-APPLICATION-LINEAGE-AVAILABILITY prefix and no partial stdout in the executed cases.'
 ],
 'resolvedDefect':{'description':'The old selected report profile admitted absent-allowed Fields with ideal nullable:false property uses and no separate use availability. The full retained applicationPlanJson could still contain descriptor availability; this is not a claim that every retained source archive erased it. The fix refuses that unrepresented selected meaning.', 'status':'reproduced-before-and-fixed-after'},
 'limits':[
  'Finite source/report correspondence evidence, not a universal implementation refinement proof or native data-leak demonstration.',
  'No P03/B08/native/backend case promotion, security activation, current authority, authentication, read permission or stored-token custody claim.',
  'Optional selected Fields are refused, not newly supported or converted to explicit null.',
  'Binaries were hashed and executed; the reviewer did not independently rebuild them. Committed source correspondence was independently verified separately.',
  'Owner-reported 292 Rust tests, 16 boundary controls and broader harness results are attributed receipts, not independently rerun here.',
  'The existing fact-fold formal model assumes faithful source classification and does not prove this Rust traversal. Its applicability note was inspected; no additional SMT qualification is claimed.',
  'Historical eight-case and preliminary source captures remain separate from final twelve-case and committed-source evidence. No shared source was modified.'
 ],
 'remainingBlockers':[],
 'sourcePinCount':len(pins),
 'sourcePins':'final-source-pins.json',
 'artifactNotes':['A preliminary tool invocation failed because the private review directory did not yet exist; it executed no source/test.','Old binary regression nonzero exits are expected negative evidence, not passing repair qualification.']
}
(base/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(base/'README.md').write_text('Selected availability review\n\nNo blocking finding within the reviewed source-only report scope. Final producer passes 12 original regression cases, 20 independently authored traversal/owner controls, and the 10-control owner current/legacy replay. Five required report outputs remain byte-identical to the old producer. The old producer fails all 11 refusal expectations in the independent 20-control corpus. Eleven reviewed source/witness files match Weft commit 84bc26c1f38f989e492abd5fbed07122eb1668bb.\n\nSee review.json for exact scope and exclusions. This is not an acceptance receipt or native/security authorization claim. The archive preserves before failures and final repairs separately.\n')
manifest=[]
for p in sorted(base.rglob('*')):
 if p.is_file() and p.name!='archive-manifest.json' and '__pycache__' not in p.parts:
  manifest.append(dict(path=str(p.relative_to(base)),sha256=sha(p.read_bytes()),bytes=p.stat().st_size))
(base/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=base.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(base.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,str(p.relative_to(base)))
print(json.dumps(dict(review=str(base/'review.json'),reviewSha256=sha((base/'review.json').read_bytes()),archive=str(archive),archiveSha256=sha(archive.read_bytes()),archiveBytes=archive.stat().st_size,sourcePins=len(pins),files=len(manifest)+1),indent=2))
