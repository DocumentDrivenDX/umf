"""Independently specified finite availability/traversal controls; no native execution."""
import copy,hashlib,json,pathlib,subprocess,sys,time
HERE=pathlib.Path(__file__).resolve().parent
FIXTURE=HERE/'umf/tests/security/protection/current-query-source.json'
BINARY=pathlib.Path(sys.argv[1]); EXPECTED_SHA=sys.argv[2]; OUTPUT=pathlib.Path(sys.argv[3])
sha=lambda b:hashlib.sha256(b).hexdigest()
original=FIXTURE.read_bytes(); fixture=json.loads(original); binary_before=sha(BINARY.read_bytes()); assert binary_before==EXPECTED_SHA
# Expected acceptance is authored from whether the selected dependencies are required.
cases=[
 ('required-plain-output','SELECT r.token FROM Resource r',[],False,'passed'),
 ('unselected-optional-salary','SELECT r.token FROM Resource r',['salary'],False,'passed'),
 ('unselected-optional-token','SELECT r.resourceId FROM Resource r',['token'],False,'passed'),
 ('two-unselected-optionals-count','SELECT COUNT(*) FROM Resource r',['salary','token'],False,'passed'),
 ('optional-hidden-group','SELECT COUNT(*) FROM Resource r GROUP BY r.token',['token'],False,'availability-refused'),
 ('optional-hidden-desc','SELECT r.resourceId FROM Resource r ORDER BY r.token DESC',['token'],False,'availability-refused'),
 ('optional-second-group','SELECT COUNT(*) FROM Resource r GROUP BY r.resourceId,r.token',['token'],False,'availability-refused'),
 ('optional-second-filter',"SELECT r.resourceId FROM Resource r WHERE r.resourceId='r1' AND r.token='x'",['token'],False,'availability-refused'),
 ('optional-rhs-filter','SELECT r.resourceId FROM Resource r WHERE r.resourceId=r.token',['token'],False,'availability-refused'),
 ('optional-rhs-join','SELECT r.resourceId FROM Resource r JOIN Resource s ON r.resourceId=s.token',['token'],False,'availability-refused'),
 ('optional-join-only-left','SELECT r.resourceId FROM Resource r JOIN Resource s ON r.token=s.resourceId',['token'],False,'availability-refused'),
 ('optional-aliased-output','SELECT r.token AS unprotected FROM Resource r',['token'],False,'availability-refused'),
 ('optional-plain-later-output','SELECT r.resourceId,r.token AS later FROM Resource r',['token'],False,'availability-refused'),
 ('required-count-group','SELECT COUNT(*) FROM Resource r GROUP BY r.token',[],False,'passed'),
 ('required-desc','SELECT r.resourceId FROM Resource r ORDER BY r.token DESC',[],False,'passed'),
 ('required-sum-unsupported-property','SELECT SUM(r.salary) AS amount FROM Resource r',[],False,'passed'),
 ('optional-sum-only','SELECT SUM(r.salary) AS amount FROM Resource r',['salary'],False,'availability-refused'),
 ('required-same-name-other-owner','SELECT o.token FROM Other o',['token'],True,'passed'),
 ('optional-same-name-correct-owner','SELECT o.otherId FROM Other o JOIN Resource r ON o.token=r.token',['token'],True,'availability-refused'),
 ('required-other-owner-with-unselected-optional-join','SELECT o.token FROM Other o JOIN Resource r ON o.otherId=r.resourceId',['token'],True,'passed'),
]
rows=[]
for name,sql,optional,other,expected in cases:
 d=copy.deepcopy(fixture['closure']['documents'][0]['document']); elements=d['modules'][0]['elements']
 for el in elements:
  if el['id'] in optional:el['nullability']='absent-allowed'
 if other:
  elements.extend([
   dict(id='Other',name='Other',kind='record',members=[dict(module='m',element='otherId'),dict(module='m',element='otherToken')],keys=[dict(id='pk',name='Key',fields=[dict(module='m',element='otherId')])],extensions={}),
   dict(id='otherId',name='otherId',kind='field',scalarType='string',cardinality='one',nullability='required',extensions={}),
   dict(id='otherToken',name='token',kind='field',scalarType='string',cardinality='one',nullability='required',extensions={}),
  ])
 encoded=json.dumps(d,ensure_ascii=False,separators=(',',':'),allow_nan=False)
 req=dict(interfaceVersion='weft-application-lineage/0.1-candidate',modules=[dict(documentJson=encoded,pin=dict(documentId=d['id'],revision='astra-availability-controls-r1',umfVersion=d['umf'],sha256=sha(encoded.encode())),selectedModuleIds=['m'])],sql=sql,parameters={},opaqueSources=[])
 raw=json.dumps(req,ensure_ascii=False,separators=(',',':'),allow_nan=False)
 p=subprocess.run([str(BINARY)],input=raw.encode(),capture_output=True,timeout=15)
 observed='passed' if p.returncode==0 and not p.stderr else 'availability-refused' if p.returncode!=0 and p.stdout==b'' and p.stderr.startswith(b'WFT-APPLICATION-LINEAGE-AVAILABILITY:') and len(p.stderr)<=8192 else 'other-refusal'
 ok=observed==expected
 if observed=='passed':
  report=json.loads(p.stdout)
  ok=ok and report['authority'] is False and report['securityReady'] is False and report['sourceRequestJson']==raw and report['sourceRequestSha256']==sha(raw.encode())
  if name=='two-unselected-optionals-count':ok=ok and report['uses']==[] and list(report['scans'])==['s0']
  if name=='required-sum-unsupported-property':ok=ok and len(report['uses'])==1 and report['uses'][0]['propertyStatus']=='unsupported' and report['uses'][0]['required'] is None
  if name=='required-same-name-other-owner':ok=ok and json.loads(report['applicationPlanJson'])['outputs'][0]['expression']['identity']['element']=='otherToken'
 rows.append(dict(id=name,expected=expected,observed=observed,passed=bool(ok),request=req,exitCode=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode()))
assert FIXTURE.read_bytes()==original and sha(BINARY.read_bytes())==binary_before
result=dict(status='passed' if all(r['passed'] for r in rows) else 'failed',runnerSha256=sha(pathlib.Path(__file__).read_bytes()),fixtureSha256=sha(original),binarySha256=binary_before,sourceUnchanged=True,observations=rows,scope='Finite independently specified dependency/projection/owner correspondence controls. No native execution or policy permission claim.')
OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':sum(r['passed'] for r in rows),'total':len(rows),'failures':[{'id':r['id'],'observed':r['observed'],'stderr':r['stderr']} for r in rows if not r['passed']]}))
sys.exit(0 if result['status']=='passed' else 1)
