Selected availability review

No blocking finding within the reviewed source-only report scope. Final producer passes 12 original regression cases, 20 independently authored traversal/owner controls, and the 10-control owner current/legacy replay. Five required report outputs remain byte-identical to the old producer. The old producer fails all 11 refusal expectations in the independent 20-control corpus. Eleven reviewed source/witness files match Weft commit 84bc26c1f38f989e492abd5fbed07122eb1668bb.

See review.json for exact scope and exclusions. This is not an acceptance receipt or native/security authorization claim. The archive preserves before failures and final repairs separately.
