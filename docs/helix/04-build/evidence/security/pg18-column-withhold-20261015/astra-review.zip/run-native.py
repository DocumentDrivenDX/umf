"""Independent isolated replay of the unchanged governed 60-second command."""
import hashlib,json,os,shutil,signal,subprocess,time,uuid
from pathlib import Path

ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
OUT=Path(__file__).resolve().parent
target=OUT/'native-final'
target.mkdir(exist_ok=False)
plan=json.loads((ROOT/'docs/helix/03-test/security/cases.json').read_text())
case=next(c for c in plan['cases'] if c['id']=='pg-raw.P01')
assert case['timeoutMs']==60000
paths=['docs/helix/03-test/security/cases.json',case['testSource'],case['oracleSource'],*case['implementationSources']]
pins={}
for path in paths:
 data=(ROOT/path).read_bytes();destination=target/path;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
 pins[path]=hashlib.sha256(data).hexdigest()
(target/case['evidence']).parent.mkdir(parents=True,exist_ok=True)
run_id=str(uuid.uuid4());env={**os.environ,'UMF_SECURITY_RUN_ID':run_id,'UMF_SECURITY_CASE_ID':'pg-raw.P01'}
start=time.monotonic()
with (OUT/'native-final.stdout').open('wb') as stdout,(OUT/'native-final.stderr').open('wb') as stderr:
 process=subprocess.Popen(case['command'],cwd=target,env=env,stdout=stdout,stderr=stderr)
 timed_out=False
 try:code=process.wait(timeout=case['timeoutMs']/1000)
 except subprocess.TimeoutExpired:
  timed_out=True;process.terminate()
  try:code=process.wait(timeout=15)
  except subprocess.TimeoutExpired:
   process.kill();code=process.wait(timeout=5)
 elapsed=time.monotonic()-start
summary={'runId':run_id,'command':case['command'],'originalTimeoutMs':case['timeoutMs'],'elapsedSeconds':elapsed,'timedOut':timed_out,'exit':code,'sourceDigests':pins,'copiedSourceUnchanged':all(hashlib.sha256((target/p).read_bytes()).hexdigest()==h for p,h in pins.items()),'authoritativeSourceUnchanged':all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in pins.items())}
evidence=target/case['evidence']
if evidence.exists():
 shutil.copyfile(evidence,OUT/'native-final.json');r=json.loads(evidence.read_text())
 summary.update(receiptStatus=r['status'],observations=len(r['observations']),postgres=r['versions']['postgres'],cleanup=r['nativeInventory'].get('cleanup'),image=r['nativeInventory']['imageId'])
(OUT/'native-replay-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
assert not timed_out and code==0 and elapsed<60 and summary['copiedSourceUnchanged'] and summary['authoritativeSourceUnchanged'],summary
