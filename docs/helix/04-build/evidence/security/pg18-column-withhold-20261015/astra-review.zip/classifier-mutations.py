"""Focused runner-classifier mutations in private copies; no native processes."""
import hashlib,json,subprocess,sys
from pathlib import Path
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
out=Path(__file__).resolve().parent
source=(root/'tests/security/native/pg18-column-withhold.py').read_text()
variants=[
 ('omit-exit',[("result.returncode!=3","False")],'wrong-psql-exit-with-correct-code'),
 ('omit-no-output',[("result.stdout!=''","False")],'permission-error-with-result-row'),
 ('substring-state-and-hardcoded-report',[("codes!=['42501']","'42501' not in result.stderr"),("sqlstate=codes[0]","sqlstate='42501'")],'wrong-primary-mentions-permission-code'),
]
rows=[]
for name,replacements,expected in variants:
 modified=source
 for before,after in replacements:
  assert modified.count(before)==1,(name,modified.count(before))
  modified=modified.replace(before,after)
 d=out/'classifier-mutants'/name;d.mkdir(parents=True,exist_ok=True)
 path=d/'runner.py';path.write_text(modified)
 run=subprocess.run([sys.executable,str(out/'refusal-controls.py'),str(path)],text=True,capture_output=True,timeout=10)
 (d/'stderr.log').write_text(run.stderr);(d/'result.json').write_text(run.stdout)
 assert run.returncode==0,(name,run.stderr)
 result=json.loads(run.stdout);failures=[r['id'] for r in result['rows'] if not r['pass']]
 assert expected in failures,(name,failures)
 rows.append({'id':name,'replacements':[{'before':a,'after':b} for a,b in replacements],'expectedNamedFailure':expected,'observedFailures':failures,'detected':True,'modifiedSha256':hashlib.sha256(modified.encode()).hexdigest()})
(out/'classifier-mutations.json').write_text(json.dumps({'status':'passed','sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'variants':rows},indent=2)+'\n')
print(json.dumps({'status':'passed','detected':len(rows)}))
