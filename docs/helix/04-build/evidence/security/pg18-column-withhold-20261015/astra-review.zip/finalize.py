"""Retain source/requirements/evidence correspondence for the bounded review."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
plan_path='docs/helix/03-test/security/cases.json'
current=load(root/plan_path);original=json.loads(subprocess.check_output(['git','show','HEAD:'+plan_path],cwd=root))
old={c['id']:c for c in original['cases']};new={c['id']:c for c in current['cases']}
allowed={'status','command','evidence','testSource','oracleSource','implementationSources'}
assert len(old)==len(new)==158 and old.keys()==new.keys()
changed={i:sorted(k for k in set(old[i])|set(new[i]) if old[i].get(k)!=new[i].get(k)) for i in old if old[i]!=new[i]}
assert set(changed)=={'pg-raw.P01'} and set(changed['pg-raw.P01'])==allowed,changed
assert {k:v for k,v in current.items() if k!='cases'}=={k:v for k,v in original.items() if k!='cases'}
p01=new['pg-raw.P01'];assert p01['timeoutMs']==60000 and p01['covers']==['US-056-AC6'] and p01['layer']=='native'
r=load(out/'native-final.json');summary=load(out/'native-replay-summary.json');oracle=load(root/p01['oracleSource'])
mutations=load(out/'classifier-mutations.json');assert mutations['status']=='passed' and len(mutations['variants'])==3
obs={x['assertionId']:x for x in r['observations']}
assert len(obs)==len(r['observations'])==119
assert all(x['expected']==x['observed'] for x in obs.values())
assert r['runId']==summary['runId'] and r['status']=='passed'
assert r['nativeInventory']['engine']['number']=='180006'
assert r['nativeInventory']['imageId']=='sha256:74935e72241653ca55e0414067e6d8763aceb8a810eb51b452253ec3dcfc4336'
assert obs['pg-raw.P01']['observed']==oracle['actors']
assert all(obs['pg-raw.P01:refusal:'+a+':'+q]['observed']=={'status':'refused','scope':'statement','sqlstate':'42501','rows':[]} for a in oracle['actors'] for q in oracle['denied'])
assert len(oracle['actors'])*len(oracle['denied'])==57
weakening=r['nativeInventory']['negativeControls'];assert len(weakening)==6
assert all('pg-raw.P01:weakened-leak:'+x in obs and 'pg-raw.P01:restored:'+x in obs and 'pg-raw.P01:restored-visible:'+x in obs for x in weakening)
assert obs['pg-raw.P01:prepared-revoked']['observed']==['42501']
assert obs['pg-raw.P01:prepared-same-native-session']['observed']==obs['pg-raw.P01:prepared-same-native-session']['expected']
native=dict(r['nativeInventory']);digest=native.pop('digest');assert sha(json.dumps(native,sort_keys=True,separators=(',',':')).encode())==digest
assert native['cleanup']['containerAbsent'] and native['cleanup']['volumesAbsent']
assert {x['name'] for x in native['installedSourceInventory']['schemas']}=={'security_raw','security_columns'}
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in r['sourceDigests'].items())
audit={'status':'passed','originalCases':158,'unchangedOtherCases':157,'changedCase':{'id':'pg-raw.P01','onlyFields':changed['pg-raw.P01']},'assertionCoverageLayerTimeoutPreserved':True,'caseTimeoutMs':60000,'nativeObservations':119,'baselineRefusals':57,'independentAuthoredExpectedRows':oracle['actors'],'deliberateGrantWeakeningAndRestorationRoutes':weakening,'preparedSameNativeSessionRecheck':True,'nativeDigestValid':True,'sourceDigestsCurrent':True,'installedSchemasInventoried':['security_raw','security_columns']}
(out/'source-evidence-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
paths=[plan_path,p01['testSource'],p01['oracleSource'],*p01['implementationSources'],'tests/security/native/test_pg18_column_refusal.py','docs/helix/03-test/security/pg-raw.md','docs/helix/03-test/test-plans/STP-056-security-bindings.md','docs/helix/04-build/security-field-protection-plan.md','docs/helix/04-build/evidence/security/pg18-column-withhold-20261015/formal.py','docs/helix/04-build/evidence/security/pg18-column-withhold-20261015/formal.json','docs/helix/04-build/evidence/security/pg18-column-withhold-20261015/README.md','docs/helix/04-build/evidence/security/acceptance.json','docs/helix/04-build/evidence/security/phase-validation.json']
pins={}
for p in paths:
 b=(root/p).read_bytes();pins[p]=sha(b);dest=out/'final-source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
(out/'final-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
review={
 'status':'reviewed-no-remaining-blocker-in-P01-scope',
 'review':'Independent source review and actual isolated native replay; authoritative checkout unchanged by reviewer.',
 'authoritativeRoot':str(root), 'headAtReview':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'scope':'pg-raw.P01 / US-056-AC6 fixed PostgreSQL18.6 column-privilege withholding only.',
 'sourcePins':'final-source-pins.json',
 'native':{'execution':'independently executed unchanged copied governed runner','runId':r['runId'],'elapsedSeconds':summary['elapsedSeconds'],'timeoutMs':60000,'observations':119,'refusals':57,'grantWeakeningRestorationRoutes':6,'sourceStable':True,'cleanupVerified':True,'receipt':'native-final.json'},
 'pureControls':{'independentRefusalCases':10,'allPassAfterFix':True,'preFixFalseClassifications':5,'classifierSourceWeakeningsDetected':3,'mutationQualification':'Two single-guard mutations plus one paired substring-state/hardcoded-report weakening; no claim each redundant guard individually necessary.','results':['refusal-before.json','refusal-after.json','classifier-mutations.json']},
 'formal':{'replayed':True,'queries':6,'unsat':3,'sat':3,'artifact':'formal-replay.json','qualification':'Conditional reference/permission laws only; native checking and complete relevant routes are assumptions, not SQL/kernel refinement.'},
 'fixedFindings':['Native refusal classifier previously accepted arbitrary 42501 substrings; now exact exit3/empty stdout/single ERROR42501/no FATAL or PANIC.','Owned PostgreSQL anonymous volume previously survived cleanup; now rm -fv with ownership/shared-use checks and verified absence before receipt publication.','Actual installed membership helper/dependency inventory was incomplete; both schemas and their relations/columns/constraints/policies/views/routines now retained.'],
 'oracleReview':'Expected rows are authored literals separate from native SQL; weakened secret rows derive only from those literals and authored actor IDs, never observed output. The complete required case assertion/covers/layer/timeout and other157 rows are unchanged.',
 'retainedFailures':['initial-source pre-fix classifier','refusal-before.json five counterexamples','refusal-after-setup-failure.json is reviewer harness missing re namespace, not product failure','classifier-mutants/substring-state retains unsuccessful mutation setup with IndexError; not counted. Paired mutation avoids hardcoded/report guard redundancy and is separately named.','review-before-mutation-finalization.json is an explicitly superseded interim receipt, not a qualified final result.','parent retains initial inherited-table restoration failure; corrected restoration regrants only original permitted columns'],
 'limits':['No other PostgreSQL18 B/L/P qualification or PostgreSQL17.9 promotion.','No complete production compiler/native profile, current-authority/DDL/custody/lifetime, arbitrary SQL side-channel or general prepared-plan theorem.','The CREATE FUNCTION attack proves protected-schema CREATE denial only.','Administrator/Docker/local socket access is excluded; deliberately weakened fixtures are sensitivity controls, never ordinary admitted paths.','Native clean replay verifies successful cleanup; no cleanup-failure injection campaign was performed.'],
 'blockingFindings':[], 'requirementsAudit':'source-evidence-audit.json'
}
(out/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(out/'review.md').write_text('No remaining blocker in the fixed P01 scope.\n\nThe unchanged runner passed119 native observations in '+format(summary['elapsedSeconds'],'.3f')+'seconds under its original60-second limit, with exact PostgreSQL18.6 image and verified owned container/volume cleanup. Ten independent refusal controls and three focused classifier weakenings pass; six conditional formal queries replay3UNSAT/3SAT.\n\nThis packet preserves the earlier substring-classification counterexamples and the reviewer harness setup failure. No other backend case, PostgreSQL17.9 evidence, native authority lifecycle, arbitrary route closure or full deployment is qualified. See review.json for source pins and exact limits.\n')
included=[]
for p in sorted(out.rglob('*')):
 if not p.is_file() or p.name in {'review-archive.zip','archive-manifest.json'}:continue
 rel=p.relative_to(out)
 if rel.parts[0]=='native-final':continue
 included.append((rel,p))
manifest={'files':[{'path':str(rel),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for rel,p in included]}
(out/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'review-archive.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for rel,p in included:z.write(p,str(rel))
 z.write(out/'archive-manifest.json','archive-manifest.json')
print(json.dumps({'review':str(out/'review.json'),'reviewSha256':sha((out/'review.json').read_bytes()),'archive':str(out/'review-archive.zip'),'archiveSha256':sha((out/'review-archive.zip').read_bytes()),'archiveBytes':(out/'review-archive.zip').stat().st_size,'files':len(included)+1,'sourcePins':len(pins)},indent=2))
