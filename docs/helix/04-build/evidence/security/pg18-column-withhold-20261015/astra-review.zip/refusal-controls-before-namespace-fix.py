"""Independent pure runner-fault controls; never launches PostgreSQL or Docker."""
import ast,json,subprocess,sys
from pathlib import Path

source=Path(sys.argv[1])
tree=ast.parse(source.read_text())
namespace={'subprocess':subprocess,'json':json}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(source),'exec'),namespace)

cases=[
 ('native-permission-error',3,'','ERROR:  42501: permission denied for table resource\nLOCATION:  aclcheck_error, aclchk.c:2843\n',True),
 ('permission-error-with-result-row',3,'secret\n','ERROR:  42501: permission denied for table resource\n',False),
 ('permission-error-zero-exit',0,'','ERROR:  42501: permission denied for table resource\n',False),
 ('wrong-primary-mentions-permission-code',3,'','ERROR:  22023: diagnostic mentions 42501\n',False),
 ('fatal-mentions-permission-code',2,'','FATAL:  08006: connection 42501 lost\n',False),
 ('wrong-psql-exit-with-correct-code',2,'','ERROR:  42501: permission denied for table resource\n',False),
 ('different-primary-then-permission-error',3,'','ERROR:  22023: invalid parameter\nERROR:  42501: permission denied for table resource\n',False),
 ('no-native-error',3,'','docker: Error response from daemon: permission token 42501\n',False),
 ('unrelated-sqlstate',3,'','ERROR:  42P01: relation does not exist\n',False),
 ('native-permission-error-localized-message',3,'','ERROR:  42501: autre diagnostic\n',True),
]
rows=[]
for label,code,stdout,stderr,expected in cases:
 namespace['sql']=lambda _text,_actor,code=code,stdout=stdout,stderr=stderr:subprocess.CompletedProcess(['psql'],code,stdout,stderr)
 try:
  result=namespace['refusal']('SELECT secret FROM resource;','ordinary')
  observed=result=={'status':'refused','scope':'statement','sqlstate':'42501','rows':[]}
 except Exception:
  observed=False
 rows.append({'id':label,'expectedAcceptAsExactRefusal':expected,'observedAcceptAsExactRefusal':observed,'pass':expected==observed})
print(json.dumps({'source':str(source),'status':'passed' if all(r['pass'] for r in rows) else 'counterexamples','rows':rows},indent=2))
