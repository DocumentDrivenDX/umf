import {runOracle} from './oracle';
const rows=runOracle();await Bun.write(import.meta.dir+'/bun-results.json',JSON.stringify({controls:rows.length,passed:rows.every(x=>x.passed),observations:rows},null,2)+'\n');console.log(JSON.stringify({controls:rows.length,failed:rows.filter(x=>!x.passed)}));if(rows.some(x=>!x.passed))process.exitCode=1;
