from pathlib import Path
import json,re,hashlib,subprocess
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/query-value-routes-astra-20261015');F=R/'src/extensions/security/query-value-routes-candidate.ts';src=F.read_text();oracle=(O/'oracle.ts').read_text()
relocated=re.sub(r"(from\s+['\"])(\.[^'\"]+)(['\"])",lambda m:m[1]+str((F.parent/m[2]).resolve())+m[3],src)
variants={
'withheld-guard-omitted':[("['withheld','transformed'].includes(other.kind)","['transformed'].includes(other.kind)"),("other.kind==='withheld'||other.kind==='transformed'","other.kind==='transformed'")],
'distinct-transform-guard-omitted':[("other.kind==='withheld'||other.kind==='transformed'","other.kind==='withheld'")],
'live-token-to-prestorage':[("valueDomain=domain(u.field);","valueDomain=domain(stored?stored.inputDomain:u.field);")],
'hidden-original-unmasks-projection':[("const projection=d.kind==='missing'?","const projection=modes[0]==='original-authorized'?{kind:'original',field:u.field}:d.kind==='missing'?")],
'silent-mode-winner':[("else if(conflict)status='conflicting-modes';","else if(false&&conflict)status='conflicting-modes';")],
'storage-constraint-omitted':[("const constraints:any[]=[ontologyConstraint,...(storageConstraint?[storageConstraint]:[]),", "const constraints:any[]=[ontologyConstraint,")],
'raw-literal-grouping':[(next(x for x in relocated.splitlines() if 'let key=canonicalSchemaJson(disposition)' in x),"   let key=canonicalSchemaJson(disposition);")],
'range-bound-omitted':[("!f||canonicalSchemaJson(property.bucket.value).length>4096","!f")],
'null-identity-without-specialcase':[("disposition.value===null?(budget.check(f.document,f.element,null),budget.retain('null')):budget.identity(f.document,f.element,disposition.value)","budget.identity(f.document,f.element,disposition.value)")],
'whole-owner-validation-omitted':[("validateCandidateCatalogStorage(program,owner,()=>budget.step())","new Map(owner.storage.map((entry:any)=>[JSON.stringify([id(entry.type),id(entry.field)]),entry]))")],
'property-budget-reset':[("budget.identity(f.document,f.element,property.bucket.value)","new ProtectionLiteralBudget().identity(f.document,f.element,property.bucket.value)")],
'context-bindings-omitted':[(",...(bindings.has(rule.id)?{contextBindings:bindings.get(rule.id)}:{})","")],
}
results=[]
for name,changes in variants.items():
 d=O/'mutants'/name;d.mkdir(parents=True,exist_ok=True);s=relocated
 for old,new in changes:
  if s.count(old)!=1:raise RuntimeError((name,'selector count',s.count(old),old))
  s=s.replace(old,new)
 (d/'route.ts').write_text(s);(d/'oracle.ts').write_text(oracle.replace("'./base-fixture.json'",repr(str(O/'base-fixture.json'))).replace(str(R/'src/extensions/security/query-value-routes-candidate'),str(d/'route')))
 (d/'run.ts').write_text("import {runOracle} from './oracle';const rows=runOracle();await Bun.write(import.meta.dir+'/result.json',JSON.stringify({controls:rows.length,failures:rows.filter(x=>!x.passed),observations:rows},null,2)+'\\n');console.log(JSON.stringify({controls:rows.length,failed:rows.filter(x=>!x.passed).map(x=>x.id)}));")
 p=subprocess.run(['/opt/homebrew/bin/bun',str(d/'run.ts')],cwd=R,text=True,capture_output=True);(d/'run.log').write_text(p.stdout+p.stderr)
 result=json.loads((d/'result.json').read_text()) if (d/'result.json').exists() else None
 results.append({'name':name,'source':str(d/'route.ts'),'sourceSha256':hashlib.sha256(s.encode()).hexdigest(),'exit':p.returncode,'controls':result and result['controls'],'failures':result and [x['id'] for x in result['failures']],'errors':result and [x for x in result['failures'] if x['error']],'detected':p.returncode==0 and bool(result and result['failures'])})
 print(json.dumps(results[-1]),flush=True)
(O/'mutation-results.json').write_text(json.dumps({'originalSource':str(F),'originalSha256':hashlib.sha256(src.encode()).hexdigest(),'variants':results},indent=2)+'\n')
if not all(x['detected'] for x in results):raise SystemExit(1)
