from pathlib import Path
import subprocess,os,json,hashlib,shutil
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');D=Path(__file__).parent;T=Path('/private/tmp/truss-main-integration-20261010')
sql=(R/'tests/security/native/pg18-preparation-data-claim.sql').read_text();runner=(R/'tests/security/native/pg18-preparation-data-claim.py').read_text()
variants=[('original',sql,None),('paired-retry-identity',sql.replace(' OR r.data_xid IS DISTINCT FROM original_data_xid','').replace('  OR r.data_xact_start IS DISTINCT FROM d.xact_start OR r.coordinator_pid','  OR r.coordinator_pid'),'Missing native refusal:same-PID-successor-D-cannot-reclaim'),('disabled-immutability',sql.replace('ENABLE ALWAYS TRIGGER preparation_data_claim_immutable','DISABLE TRIGGER preparation_data_claim_immutable'),'Missing native refusal:immutable-update')]
assert variants[1][1]!=sql and 'r.data_xid IS DISTINCT FROM original_data_xid' not in variants[1][1] and 'r.data_xact_start IS DISTINCT FROM d.xact_start' not in variants[1][1]
results=[]
for name,text,expected in variants:
 work=D/'native-controls'/name;dest=work/'tests/security/native';dest.mkdir(parents=True,exist_ok=True)
 (dest/'pg18-preparation-data-claim.sql').write_text(text);(dest/'pg18-preparation-data-claim.py').write_text(runner)
 env={**os.environ,'PYTHONPATH':str(T/'packages/python/src')+':/private/tmp/weft-mutation-wheel-installed','PYTHONDONTWRITEBYTECODE':'1'}
 p=subprocess.run(['/private/tmp/truss-clean-install-20261013/bin/python',str(dest/'pg18-preparation-data-claim.py'),str(work/'evidence')],cwd=work,env=env,text=True,capture_output=True,timeout=150)
 (work/'run.log').write_text(p.stdout+p.stderr)
 passed=(p.returncode==0) if expected is None else (p.returncode!=0 and expected in p.stderr)
 receipt=work/'evidence/receipt.json'
 row={'name':name,'exit':p.returncode,'expectedDiagnostic':expected,'pass':passed,'sqlSha256':hashlib.sha256(text.encode()).hexdigest(),'runnerSha256':hashlib.sha256(runner.encode()).hexdigest(),'observations':len(json.loads(receipt.read_text())['observations']) if receipt.exists() else None}
 results.append(row);(D/'native-controls.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if not passed:raise AssertionError((name,'Unexpected failure, not counted',p.stderr[-3000:]))
