assert evaluated['kind'] == 'evaluation' and evaluated['projectionResults'] == inspected['projectionResults'] and (evaluated['routeResults'] == [])
assert [x['id'] for x in inspected['projectionResults']] == ['projection0']
metadata = evaluated['projectionResults'][0]['result']
assert metadata['selection'] == projections[0]['selection']
assert metadata['status'] == 'inspected' and metadata['authority'] is False and (metadata['complete'] is False)
batch = evaluated['batch']
assert batch['authority'] is False and batch['complete'] is False
if variant in ['missing', 'conflict']:
    assert batch == {'status': 'refused', 'complete': False, 'authority': False, 'operations': []}
else:
    cell = {'field': ref(field), 'disposition': 'original', 'value': {'string': 'opaque-token'}} if name == 'stored-token' else {'field': ref(field), 'disposition': 'withheld'} if variant == 'withheld' else {'field': ref(field), 'disposition': 'transformed', 'outputType': ref({**field, 'element': 'salaryMaskLabel'}), 'value': {'string': '[private]'}}
    rule_rows = [] if variant == 'empty' else [{'resource': {'type': scan['type'], 'key': [{'string': 'r1'}]}, 'decision': 'permit', 'rules': [{'ruleIndex': 0, 'truth': 'T'}, {'ruleIndex': 1, 'truth': 'T'}]}]
    expected_batch = {'status': 'completed', 'complete': False, 'authority': False, 'operations': [{'id': 'rules', 'kind': 'read-rules', 'outcome': {'status': 'evaluated', 'complete': False, 'authority': False, 'rows': rule_rows}}, {'id': 'cells', 'kind': 'scan', 'outcome': {'status': 'rendered', 'complete': False, 'authority': False, 'rows': [] if variant == 'empty' else [[cell]], 'valueProfiles': []}}]}
    assert batch == expected_batch, (name, variant, 'Complete original operation/result correspondence failed')
