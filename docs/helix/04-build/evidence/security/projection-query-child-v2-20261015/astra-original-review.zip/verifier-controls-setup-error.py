import ast,copy,hashlib,json,pathlib,textwrap
root=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
out=pathlib.Path('/private/tmp/projection-query-child-v2-astra-20261015')
path=root/'tools/security/weft-projection-child-interop-v2.py'
raw=path.read_bytes(); source=raw.decode(); tree=ast.parse(source)
blocks=[]
for node in ast.walk(tree):
 if isinstance(node,ast.Try):
  for i,n in enumerate(node.body):
   if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='evaluated' for t in n.targets):
    j=next(j for j in range(i+1,len(node.body)) if isinstance(node.body[j],ast.Expr) and isinstance(node.body[j].value,ast.Call) and isinstance(node.body[j].value.func,ast.Attribute) and node.body[j].value.func.attr=='append')
    blocks=node.body[i+1:j]
assert blocks
code=ast.unparse(ast.Module(body=blocks,type_ignores=[]))+'\n'; (out/'extracted-final-outcome-verifier.py').write_text(code)
compiled=compile(code,str(path)+':extracted-outcome','exec')
receipt_path=pathlib.Path('/private/tmp/umf-projection-v2-interop-final-20261015/receipt.json')
receipt=json.loads(receipt_path.read_bytes()); assert len(receipt['observations'])==9
sha=lambda b:hashlib.sha256(b).hexdigest()
ref=lambda e:{'documentId':'domain','moduleId':'m','elementId':e}
def env_for(observation):
 name,variant=observation['id'].split(':'); f='token' if name=='stored-token' else 'salary'
 return {'name':name,'variant':variant,'inspected':copy.deepcopy(observation['inspect']),'evaluated':copy.deepcopy(observation['evaluation']),'field':{'documentId':'domain','revision':'query-value-core-r1','module':'m','element':f},'scan':{'type':ref('Resource')},'projections':[{'id':'projection0','selection':{'type':ref('Resource'),'field':ref(f)}}],'ref':lambda identity:{'documentId':identity['documentId'],'moduleId':identity['module'],'elementId':identity['element']}}
rows=[]
for ob in receipt['observations']:
 exec(compiled,env_for(ob)); rows.append({'id':'positive:'+ob['id'],'passed':True})
base=next(x for x in receipt['observations'] if x['id']=='plain-salary:baseline')
empty=next(x for x in receipt['observations'] if x['id']=='plain-salary:empty')
refused=next(x for x in receipt['observations'] if x['id']=='plain-salary:missing')
def setpath(env,path,value):
 obj=env
 for part in path[:-1]:obj=obj[part]
 obj[path[-1]]=copy.deepcopy(value)
def mutate(identifier, changes, ob=base):
 env=env_for(ob)
 for p,v in changes:setpath(env,p,v)
 try:exec(compiled,env)
 except AssertionError:rows.append({'id':identifier,'passed':True,'outcome':'intended assertion refusal'});return
 except Exception as e:raise RuntimeError(identifier+' failed for unintended '+type(e).__name__) from e
 raise AssertionError('undetected: '+identifier)
b=['evaluated','batch']; ops=b+['operations']; cells=ops+[1,'outcome']; rules=ops+[0,'outcome']; row=copy.deepcopy(base['evaluation']['batch']['operations'][1]['outcome']['rows'][0]); cell=row[0]
mutate('extra-resource-row',[(cells+['rows'],[row,row])])
mutate('extra-cell',[(cells+['rows'],[[cell,cell]])])
mutate('wrong-cell-field',[(cells+['rows',0,0,'field'],ref('token'))])
mutate('wrong-output-domain',[(cells+['rows',0,0,'outputType'],ref('salary'))])
mutate('raw-value-leak',[(cells+['rows',0,0,'value'],{'integer':'100'})])
mutate('omitted-output',[(cells+['rows'],[])])
mutate('extra-value-profile',[(cells+['valueProfiles'],[{'field':ref('salary'),'profile':'invented'}])])
mutate('wrong-operation-id',[(ops+[1,'id'],'another')])
mutate('wrong-operation-kind',[(ops+[1,'kind'],'action')])
mutate('omitted-read-rule-operation',[(ops,[base['evaluation']['batch']['operations'][1]])])
mutate('reordered-operations',[(ops,list(reversed(base['evaluation']['batch']['operations'])))])
mutate('extra-operation',[(ops,base['evaluation']['batch']['operations']+[base['evaluation']['batch']['operations'][0]])])
mutate('wrong-resource-key',[(rules+['rows',0,'resource','key'],[{'string':'r2'}])])
mutate('wrong-rule-truth',[(rules+['rows',0,'rules',0,'truth'],'F')])
mutate('wrong-rule-index',[(rules+['rows',0,'rules',0,'ruleIndex'],1)])
mutate('wrong-read-decision',[(rules+['rows',0,'decision'],'deny')])
mutate('wrong-projection-id',[(k+['projectionResults',0,'id'],'other') for k in [['inspected'],['evaluated']]])
mutate('extra-projection',[(k+['projectionResults'],[base[k[0]]['projectionResults'][0]]*2) for k in [['inspected'],['evaluated']]])
mutate('wrong-projection-selection',[(k+['projectionResults',0,'result','selection','field'],ref('token')) for k in [['inspected'],['evaluated']]])
mutate('unexpected-query-route', [(['evaluated','routeResults'],[{}])])
mutate('authority-promotion',[(b+['authority'],True)])
mutate('complete-promotion',[(b+['complete'],True)])
mutate('empty-population-extra-row',[(cells+['rows'],[row])],empty)
mutate('refusal-prefix-escape',[(ops,[base['evaluation']['batch']['operations'][0]])],refused)
mutate('refusal-extra-member',[(b,dict(refused['evaluation']['batch'],extra=True))],refused)
# Historical first-cell predicate transcribed from inspected pre-fix segment only;
# not presented as recovered full source bytes. Demonstrate the concrete old gaps.
legacy="""metadata=evaluated['projectionResults'][0]['result'];assert metadata['status']=='inspected' and metadata['authority'] is False and metadata['complete'] is False
batch=evaluated['batch'];assert batch['authority'] is False and batch['complete'] is False
assert batch['status']=='completed';rows=batch['operations'][1]['outcome']['rows']
assert rows[0][0]['disposition']=='transformed' and rows[0][0]['outputType']==ref({**field,'element':'salaryMaskLabel'}) and rows[0][0]['value']=={'string':'[private]'}
"""
(out/'historical-first-cell-predicate-transcription.py').write_text(legacy)
old=[]
for label,p,v in [('extra-resource-row',cells+['rows'],[row,row]),('extra-cell',cells+['rows'],[[cell,cell]]),('wrong-cell-field',cells+['rows',0,0,'field'],ref('token')),('wrong-operation-id',ops+[1,'id'],'other'),('wrong-resource-key',rules+['rows',0,'resource','key'],[{'string':'r2'}])]:
 e=env_for(base);setpath(e,p,v);exec(legacy,e);old.append({'id':label,'historicalPredicateAccepted':True,'finalVerifierRefuses':True})
result={'passed':all(x['passed'] for x in rows),'sourceSha256':sha(raw),'receiptSha256':sha(receipt_path.read_bytes()),'positiveControls':9,'negativeControls':len(rows)-9,'rows':rows,'historicalSurvivors':old,'scope':'Extracted exact final outcome assertions against retained actual original-pipe responses; finite mutation discrimination, not independent native or producer implementation execution.'}
(out/'verifier-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['passed','sourceSha256','positiveControls','negativeControls']}))
