metadata=evaluated['projectionResults'][0]['result'];assert metadata['status']=='inspected' and metadata['authority'] is False and metadata['complete'] is False
batch=evaluated['batch'];assert batch['authority'] is False and batch['complete'] is False
assert batch['status']=='completed';rows=batch['operations'][1]['outcome']['rows']
assert rows[0][0]['disposition']=='transformed' and rows[0][0]['outputType']==ref({**field,'element':'salaryMaskLabel'}) and rows[0][0]['value']=={'string':'[private]'}
