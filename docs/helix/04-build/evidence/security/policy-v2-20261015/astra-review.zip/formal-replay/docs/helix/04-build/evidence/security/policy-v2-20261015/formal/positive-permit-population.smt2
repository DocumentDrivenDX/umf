; benchmark generated from python API
(set-info :status unknown)
(declare-sort JsonValue 0)
(declare-fun legacy_outcome (JsonValue JsonValue JsonValue) Int)
(declare-fun same_admitted_facts () JsonValue)
(declare-fun source () (Array Int JsonValue))
(declare-fun r3 () JsonValue)
(declare-fun v1 () JsonValue)
(declare-fun r2 () JsonValue)
(declare-fun v2 () JsonValue)
(declare-fun changed () JsonValue)
(assert
 (let ((?x35 (select source 3)))
 (let ((?x53 (select source 2)))
 (let ((?x31 (legacy_outcome ?x53 ?x35 same_admitted_facts)))
 (= ?x31 1)))))
(assert
 (let ((?x16 (store (store (store (store source 0 v2) 1 r2) 0 v1) 1 r3)))
 (let ((?x41 (legacy_outcome (select ?x16 2) (select ?x16 3) same_admitted_facts)))
 (= ?x41 1))))
(assert
 (let ((?x53 (select source 2)))
(and (distinct ?x53 changed) true)))
(check-sat)
