; benchmark generated from python API
(set-info :status unknown)
(declare-fun has_catalog_tag () Bool)
(declare-fun has_pin () Bool)
(assert
 (let (($x19 (not has_catalog_tag)))
 (let (($x55 (not has_pin)))
 (and $x55 $x19))))
(assert
 has_catalog_tag)
(check-sat)
