from pathlib import Path
import json,hashlib,difflib,datetime
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent;dest=out/'adoption';dest.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
original=(out/'oracle.ts').read_text();adopted=(root/'tests/security/protection/migration-oracle.ts').read_text()
expected=original.replace("'/Users/erik/.codex/worktrees/security-main-integration/umf/src/index.ts'","'../../../src/index'").replace("badResolution.resolution.documents[0].revision", "badResolution.resolution.documents[0]!.revision")
assert adopted==expected
old=json.loads((out/'sources/docs/helix/03-test/security/cases.json').read_text());new=json.loads((root/'docs/helix/03-test/security/cases.json').read_text())
assert len(old['cases'])==len(new['cases'])==158
oldcase=next(c for c in old['cases'] if c['id']=='S15');newcase=next(c for c in new['cases'] if c['id']=='S15')
allowed={'status','command','evidence','testSource','oracleSource','implementationSources'}
assert {k:v for k,v in oldcase.items() if k not in allowed}=={k:v for k,v in newcase.items() if k not in allowed}
assert [c for c in old['cases'] if c['id']!='S15']==[c for c in new['cases'] if c['id']!='S15']
assert newcase['command']==['bun','tests/security/protection/migration-acceptance.ts','S15'] and newcase['testSource']==newcase['command'][1]
assert newcase['oracleSource']=='tests/security/protection/migration-oracle.ts'
assert len(newcase['implementationSources'])==33
paths=list(dict.fromkeys([newcase['testSource'],newcase['oracleSource'],*newcase['implementationSources'],'docs/helix/03-test/security/cases.json','docs/helix/02-design/spikes/security/acceptance.ts','tools/security/run-command.ts']))
pins={}
for p in paths:
 data=(root/p).read_bytes();pins[p]=sha(data);target=dest/'sources'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
(dest/'adoption.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),adopted.splitlines(True),fromfile='independent-review-oracle',tofile='adopted-oracle')))
checks={'mechanicalImportAndNonnullOnly':True,'same149Expectations':True,'unchangedS15AssertionCoversRequiredLayerTimeoutAndAssertionIds':True,'unchangedOther157Cases':True,'original158RequiredRows':True,'exactCommandTestSourceOracleBinding':True,'selectedSourceCount':35,'newCase':newcase}
(dest/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(dest/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
review={'status':'reviewed-no-actionable-finding','createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Mechanical independent oracle adoption, governed wrapper source and S15-only runner binding; no source edits or full gate rerun by reviewer.','checks':'checks.json','sourceDigests':'source-pins.json','independentEvidence':'../results.json (149 actual Bun/Chromium controls, full observation parity)','wrapper':'Source reviewed: exact fresh case/run/command, independently authored oracle in Bun/browser, no empty/passing-false row, all observations checked, source-before/after equality, host globals/network/page errors, structured aggregate S15 receipt.','gateStatus':'Parent full shared gate running at review time. No final acceptance outcome inferred; parent fresh execution receipt must establish it.','qualification':'Unchanged S15 legacy migration/rollback assertion can be qualified by the bound finite independent semantic oracle and actual fresh governed Bun/Chromium execution. No S13/domain/function/native closure is inferred.','scopeLimits':['Synthetic host attestations; logical results, not credentials or native policy activation.','Finite controls, conditional formal laws; no universal implementation/refinement theorem.','Selected source endpoint custody only; installed dependencies/runtime/source ABA remain trusted.'],'findings':[],'artifactSha256':{p:sha((dest/p).read_bytes()) for p in ['checks.json','source-pins.json','adoption.diff']}}
(dest/'review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({'receipt':str(dest/'review.json'),'sha256':sha((dest/'review.json').read_bytes())}))
