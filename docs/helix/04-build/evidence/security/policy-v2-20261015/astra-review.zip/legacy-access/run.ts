import {chromium} from '/Users/erik/.codex/worktrees/security-main-integration/umf/node_modules/playwright/index.mjs';
import {createHash} from 'node:crypto';
import {runOracle} from './oracle';
const out=import.meta.dir,root='/Users/erik/.codex/worktrees/security-main-integration/umf';
const sources=['src/index.ts','src/extensions/security/policy-v2-legacy-access.ts','src/extensions/security/policy-representation-v2.ts','src/extensions/security/protection/references.ts','src/extensions/security/protection/catalog.ts','src/extensions/security/evaluate.ts','src/extensions/security/policy.ts','src/extensions/security/types.ts','src/model/json.ts','src/model/schema-literals.ts','src/model/key-tuple.ts','spec/extensions/security/package.json','spec/extensions/security/schema.json','spec/extensions/security/ontology.schema.json','spec/extensions/security-v0.2/package.json','spec/extensions/security-v0.2/schema.json','spec/extensions/security-protection/schema.json','spec/extensions/security-protection/package.json','tests/security/protection/policy-v2.test.ts','tools/security/policy-v2-browser.ts','tools/security/policy-v2-controls.ts','tools/security/prove-policy-source-migration.py','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md','docs/helix/03-test/security/cases.json','docs/helix/03-test/test-plans/STP-079-security-semantics.md','bun.lock'];
const hash=(v:Uint8Array|string)=>createHash('sha256').update(v).digest('hex');
async function pins(){return Object.fromEntries(await Promise.all(sources.map(async p=>[p,hash(new Uint8Array(await Bun.file(root+'/'+p).arrayBuffer()))])));}
const before=await pins();await Bun.write(out+'/source-pins-before.json',JSON.stringify(before,null,2)+'\n');
const bun=runOracle();await Bun.write(out+'/bun-results.json',JSON.stringify(bun,null,2)+'\n');
if(bun.some(x=>!x.passed))throw Error('Independent Bun expectations failed '+JSON.stringify(bun.filter(x=>!x.passed)));
const built=await Bun.build({entrypoints:[out+'/oracle.ts'],target:'browser',format:'esm'});if(!built.success||built.outputs.length!==1)throw Error('browser build '+JSON.stringify(built.logs));
const js=await built.outputs[0].text();if(js.length>16_000_000)throw Error('local harness bundle ceiling');
await Bun.write(out+'/oracle.bundle.js',js);

let browser;try{
 browser=await chromium.launch({headless:true,...(Bun.env.UMF_CHROMIUM_PATH?{executablePath:Bun.env.UMF_CHROMIUM_PATH}:{})});
 const page=await browser.newPage();let externalRequests=0;const consoleErrors:string[]=[];page.on('pageerror',e=>consoleErrors.push(String(e)));
 await page.route('**/*',r=>{externalRequests++;return r.abort();});
 await page.goto('about:blank');
 const browserResult=await page.evaluate(async(bundle)=>{const path=URL.createObjectURL(new Blob([bundle],{type:'text/javascript'}));try{const m=await import(path);return {rows:m.runOracle(),hostGlobalsAbsent:['Bun','process','Buffer','Deno'].every(k=>!(k in globalThis))};}finally{URL.revokeObjectURL(path);}},js);
 const after=await pins();await Bun.write(out+'/source-pins-after.json',JSON.stringify(after,null,2)+'\n');
 const result={status:'passed',bunVersion:Bun.version,chromiumVersion:browser.version(),controls:bun.length,bun,browser:browserResult,externalRequests,consoleErrors,sourceUnchanged:JSON.stringify(before)===JSON.stringify(after),sourceDigests:after,bundleSha256:hash(js),bundleUtf16Units:js.length,bundleBytes:Buffer.byteLength(js),oracleSha256:hash(new Uint8Array(await Bun.file(out+'/oracle.ts').arrayBuffer())),runnerSha256:hash(new Uint8Array(await Bun.file(out+'/run.ts').arrayBuffer())),limits:['Independent finite original legacy-domain oracle, not a proof of all literals or schema walkers.','Synthetic explicit host attestations; no native admission, source authentication, protection/domain/custody interpretation, compiler or collection/write claim.','S15 plan remains unmodified and unbound; governed acceptance runner and receipt custody are separate.']};
 if(externalRequests||consoleErrors.length||!browserResult.hostGlobalsAbsent||JSON.stringify(browserResult.rows)!==JSON.stringify(bun)||!result.sourceUnchanged)throw Error('Browser parity/custody failure');
 await Bun.write(out+'/results.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,controls:result.controls,chromium:result.chromiumVersion,sourceUnchanged:result.sourceUnchanged}));
}finally{await browser?.close();}
