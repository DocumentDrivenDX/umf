from pathlib import Path
import hashlib,io,json,subprocess,tarfile,zipfile
p=Path(__file__).resolve().parent;run=Path('/private/tmp/umf-weft-public-cohort-20261015-r2');root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');truss=Path('/private/tmp/truss-main-integration-20261010')
sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((run/'receipt.json').read_text());checks=[]
def check(n,b,count=None):
 checks.append({'name':n,'passed':bool(b),'count':count});assert b,n
check('exact-passing-receipt',r['status']=='passed' and r['trussCommit']=='ad794577539be9d059708a1f7e3a71857c644cbc')
check('retained-before-after-inputs-current',all(sha(Path(k).read_bytes())==v for k,v in r['pinsBeforeAfter'].items()),len(r['pinsBeforeAfter']))
pins=r['sourceInputs'];data=subprocess.check_output(['git','-C',str(truss),'archive',r['trussCommit'],'packages/python/src'])
with tarfile.open(fileobj=io.BytesIO(data)) as t:
 actual={m.name:sha(t.extractfile(m).read()) for m in t.getmembers() if m.isfile()}
check('exact-committed-source-population',actual==pins,len(pins))
check('original-archive-digest',sha((run/'original-inputs.zip').read_bytes())==r['archiveSha256'])
with zipfile.ZipFile(run/'original-inputs.zip') as z:
 check('unique-exact-archive-population',len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(pins),len(pins))
 check('archive-bytes-exact',all(sha(z.read(k))==v for k,v in pins.items()),len(pins))
check('original-extracted-bytes-exact',all(sha((run/'original'/k).read_bytes())==v for k,v in pins.items()),len(pins))
check('loaded-modules-from-exact-committed-snapshot',all(pins.get(v['path'])==v['sha256'] and (run/'original'/v['path']).resolve().is_relative_to((run/'original').resolve()) for v in r['loadedTrussModules'].values()),len(r['loadedTrussModules']))
ci=Path('/private/tmp/weft-release033-ci-arm/weft_sql-0.4.33-cp39-abi3-macosx_11_0_arm64.whl');public=Path('/private/tmp/weft-release033-published-20261015/weft_sql-0.4.33-cp39-abi3-macosx_11_0_arm64.whl')
expected={'weft/__init__.py','weft/weft.abi3.so',*[f'weft_sql-0.4.33.dist-info/{n}' for n in ['METADATA','WHEEL','RECORD']]}
check('distinct-explicitly-pinned-wheel-archives',sha(ci.read_bytes())=='dfe0fa7f8286758c6e1f24e417e62e11f252dce9896ecf99800f5151b49c9fb3' and sha(public.read_bytes())=='8ea8e06b7e8cf3623df69dd1e27c3bde3a1189f3adbd01c43f4a1519431b2b35' and ci.read_bytes()!=public.read_bytes())
with zipfile.ZipFile(ci) as a,zipfile.ZipFile(public) as b:
 check('both-five-member-populations-unique-exact',len(a.namelist())==len(b.namelist())==5 and set(a.namelist())==set(b.namelist())==expected)
 check('all-five-payloads-byte-identical',all(a.read(k)==b.read(k) for k in expected),5)
 check('receipt-member-digests-match',r['wheelMembersIdentical']=={k:sha(b.read(k)) for k in expected},5)
check('installed-five-members-remain-exact',all(sha((run/'public-installed'/k).read_bytes())==v for k,v in r['wheelMembersIdentical'].items()),5)
check('exact-child-and-manifest',pins['packages/python/src/truss/_current_query_owner/current-query-child.mjs']==r['publicConsumer']['umfBundleSha256']=='36e2c63fb0d942c9b94141f1753bcd9b56aad9e32dec5aa1a9ee27aabc674248' and pins['packages/python/src/truss/_current_query_owner/manifest.json']==r['publicConsumer']['umfManifestSha256']=='98eed644128b6f77d087293360e062fc06cce941dcb686e09c35632a5560f03d')
case=root/'docs/helix/03-test/security/cases.json';raw=case.read_bytes();check('all-original-case-definitions-unchanged',raw==subprocess.check_output(['git','-C',str(root),'show','HEAD:docs/helix/03-test/security/cases.json']))
cases=json.loads(raw)['cases'];check('all-158-and-30-truss-retained',len(cases)==158 and sum(c['id'].startswith('truss.') for c in cases)==30)
(p/'verification.json').write_text(json.dumps({'status':'passed','checks':checks,'count':len(checks),'nativeDatabaseRun':False},indent=2)+'\n')
selected=[root/'tools/security/verify-published-weft-cohort.py',run/'receipt.json',run/'original/packages/python/src/truss/_current_query_originals.py',case]
(p/'source-pins.json').write_text(json.dumps({'files':{str(f):sha(f.read_bytes()) for f in selected},'inputArchive':{'path':str(run/'original-inputs.zip'),'sha256':r['archiveSha256']},'inputs':r['pinsBeforeAfter'],'consumer':r['publicConsumer']},indent=2)+'\n')
print(json.dumps({'status':'passed','checks':len(checks),'sourceFiles':len(pins),'loadedModules':len(r['loadedTrussModules'])}))
