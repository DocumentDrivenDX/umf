from pathlib import Path
import ast,hashlib,io,json,tempfile,types,zipfile,warnings,sys,importlib
p=Path(__file__).resolve().parent;tool=Path('/Users/erik/.codex/worktrees/security-main-integration/umf/tools/security/verify-published-weft-cohort.py');src=tool.read_text();tree=ast.parse(src);before=hashlib.sha256(tool.read_bytes()).hexdigest();sha=lambda b:hashlib.sha256(b).hexdigest()
node=next(n for n in tree.body if isinstance(n,ast.With) and len(n.items)==2 and 'zipfile.ZipFile(a.ci_wheel)' in ast.get_source_segment(src,n))
post=next(n for n in tree.body if isinstance(n,ast.Assert) and 'installed/name' in ast.get_source_segment(src,n))
(p/'extracted-wheel-guards.py.txt').write_text(ast.get_source_segment(src,node)+'\n'+ast.get_source_segment(src,post)+'\n')
body=compile(ast.Module(body=[node],type_ignores=[]),str(tool),'exec');final=compile(ast.Module(body=[post],type_ignores=[]),str(tool),'exec')
ci=Path('/private/tmp/weft-release033-ci-arm/weft_sql-0.4.33-cp39-abi3-macosx_11_0_arm64.whl').read_bytes();public=Path('/private/tmp/weft-release033-published-20261015/weft_sql-0.4.33-cp39-abi3-macosx_11_0_arm64.whl').read_bytes();results=[]
with zipfile.ZipFile(io.BytesIO(public)) as z: entries=[(n,z.read(n)) for n in z.namelist()]
expected_names={n for n,b in entries}
def mutate(kind):
 target='weft/__init__.py';pairs=list(entries)
 if kind=='duplicate':pairs.append(pairs[0])
 elif kind=='omitted':pairs=pairs[:-1]
 elif kind=='extra':pairs.append(('extra.py',b''))
 elif kind in ('shim-bytes','metadata-bytes'):
  target=target if kind=='shim-bytes' else 'weft_sql-0.4.33.dist-info/METADATA';pairs=[(n,b+b'\n' if n==target else b) for n,b in pairs]
 out=io.BytesIO()
 with warnings.catch_warnings():
  warnings.simplefilter('ignore',UserWarning)
  with zipfile.ZipFile(out,'w') as z:
   for n,b in pairs:
    if kind=='symlink' and n==target:
     info=zipfile.ZipInfo(n);info.external_attr=0o120777<<16;z.writestr(info,b)
    else:z.writestr(n,b)
 return out.getvalue()
for kind in ['baseline','duplicate','omitted','extra','shim-bytes','metadata-bytes','symlink','installed-after-import-change']:
 with tempfile.TemporaryDirectory(prefix='weft-payload-review-') as tmp:
  new=public if kind in ('baseline','installed-after-import-change') else mutate(kind)
  ns={'zipfile':zipfile,'a':types.SimpleNamespace(ci_wheel=io.BytesIO(ci),public_wheel=io.BytesIO(new)),'expected_names':expected_names,'installed':Path(tmp),'members':{},'sha':sha}
  rejected=False
  try:
   exec(body,ns)
   if kind=='installed-after-import-change':(Path(tmp)/'weft/__init__.py').write_bytes(b'changed')
   exec(final,ns)
  except AssertionError:rejected=True
  passed=rejected==(kind!='baseline');results.append({'case':kind,'passed':passed,'rejected':rejected});assert passed,kind
# Original committed consumer helpers with actual already-verified public native bytes;
# no database, child process or native query is invoked.
run=Path('/private/tmp/umf-weft-public-cohort-20261015-r2');sys.dont_write_bytecode=True;sys.path[:0]=[str(run/'public-installed'),str(run/'original/packages/python/src')]
original=importlib.import_module('truss._current_query_originals');native=importlib.import_module('weft.weft')
assert Path(original.__file__).resolve().is_relative_to((run/'original').resolve());assert sha(Path(native.__file__).read_bytes())=='60b977a1c8b8a355b86be40375aab209ed894b172dbed972498721eab8bbddae'
expected={'profile':'truss-current-query-consumer/0.1-candidate','umfRevision':'579675bdad79c349b06e25979108f8ac1bb7f7e0','umfBundleSha256':'36e2c63fb0d942c9b94141f1753bcd9b56aad9e32dec5aa1a9ee27aabc674248','umfManifestSha256':'98eed644128b6f77d087293360e062fc06cce941dcb686e09c35632a5560f03d','bunVersion':'1.4.2','weftRevision':'cc943a2f0ad87e3742cccdc171184bad7d4dbf60','weftWheelSha256':'8ea8e06b7e8cf3623df69dd1e27c3bde3a1189f3adbd01c43f4a1519431b2b35','weftModuleSha256':'60b977a1c8b8a355b86be40375aab209ed894b172dbed972498721eab8bbddae','resultAbi':'weft.postgresql.current-values/0.2-candidate'}
assert original._actual_consumer()==expected;results.append({'case':'actual-original-consumer-exact-independent-dictionary','passed':True})
for name,change in [('original-positive',{}),('stale-ci',{'weftWheelSha256':'dfe0fa7f8286758c6e1f24e417e62e11f252dce9896ecf99800f5151b49c9fb3'}),('wrong-abi',{'resultAbi':'weft.postgresql.current-values/0.4-candidate'}),('extra-member',{'unrecognized':True}),('wrong-child',{'umfBundleSha256':'0'*64})]:
 rejected=False
 try:assert original._match_consumer({**expected,**change}) is None
 except ValueError as e:
  assert str(e)=='Unsupported exact query consumer selection';rejected=True
 passed=rejected==(name!='original-positive');assert passed,name;results.append({'case':name,'passed':passed,'rejected':rejected})
assert sha(tool.read_bytes())==before
(p/'controls.json').write_text(json.dumps({'status':'passed','toolSha256':before,'count':len(results),'results':results,'scope':'Eight extracted original ZIP/member guard controls, six actual original consumer controls; digest preflight omitted only in extracted synthetic ZIP tests so payload guards are exercised. No DB, child or cloud execution.'},indent=2)+'\n')
print(json.dumps({'status':'passed','controls':len(results)}))
