from pathlib import Path
import hashlib,json,subprocess
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/query-value-sources-astra-20261015');checks=[]
def check(id,x):checks.append({'id':id,'passed':bool(x)});assert x,id
for variant in ['r1-undisclosed','r2-allowed','r2-revoked']:
 prefix=O/'readsets-final'
 a=json.loads((prefix/(variant+'-mixed-order-id-asc-token-desc-zero.report.json')).read_text());b=json.loads((prefix/(variant+'-mixed-order-id-desc-token-asc-zero.report.json')).read_text())
 check(variant+':whole-plan-byte-equal',a['applicationPlanJson']==b['applicationPlanJson'])
 check(variant+':opposite-independent-directions',a['orderDirections']==['asc','desc'] and b['orderDirections']==['desc','asc'])
 check(variant+':different-original-requests',a['sourceRequestJson']!=b['sourceRequestJson'])
for name in ['current-query-source.json','current-query-read-scenarios.json']:
 p='tests/security/protection/'+name;check(name+':historical-source-byte-preserved',subprocess.check_output(['git','show','ed676698:'+p],cwd=R)==(R/p).read_bytes())
f=json.loads((R/'tests/security/protection/query-value-modes-source.json').read_text());fields={e['id']:e for e in f['closure']['documents'][0]['document']['modules'][0]['elements']};member={x['element'] for x in fields['Resource']['members']}
check('independent-original-and-dto-types',(fields['salary']['scalarType'],fields['salaryMaskLabel']['scalarType'],fields['token']['scalarType'],fields['clear']['scalarType'])==('integer','string','string','integer'))
check('storage-input-not-live-resource-member','clear' not in member and 'token' in member)
entity=next(e for e in f['ontology']['entities'] if e['type']['elementId']=='Resource');modes={e['ref']['elementId']:e.get('queryUse') for e in entity['fields']}
check('exact-mode-table-correspondence',all(modes[t['outputDomain']['elementId'] if t['id']=='vault' else t['inputDomain']['elementId']]==t['queryUse'] for t in f['catalog']['transforms']))
base=next(r for r in f['policy']['rules'] if r['id']=='membership')['condition']
check('exact-two-distinct-original-intents',[(x['field']['elementId'],x['operator'],x['action']) for x in f['intendedOriginalActions']]==[('salary','predicate','query-original-salary-predicate'),('token','order','query-original-token-order')])
for intent in f['intendedOriginalActions']:
 action=intent['action'];check(action+':source-purpose',next(x for x in f['ontology']['actionPurposes'] if x['action']==action)['purposes']==['original-authorized']);check(action+':membership-not-weakened',next(r for r in f['policy']['rules'] if r['id']==action+'-membership')['condition']==base)
# Verify final fixture drift was refused before success publication.
check('fixed-issuer-positive-109',json.loads((O/'fixed-issuer/reports/receipt.json').read_text())['controls']==109)
check('fixed-fixture-drift-refused-no-receipt',not (O/'fixed-issuer-fixture-drift/reports/receipt.json').exists() and 'error: producer-unchanged' in (O/'fixed-issuer-fixture-drift/run.log').read_text())
check('direction-tamper-exact-diagnostic','hidden-read-false-zero:original-order-directions' in (O/'directions-tampered.log').read_text())
check('direction-check-omission-counterexample',json.loads((O/'readsets-directions-unchecked/receipt.json').read_text())['controls']==418)
check('native-14-final-cleanup', (lambda x:x['status']=='primitive-observations-passed' and len(x['checks'])==14 and all(c['passed'] for c in x['checks']) and x['cleanup']['ownedVolumesAbsent'] and x['cleanup']['containerAbsent'] and x['sourcesUnchanged'])(json.loads((O/'native-final-escalated.json').read_text())))
result={'status':'passed','checks':checks,'scope':'Independent fixed expectations and byte comparisons. Mode correspondence is source intent, not an issued compiler designation. Native observations are owner-only primitives.'};(O/'independent-report-source-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'controls':len(checks),'passed':len(checks)}))
