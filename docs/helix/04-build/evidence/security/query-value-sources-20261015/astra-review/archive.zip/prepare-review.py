from pathlib import Path
import json,hashlib,shutil,re
ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf'); OUT=Path('/private/tmp/query-value-sources-astra-20261015')
files=json.loads((OUT/'initial-source-pins.json').read_text())
if isinstance(files,dict) and 'sources' in files: files=files['sources']
if not isinstance(files,dict): raise RuntimeError(type(files))
paths=list(files)
if any(not isinstance(x,str) or not (ROOT/x).is_file() for x in paths):
 paths=['tools/security/query-value-mode-issuer.ts','tools/security/query-value-native-spike.py','tools/security/prove-query-value-sources.py','tools/security/current-query-readsets.ts','tools/security/query-value-source-browser.ts','tests/security/query-value-source-corpus.ts','tests/security/query-value-source.test.ts','tests/security/protection/query-value-modes-source.json','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md','docs/helix/02-design/technical-designs/TD-079-security-semantics.md','docs/helix/03-test/test-plans/STP-079-security-semantics.md']
paths+=['src/extensions/security/stored-query-candidate.ts','src/extensions/security/evaluate.ts','tests/security/protection/current-query-source.json','tests/security/protection/current-query-read-scenarios.json','docs/helix/04-build/evidence/security/query-value-sources-20261015/weft-original-report.schema.json']
pins={}
for p in sorted(set(paths)):
 b=(ROOT/p).read_bytes(); dst=OUT/'final-sources'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);pins[p]=hashlib.sha256(b).hexdigest()
(OUT/'final-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
issuer=(ROOT/'tools/security/query-value-mode-issuer.ts').read_text()
for name,change in [('fixed-issuer',False),('fixed-issuer-fixture-drift',True)]:
 dst=OUT/name;dst.mkdir();(dst/'tools/security').mkdir(parents=True)
 for link in ['src','node_modules']: (dst/link).symlink_to(ROOT/link,target_is_directory=True)
 for p in ['tests/security/protection/query-value-modes-source.json','docs/helix/04-build/evidence/security/query-value-sources-20261015/weft-original-report.schema.json','bun.lock','package.json']:
  d=dst/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/p,d)
 code=issuer
 if change:
  needle='const report=JSON.parse(stdout);';assert code.count(needle)==1
  code=code.replace(needle,needle+"if(name==='disclosed-token-equality'){const altered=JSON.parse(await Bun.file(fixturePath).text());altered.catalog.transforms[0].queryUse.order='prohibited';await Bun.write(fixturePath,JSON.stringify(altered));}")
 (dst/'tools/security/query-value-mode-issuer.ts').write_text(code)
# Private single-module weakenings use original dependency instances, so original handles stay genuine.
def relocate(path,text):
 return re.sub(r"(from\s+['\"])(\.[^'\"]+)(['\"])",lambda m:m[1]+str((path.parent/m[2]).resolve())+m[3],text)
sp=ROOT/'src/extensions/security/stored-query-candidate.ts'; code=sp.read_text();needle='queryDomain:transform.outputDomain';assert code.count(needle)==1
(OUT/'stored-prestorage-mutant.ts').write_text(relocate(sp,code.replace(needle,'queryDomain:transform.inputDomain')))
ep=ROOT/'src/extensions/security/evaluate.ts'; code=ep.read_text();needle='const d=disposition(r);if(d.kind';assert code.count(needle)==1
code=code.replace(needle,"const d=request.queryUses?.some(q=>id(q.field)===id(r)&&q.originalAction)?{kind:'original' as const}:disposition(r);if(d.kind")
(OUT/'global-field-remap-mutant.ts').write_text(relocate(ep,code))
# Actual report tamper: invert every issued direction; proper verifier must refuse.
rp=ROOT/'tools/security/current-query-readsets.ts';base=rp.read_text();needle='const report=JSON.parse(stdout);';assert base.count(needle)==1
changed=base.replace(needle,needle+"report.orderDirections=report.orderDirections.map((x:string)=>x==='asc'?'desc':'asc');")
(OUT/'directions-tampered.ts').write_text(relocate(rp,changed))
guard="check(label+':original-order-directions',same(report.orderDirections,expectedDirections));";assert changed.count(guard)==1
(OUT/'directions-check-omitted.ts').write_text(relocate(rp,changed.replace(guard,'')))
print(json.dumps({'pins':len(pins),'prepared':True}))
