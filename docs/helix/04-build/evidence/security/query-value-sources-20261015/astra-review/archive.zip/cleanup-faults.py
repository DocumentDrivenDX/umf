from pathlib import Path
import ast,json,hashlib,subprocess,traceback
ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');OUT=Path('/private/tmp/query-value-sources-astra-20261015'); path=ROOT/'tools/security/query-value-native-spike.py';source=path.read_text();tree=ast.parse(source);body=next(n for n in tree.body if isinstance(n,ast.Try)).finalbody
code=compile(ast.Module(body=body,type_ignores=[]),str(path)+':finally','exec');results=[]
cases=[('owned-clean',{}),('container-inventory-error',{'container_inventory_error':True}),('volume-inventory-error',{'volume_inventory_error':True}),('container-still-present',{'container_present':True}),('owned-volume-still-present',{'volume_present':True}),('remove-error',{'remove_error':True}),('inspect-error',{'inspect_error':True}),('source-drift',{'source_drift':True}),('incomplete-primitives',{'incomplete':True})]
for name,mode in cases:
 out=OUT/('cleanup-final-'+name+'.json');calls=[]
 def command(args,**kw):
  calls.append(args)
  if args[1]=='inspect': return subprocess.CompletedProcess(args,1 if mode.get('inspect_error') else 0,json.dumps([{'Mounts':[{'Type':'volume','Name':'ownedvol'}]}]),'daemon unavailable' if mode.get('inspect_error') else '')
  if args[1]=='rm':return subprocess.CompletedProcess(args,1 if mode.get('remove_error') else 0,'','remove failed' if mode.get('remove_error') else '')
  if args[1:3]==['container','ls']:return subprocess.CompletedProcess(args,1 if mode.get('container_inventory_error') else 0,'ownedid ownedname\n' if mode.get('container_present') else '','inventory failure' if mode.get('container_inventory_error') else '')
  if args[1:3]==['volume','ls']:return subprocess.CompletedProcess(args,1 if mode.get('volume_inventory_error') else 0,'ownedvol\n' if mode.get('volume_present') else '','inventory failure' if mode.get('volume_inventory_error') else '')
  raise AssertionError(args)
 def require(result):
  if result.returncode:raise RuntimeError(result.stderr[:2000])
  return result.stdout.strip()
 sources=[str(path)];pins_before={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sources}
 if mode.get('source_drift'):pins_before[str(path)]='0'*64
 env={'json':json,'hashlib':hashlib,'pathlib':__import__('pathlib'),'container':'ownedid','name':'ownedname','command':command,'require':require,'sources':sources,'pins_before':pins_before,'checks':list(range(13 if mode.get('incomplete') else 14)),'cases':list(range(14)),'error':None,'cleanup':{},'versions':{},'out':out}
 error=None
 try:exec(code,env)
 except Exception as e:error=type(e).__name__+': '+str(e)
 receipt=json.loads(out.read_text()) if out.exists() else None
 positive=name=='owned-clean';passed=(error is None and receipt and receipt['status']=='primitive-observations-passed') if positive else (error is not None and (receipt is None or receipt['status']=='failed'))
 results.append({'id':name,'passed':bool(passed),'exception':error,'receiptStatus':receipt and receipt['status'],'commands':calls})
result={'scope':'Extracted actual final finally-block executed with controlled subprocess results; no Docker operations or native SQL in these faults. Successful baseline required.','source':str(path),'sha256':hashlib.sha256(source.encode()).hexdigest(),'controls':results};(OUT/'final-cleanup-fault-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'controls':len(results),'passed':sum(x['passed'] for x in results)}));assert all(x['passed'] for x in results)
