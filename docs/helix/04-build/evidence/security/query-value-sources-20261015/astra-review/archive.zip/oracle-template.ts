import fixture from '/Users/erik/.codex/worktrees/security-main-integration/umf/tests/security/protection/query-value-modes-source.json';
import {compileCandidateCatalogProgram as compile} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-program-candidate';
import {evaluateCandidateCatalogScanBatch as scan,evaluateCandidateCatalogAction as act} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-runtime-candidate';
import {inspectCandidateStoredQueryProperties as stored} from '__STORED__';
import {inspectProtectionQueryProperties as selected} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/protection/queries';
import {evaluateSecurityAccess as access} from '__ACCESS__';
import {evaluationFixture} from '/Users/erik/.codex/worktrees/security-main-integration/umf/tests/security/evaluation-fixture';
const r=(elementId:string)=>({documentId:'domain',moduleId:'m',elementId});
export function runOracle(){
 const rows:any[]=[],check=(id:string,expected:any,observed:any)=>rows.push({id,expected,observed,passed:JSON.stringify(expected)===JSON.stringify(observed)});
 const f:any=structuredClone(fixture),before=JSON.stringify(f),p=compile(f.policy,f.catalog,f.closure,f.ontology);
 const render=(x:any,field:string)=>scan(compile(x.policy,x.catalog,x.closure,x.ontology),x.owner,x.logicalCut,[{scan:'s0',type:r('Resource'),fields:[r(field)]}]);
 const action=(x:any,name:string)=>act(compile(x.policy,x.catalog,x.closure,x.ontology),x.owner,x.logicalCut,{action:name,targets:[r('Resource')],resources:[{type:r('Resource'),key:[{string:'r1'}]}],fields:[]});
 const q=stored(p,f.owner,{type:r('Resource'),field:r('token'),operator:'order',required:['order']});
 check('canonical-stored-query-domain',r('token'),(q.selection as any)?.queryDomain);
 check('prestorage-input-remains-separate',r('clear'),(q.selection as any)?.inputDomain);
 check('conditional-original-route-not-permission','requires-original-action',q.report?.status);
 check('conditional-result-no-authority',[false,false],[q.authority,q.complete]);
 check('actual-token-original-cell',{field:r('token'),disposition:'original',value:{string:'opaque-token'}},render(f,'token').scans[0]?.rows[0]?.[0]);
 check('actual-integer-to-string-mask-cell',{field:r('salary'),disposition:'transformed',outputType:r('salaryMaskLabel'),value:{string:'[private]'}},render(f,'salary').scans[0]?.rows[0]?.[0]);
 check('prestorage-input-not-member','refused',render(f,'clear').status);
 check('original-core-descriptor-unchanged','integer',f.closure.documents[0].document.modules[0].elements.find((e:any)=>e.id==='salary').scalarType);
 for(const name of ['query-original-token-order','query-original-salary-predicate']){
  check(name+':explicit-grant','permit',action(f,name).rows[0]?.decision);
  const denied=structuredClone(f);denied.policy.rules=denied.policy.rules.filter((x:any)=>x.id!==name+'-permit');
  check(name+':read-does-not-supply-grant','deny',action(denied,name).rows[0]?.decision);
  check(name+':mask-survives-grant-removal','[private]',(render(denied,'salary').scans[0]?.rows[0]?.[0] as any)?.value?.string);
 }
 for(const name of ['reverse','vault-write'])check(name+':not-granted-by-original','deny',action(f,name).rows[0]?.decision);
 const inactive=structuredClone(f);inactive.logicalCut.facts.find((x:any)=>x.type.elementId==='Assignment').fields.find((x:any)=>x.field.elementId==='active').value={boolean:false};
 check('original-action-requires-active-membership','deny',action(inactive,'query-original-token-order').rows[0]?.decision);
 const absent=structuredClone(f);absent.closure.documents[0].document.modules[0].elements.find((x:any)=>x.id==='salary').nullability='absent-allowed';const fact=absent.logicalCut.facts.find((x:any)=>x.type.elementId==='Resource');fact.fields=fact.fields.filter((x:any)=>x.field.elementId!=='salary');fact.absent.push(r('salary'));
 check('catalog-present-input-contract-not-silently-generalized','refused',render(absent,'salary').status);
 const wrongOutput=structuredClone(f);wrongOutput.policy.rules[0].disclosure[0].disposition.field=r('token');
 let wrongStatus:string;try{wrongStatus=render(wrongOutput,'salary').status;}catch{wrongStatus='refused';}
 check('global-output-domain-substitution-refused','refused',wrongStatus);
 const conflict=structuredClone(f);conflict.ontology.entities.find((x:any)=>x.type.elementId==='Resource').fields.find((x:any)=>x.ref.elementId==='token').queryUse.order='prohibited';
 const conditional=stored(compile(conflict.policy,conflict.catalog,conflict.closure,conflict.ontology),conflict.owner,{type:r('Resource'),field:r('token'),operator:'order',required:['order']});
 check('catalog-helper-is-not-mode-conjunction',['prohibited','requires-original-action'],[conflict.ontology.entities.find((x:any)=>x.type.elementId==='Resource').fields.find((x:any)=>x.ref.elementId==='token').queryUse.order,conditional.report?.status]);
 check('query-prohibition-before-any-native-work','prohibited',selected(f.policy,f.catalog,f.closure,{ruleIndex:0,disclosureIndex:0,operator:'order',required:['order']}).status);
 // Independent route-set table: design model only, not an implementation claim.
 const routeSets:any={prohibited:[],disclosed:['disclosed'],'original-authorized':['original']};
 let conflicts=0,silentWinner=0;for(const a of Object.keys(routeSets))for(const b of Object.keys(routeSets)){const ok=routeSets[a].filter((v:string)=>routeSets[b].includes(v));if(a!==b&&ok.length===0)conflicts++;if(a!==b&&routeSets[b].length)silentWinner++;}
 check('source-conjunction-disjoint-pairs',6,conflicts);check('catalog-winner-admits-disjoint-route-counterexamples',4,silentWinner);
 // Legacy typed permission controls. The actual request supplies no scalar SQL encoder.
 const g:any=evaluationFixture(),salary=g.resolution.ontology.entities.find((x:any)=>x.type.elementId==='Resource').fields.find((x:any)=>x.ref.elementId==='salary');salary.queryUse={predicate:'original-authorized'};g.resolution.ontology.actions.push('query-original');
 const request={action:'read',output:[r('salary')],queryUses:[{field:r('salary'),operator:'predicate' as const,originalAction:'query-original'}]};
 check('legacy-hidden-original-needs-separate-grant','indeterminate',access(g.policy,g.resolution,g.cut,request,g.resource).decision);
 g.policy.rules.push({id:'query-original',effect:'permit',actions:['query-original'],target:[r('Resource')],condition:{op:'literal',value:true}});
 check('hidden-original-cannot-unmask-projection',{decision:'permit',output:[{field:r('salary'),disposition:'withheld'}]},access(g.policy,g.resolution,g.cut,request,g.resource));
 g.policy.rules[0].disclosure[0].disposition={kind:'transformed',transform:'constant',version:'0.1.0',field:r('staffId'),value:{string:'redacted'}};
 check('hidden-original-cannot-retype-projection',{decision:'permit',output:[{field:r('salary'),disposition:'transformed',outputType:r('staffId'),value:{string:'redacted'}}]},access(g.policy,g.resolution,g.cut,request,g.resource));
 g.resource.fields=g.resource.fields.filter((x:any)=>x.field.elementId!=='salary');g.resource.absent=[r('salary')];g.resolution.documents[0].document.modules[0].elements.find((x:any)=>x.id==='salary').nullability='absent-allowed';salary.queryUse={predicate:'disclosed'};
 check('legacy-inline-constant-without-live-input',{decision:'permit',output:[{field:r('salary'),disposition:'transformed',outputType:r('staffId'),value:{string:'redacted'}}]},access(g.policy,g.resolution,g.cut,{...request,queryUses:[{field:r('salary'),operator:'predicate'}]},g.resource));
 salary.queryUse={predicate:'original-authorized'};check('known-absence-permission-is-not-scalar-admission','permit',access(g.policy,g.resolution,g.cut,request,g.resource).decision);
 check('new-source-not-mutated',before,JSON.stringify(f));
 return rows;
}
