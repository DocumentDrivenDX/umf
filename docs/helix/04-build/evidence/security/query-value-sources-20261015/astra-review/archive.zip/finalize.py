from pathlib import Path
import json,hashlib,re,subprocess,zipfile,datetime
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/query-value-sources-astra-20261015')
sha=lambda b:hashlib.sha256(b).hexdigest()
initial=json.loads((O/'final-source-pins.json').read_text());before_drift={p:{'captured':h,'current':sha((R/p).read_bytes())} for p,h in initial.items() if sha((R/p).read_bytes())!=h};assert not before_drift,before_drift
selected=set(initial)
for path in ['readsets-final/receipt.json','fixed-issuer/reports/receipt.json','native-final-escalated.json']:
 x=json.loads((O/path).read_text());pins=x.get('selectedSourceDigests',x.get('beforePins',{}))
 for p in pins:
  if not Path(p).is_absolute(): selected.add(p)
selected.update(['src/extensions/security/catalog-runtime-candidate.ts','src/extensions/security/catalog-program-candidate.ts','src/extensions/security/catalog-storage-candidate.ts','src/extensions/security/operation-budget-candidate.ts','src/extensions/security/protection/queries.ts','tests/security/evaluation-fixture.ts','tests/security/fixture.ts'])
# Selected transitive static relative imports; no dynamic/build/runtime closure claim.
queue=list(selected);done=set()
while queue:
 p=queue.pop()
 if p in done:continue
 done.add(p);file=R/p
 if file.suffix not in ['.ts','.js']:continue
 text=file.read_text()
 for rel in re.findall(r"(?:from\s*|import\s*)['\"](\.[^'\"]+)['\"]",text):
  base=file.parent/rel
  candidates=[base,Path(str(base)+'.ts'),Path(str(base)+'.json'),base/'index.ts']
  chosen=next((x for x in candidates if x.is_file()),None)
  if chosen:
   try:q=str(chosen.resolve().relative_to(R.resolve()))
   except ValueError:continue
   if q not in selected:selected.add(q);queue.append(q)
pins={}
for p in sorted(selected):
 b=(R/p).read_bytes();pins[p]=sha(b);d=O/'final-sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
(O/'final-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
# Strong evidence claims are validated here, not copied from parent counts.
browser=json.loads((O/'browser-result.json').read_text());assert browser['parity'] and not browser['pageErrors'] and not browser['externalRequests']
assert len(browser['results'][0]['rows'])==29 and all(x['passed'] for x in browser['results'][0]['rows'])
assert [sum(not r['passed'] for r in x['rows']) for x in browser['results']]==[0,1,2]
formal=json.loads((O/'formal-initial/receipt.json').read_text());assert len(formal['checks'])==31
assert sum(c['observed']=='unsat' for c in formal['checks'])==17
native=json.loads((O/'native-final-escalated.json').read_text());assert len(native['checks'])==14 and all(x['passed'] for x in native['checks']) and native['cleanup']['containerAbsent'] and native['cleanup']['ownedVolumesAbsent'] and native['sourcesUnchanged']
cleanup=json.loads((O/'final-cleanup-fault-controls.json').read_text());assert len(cleanup['controls'])==9 and all(x['passed'] for x in cleanup['controls'])
reportaudit=json.loads((O/'independent-report-source-audit.json').read_text());assert len(reportaudit['checks'])==24 and all(x['passed'] for x in reportaudit['checks'])
for rel,count in [('readsets-final/receipt.json',445),('fixed-issuer/reports/receipt.json',109)]:assert json.loads((O/rel).read_text())['controls']==count
assert not (O/'fixed-issuer-fixture-drift/reports/receipt.json').exists()
assert 'producer-unchanged' in (O/'fixed-issuer-fixture-drift/run.log').read_text()
assert 'original-order-directions' in (O/'directions-tampered.log').read_text()
assert "('conflicting-source-modes-have-no-route', 'sat')" in (O/'formal-catalog-winner-mutant.log').read_text()
review={
 'kind':'independent-astra-security-review','date':'2026-10-15','base':'ed676698','headObserved':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
 'scope':'Value-origin/designation prerequisite: normative contract refinement, independently named source fixture, conditional algebra, actual policy-independent Weft report correspondence, existing logical permission/value helpers and isolated owner-context PostgreSQL primitives.',
 'disposition':'No remaining blocking finding within the stated prerequisite scope after two evidence-custody corrections. This is not approval of executable native query admission.',
 'findings':[{'id':'issuer-fixture-custody','priority':'P2','status':'fixed-and-independently-reproduced','initial':'Final-only fixture hash allowed109 checks to pass while actual requests retained original-authorized and receipt pinned a fixture changed mid-run to prohibited.','fixed':'Parse captured raw fixture bytes, retain before/after selected file pins and require unchanged values before passed receipt; use fresh output directory.','positive':'fixed-issuer/reports/receipt.json','negative':'fixed-issuer-fixture-drift/run.log','initialEvidence':'initial-issuer-custody-control.json'},
 {'id':'native-cleanup-false-success','priority':'P2','status':'fixed-and-independently-reproduced','initial':'Nonzero inspect status was treated as container absence; daemon and permission errors could produce passed-looking receipts, even before a later removal assertion failed.','fixed':'Require successful container and volume inventories, verify container/owned-volume absence, removal success and before/after source equality before passed status.','initialEvidence':'initial-cleanup-fault-controls.json','finalEvidence':'final-cleanup-fault-controls.json','remainingLimit':'A failed pre-removal inspect now throws without passed receipt and can leave the isolated owned fixture requiring manual cleanup; no guaranteed cleanup on arbitrary daemon failure claim.'}],
 'independentExecution':{
  'sourceApiOracle':{'controls':29,'bun':'1.4.2','chromium':browser['browser'],'parity':True,'globalBunProcessAbsent':True,'pageErrors':0,'externalRequests':0,'receipt':'browser-result.json'},
  'actualWeftReadsets':{'controls':445,'reports':27,'receipt':'readsets-final/receipt.json'},
  'actualNewSourceIssuer':{'controls':109,'reports':7,'receipt':'fixed-issuer/reports/receipt.json','note':'Exact final issuer copied unchanged to a private fixture workspace; before/after captured source fixture/schema/helper pins, same original producer binary.'},
  'sourceReportAudits':{'controls':24,'receipt':'independent-report-source-audit.json'},
  'nativePrimitives':{'controls':14,'server':native['versions']['server'],'receipt':'native-final-escalated.json','cleanup':native['cleanup'],'note':'Owner-context VALUES/CTE primitives; no ordinary actor/native policy or protected query.'},
  'cleanupFaults':{'controls':9,'receipt':'final-cleanup-fault-controls.json','note':'Actual extracted final finally-block with controlled subprocess outcomes, not native fault injection.'},
  'formal':{'queries':31,'unsat':17,'sat':14,'freshSmtContexts':True,'solver':formal['solverVersion'],'receipt':'formal-initial/receipt.json','note':'Conditional algebra with source/completeness/correct classification, paired scope and authority as premises. No code/SQL refinement.'}},
 'meaningfulWeakenings':[
  {'id':'original-to-prestorage','kind':'private actual library module','source':'stored-prestorage-mutant.ts','result':'One exact query-domain expectation fails in both runtimes; canonical token cannot be relabeled pre-storage clear.'},
  {'id':'global-field-remap','kind':'private actual legacy evaluator module','source':'global-field-remap-mutant.ts','result':'Two exact public-output expectations fail in both runtimes: original salary100 replaces withheld or string mask.'},
  {'id':'ignored-direction-vector','kind':'private host verifier and actual original producer reports','source':'directions-tampered.ts','result':'Flipped original direction vector rejected at exact named check; removing only that check allows418 remaining checks to pass on deliberately wrong reports.','weakenedSource':'directions-check-omitted.ts'},
  {'id':'silent-catalog-mode-winner','kind':'conditional formal model, not implemented query admission','source':'formal-catalog-winner-mutant.py','result':'Dropping ontology constraint changes conflicting-source-modes-have-no-route from UNSAT to SAT; independent finite route table has4 catalog-winner counterexamples.'}],
 'semanticConclusions':[
  'Original live token has the stored output String domain; the integer pre-storage input is not a Resource member or an original-authorized operand.',
  'Read-time salary constant output is a separate String DTO. Exact original-action permissions remain separately gated by copied Project membership requirements and do not alter public projection disposition or type.',
  'Source action intents and matching mode tables are explicitly authored expectations, not a Weft-issued originalAction profile. Existing conditional property helpers do not implement whole-source mode conjunction.',
  'Same whole ApplicationPlan bytes retain opposite ASC/DESC vectors in the original reports; the verifier checks exact ordered vectors. Inert whitespace calibration is preserved, not reported as producer semantic loss.',
  'Legacy permission to known absence is not scalar conversion/admission. Legacy source-independent inline constant may render without live input, while current catalog constant present-input contract still refuses known absence.',
  'Deterministic equality is disclosed-class stability, not injectivity or cross-key comparability. Required descriptors, row eligibility, native origin and output binding remain separate.'
 ],
 'qualificationLimits':[
  'No src/spec/package/runtime API or case-definition change in this increment; historical r1/r2 fixtures preserved byte-for-byte.',
  'No native SQL lowerer, executable policy/catalog0.2 originalAction designation, authenticated source completeness, common key scope, current authority, selector, permit, final release or P03/B08 qualification.',
  'Readset/property/logical permission observations do not establish whole-query admission or absence-to-NULL encoding.',
  'Selected static-relative source pins do not claim a hermetic dependency/runtime closure. The actual producer binary is pinned but this review does not rebuild it.',
  'The14 PostgreSQL observations do not qualify actors, custody, crypto, RLS, native transport or backend correctness.',
  'Full158-case gate is parent-owned and running at review finalization; no fresh full-gate result is independently claimed here.'
 ],
 'failedAndCalibrationEvidence':[
  'initial-source-pins.json','initial-sources/','initial-issuer-custody-control.json','initial-cleanup-fault-controls.json','fixture-drifts-midrun/','original/',
  'native-final.log (sandbox Docker permission refusal, before any fixture creation)','native-final.json (failed receipt)','browser.log (sandbox loopback EADDRINUSE, before browser execution)',
  'All deliberately failing mutants and pre-fix controls are retained with their exact sources/results; they are not successful qualification runs.'
 ],
 'producer':{'path':'/private/tmp/weft-lineage02-current-binaries/application_lineage','sha256':'a78a3c04b69cf669f1f7ee9dfc91f4a1b1e495692684a16012f418ce1084862e'},
 'selectedSourceCount':len(pins),'selectedSourcePins':'final-source-pins.json','sourcePinsRechecked':True,'casePromotions':[],'rootSourceEditsByReviewer':False
}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(O/'review.md').write_text('''# Scoped independent review\n\nNo remaining blocker after the issuer snapshot and native cleanup receipt fixes. Independent evidence:29 source/API controls in Bun and Chromium;445 existing-source report checks;109 new-source issuer checks;24 source/report audits;14 owner-only PostgreSQL primitives;9 extracted cleanup faults;31 conditional SMT queries(17UNSAT/14SAT).\n\nPrivate source weakenings expose pre-storage substitution, hidden-original projection unmasking and missing direction checks. A conditional model weakening exposes a silent catalog-mode winner. Initial failures and calibration witnesses are retained.\n\nThis prerequisite supplies source/value distinctions and correspondence evidence. It does not issue a Weft originalAction profile, lower an executable query, prove native authority/custody or promote P03/B08. Known absence remains separate from scalar admission. See review.json for exact evidence and limits.\n''')
# Snapshot final sources once more before freezing receipt/archive.
assert all(sha((R/p).read_bytes())==h for p,h in pins.items())
files=[]
for path in sorted(O.rglob('*')):
 if not path.is_file() or path.is_symlink():continue
 rel=path.relative_to(O)
 if any(x in ['node_modules','__pycache__'] for x in rel.parts) or rel.name in ['archive.zip','manifest.json','archive-summary.json']:continue
 # rglob does not follow symlink dirs. Private original fixtures and exact mutant modules retained.
 files.append(path)
manifest={'reviewSha256':sha((O/'review.json').read_bytes()),'files':[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files],'scope':'Compact reproducible review packet; symlinked dependency trees and producer binaries excluded.'}
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(O/'manifest.json')
with zipfile.ZipFile(O/'archive.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(O)))
summary={'review':str(O/'review.json'),'reviewSha256':sha((O/'review.json').read_bytes()),'archive':str(O/'archive.zip'),'archiveSha256':sha((O/'archive.zip').read_bytes()),'archiveBytes':(O/'archive.zip').stat().st_size,'files':len(files),'sourcePins':len(pins)}
(O/'archive-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
