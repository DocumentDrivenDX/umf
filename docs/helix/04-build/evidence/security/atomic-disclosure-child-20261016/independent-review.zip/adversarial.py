from pathlib import Path
import json,hashlib,struct,subprocess,time,copy,os,selectors
from replay import R,B,V,sha,frame,decode,messages
p=json.loads((R/'frozen/evidence/inputs.json').read_bytes())['packets'][0]
a,b,expected=messages(p);initial=json.loads(a[4:]);evaluation=json.loads(b[4:]);refused={'version':'umf.security.logical-disclosure-batch/0.1-candidate','status':'refused','complete':False,'authority':False,'sources':None,'decisions':[],'resources':[],'batch':None}
D=R/'adversarial-raw';D.mkdir();empty=R/'empty-cwd';empty.mkdir();records=[]
def run(name,data,code,kinds,validate=None):
 started=time.monotonic();r=subprocess.run(['/opt/homebrew/bin/bun',str(B)],input=data,capture_output=True,timeout=20,cwd=empty,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'})
 prefix=D/name;prefix.with_suffix('.stdin').write_bytes(data);prefix.with_suffix('.stdout').write_bytes(r.stdout);prefix.with_suffix('.stderr').write_bytes(r.stderr)
 frames=decode(r.stdout)
 assert r.returncode==code,(name,r.returncode,r.stderr)
 assert r.stderr==(b'UMF_DISCLOSURE_CHILD_REFUSED\n' if code==2 else b''),(name,r.stderr)
 assert [x['kind'] for x in frames]==kinds,(name,frames)
 if validate:validate(frames)
 records.append({'id':name,'exitCode':r.returncode,'replyKinds':kinds,'inputSha256':sha(data),'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr),'seconds':time.monotonic()-started,'passed':True})
def noresult(frames):
 assert all('result' not in x for x in frames)
def cleared(frames):assert frames[-1]['result']==refused
def eqresult(frames):assert frames[-1]['result']==p['result']
# Closed initial and source envelopes, plus fixed projection shape.
for field in initial:
 x=copy.deepcopy(initial);del x[field];run('init-missing-'+field,frame(x),2,[])
for key in ['extra','__proto__','operations','routes','predicate']:
 x=copy.deepcopy(initial);x[key]={'private':'SHOULD_NOT_LEAK'};run('init-extra-'+key,frame(x),2,[])
for field in initial['sources']:
 x=copy.deepcopy(initial);del x['sources'][field];run('source-missing-'+field,frame(x),2,[])
for key in ['extensionSelection','extra','sourceReceipt']:
 x=copy.deepcopy(initial);x['sources'][key]=None;run('source-extra-'+key,frame(x),2,[])
for field in initial['selection']:
 x=copy.deepcopy(initial);del x['selection'][field];run('selection-missing-'+field,frame(x),2,[])
for key in ['predicate','limit','order','action','extra']:
 x=copy.deepcopy(initial);x['selection'][key]=False;run('selection-extra-'+key,frame(x),2,[])
for n in [256,257]:
 x=copy.deepcopy(initial);x['selection']['fields']=[x['selection']['fields'][0]]*n
 run('selection-count-'+str(n),frame(x),0 if n==256 else 2,['initialized'] if n==256 else [])
for name,apply in [('null-catalog',lambda x:x['sources'].__setitem__('catalog',None)),('unknown-policy-version',lambda x:x['sources']['policy'].__setitem__('version','unknown')),('invalid-owner-shape',lambda x:x.__setitem__('owner',None))]:
 x=copy.deepcopy(initial);apply(x)
 if name=='invalid-owner-shape':
  aa=frame(x);ee=copy.deepcopy(evaluation);ee['sourceReceipt']=sha(aa);run(name,aa+frame(ee),0,['initialized','disclosure-evaluated'],cleared)
 else:run(name,frame(x),2,[])
# Malformed bytes and exact number / duplicate-key parser profiles.
raw=a[4:]
malformed={'utf8-overlong':b'\xc0\xaf','utf8-surrogate':b'\xed\xa0\x80','utf8-out-of-range':b'\xf4\x90\x80\x80','utf8-truncated':b'\xf0\x9f','utf8-bom':b'\xef\xbb\xbf'+raw,'duplicate-key':raw.replace(b'"kind":"initialize"',b'"kind":"initialize","kind":"initialize"'),'escaped-duplicate-key':raw.replace(b'"kind":"initialize"',b'"kind":"initialize","k\\u0069nd":"initialize"'),'json-trailing':raw+b' true','json-array':b'[]','json-null':b'null','json-string':b'"x"'}
for token in ['-0','9007199254740993','1e309','1e-999','0.10000000000000001']:
 malformed['number-'+token.replace('.','_').replace('-','neg')]=raw.replace(b'"owner":',('"numericPadding":'+token+',"owner":').encode())
for name,body in malformed.items():run(name,struct.pack('>I',len(body))+body,2,[])
for name,data in [('length-zero',b'\0'*4),('length-oversize',struct.pack('>I',4194305)),('length-u32max',b'\xff'*4),('truncated-prefix',a[:3]),('truncated-body',a[:-1])]:run(name,data,2,[])
# Independent parser and framing resource endpoints. These initializers test transport admission only.
for n in [4_000_000,4_000_001]:
 body=raw+b' '*(n-len(raw));run('parser-text-'+str(n),struct.pack('>I',n)+body,0 if n==4_000_000 else 2,['initialized'] if n==4_000_000 else [])
for n in [4_194_304,4_194_305]:
 x=copy.deepcopy(initial);x['owner']['revision']='';base=json.dumps(x,separators=(',',':'),ensure_ascii=False).encode();amount=n-len(base);x['owner']['revision']='\U0001f642'*(amount//4)+'x'*(amount%4);body=json.dumps(x,separators=(',',':'),ensure_ascii=False).encode();assert len(body)==n
 run('request-utf8-bytes-'+str(n),struct.pack('>I',n)+body,0 if n==4_194_304 else 2,['initialized'] if n==4_194_304 else [])
for name,value in [('depth',[[0]]),('values',[None]*100001)]:
 if name=='depth':
  for _ in range(130):value=[value]
 x=copy.deepcopy(initial);x['owner']['probe']=value;run('parser-'+name,frame(x),2,[])
for value in ['', 'a'*65, 'a b', 'é', 1, None]:
 x=copy.deepcopy(initial);x['requestId']=value;run('id-'+str(len(records)),frame(x),2,[])
x=copy.deepcopy(initial);x['requestId']='a'*64;run('id-64',frame(x),0,['initialized'])
# Closed evaluation requests, receipt binding, fail-terminal behavior, and no extra producer dispatch.
for field in evaluation:
 x=copy.deepcopy(evaluation);del x[field]
 # Missing request ID yields no correlated refusal frame.
 kinds=['initialized'] if field=='requestId' else ['initialized','refused'];code=2 if field=='requestId' else 0
 run('eval-missing-'+field,a+frame(x),code,kinds,noresult)
for key in ['owner','selection','operations','routes','predicate','limit','order','action','extra']:
 x=copy.deepcopy(evaluation);x[key]={'private':'SHOULD_NOT_LEAK'};run('eval-extra-'+key,a+frame(x),0,['initialized','refused'],noresult)
for key,value in [('version','unknown'),('sourceReceipt','0'*64),('requestId','init'),('kind','evaluate'),('kind','inspect-routes'),('kind','initialize')]:
 x=copy.deepcopy(evaluation);x[key]=value;run('eval-mutated-'+key+'-'+str(len(records)),a+frame(x),0,['initialized','refused'],noresult)
run('evaluation-before-init',b,2,[])
run('duplicate-init',a+a,0,['initialized','refused'],noresult)
for name,data in [('third-same-evaluation',a+b+b),('trailing-truncated-after-result',a+b+b[:3])]:
 run(name,data,2,['initialized','disclosure-evaluated'],eqresult)
x=copy.deepcopy(evaluation);x['requestId']='evaluate-again';run('third-fresh-id-evaluation',a+b+frame(x),2,['initialized','disclosure-evaluated'],eqresult)
x=copy.deepcopy(evaluation);x['extra']='private';run('refusal-is-terminal',a+frame(x)+b,2,['initialized','refused'],noresult)
run('malformed-evaluation-after-init',a+struct.pack('>I',1)+b'\xff',2,['initialized'],noresult)
for total in [10000,10001]:
 x=copy.deepcopy(evaluation);x['cut']['facts']=[{}]*total;x['cut']['graphs']=[]
 run('fact-count-'+str(total),a+frame(x),0,['initialized','disclosure-evaluated' if total==10000 else 'refused'],cleared if total==10000 else noresult)
x=copy.deepcopy(evaluation);x['cut']['facts']=[{}]*5000;x['cut']['graphs']=[{}]*5001;run('combined-fact-graph-count',a+frame(x),0,['initialized','refused'],noresult)
for key in ['facts','graphs']:
 x=copy.deepcopy(evaluation);x['cut'][key]={};run('cut-nonarray-'+key,a+frame(x),0,['initialized','refused'],noresult)
for key,value in [('maxSteps',1),('maxSteps',1000001),('maxFacts',10001),('expectedGeneration','stale'),('extra','SHOULD_NOT_LEAK')]:
 x=copy.deepcopy(evaluation);x['cut'][key]=value;run('producer-refusal-'+key+'-'+str(len(records)),a+frame(x),0,['initialized','disclosure-evaluated'],cleared)
# Frame hashing uses the complete exact initializer, including syntax, not parsed source identity.
body=b' '+raw+b'\n';aa=struct.pack('>I',len(body))+body;assert sha(aa)!=sha(a)
x=copy.deepcopy(evaluation);x['sourceReceipt']=sha(aa);run('whitespace-receipt-new',aa+frame(x),0,['initialized','disclosure-evaluated'],eqresult)
run('whitespace-receipt-old',aa+b,0,['initialized','refused'],noresult)
# EOF is cancellation; acknowledgement or process exit is not an evaluation/grant.
run('empty-eof',b'',0,[]);run('initialization-only-eof',a,0,['initialized'],noresult)
# Separate held calls need a parent deadline/kill; the child does not self-timeout or self-exit after evaluation.
for name,data in [('partial-frame-open-stdin',a[:8]),('complete-result-open-stdin',a+b)]:
 child=subprocess.Popen(['/opt/homebrew/bin/bun',str(B)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=empty)
 try:
  child.stdin.write(data);child.stdin.flush();time.sleep(.2);assert child.poll() is None
  child.kill();child.wait(timeout=2);out=child.stdout.read();err=child.stderr.read()
  assert not err
  if name.startswith('partial'):assert not out
  records.append({'id':name,'passed':True,'parentKilledAndJoined':True,'exitCode':child.returncode,'stdoutSha256':sha(out),'scope':'Observed parent-owned lifecycle, not automatic child timeout.'})
 finally:
  if child.poll() is None:child.kill();child.wait(timeout=2)
  child.stdin.close();child.stdout.close();child.stderr.close()
(R/'adversarial.json').write_text(json.dumps({'status':'passed','controls':len(records),'checks':records,'scope':'Actual rebuilt bundle, original producer and protocol only; endpoints distinguish framing admission, semantic refusal, EOF cancellation, and parent lifecycle. No native authority.'},indent=2)+'\n')
print(json.dumps({'status':'passed','controls':len(records)}))
