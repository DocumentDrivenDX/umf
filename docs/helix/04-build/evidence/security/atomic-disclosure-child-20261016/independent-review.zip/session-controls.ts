import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {CurrentDisclosureChildSession,encodeDisclosureChildFrame as encode,DISCLOSURE_CHILD_VERSION as version} from './reconstructed/tools/security/current-disclosure-child';
const root=import.meta.dir,checks:any[]=[],assert=(v:unknown,id:string)=>{if(!v)throw Error(id);checks.push({id,passed:true});};
const decode=(b:Uint8Array)=>JSON.parse(new TextDecoder().decode(b.subarray(4))),sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const packet=JSON.parse(readFileSync(root+'/frozen/evidence/inputs.json','utf8')).packets[0],s=packet.source;
const init={version,kind:'initialize',requestId:'init',sources:{policy:s.policy,catalog:s.catalog,closure:s.closure,ontology:s.ontology,associationBindings:[]},owner:s.owner,selection:packet.selection};
for(const mode of ['plain','offset','copyThenOverwrite']) {
 const session=new CurrentDisclosureChildSession(),a=encode(init),h=sha(a),carrier=Buffer.concat([Buffer.from('junk'),a,Buffer.from('junk')]);
 const reply=decode(session.process(mode==='offset'?carrier.subarray(4,carrier.length-4):a));assert(reply.sourceReceipt===h,mode+'-receipt');
 if(mode==='copyThenOverwrite')a.fill(255);
 const out=decode(session.process(encode({version,kind:'evaluate-disclosure',requestId:'eval',sourceReceipt:h,cut:packet.cut})));assert(JSON.stringify(out.result)===JSON.stringify(packet.result),mode+'-exact-result');
 let refused=false;try{session.process(encode(init));}catch{refused=true;}assert(refused,mode+'-terminal');
}
for(const n of [16777216,16777217]) {
 let frame:Uint8Array|undefined,threw=false;try{frame=encode('x'.repeat(n-2));}catch{threw=true;}
 assert(n===16777216?!!frame&&frame.length===n+4:threw,'response-ascii-bytes-'+n);
 if(frame)assert(new DataView(frame.buffer,frame.byteOffset,frame.byteLength).getUint32(0)===n,'response-length-prefix');
}
for(const n of [16777216,16777217]) {
 const content=n-2,value='🙂'.repeat(Math.floor(content/4))+'x'.repeat(content%4);let frame:Uint8Array|undefined,threw=false;try{frame=encode(value);}catch{threw=true;}
 assert(n===16777216?!!frame&&frame.length===n+4:threw,'response-unicode-bytes-'+n);
}
writeFileSync(root+'/session-controls.json',JSON.stringify({status:'passed',controls:checks.length,checks,scope:'Exact session framing/copy/terminal and exported encoder byte endpoints; response maximum checked directly, not a claimed maximal producer population campaign.'},null,2)+'\n');console.log(JSON.stringify({status:'passed',controls:checks.length}));
