import hashlib,json,pathlib,struct,subprocess,time,importlib.util
spec=importlib.util.spec_from_file_location("truss_pinned_current_query_pipe","/private/tmp/truss-presence-seam-audit-20261016/_current_query_pipe.py")
pipe_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(pipe_module)
root=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
bundle=pathlib.Path('/private/tmp/umf-current-disclosure-child-bundle-r1-20261016/current-disclosure-child.mjs')
manifest=json.loads(bundle.with_name('manifest.json').read_text())
inputs=pathlib.Path('/private/tmp/umf-atomic-presence-handoff-r3-20261016/inputs.json')
version='umf.security.private-disclosure-child/0.1-candidate'
sha=lambda b:hashlib.sha256(b).hexdigest()
def pins():
 return {p:sha((root/p).read_bytes()) for p in manifest['sourcePins']}
assert pins()==manifest['sourcePins']
assert sha(bundle.read_bytes())==manifest['bundleSha256']
def frame(x):
 raw=json.dumps(x,separators=(',',':'),ensure_ascii=True).encode();return struct.pack('>I',len(raw))+raw
checks=[]
for packet in json.loads(inputs.read_bytes())['packets']:
 s=packet['source']
 initial=frame(dict(version=version,kind='initialize',requestId='init',sources={**{k:s[k] for k in ('policy','catalog','closure','ontology')},'associationBindings':[]},owner=s['owner'],selection=packet['selection']))
 receipt=sha(initial)
 request=frame(dict(version=version,kind='evaluate-disclosure',requestId='evaluate',sourceReceipt=receipt,cut=packet['cut']))
 with pipe_module.CurrentQueryPipe(('/opt/homebrew/bin/bun',str(bundle)),timeout_seconds=10) as child:
  initial_reply=child.exchange(initial[4:],source_receipt=receipt)
  evaluation_reply=child.exchange(request[4:],source_receipt=receipt)
  output=struct.pack('>I',len(initial_reply))+initial_reply+struct.pack('>I',len(evaluation_reply))+evaluation_reply
 run=type('HeldPipeResult',(),{'returncode':0,'stderr':b'','stdout':output})()
 assert run.returncode==0 and run.stderr==b'',(packet['id'],run.returncode,run.stderr)
 replies=[];raw=run.stdout
 while raw:
  assert len(raw)>=4
  n=struct.unpack('>I',raw[:4])[0];assert n>0 and len(raw)>=4+n
  replies.append(json.loads(raw[4:4+n]));raw=raw[4+n:]
 assert len(replies)==2
 assert replies[0]==dict(version=version,kind='initialized',requestId='init',sourceReceipt=receipt)
 assert replies[1]==dict(version=version,kind='disclosure-evaluated',requestId='evaluate',sourceReceipt=receipt,result=packet['result']),packet['id']
 checks.append(dict(id=packet['id'],matched=True,initialFrameSha256=sha(initial),evaluationFrameSha256=sha(request),stdoutSha256=sha(run.stdout),resultStatus=replies[1]['result']['status']))
assert pins()==manifest['sourcePins']
receipt=dict(trussPipeSource={'revision':'ea9c3f080cecd5da2d3be42258c26c3d0dcab7bc','sha256':sha(pathlib.Path(spec.origin).read_bytes())},status='passed',version=version,bun='1.4.2',bundleSha256=sha(bundle.read_bytes()),manifestSha256=sha(bundle.with_name('manifest.json').read_bytes()),inputSha256=sha(inputs.read_bytes()),sourcePins=manifest['sourcePins'],checks=checks,scope='66 actual pinned Truss nonblocking pipe / bundled child evaluations preserve the existing producer handoff exactly. Supplied logical cuts and fixed original owner/selection; no authenticated backend facts, native SQL, caller/current authority or guarded release. No required acceptance promotion.')
pathlib.Path('/private/tmp/umf-current-disclosure-child-truss-pipe-replay-20261016.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(status='passed',cases=len(checks),sourcePins=len(manifest['sourcePins']),bundleSha256=receipt['bundleSha256'])))
