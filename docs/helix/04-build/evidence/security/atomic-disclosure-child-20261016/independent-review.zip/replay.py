from pathlib import Path
import json,hashlib,struct,subprocess,time,importlib.util
R=Path(__file__).parent;B=R/'rebuilt-bundle/current-disclosure-child.mjs';V='umf.security.private-disclosure-child/0.1-candidate';sha=lambda b:hashlib.sha256(b).hexdigest()
def frame(value):
 b=json.dumps(value,ensure_ascii=True,separators=(',',':')).encode();return struct.pack('>I',len(b))+b
def decode(raw):
 frames=[]
 while raw:
  assert len(raw)>=4
  n=struct.unpack('>I',raw[:4])[0];assert 0<n<=16777216 and len(raw)>=n+4
  frames.append(json.loads(raw[4:n+4].decode('utf8')));raw=raw[n+4:]
 return frames
def messages(p):
 s=p['source'];i={'version':V,'kind':'initialize','requestId':'init','sources':{**{k:s[k] for k in ('policy','catalog','closure','ontology')},'associationBindings':[]},'owner':s['owner'],'selection':p['selection']};a=frame(i);h=sha(a)
 e={'version':V,'kind':'evaluate-disclosure','requestId':'evaluate','sourceReceipt':h,'cut':p['cut']};b=frame(e)
 return a,b,[{'version':V,'kind':'initialized','requestId':'init','sourceReceipt':h},{'version':V,'kind':'disclosure-evaluated','requestId':'evaluate','sourceReceipt':h,'result':p['result']}]
def main():
 manifest=json.loads((R/'frozen/bundle/manifest.json').read_text());assert all(sha((R/'reconstructed'/p).read_bytes())==h for p,h in manifest['sourcePins'].items());assert sha(B.read_bytes())==manifest['bundleSha256']
 originals=json.loads((R/'frozen/evidence/inputs.json').read_bytes())['packets'];mixed=json.loads((R/'supplemental/independent-controls.json').read_bytes())['observations'];packets=originals+[{**x['packet'],'id':x['id'],'result':x['result']} for x in mixed]
 records=[];d=R/'replay-raw';d.mkdir()
 spec=importlib.util.spec_from_file_location('pinned_truss_pipe',R/'supplemental/_current_query_pipe.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 for index,p in enumerate(packets):
  a,b,expect=messages(p);record={'id':p['id'],'inputSha256':sha(a+b),'initialFrameSha256':sha(a),'evaluationFrameSha256':sha(b)}
  stem=d/str(index).zfill(3);stem.with_suffix('.stdin').write_bytes(a+b)
  start=time.monotonic();run=subprocess.run(['/opt/homebrew/bin/bun',str(B)],input=a+b,capture_output=True,timeout=15)
  stem.with_suffix('.stdout').write_bytes(run.stdout);stem.with_suffix('.stderr').write_bytes(run.stderr)
  assert run.returncode==0 and not run.stderr,(p['id'],run.returncode,run.stderr)
  assert decode(run.stdout)==expect,p['id']
  record.update(exitCode=run.returncode,stdoutSha256=sha(run.stdout),seconds=time.monotonic()-start,status=expect[1]['result']['status'],exactResult=True)
  with mod.CurrentQueryPipe(('/opt/homebrew/bin/bun',str(B)),timeout_seconds=15) as child:
   f=child.exchange(a[4:],source_receipt=sha(a));assert json.loads(f)==expect[0]
   assert child._child.poll() is None and not child._child.stdin.closed
   g=child.exchange(b[4:],source_receipt=sha(a));assert json.loads(g)==expect[1]
   assert child._child.poll() is None and not child._child.stdin.closed
   pid=child._child.pid
  assert child._cleanup_complete and child._child.poll() is not None and child._child.stdin.closed and child._child.stdout.closed
  record.update(pipeExactResult=True,pipePid=pid,pipeKilledAndJoined=True)
  records.append(record)
 assert all(sha((R/'reconstructed'/p).read_bytes())==h for p,h in manifest['sourcePins'].items())
 (R/'replay.json').write_text(json.dumps({'status':'passed','bundleSha256':sha(B.read_bytes()),'sourcePinCount':len(manifest['sourcePins']),'cases':len(records),'processExecutions':len(records)*2,'trussPipeSha256':sha((R/'supplemental/_current_query_pipe.py').read_bytes()),'checks':records,'scope':'Actual rebuilt Bun child; 72 closed-stdin executions plus 72 sequential held-pipe executions with actual cleanup. Standalone pinned Truss transport module only, not installed Truss admission/query API; no DB/native authority.'},indent=2)+'\n')
 print(json.dumps({'status':'passed','cases':len(records),'processExecutions':len(records)*2}))
if __name__=='__main__':main()
