from pathlib import Path
import json,hashlib,shutil,subprocess
R=Path(__file__).parent;F=R/'frozen-r2';S=R/'r2-reconstructed';D=R/'config-controls';D.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((F/'manifest.json').read_text())
for p,item in manifest['files'].items():assert sha((F/p).read_bytes())==item['sha256'] and len((F/p).read_bytes())==item['bytes']
shutil.copytree(R/'reconstructed',S)
for p in (F/'overlay').rglob('*'):
 if p.is_file():dest=S/p.relative_to(F/'overlay');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
config=(S/'tsconfig.json').read_bytes();bunfig=(S/'bunfig.toml').read_bytes();entry=(S/'tools/security/current-disclosure-child-main.ts').read_bytes();session=(S/'tools/security/current-disclosure-child.ts').read_bytes()
checks=[]
def reset():
 (S/'tsconfig.json').write_bytes(config);(S/'bunfig.toml').write_bytes(bunfig);(S/'tools/security/current-disclosure-child-main.ts').write_bytes(entry);(S/'tools/security/current-disclosure-child.ts').write_bytes(session)
 (S/'tools/security/probe-added.ts').unlink(missing_ok=True)
def invoke(name,expected=0,message=None,wrapper=None,argument=None):
 output=D/(name+'-output');log=D/(name+'.log');cmd=['/opt/homebrew/bin/bun']
 if wrapper:
  w=D/(name+'-preload.ts');w.write_text(wrapper);cmd+=['--preload',str(w)]
 cmd+=['tools/security/build-current-disclosure-child.ts',argument or str(output)]
 run=subprocess.run(cmd,cwd=S,capture_output=True,timeout=30);log.write_bytes(run.stdout+run.stderr)
 assert (run.returncode==0)==(expected==0),(name,run.stdout,run.stderr)
 if message:assert message.encode() in run.stderr,(name,run.stderr)
 if expected:assert not (output/'manifest.json').exists(),name
 else:assert (output/'manifest.json').is_file()
 record={'id':name,'passed':True,'exitCode':run.returncode,'command':cmd,'stderrSha256':sha(run.stderr),'stdoutSha256':sha(run.stdout),'manifestIssued':(output/'manifest.json').exists()}
 checks.append(record);return output
out=invoke('baseline');final=json.loads((out/'manifest.json').read_text());frozen=json.loads((F/'bundle/manifest.json').read_text())
assert final['sourcePins']==frozen['sourcePins'];assert final['bundleSha256']==frozen['bundleSha256']=='911955bf09c7a67003cab4c418a7f88753f00778c1e20aeaee77626c257bc281';assert len(final['sourcePins'])==254
for field in ['tsconfig.json','bunfig.toml']:assert sha((S/field).read_bytes())==final['sourcePins'][field]
changed=json.loads(config);changed['compilerOptions']['useDefineForClassFields']=False;(S/'tsconfig.json').write_text(json.dumps(changed,indent=2)+'\n')
out=invoke('changed-configuration');mut=json.loads((out/'manifest.json').read_text());assert mut['sourcePins']['tsconfig.json']!=final['sourcePins']['tsconfig.json'];assert mut['bundleSha256']!=final['bundleSha256'];assert {p for p in final['sourcePins'] if final['sourcePins'][p]!=mut['sourcePins'][p]}=={'tsconfig.json'};reset()
for label,value in [('local','./parent.json'),('package','pkg/config'),('url','https://invalid.example/config'),('array',['./one.json']),('null',None)]:
 c=json.loads(config);c['extends']=value;(S/'tsconfig.json').write_text(json.dumps(c));invoke('extends-'+label,1,'Standalone root TypeScript configuration required');reset()
for label,value in [('null',None),('array',[]),('string','config')]:
 (S/'tsconfig.json').write_text(json.dumps(value));invoke('invalid-config-'+label,1,'Standalone root TypeScript configuration required');reset()
for p in ['tsconfig.json','bunfig.toml']:
 (S/p).unlink();invoke('missing-'+p.replace('.','-'),1);reset()
# Fault injection wraps actual Bun.build but imports the exact unchanged builder.
for path in ['tsconfig.json','bunfig.toml']:
 for phase in ['after-discovery','after-actual']:
  n=1 if phase=='after-discovery' else 2
  wrapper="import {appendFileSync} from 'node:fs';const original=Bun.build;let n=0;(Bun as any).build=async function(config:any){const result=await original(config);if(++n==="+str(n)+")appendFileSync("+json.dumps(str(S/path))+",'\\n');return result;};\n"
  invoke('drift-'+path.replace('.','-')+'-'+phase,1,'Build configuration changed',wrapper);reset()
wrapper="import {appendFileSync} from 'node:fs';const original=Bun.build;let n=0;(Bun as any).build=async function(config:any){const result=await original(config);if(++n===2)appendFileSync("+json.dumps(str(S/'tools/security/current-disclosure-child.ts'))+",'\\n// reviewer source drift\\n');return result;};\n"
invoke('source-drift-after-actual',1,'Build source changed',wrapper);reset()
wrapper="import {appendFileSync,writeFileSync} from 'node:fs';const original=Bun.build;let n=0;(Bun as any).build=async function(config:any){const result=await original(config);if(++n===1){appendFileSync("+json.dumps(str(S/'tools/security/current-disclosure-child-main.ts'))+",\"\\nimport './probe-added';\\n\");writeFileSync("+json.dumps(str(S/'tools/security/probe-added.ts'))+",\"console.log('never-executed-by-review');\\n\");}return result;};\n"
invoke('closure-drift-after-discovery',1,'Build closure changed',wrapper);reset()
invoke('relative-output',1,'One absolute fresh output directory required',argument='relative-output')
exists=D/'existing-output';exists.mkdir();invoke('existing-output',1,argument=str(exists))
assert all(sha((S/p).read_bytes())==h for p,h in final['sourcePins'].items())
(R/'config-r2-audit.json').write_text(json.dumps({'status':'passed','controls':len(checks),'resolvedFinding':'CHILD-001','sourcePins':len(final['sourcePins']),'bundleSha256':final['bundleSha256'],'checks':checks,'scope':'Actual build/config endpoint and failure guards with original unchanged R2 builder in isolated reconstruction; Bun.build wrappers intentionally mutate local test inputs. Not hermetic or held-file/ABA proof.'},indent=2)+'\n')
print(json.dumps({'status':'passed','controls':len(checks),'sourcePins':len(final['sourcePins'])}))
