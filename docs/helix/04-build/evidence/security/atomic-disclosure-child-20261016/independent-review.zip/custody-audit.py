from pathlib import Path
import json,hashlib,subprocess,collections,difflib
R=Path(__file__).parent;owner=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def check(name,yes,**kw):
 assert yes,name;checks.append({'id':name,'passed':True,**kw})
for epoch in ['frozen','frozen-r2']:
 m=json.loads((R/epoch/'manifest.json').read_text())
 for p,v in m['files'].items():check(epoch+':'+p,sha((R/epoch/p).read_bytes())==v['sha256'] and len((R/epoch/p).read_bytes())==v['bytes'])
 before=json.loads((R/epoch/'bundle/manifest.json').read_text());meta=json.loads((R/epoch/'bundle/metafile.json').read_text())
 extras={'tools/security/build-current-disclosure-child.ts','bun.lock','package.json'}|({'tsconfig.json','bunfig.toml'} if epoch=='frozen-r2' else set())
 check(epoch+':metafile-exact-domain',set(before['sourcePins'])==set(meta['inputs'])|extras)
 check(epoch+':no-output-external-imports',all(v['imports']==[] for v in meta['outputs'].values()))
 for notice in before['notices']:
  pkg=json.loads((R/epoch/'bundle/notices'/notice['name']/'package.json').read_bytes());check(epoch+':notice:'+notice['name'],all(pkg[k]==notice[k] for k in ['name','version','license']))
reconstruction=json.loads((R/'reconstruction.json').read_text());base=reconstruction['base']
for p,h in reconstruction['snapshot'].items():check('r1-source-unchanged:'+p,sha((R/'reconstructed'/p).read_bytes())==h)
final=json.loads((R/'frozen-r2/bundle/manifest.json').read_text())
for p,h in final['sourcePins'].items():
 check('r2-source-pin:'+p,sha((R/'r2-reconstructed'/p).read_bytes())==h)
 check('final-owner-endpoint:'+p,sha((owner/p).read_bytes())==h)
inputs=json.loads((R/'frozen/evidence/inputs.json').read_bytes())
for p,text in inputs['sources'].items():
 check('original-producer-input:'+p,sha(text.encode())==inputs['sourcePins'][p] and text.encode()==(R/'reconstructed'/p).read_bytes())
legacy=['tools/security/current-query-child.ts','tools/security/current-query-child-main.ts','tools/security/build-current-query-child.ts','tests/security/current-query-child.test.ts','src/index.ts','package.json','bun.lock']
for p in legacy:
 original=subprocess.check_output(['git','show',base+':'+p],cwd=owner);check('legacy-base-identical:'+p,original==(R/'reconstructed'/p).read_bytes() and original==(owner/p).read_bytes(),sha256=sha(original))
for p in ['docs/helix/02-design/technical-designs/TD-056-security-bindings.md','docs/helix/03-test/test-plans/STP-056-security-bindings.md','docs/helix/04-build/implementation-plan.md','tsconfig.tools.json']:
 original=subprocess.check_output(['git','show',base+':'+p],cwd=owner);changed=(R/'frozen/overlay'/p).read_bytes();(R/(Path(p).name+'.diff')).write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),changed.decode().splitlines(True),fromfile=base+':'+p,tofile='R1:'+p)))
# Exact producer case/status and byte outputs versus supplied bundle replay receipts.
replay=json.loads((R/'replay.json').read_text());orig=json.loads((R/'frozen/evidence/umf-current-disclosure-child-bundle-replay-20261016.json').read_text());mixed=json.loads((R/'supplemental/umf-current-disclosure-child-bundle-mixed-replay-20261016.json').read_text());pipe=json.loads((R/'supplemental/umf-current-disclosure-child-truss-pipe-replay-20261016.json').read_text())
for record in replay['checks']:
 supplied=next(x for x in orig['checks']+mixed['checks'] if x['id']==record['id'])
 check('supplied-output-byte-match:'+record['id'],all(record[k]==supplied[k] for k in ['initialFrameSha256','evaluationFrameSha256','stdoutSha256']))
 if record['id'] in {x['id'] for x in pipe['checks']}:
  supplied=next(x for x in pipe['checks'] if x['id']==record['id']);check('supplied-truss-pipe-byte-match:'+record['id'],all(record[k]==supplied[k] for k in ['initialFrameSha256','evaluationFrameSha256','stdoutSha256']))
check('all-bundles-exact',len({sha((R/p).read_bytes()) for p in ['frozen/bundle/current-disclosure-child.mjs','rebuilt-bundle/current-disclosure-child.mjs','frozen-r2/bundle/current-disclosure-child.mjs','config-controls/baseline-output/current-disclosure-child.mjs']})==1)
check('final-pins-add-only-configs',set(final['sourcePins'])-set(json.loads((R/'frozen/bundle/manifest.json').read_text())['sourcePins'])=={'tsconfig.json','bunfig.toml'})
old=json.loads((R/'frozen/bundle/manifest.json').read_text())['sourcePins'];check('shared-pins-only-builder-changed',[p for p in old if old[p]!=final['sourcePins'][p]]==['tools/security/build-current-disclosure-child.ts'])
result={'status':'passed','count':len(checks),'checks':checks,'producerStatusCounts':dict(collections.Counter(p['result']['status'] for p in inputs['packets'])),'runtime':{'bunVersion':subprocess.check_output(['/opt/homebrew/bin/bun','--version'],text=True).strip(),'bunSha256':sha(Path('/opt/homebrew/bin/bun').read_bytes()),'python':subprocess.check_output(['python3','--version'],text=True).strip()},'scope':'Artifact, selected source/config, baseline/overlay and current endpoint byte custody; no held-file/ABA or hermetic runtime proof.'}
(R/'custody-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'passed','checks':len(checks)}))
