from pathlib import Path
import subprocess,json,hashlib,shutil,zipfile
R=Path(__file__).parent;owner=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');f=R/'frozen';out=R/'reconstructed';out.mkdir(exist_ok=True)
base=json.loads((f/'manifest.json').read_text())['baseRevision'];files=subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=owner,text=True).splitlines()
selected=[p for p in files if p.startswith(('src/','spec/','tests/security/','tools/security/')) or p in ['AGENTS.md','.helix.yml','package.json','bun.lock','tsconfig.json','tsconfig.tools.json','tsconfig.browser.json','docs/helix/README.md']]
for p in selected:
 dest=out/p
 if not dest.exists():
  b=subprocess.check_output(['git','show',base+':'+p],cwd=owner);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
for p in (f/'overlay').rglob('*'):
 if p.is_file():d=out/p.relative_to(f/'overlay');d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
manifest=json.loads((f/'bundle/manifest.json').read_text());pins=manifest['sourcePins'];sha=lambda b:hashlib.sha256(b).hexdigest()
for notice in manifest['notices']:
 p='node_modules/'+notice['name'];shutil.copytree(owner/p,out/p,dirs_exist_ok=True)
checks=[]
for p,h in pins.items():
 got=sha((out/p).read_bytes());assert got==h,(p,got,h)
 checks.append({'path':p,'sha256':got,'ownerMatches':sha((owner/p).read_bytes())==h})
assert all(x['ownerMatches'] for x in checks)
meta=json.loads((f/'bundle/metafile.json').read_text());assert set(pins)==set(meta['inputs'])|{'tools/security/build-current-disclosure-child.ts','bun.lock','package.json'}
snapshot={str(p.relative_to(out)):sha(p.read_bytes()) for p in out.rglob('*') if p.is_file()}
(R/'reconstruction.json').write_text(json.dumps({'base':base,'selectedGitFiles':len(selected),'pins':checks,'snapshot':snapshot,'bundleInputs':len(meta['inputs']),'dependencyCustody':'Copied original installed dependencies; selected executable input hashes match supplied bundle manifest; external Bun executable remains non-hermetic.'},indent=2)+'\n')
with zipfile.ZipFile(R/'reconstructed-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(snapshot):z.write(out/p,p)
print(json.dumps({'gitFiles':len(selected),'snapshotFiles':len(snapshot),'bundlePins':len(checks)}))
