# B-SFP-005 action separation design review

Review baseline: UMF `64a6b51933cb796a3e8aa3645d47909a2c761bbe`.
This is a proposed source model and conditional analysis, not an implemented
ontology, compiler profile, permission, source issuer or backend qualification.

The concrete gap is missing purpose, not missing action names. Both current
ontology grammars declare `actions: string[]`. Policy `rules[].actions` describes
which exact action a rule governs, so it may legitimately contain a reverse
action. Weft's existing `SecurityQueryProfile::read` closes original-action
bindings for its selected target/field/operator tuples; it does not enumerate
every read/write operation or every possible profile. UMF's existing write
profile separately owns the complete field-action mapping for one target.
Neither a supplied exclusion list nor one selected query profile proves global
reverse-action separation.

## Recommended source model

Add optional, version-qualified `actionPurposes` metadata to the canonical
ontology candidate, preserving the prior grammar and original source bytes.
Absence remains representable, but the new protection-obligation operation must
refuse to claim complete action separation without it. Do not insert inferred
purposes or label-based defaults during migration. Older engines remain closed
on the new meaning until explicitly supported.

Use an array of exact `{action, purposes}` entries, one entry for every exact
`ontology.actions` ID and no extras. Each purpose set must be nonempty, unique,
bounded and drawn from the closed vocabulary proposed by the owner:
`read`, `field`, `original-authorized`, `reverse`, `vault-write`, `other`.
`field` includes the field access/mutation category governed by the selected
owner profile. `other` means an operation outside these protected categories,
not permission to conceal a protected use. Unknown purposes block this check
rather than becoming `other` automatically. The exact ontology0.2 version and
revision own this grammar; an independent operational profile is not introduced.

Normal actions may have several explicitly declared purposes when their owning
operation contracts allow that reuse. A `reverse` action must have exactly the
singleton purpose `reverse`; this makes its separation from all read, field and
original-query actions explicit. Prefer the same exclusive reservation for
`vault-write`, so future S25 cannot silently alias its additional permission to
read, field mutation or reversal. A reverse action can be shared by multiple
transforms if that exact shared authority is deliberately authored; do not
invent a per-transform uniqueness requirement absent from the contract.

Every catalog keyed/vault `reverseAction` must resolve to an exact declared
singleton reverse action. Every present `vaultWriteAction` must resolve to its
own reserved purpose. Absence of the optional vault-write declaration may
remain a read-only declaration, but must never satisfy write admission. All
policy rule actions must be declared, including legitimate reverse grants.
Require the exact policy-to-ontology revision pin and retained source snapshots.
Check the entire catalog, including unused reversible transforms.

The purpose table does NOT select target, field or operator actions. Weft keeps
the sole original-action designation in its existing query profile. Do not
duplicate those bindings in UMF's new table. Required consumer checks are:

- An actual read/query profile primary action has purpose `read`.
- Each original action selected by Weft has purpose `original-authorized`.
- Each actual write-profile field action has purpose `field`; any other actual
  protected use of an object/policy/ownership action must also agree with its
  declared purpose. Existing owner's stricter distinctness rules still apply.
- An operation needing reversal or vault write resolves the exact reserved
  action and independently evaluates its permission; ordinary token transport
  never supplies that permission.

These checks must be performed by the operation owners against the actual
selected immutable profile, not a second caller-authored summary. The initial
UMF operation may truthfully report **declared purpose separation** with
`complete:false, authority:false`; it cannot report all native/profile routes
as closed. A complete inventory of source-pinned existing profiles is an
alternative only when its completeness is independently owned and established.
An arbitrary array or a Boolean `complete:true` adds no such evidence.

## S21 and S23 obligations

Each hash retains the exact algorithm and salt-custody declaration. Unsalted
hashes must retain equality and produce a mandatory structured dictionary-attack
warning tied to the exact catalog/transform identity. Algorithm existence,
collision properties and actual key custody remain unverified. Do not infer an
algorithm or silently turn an unknown algorithm into an implemented one.

Token/encryption declarations require owner, appropriate vault/key reference,
storage effect and all five propagation declarations: history, snapshots,
exports, feeds and caches. Return each declaration as an unverified obligation.
Unknown required structure or purpose refuses atomically with sources retained;
opaque native archive text and explicitly opaque declaration strings remain
preserved. A string that says `tokens` or `unknown` is not native enforcement
evidence; unknown required schema meaning is distinct from opaque text.

The inspector must validate every declared transform and all action metadata,
even with no selected disclosure. Closed shapes, duplicates, missing/extra
action coverage, exact pins and bounded immutable capture precede any successful
obligation result. Retain the original policy, catalog and ontology. Never return
a partial set of validated obligations after a late invalid declaration.

## Meaningful qualification

S21/S23 need independently authored positive and refusal cases for the full
declaration obligations, not presence-only tests. S22 needs a real declared
action model with exhaustive source identity coverage, all read/field/query
collision refusals, unknown/missing classifications, legitimate reverse-action
policy grants, and the S20 original-token transport behavior. A policy granting
both read and reverse remains legitimate; the operations are independent.

The semantic cases can qualify that authored model in Bun/Chromium without
claiming authenticated sources or complete native routes. Existing Weft/runtime
consumers must remain refused or unqualified until their actual profile checks
consume the new purpose metadata. Merely accepting a purpose table is not proof
that existing .1 evaluators, all query profiles or every write route obey it.

The accompanying proof keeps actual owner use separate from declared purpose.
It demonstrates why missing inventory or a misclassified action remains a SAT
counterexample, and why owner compatibility is an essential premise. It does
not prove TypeScript, Rust, native SQL, source authenticity or route completeness.
