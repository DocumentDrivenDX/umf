import hashlib,json,re
from pathlib import Path
ROOT=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
OUT=Path(__file__).parent
files=set()
def visit(p):
    p=p.resolve()
    if p in files:return
    files.add(p)
    if p.suffix!='.ts':return
    for name in re.findall(r"(?:from\s*|import\s*)['\"](\.[^'\"]+)['\"]",p.read_text()):
        q=p.parent/name
        candidates=[q,q.with_suffix('.ts'),q.with_suffix('.json'),q/'index.ts']
        match=next((x for x in candidates if x.is_file()),None)
        if match:visit(match)
visit(ROOT/'src/extensions/security/protection/disclosure.ts')
visit(ROOT/'src/extensions/security/protection/obligations.ts')
visit(ROOT/'src/extensions/security/ontology-migration-candidate.ts')
for x in ['src/index.ts','bun.lock','tests/security/action-purposes.test.ts','tests/security/protection/obligations.test.ts','scripts/security-ontology-v2-schema.py','docs/helix/02-design/spikes/security/ontology-v0.2.schema.json','src/extensions/security/disclosure.ts','tests/security/disclosure.test.ts','tests/security/protection/disclosure.test.ts','tools/security/prove-protection-disclosure.py','tools/security/protection-disclosure-mutations.py','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md','docs/helix/02-design/contracts/CONTRACT-066-gregorian-date-operations.md']:
    files.add(ROOT/x)
pins={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(OUT/'source-pins-current.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'sourceCount':len(pins),'obligations':pins['src/extensions/security/protection/obligations.ts']}))
