import {runOracle} from './oracle';
const groups=Object.fromEntries(['S21','S22','S23'].map(id=>[id,runOracle(id as 'S21'|'S22'|'S23')]));
const rows=Object.values(groups).flat();
await Bun.write('/private/tmp/protection-obligations-astra-20261015/bun-results.json',JSON.stringify({groups,rows,passed:rows.filter(r=>r.passed).length,failed:rows.filter(r=>!r.passed)},null,2)+'\n');
console.log(JSON.stringify({rows:rows.length,passed:rows.filter(r=>r.passed).length,failed:rows.filter(r=>!r.passed)}));
if(rows.some(r=>!r.passed))process.exitCode=1;
