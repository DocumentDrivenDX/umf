"""Conditional action-purpose closure, not program/native refinement."""
from pathlib import Path
import hashlib,json,z3
out=Path(__file__).parent
rows=[]
def check(name, premises, claim, expected):
 s=z3.Solver();s.set(timeout=5000);s.add(*premises,claim)
 actual=str(s.check());assert actual==expected,(name,actual)
 smt=s.to_smt2();ctx=z3.Context();again=z3.Solver(ctx=ctx);again.from_string(smt);again.set(timeout=5000)
 assert str(again.check())==expected
 rows.append({'id':name,'expected':expected,'observed':actual,'smt2':smt,'model':str(s.model()) if actual=='sat' else None})
A=z3.IntSort()
declared=z3.Function('declared',A,z3.BoolSort())
read=z3.Function('purpose_read',A,z3.BoolSort())
field=z3.Function('purpose_field',A,z3.BoolSort())
query=z3.Function('purpose_query_original',A,z3.BoolSort())
reverse=z3.Function('purpose_reverse',A,z3.BoolSort())
actual_read=z3.Function('actual_read',A,z3.BoolSort())
actual_field=z3.Function('actual_field',A,z3.BoolSort())
actual_query=z3.Function('actual_query_original',A,z3.BoolSort())
grant=z3.Function('grant',A,z3.BoolSort())
x,r,q,u=z3.Ints('x reverse_id selected_query_id hidden_profile_id')
separate=z3.ForAll(x,z3.Implies(reverse(x),z3.And(declared(x),z3.Not(read(x)),z3.Not(field(x)),z3.Not(query(x)))))
base=[separate,reverse(r)]
check('declared-reverse-read-collision-refuses',base,read(r),'unsat')
check('declared-reverse-field-collision-refuses',base,field(r),'unsat')
check('declared-reverse-query-collision-refuses',base,query(r),'unsat')
check('classification-is-not-owner-attestation',base,actual_query(r),'sat')
selected_only=[q!=r,actual_query(q),query(q),declared(q),u==r,actual_query(u)]
check('one-selected-profile-does-not-close-other-profiles',base+selected_only,actual_query(r),'sat')
read_owner=z3.ForAll(x,z3.Implies(actual_read(x),z3.And(declared(x),read(x))))
field_owner=z3.ForAll(x,z3.Implies(actual_field(x),z3.And(declared(x),field(x))))
query_owner=z3.ForAll(x,z3.Implies(actual_query(x),z3.And(declared(x),query(x))))
check('owner-checked-read-cannot-be-reverse',base+[read_owner],actual_read(r),'unsat')
check('owner-checked-field-cannot-be-reverse',base+[field_owner],actual_field(r),'unsat')
check('owner-checked-query-cannot-be-reverse',base+[query_owner],actual_query(r),'unsat')
check('omitted-field-owner-still-has-countermodel',base+[read_owner,query_owner],actual_field(r),'sat')
check('legitimate-reverse-policy-grant-is-allowed',base+[read(q),declared(q),q!=r],z3.And(grant(q),grant(r)),'sat')
check('read-grant-does-not-entail-reverse-grant',base+[read(q),declared(q),q!=r],z3.And(grant(q),z3.Not(grant(r))),'sat')
selected=z3.Int('selected_action')
can_reverse=z3.And(selected==r,grant(r))
check('read-selection-is-not-reverse-operation',base+[read(q),declared(q),q!=r,selected==q,grant(q)],can_reverse,'unsat')
known,complete_purposes,complete_custody,complete_propagation,warning=z3.Bools('known complete_purposes complete_custody complete_propagation dictionary_warning')
unsalted=z3.Bool('unsalted'); equality=z3.Bool('equality')
validated=z3.And(known,complete_purposes,complete_custody,complete_propagation,z3.Implies(unsalted,z3.And(equality,warning)))
check('missing-propagation-refuses',[],z3.And(validated,z3.Not(complete_propagation)),'unsat')
check('unsalted-without-warning-refuses',[unsalted],z3.And(validated,z3.Not(warning)),'unsat')
check('unknown-required-purpose-refuses',[],z3.And(validated,z3.Not(known)),'unsat')
authentic=z3.Bool('authentic_sources')
check('source-equality-does-not-authenticate',[],z3.And(validated,z3.Not(authentic)),'sat')
packet={'status':'conditional-design-model-passed','solver':z3.get_version_string(),'checks':rows,
 'scope':'Unbounded action IDs. Exact declared reverse separation plus explicit per-owner purpose compatibility premises. Missing owner closure and independent grant countermodels. Boolean custody/purpose/propagation completeness are assumed predicates, not source/native validation proofs.',
 'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'promotion':None}
(out/'proof.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'queries':len(rows),'unsat':sum(x['observed']=='unsat' for x in rows),'sat':sum(x['observed']=='sat' for x in rows)}))
