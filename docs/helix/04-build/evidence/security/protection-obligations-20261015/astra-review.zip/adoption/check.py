from pathlib import Path
import json,hashlib,subprocess
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/protection-obligations-astra-20261015');D=O/'adoption'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((R/'docs/helix/03-test/security/cases.json').read_text());old=json.loads(subprocess.check_output(['git','show','HEAD:docs/helix/03-test/security/cases.json'],cwd=R,text=True))
a={c['id']:c for c in plan['cases']};b={c['id']:c for c in old['cases']};controls=[]
def add(id,result):controls.append({'id':id,'passed':bool(result)})
add('python-byte-exact', (O/'oracle.py').read_bytes()==(R/'tests/security/protection/obligations-oracle.py').read_bytes())
add('fixtures-byte-exact',(O/'fixtures.json').read_bytes()==(R/'tests/security/protection/obligations-fixtures.json').read_bytes())
expected=(O/'oracle.ts').read_text().replace("'/Users/erik/.codex/worktrees/security-main-integration/umf/src/index'","'../../../src/index'").replace("'./fixtures.json'","'./obligations-fixtures.json'")
add('adapter-only-two-authorized-relocations',expected==(R/'tests/security/protection/obligations-oracle.ts').read_text())
add('all158-identities-order-preserved',[c['id'] for c in plan['cases']]==[c['id'] for c in old['cases']] and len(a)==158)
allowed={'status','command','evidence','testSource','oracleSource','implementationSources'}
for id in ['S21','S22','S23']:
 add(id+'-unchanged-full-obligation-and-timeout',all(a[id][k]==v for k,v in b[id].items() if k not in allowed) and a[id]['timeoutMs']==60000)
 add(id+'-exact-bound-command',a[id]['command']==['bun','tests/security/protection/obligations-acceptance.ts',id] and a[id]['oracleSource']=='tests/security/protection/obligations-oracle.py' and a[id]['testSource']=='tests/security/protection/obligations-acceptance.ts')
 add(id+'-pins-present-and-unique',len(a[id]['implementationSources'])==len(set(a[id]['implementationSources'])) and all((R/f).is_file() for f in a[id]['implementationSources']))
for id in a:
 if id not in ['S21','S22','S23']:
  add(id+'-no-semantic-or-runner-change', {k:v for k,v in a[id].items() if k!='implementationSources'}=={k:v for k,v in b[id].items() if k!='implementationSources'})
  add(id+'-no-existing-pin-removal',set(b[id]['implementationSources']).issubset(a[id]['implementationSources']))
selected=set(['docs/helix/03-test/security/cases.json'])
for id in ['S21','S22','S23']:selected.update([a[id]['testSource'],a[id]['oracleSource'],*a[id]['implementationSources']])
result={'status':'passed' if all(c['passed'] for c in controls) else 'failed','controls':controls,'caseCounts':{'total':len(a),'bound':['S21','S22','S23']},'sourceDigests':{f:sha(R/f) for f in sorted(selected)}}
(D/'adoption-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'controls':len(controls),'failed':[c for c in controls if not c['passed']],'pins':len(selected)}));assert all(c['passed'] for c in controls)
