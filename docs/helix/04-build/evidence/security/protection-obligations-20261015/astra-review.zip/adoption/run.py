from pathlib import Path
import os,json,subprocess,uuid,time,hashlib
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/protection-obligations-astra-20261015/adoption')
results=[]
for id in ['S21','S22','S23']:
 run=str(uuid.uuid4());env={**os.environ,'PATH':'/opt/homebrew/bin:'+os.environ['PATH'],'UMF_SECURITY_CASE_ID':id,'UMF_SECURITY_RUN_ID':run}
 start=time.monotonic();p=subprocess.run(['bun','tests/security/protection/obligations-acceptance.ts',id],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);elapsed=time.monotonic()-start
 (O/(id+'.stdout.json')).write_bytes(p.stdout);(O/(id+'.stderr.log')).write_bytes(p.stderr)
 receipt=json.loads(p.stdout);rows=receipt['observations'];ok=p.returncode==0 and not p.stderr and receipt['status']=='passed' and receipt['id']==id and receipt['runId']==run and all(row['expected']==row['observed'] for row in rows)
 result={'id':id,'runId':run,'exitCode':p.returncode,'stderrBytes':len(p.stderr),'stdoutBytes':len(p.stdout),'seconds':elapsed,'observations':len(rows),'pins':len(receipt['sourceDigests']),'status':receipt['status'],'passed':ok,'sha256':hashlib.sha256(p.stdout).hexdigest(),'versions':receipt['versions']};results.append(result);print(json.dumps(result),flush=True)
 assert ok
(O/'preflight-results.json').write_text(json.dumps(results,indent=2)+'\n')
# Startup controls do not launch the browser; each must refuse before a structured receipt.
for name,args,vars in [('missing-id',[],{}),('wrong-id',['S99'],{'UMF_SECURITY_CASE_ID':'S99','UMF_SECURITY_RUN_ID':'fresh'}),('missing-run',['S21'],{'UMF_SECURITY_CASE_ID':'S21'}),('wrong-case',['S21'],{'UMF_SECURITY_CASE_ID':'S22','UMF_SECURITY_RUN_ID':'fresh'})]:
 env={k:v for k,v in os.environ.items() if k not in ['UMF_SECURITY_CASE_ID','UMF_SECURITY_RUN_ID']};env.update(vars);env['PATH']='/opt/homebrew/bin:'+env['PATH']
 p=subprocess.run(['bun','tests/security/protection/obligations-acceptance.ts',*args],cwd=R,env=env,capture_output=True,timeout=15)
 (O/(name+'.stderr.log')).write_bytes(p.stderr);assert p.returncode!=0 and p.stdout==b'' and b'Fresh governed S21-S23 case/run required' in p.stderr
print('4 startup refusal controls passed',flush=True)
