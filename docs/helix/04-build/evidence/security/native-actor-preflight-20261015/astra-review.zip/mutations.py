from pathlib import Path
import json,subprocess,hashlib,sys
O=Path('/private/tmp/databricks-actors-astra-20261015');S=Path('/Users/erik/.codex/worktrees/security-main-integration/umf/tools/security/databricks-actors.py');source=S.read_text()
variants={
 'pending-publication-omitted':('    write_receipt(output,receipt)\n',''),
 'failure-counts-falsely-zero':("receipt.update(status='observation-failed',errors=[{**stage,'code':code}])","receipt.update(status='observation-failed',distinctNonInstallerActors=0,matchingConfiguredContext=False,errors=[{**stage,'code':code}])"),
 'raw-exception-retained':("else 'OBSERVATION_UNAVAILABLE'","else str(error)"),
 'attempt-identity-match-omitted':("current.get('attemptId')!=expected_attempt or ",''),
 'pending-status-match-omitted':(" or current.get('status')!='observation-pending'",''),
 'publication-lock-omitted':('fcntl.flock(lock.fileno(),fcntl.LOCK_EX)','pass'),
 'host-preparse-controls-omitted':(' or not host.isascii() or any(ord(c)<33 or ord(c)==127 for c in host)',''),
 'profile-aliases-count-as-actors':('len(actors)',"(len(receipt['observations'])-1)"),
 'source-drift-admitted':('if before!=after:receipt.update','if False:receipt.update')
}
rows=[]
for name,(a,b)in variants.items():
 expected=2 if name=='profile-aliases-count-as-actors' else 1
 assert source.count(a)==expected,(name,source.count(a));code=source.replace(a,b);d=O/'mutants'/name;d.mkdir(parents=True,exist_ok=True);p=d/'helper.py';p.write_text(code)
 r=subprocess.run([sys.executable,'-B',str(O/'controls.py'),str(p),str(d/'result.json')],text=True,capture_output=True,timeout=20);(d/'run.log').write_text(r.stdout+r.stderr);j=json.loads((d/'result.json').read_text())if(d/'result.json').exists()else None;fs=[v for v in j['controls']if not v['passed']]if j else [];semantic=[v for v in fs if v['error']is None];row={'name':name,'exit':r.returncode,'controls':len(j['controls'])if j else 0,'failures':[v['id']for v in semantic],'harnessErrors':[v for v in fs if v['error']is not None],'detected':r.returncode==1 and bool(semantic),'sourceSha256':hashlib.sha256(code.encode()).hexdigest()};rows.append(row);print(json.dumps(row),flush=True)
(O/'mutation-results.json').write_text(json.dumps({'originalSourceSha256':hashlib.sha256(S.read_bytes()).hexdigest(),'variants':rows},indent=2)+'\n')
if not all(x['detected']for x in rows):raise SystemExit(1)
