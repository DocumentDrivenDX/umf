from pathlib import Path
import contextlib,io,json,importlib.util,sys,tempfile,hashlib,subprocess,threading,time
from unittest.mock import patch
SOURCE=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/Users/erik/.codex/worktrees/security-main-integration/umf/tools/security/databricks-actors.py')
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else Path('/private/tmp/databricks-actors-astra-20261015/controls.json')
spec=importlib.util.spec_from_file_location('independent_actor',SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
PROFILES=['installer','first','second'];SECRET='SYNTHETIC_PRIVATE_AUTH_TEXT';rows=[]
def check(name,fn):
 try:passed=bool(fn());error=None
 except BaseException as e:passed=False;error=type(e).__name__+':'+str(e)
 rows.append({'id':name,'passed':passed,'error':error})
def fake(ids=('i','a','b'),host='https://review.invalid',changes=None):
 def invoke(args):
  if args==['--version']:return 'Databricks CLI v1.19.0'
  if args[0]=='auth':value={'profiles':[{'name':p,'host':host,'account_id':'A1','workspace_id':'W1','token':SECRET}for p in PROFILES]};stage='metadata'
  else:value={'id':ids[PROFILES.index(args[3])],'active':True,'secret':SECRET,'userName':SECRET};stage=args[3]
  if changes:value=changes(stage,value)
  return json.dumps(value)
 return invoke
def run(invoke=None,profiles=None):
 with tempfile.TemporaryDirectory()as td:
  out=Path(td)/'out.json';out.write_text('{"status":"identities-available","distinctNonInstallerActors":99,"old":true}')
  stream=io.StringIO()
  with contextlib.redirect_stdout(stream):code=m.main(PROFILES if profiles is None else profiles,invoke=fake() if invoke is None else invoke,output=out)
  r=json.loads(out.read_text());return code,r,stream.getvalue(),list(Path(td).glob('*.tmp'))
def stable(r):return r['authority'] is False and r['complete'] is False and r['sourcesUnchanged'] is True and r['sourceDigests']==r['finalSourceDigests']
check('three-identities-observation-only',lambda:(lambda v:v[0]==0 and v[1]['status']=='identities-available' and v[1]['distinctNonInstallerActors']==2 and stable(v[1]) and not v[3] and SECRET not in json.dumps(v[1])+v[2] and 'old' not in v[1])(run()))
for ids,count in [(('i','i','i'),0),(('i','a','a'),1)]:check('aliases-'+str(count),lambda ids=ids,count=count:(lambda v:v[0]==1 and v[1]['status']=='not-qualified' and v[1]['distinctNonInstallerActors']==count and stable(v[1]))(run(fake(ids))))
for stage,observed in [('version',0),('metadata',0),('installer',0),('first',1),('second',2)]:
 def one(stage=stage,observed=observed):
  native=fake()
  def invoke(args):
   at='version' if args==['--version'] else 'metadata' if args[0]=='auth' else args[3]
   if at==stage:raise RuntimeError(SECRET)
   return native(args)
  code,r,s,temps=run(invoke);return code==2 and r['status']=='observation-failed' and len(r['observations'])==observed and r['distinctNonInstallerActors'] is None and r['matchingConfiguredContext'] is None and SECRET not in json.dumps(r)+s and not temps and stable(r)
 check('failure-'+stage+'-unknown-counts',one)
def pending():
 with tempfile.TemporaryDirectory()as td:
  p=Path(td)/'r.json';p.write_text('{"status":"identities-available","old":true}');seen=[]
  def call(args):seen.append(json.loads(p.read_text()));raise SystemExit(37)
  try:m.main(PROFILES,invoke=call,output=p)
  except SystemExit:pass
  r=json.loads(p.read_text());return len(seen)==1 and r==seen[0] and r['status']=='observation-pending' and r['distinctNonInstallerActors'] is None and 'old' not in r
check('hard-exit-keeps-new-pending-before-cli',pending)
def writes():
 with tempfile.TemporaryDirectory()as td:
  calls=[]
  with patch.object(m,'write_receipt',side_effect=OSError('synthetic write failure')):
   try:m.main(PROFILES,invoke=lambda x:calls.append(x),output=Path(td)/'r.json')
   except OSError:pass
  return not calls
check('pending-write-failure-prevents-authentication',writes)
def final_failure():
 with tempfile.TemporaryDirectory()as td:
  p=Path(td)/'r.json';write=m.write_receipt;count=0
  def fail(path,r,**kwargs):
   nonlocal count
   count+=1
   if count==2:raise OSError('synthetic final failure')
   return write(path,r,**kwargs)
  s=io.StringIO()
  with patch.object(m,'write_receipt',side_effect=fail),contextlib.redirect_stdout(s):
   try:m.main(PROFILES,invoke=fake(),output=p)
   except OSError:pass
  r=json.loads(p.read_text());return count==2 and r['status']=='observation-pending' and r['distinctNonInstallerActors'] is None and not s.getvalue()
check('failed-final-write-cannot-publish-success',final_failure)
for host in ['https://review.invalid\n'+SECRET,'https://review.invalid\t'+SECRET,'https://review.invalid\x00'+SECRET,'https://review.invalid space','https://user:'+SECRET+'@review.invalid','https://review.invalid?auth='+SECRET,'https://review.invalid/#'+SECRET,'https://review.invalid/'+SECRET]:
 check('host-rejected-'+str(len(rows)),lambda host=host:(lambda v:v[0]==2 and v[1]['status']=='observation-failed' and v[1]['distinctNonInstallerActors'] is None and SECRET not in json.dumps(v[1])+v[2])(run(fake(host=host))))
for change in [{'id':True},{'active':1},{'id':'bad\nidentifier'},{'id':''}]:
 def test_actor(change=change):
  def transform(stage,value):
   if stage=='first':value.update(change)
   return value
  code,r,s,_=run(fake(changes=transform));return code==2 and r['distinctNonInstallerActors'] is None and len(r['observations'])==1 and SECRET not in json.dumps(r)+s
 check('malformed-actor-'+str(len(rows)),test_actor)
for duplicate in [False,True]:
 def contexts(duplicate=duplicate):
  def transform(stage,value):
   if stage=='metadata':value['profiles']=value['profiles']+[value['profiles'][1]] if duplicate else value['profiles'][:1]+value['profiles'][2:]
   return value
  code,r,s,_=run(fake(changes=transform));return code==2 and r['distinctNonInstallerActors'] is None
 check('profile-context-duplicate' if duplicate else 'profile-context-missing',contexts)
check('new-attempt-identity',lambda:run()[1]['attemptId']!=run()[1]['attemptId'])
def cli_error(effect,expected):
 with patch.object(m.subprocess,'run',side_effect=effect):
  try:m.invoke_cli(['--version'])
  except Exception as e:return isinstance(e,m.ObservationError) and str(e)==expected and SECRET not in str(e)
 return False
check('cli-timeout-redacted',lambda:cli_error(subprocess.TimeoutExpired(['x'],1,output=SECRET,stderr=SECRET),'CLI_TIMEOUT'))
check('cli-not-found-redacted',lambda:cli_error(FileNotFoundError(SECRET),'CLI_UNAVAILABLE'))
def overflow():
 with patch.object(m.subprocess,'run',return_value=subprocess.CompletedProcess(['x'],0,'x'*4000001,SECRET)):
  try:m.invoke_cli(['--version'])
  except Exception as e:return isinstance(e,m.ObservationError) and str(e)=='CLI_OUTPUT_LIMIT'
 return False
check('cli-output-bound',overflow)
def changed_source():
 with tempfile.TemporaryDirectory()as td:
  path=Path(td)/'captured.py';path.write_bytes(SOURCE.read_bytes());old=m.__file__;m.__file__=str(path);native=fake();changed=False
  def invoke(args):
   nonlocal changed
   if not changed:path.write_text(path.read_text()+'\n# synthetic drift\n');changed=True
   return native(args)
  try:
   code,r,out,_=run(invoke);return code==2 and r['status']=='observation-failed' and r['distinctNonInstallerActors'] is None and r['matchingConfiguredContext'] is None and r['sourcesUnchanged'] is False and r['errors']==[{'name':'source-custody','code':'SOURCE_CHANGED'}]
  finally:m.__file__=old
check('source-drift-never-publishes-identity-success',changed_source)
def configured_context():
 def transform(stage,v):
  if stage=='metadata':v['profiles'][-1]['workspace_id']='other'
  return v
 code,r,out,_=run(fake(changes=transform));return code==1 and r['status']=='not-qualified' and r['matchingConfiguredContext'] is False and r['distinctNonInstallerActors']==1
check('different-configured-context-does-not-create-readiness',configured_context)
def newer_attempt_wins():
 with tempfile.TemporaryDirectory()as td:
  out=Path(td)/'r.json';native=fake();new=[];start=[];stream=io.StringIO()
  def first(args):
   if args==['--version']:start.append(json.loads(out.read_text()).get('attemptId'))
   reply=native(args)
   if args[0]=='current-user' and args[3]=='second':
    def fail(args):raise m.ObservationError('CLI_COMMAND_FAILED')
    with contextlib.redirect_stdout(io.StringIO()):code=m.main(PROFILES,invoke=fail,output=out)
    new.append((code,json.loads(out.read_text())))
   return reply
  with contextlib.redirect_stdout(stream):code=m.main(PROFILES,invoke=first,output=out)
  return code==2 and new[0][0]==2 and json.loads(out.read_text())==new[0][1] and new[0][1]['attemptId']!=start[0] and new[0][1]['status']=='observation-failed' and json.loads(stream.getvalue())['status']=='observation-superseded'
check('newer-failure-cannot-be-overwritten-by-older-success',newer_attempt_wins)
def once():
 with tempfile.TemporaryDirectory()as td:
  p=Path(td)/'r.json';pending={'attemptId':'a','status':'observation-pending'};done={'attemptId':'a','status':'observation-failed'}
  return m.write_receipt(p,pending) is True and m.write_receipt(p,done,expected_attempt='a') is True and m.write_receipt(p,{'attemptId':'a','status':'identities-available'},expected_attempt='a') is False and json.loads(p.read_text())==done
check('only-pending-attempt-can-publish-once',once)
def newer_pending_wins():
 with tempfile.TemporaryDirectory()as td:
  out=Path(td)/'r.json';native=fake();saved=[]
  def first(args):
   reply=native(args)
   if args[0]=='current-user' and args[3]=='second':
    p=json.loads(out.read_text());p['attemptId']='distinct-newer-attempt';m.write_receipt(out,p);saved.append(p)
   return reply
  with contextlib.redirect_stdout(io.StringIO()):code=m.main(PROFILES,invoke=first,output=out)
  return code==2 and json.loads(out.read_text())==saved[0] and saved[0]['status']=='observation-pending'
check('newer-pending-cannot-be-overwritten-by-older-success',newer_pending_wins)
for bad in ['https://re\nview.invalid','https://re\tview.invalid']:
 check('urlsplit-normalization-must-not-admit-'+str(len(rows)),lambda bad=bad:(lambda v:v[0]==2 and v[1]['status']=='observation-failed' and v[1]['observations']==[])(run(fake(host=bad))))
def conditional_publication_is_locked():
 with tempfile.TemporaryDirectory()as td:
  p=Path(td)/'r.json';a={'attemptId':'a','status':'observation-pending'};b={'attemptId':'b','status':'observation-pending'};done={'attemptId':'a','status':'identities-available'};m.write_receipt(p,a)
  entered=threading.Event();release=threading.Event();b_done=threading.Event();errors=[];original=m.os.replace
  def replace(src,dst):
   if threading.current_thread().name=='old-publisher':
    entered.set()
    if not release.wait(3):raise RuntimeError('review barrier timeout')
   return original(src,dst)
  def old():
   try:m.write_receipt(p,done,expected_attempt='a')
   except BaseException as e:errors.append(type(e).__name__)
  def new():
   try:m.write_receipt(p,b);b_done.set()
   except BaseException as e:errors.append(type(e).__name__)
  t1=threading.Thread(target=old,name='old-publisher');t2=threading.Thread(target=new,name='new-claim')
  with patch.object(m.os,'replace',side_effect=replace):
   try:
    t1.start()
    if not entered.wait(2):return False
    t2.start();premature=b_done.wait(.15);release.set();t1.join(3);t2.join(3)
    return not premature and not errors and not t1.is_alive() and not t2.is_alive() and json.loads(p.read_text())==b
   finally:
    release.set()
    if t1.ident:t1.join(3)
    if t2.ident:t2.join(3)
check('cas-check-and-replace-share-one-lock',conditional_publication_is_locked)
OUT.write_text(json.dumps({'sourceSha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'python':sys.version,'scope':'Entirely synthetic injected responses, private receipt paths and mocked subprocess.run. No real auth CLI or network.','controls':rows},indent=2)+'\n');print(json.dumps({'controls':len(rows),'failures':[x['id'] for x in rows if not x['passed']]}))
if any(not x['passed'] for x in rows):raise SystemExit(1)
