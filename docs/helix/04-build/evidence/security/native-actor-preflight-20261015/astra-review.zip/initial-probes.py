from pathlib import Path
import importlib.util,json,contextlib,io,hashlib
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/databricks-actors-astra-20261015');S=R/'tools/security/databricks-actors.py'
spec=importlib.util.spec_from_file_location('actor_probe',S);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
(O/'before-review-source.py').write_bytes(S.read_bytes());profiles=['root','left','right'];ids={'root':'i','left':'a','right':'b'}
def data(args,host='https://example.invalid'):
 if args==['--version']:return 'Databricks CLI v1.19.0'
 if args[0]=='auth':return json.dumps({'profiles':[{'name':p,'host':host}for p in profiles]})
 return json.dumps({'id':ids[args[3]],'active':True})
path=O/'concurrent-canonical.json';stages=[];started=None
with contextlib.redirect_stdout(io.StringIO()):
 def first(args):
  global started
  if args==['--version']:started=json.loads(path.read_text())['attemptId']
  reply=data(args)
  if args[0]=='current-user' and args[3]=='right':
   def fail(args):raise m.ObservationError('CLI_COMMAND_FAILED')
   code=m.main(profiles,invoke=fail,output=path);stages.append({'newerAttemptCode':code,'newerAttemptReceipt':json.loads(path.read_text())})
  return reply
 code=m.main(profiles,invoke=first,output=path)
stages.append({'olderAttemptCode':code,'olderAttemptId':started,'finalCanonicalReceipt':json.loads(path.read_text())})
result={'sourceSha256':hashlib.sha256(S.read_bytes()).hexdigest(),'scope':'Synthetic reentrant scheduling of two overlapping attempts; all configured contexts/actors mocked, no external CLI. First attempt already captured final identity reply before newer attempt writes failure.','stages':stages,'olderOverwroteNewerFailure':json.loads(path.read_text())['attemptId']==started and stages[0]['newerAttemptReceipt']['attemptId']!=started}
(O/'concurrent-overwrite.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'olderOverwroteNewerFailure':result['olderOverwroteNewerFailure']}))
rows=[]
for host in ['https://example.invalid\nRAW-MARKER','https://example.invalid\x00RAW-MARKER','https://example.invalid space','https://example.invalid\tRAW-MARKER']:
 try:r=m.selected_context({'host':host});rows.append({'host':host,'accepted':True,'retained':r})
 except Exception as e:rows.append({'host':host,'accepted':False,'code':type(e).__name__})
(O/'host-text-probes.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'malformedHostAcceptances':sum(x['accepted']for x in rows)}))
