# Independent actor preflight custody review

No remaining blocker in the POSIX observation scope. Two reproduced defects are fixed: older overlapping success can no longer replace a newer failed/pending attempt, and malformed raw hosts are rejected before URL normalization. Stable flock plus exact current-pending attempt checks protect publication.

37 independent synthetic controls and21 repository cases pass, including owned process termination/different-cwd and two-process overlap. All9 deliberate source weakenings are detected by semantic expectation failures. Initial witnesses, preimages and incidental mutation harness errors are retained.

No real cloud/auth CLI was invoked and no canonical root actor receipt was modified by reviewer. Identity observations still confer no grants/native authority. Process-abort visibility is qualified; power-loss durability, hostile filesystem/ABA immunity and hermetic runtime provenance are not. All158 original case definitions and src/spec/package sources remain unchanged.
