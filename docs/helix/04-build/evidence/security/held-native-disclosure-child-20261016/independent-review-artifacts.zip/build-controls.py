from pathlib import Path
import shutil,subprocess,json,hashlib
R=Path(__file__).parent;S=R/'build-probe';shutil.copytree(R/'reconstructed',S);D=R/'build-controls';D.mkdir();paths=['tsconfig.json','bunfig.toml','tools/security/current-native-disclosure-child.ts'];original={p:(S/p).read_bytes() for p in paths};checks=[]
def reset():
 for p,b in original.items():(S/p).write_bytes(b)
def run(name,needle,preload=None):
 out=D/(name+'-output');cmd=['/opt/homebrew/bin/bun']
 if preload:w=D/(name+'-preload.ts');w.write_text(preload);cmd+=['--preload',str(w)]
 cmd+=['tools/security/build-current-native-disclosure-child.ts',str(out)];r=subprocess.run(cmd,cwd=S,capture_output=True,timeout=20);(D/(name+'.log')).write_bytes(r.stdout+r.stderr);assert r.returncode!=0 and not (out/'manifest.json').exists() and needle.encode() in r.stderr,(name,r.stderr);checks.append({'id':name,'passed':True,'exitCode':r.returncode,'manifestIssued':False,'command':cmd});reset()
for label,value in [('local','./other.json'),('array',['./other.json']),('null',None)]:
 c=json.loads(original['tsconfig.json']);c['extends']=value;(S/'tsconfig.json').write_text(json.dumps(c));run('extends-'+label,'Standalone root TypeScript configuration required')
(S/'tsconfig.json').write_text('[]');run('config-array','Standalone root TypeScript configuration required')
(S/'bunfig.toml').unlink();run('missing-bunfig','ENOENT')
for p in paths:
 for stage in ([1,2] if p!='tools/security/current-native-disclosure-child.ts' else [2]):
  wrapper="import {appendFileSync} from 'node:fs';const original=Bun.build;let n=0;(Bun as any).build=async function(config:any){const result=await original(config);if(++n==="+str(stage)+")appendFileSync("+json.dumps(str(S/p))+",'\\n');return result;};\n"
  run(p.replace('/','-').replace('.','-')+'-stage'+str(stage),'Build source changed' if p.startswith('tools/') else 'Build configuration changed',wrapper)
(R/'build-controls.json').write_text(json.dumps({'status':'passed','controls':len(checks),'checks':checks,'scope':'Actual frozen new builder/config refusal and injected closing drift in isolated copy; original executable rebuild independently matches supplied bundle.'},indent=2)+'\n');print(json.dumps({'status':'passed','controls':len(checks)}))
