from pathlib import Path
import importlib.util,importlib._bootstrap_external,hashlib,json,shutil
R=Path(__file__).parent;D=R/'pycache-control';D.mkdir();p=D/'pipe.py';original=(R/'frozen/evidence/15-_current_query_pipe.py').read_bytes();p.write_bytes(original)
marker=D/'executed-unpinned-cache.txt';payload=original+b'\nfrom pathlib import Path as _ReviewerPath\n_ReviewerPath('+repr(str(marker)).encode()+b').write_text("unrecorded cached bytecode executed\\n")\n';(D/'cached-payload-source.py').write_bytes(payload)
code=compile(payload,str(p),'exec');stat=p.stat();bytecode=importlib._bootstrap_external._code_to_timestamp_pyc(code,int(stat.st_mtime),stat.st_size);cache=Path(importlib.util.cache_from_source(str(p)));cache.parent.mkdir();cache.write_bytes(bytecode)
spec=importlib.util.spec_from_file_location('reviewer_cached_pipe',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert marker.exists() and p.read_bytes()==original
r={'status':'counterexample-confirmed','moduleSourceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cacheSha256':hashlib.sha256(cache.read_bytes()).hexdigest(),'payloadExecuted':marker.read_text(),'sourceUnchanged':p.read_bytes()==original,'scope':'Actual same importlib loader mechanism as R1 CLI, matching source timestamp/length .pyc; benign marker only, no DB. Source hash alone does not bind executed Python module when importlib accepts adjacent cache.'}
(R/'pycache-control.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
