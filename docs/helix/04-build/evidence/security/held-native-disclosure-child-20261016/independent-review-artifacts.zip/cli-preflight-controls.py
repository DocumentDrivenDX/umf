from pathlib import Path
import json,subprocess,shutil
R=Path(__file__).parent;F=R/'frozen';D=R/'cli-preflight';D.mkdir();script=R/'frozen-r2/tools/security/replay-held-native-disclosure.py';base={'umf-root':R/'reconstructed','bundle-root':R/'rebuilt-bundle','wheel':F/'evidence/14-weft_sql-0.4.37.dev0-cp39-abi3-macosx_11_0_arm64.whl','wheel-manifest':F/'evidence/13-presence-bridge-review-manifest-r1.json','pipe-source':F/'evidence/15-_current_query_pipe.py','native-receipt':F/'evidence/16-receipt.json','bun':'/opt/homebrew/bin/bun'};checks=[]
for mode in ['optimized-python','existing-output','missing-argument','wrong-wheel','wrong-pipe','wrong-native','wrong-wheel-manifest','wrong-bundle-profile']:
 args=dict(base);out=D/(mode+'-output');args['output']=out
 if mode=='existing-output':out.mkdir()
 if mode.startswith('wrong-') and mode!='wrong-bundle-profile':
  k={'wrong-wheel':'wheel','wrong-pipe':'pipe-source','wrong-native':'native-receipt','wrong-wheel-manifest':'wheel-manifest'}[mode];p=D/(mode+'.input');p.write_bytes(Path(args[k]).read_bytes()+b'\n' if mode!='wrong-wheel-manifest' else b'{}');args[k]=p
 if mode=='wrong-bundle-profile':
  d=D/'profile-bundle';d.mkdir();m=json.loads((R/'rebuilt-bundle/manifest.json').read_text());m['profile']='old';(d/'manifest.json').write_text(json.dumps(m));args['bundle-root']=d
 if mode=='missing-argument':del args['native-receipt']
 command=['/private/tmp/truss-practical-performance-env/bin/python']+(['-O'] if mode=='optimized-python' else [])+[str(script)]+[item for k,v in args.items() for item in ['--'+k,str(v)]]
 r=subprocess.run(command,capture_output=True,timeout=15);(D/(mode+'.log')).write_bytes(r.stdout+r.stderr);assert r.returncode!=0 and not (out/'receipt.json').exists(),mode
 checks.append({'id':mode,'exitCode':r.returncode,'receiptIssued':False,'passed':True,'command':command})
(R/'cli-preflight-controls.json').write_text(json.dumps({'status':'passed','controls':len(checks),'checks':checks,'scope':'Actual corrected CLI preflight failures, no child SQL/native database execution.'},indent=2)+'\n');print(json.dumps({'status':'passed','controls':len(checks)}))
