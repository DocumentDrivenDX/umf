from pathlib import Path
import json, hashlib
R=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 b=(R/p).read_bytes();return {'path':p,'sha256':sha(b),'bytes':len(b)}
def write(p,o): (R/p).write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
initial={
 'version':'independent-component-review/1','reviewer':'Astra Ultra independent review','status':'changes-required-in-r1','baseCommit':'17221c40c261c784c427186b314ef02679c079ea',
 'inputs':[pin('frozen/review.zip'),pin('frozen/overlay/tools/security/replay-held-native-disclosure.py')],
 'findings':[{'id':'HELD-001','priority':'P2','title':'Replay CLI does not bind the executed pipe module to its reported source digest','file':'tools/security/replay-held-native-disclosure.py','description':'R1 checks the pipe source digest before importlib loading, then reports a recomputed closing digest without requiring equality. A post-import mutation completes all 52 records and issues a successful receipt naming different bytes. Separately, the same importlib loader accepts a timestamp/size-valid adjacent bytecode cache while the source bytes retain their expected digest. The wheel manifest also lacks captured-byte closing custody.',
 'actualCounterexample':{'execution':'cli-pipe-drift-execution.json','receipt':'cli-pipe-drift/receipt.json','exitCode':0,'records':52,'initialPipeSha256':'39c7ab62660f64241f59008f5cb0b16b721f741657c44d321189237655031d7f','reportedClosingSha256':'6e1ff18ac76349a34d027afce6b7d43df329d4b7e8f297b495102243a1d8dfa4'},
 'loaderCounterexample':'pycache-control.json','requestedCorrection':'Capture and execute the exact checked pipe bytes without adjacent pycache, capture the wheel-manifest bytes, compare both supplied files at close, and report the captured digests.',
 'scope':'Evidence/execution custody defect; no observed child semantic defect or native-authority bypass. The separate pycache control exercises the actual loader mechanism, not a second full CLI campaign.'}],
 'retention':'Original R1 source, receipt, archive and counterexamples are preserved unchanged. Later R2 controls do not retroactively qualify R1.'}
write('initial-review.json',initial)
executions=[
 {'command':['/opt/homebrew/bin/bun','tools/security/build-current-native-disclosure-child.ts',str(R/'rebuilt-bundle')],'cwd':str(R/'reconstructed'),'evidence':'build.log','result':'byte-identical executable; 257 selected source/config pins'},
 {'command':['/opt/homebrew/bin/bun','test','tests/security/current-native-disclosure-child.test.ts','tests/security/current-disclosure-child.test.ts','tests/security/current-query-child.test.ts'],'cwd':str(R/'reconstructed'),'evidence':'held-and-legacy-tests.log','passedTests':19,'failedTests':0,'assertions':812},
 {'command':['python3',str(R/'process-controls.py')],'evidence':'process-controls.json','passedControls':143,'originalVectors':72},
 {'command':['/opt/homebrew/bin/bun',str(R/'session-controls.ts')],'evidence':'session-controls.json','passedControls':69},
 {'command':['python3',str(R/'build-controls.py')],'evidence':'build-controls.json','passedControls':10},
 {'command':['python3',str(R/'cli-preflight-controls.py')],'evidence':'cli-preflight-controls.json','passedControls':8},
 {'command':['python3',str(R/'run-cli.py'),'normal'],'evidence':'cli-normal-execution.json','records':52,'result':'47 data-only matches, 4 structural refusals with canceled child, 1 whole-V2 refusal'},
 {'command':['/private/tmp/truss-practical-performance-env/bin/python',str(R/'run-cli-r2.py'),'poisoned-cache'],'evidence':'cli-r2-poisoned-cache-execution.json','records':52,'result':'normal R2 replay succeeds; adjacent cache marker not executed'},
 {'command':['/private/tmp/truss-practical-performance-env/bin/python',str(R/'run-cli-r2.py'),'pipe-drift'],'evidence':'cli-r2-pipe-drift-execution.json','result':'closing custody assertion refuses, exit 1, no receipt'},
 {'command':['/private/tmp/truss-practical-performance-env/bin/python',str(R/'run-cli-r2.py'),'manifest-drift'],'evidence':'cli-r2-manifest-drift-execution.json','result':'closing custody assertion refuses, exit 1, no receipt'},
 {'command':['python3',str(R/'custody-audit.py')],'evidence':'custody-audit.json','passedChecks':3704}]
report={
 'version':'independent-component-review/1','reviewer':'Astra Ultra independent review','date':'2026-10-16','status':'review-complete-no-remaining-findings','baseCommit':'17221c40c261c784c427186b314ef02679c079ea','profile':'umf.security.private-disclosure-child/0.2-candidate',
 'verdict':'R1 held-child source and the separate R2 replay-CLI custody repair are consistent with the tested private data-only component scope. HELD-001 is resolved in R2; no remaining actionable findings.',
 'inputs':[pin(p) for p in ['frozen/review.zip','frozen-r2/review.zip','frozen/selected-source-inputs.zip','frozen/bundle/current-native-disclosure-child.mjs','frozen/bundle/manifest.json','frozen/overlay/tools/security/current-native-disclosure-child.ts','frozen/overlay/tools/security/current-native-disclosure-child-main.ts','frozen/overlay/tools/security/build-current-native-disclosure-child.ts','frozen-r2/tools/security/replay-held-native-disclosure.py','frozen/evidence/14-weft_sql-0.4.37.dev0-cp39-abi3-macosx_11_0_arm64.whl','frozen/evidence/15-_current_query_pipe.py','frozen/evidence/16-receipt.json','reconstructed-source.zip']],
 'sourceBasis':{'reconstructedFiles':2456,'selectedBundleInputs':257,'metafileInputs':252,'additionalPins':['builder','package.json','bun.lock','tsconfig.json','bunfig.toml'],'r2Delta':'Only replay-held-native-disclosure.py; child/session/main/builder/tests and bundle unchanged.','custodyAudit':'custody-audit.json','supplementalGovernance':'supplemental-governance/pins.json'},
 'resolvedFindings':[{'id':'HELD-001','priority':'P2','originalDisposition':'initial-review.json','repair':'Capture exact pipe bytes and execute compile/exec in a fresh ModuleType without importlib/pycache; capture wheel-manifest bytes; compare both inputs again before issuing the receipt; report captured digests.','repairSource':pin('frozen-r2/tools/security/replay-held-native-disclosure.py'),'verification':['cli-r2-poisoned-cache-execution.json','cli-r2-pipe-drift-execution.json','cli-r2-manifest-drift-execution.json'],'result':'Actual 52-record replay succeeds with an ignored poisoned cache. Both post-capture drift campaigns refuse at close without a success receipt.'}],
 'remainingFindings':[],
 'independentExecutions':executions,
 'reviewConclusions':[
 'One closed initialization and one actual atomic WithinOperation evaluation hold the compiled program, original sources and produced batch until one inspection. The original whole V2 inspector precedes canonical equality to the held original batch. Terminal paths clear retained references and correlation state.',
 'All 72 vectors trace to the original 66 producer packets and six mixed/empty packets. Process controls retain exact original results, full length-prefixed frame hashes, strict shapes, Unicode/numeric/key checks, sequencing, refusal and EOF behavior. A source-valid alternate selected occurrence is accepted by whole V2 but rejected by held-original equality.',
 'Direct process inspection accepts the exact 16 MiB endpoint and refuses one byte above; this uses padding, not a maximum semantic batch. Direct scanner controls exercise depth 64/65 and nodes 100016/100017 separately from V2 semantic validity.',
 'The actual reviewed Python extension and parent object remain live through fresh structural checking and held-child inspection of the 52 supplied native records. Untouched driver cells, private-key bag and order are reconstructed; four corrupted frames refuse structurally, while selected occurrence 999/999 matches structurally and then refuses whole V2.',
 'Custody checks verify complete core module bytes/revisions/selected-module closure for all 52 records, four opaque source roles, bundle/source correspondence, exact legacy API source isolation and unchanged source endpoints. Rebuilt executable is byte-identical.',
 'Supplemental STP and implementation checkpoint correctly retain the R1 finding, R2 repair, exact independent counts, old pipe cap and unchanged acceptance scope.'
 ],
 'suppliedEvidence':{'authorFullSecuritySuite':{'testsPassed':332,'assertions':5929,'evidence':'frozen/evidence/01-umf-native-disclosure-child-security-r2-20261016.log','independentlyRerun':False},'authorToolsTypecheck':'Author reports exit 0; retained log is empty, not an independently observed typecheck exit.','laterAuthorR2Replay':'supplemental-r2/owner-receipt.json; 52 records independently compared with reviewer R2 replay.','originalNativeCampaign':'Previously audited supplied 52-record PG18.6 campaign; no new database execution in this review.'},
 'scopeLimits':[
 'No new SQL/database campaign. Fresh child lifetime covers this replay, not the earlier historical SQL execution. Native records are supplied evidence, not an independent native replay.',
 'Data-only inspection is not evidence of native execution: an unchanged original batch can be echoed without a database. Actual caller, authenticated sources, complete current cut, native carrier/key bag, closing guards and guarded release remain host obligations.',
 'The reused pinned Truss pipe caps requests at 4194304 bytes; 16777216-byte inspection coverage belongs to direct child/new-consumer controls. No installed Truss query API adoption is claimed.',
 'SourceReceipt is this profile’s entire initializer-frame digest, distinct from 0.1 and Truss registration receipts. It cannot replace registration authority or be compared as an equal hash to a different envelope.',
 'Parent owns timeout, cancellation and cleanup. Reference clearing is not secure memory zeroization. Canonical batch equality does not replace private-key/complete-bag checks for equal cell values.',
 'External Bun/Python executable closure is non-hermetic. Source endpoint comparisons are not held-file, anti-ABA or authentication proofs. Tests are not a formal semantic refinement proof.',
 'Private evaluation census remains internal, not ordinary reader output. No operator/action permission, public release, native authority, backend admission or acceptance promotion. All original 158 UMF and 132 Weft allocations remain; UMF 45 implemented/113 missing unchanged.'
 ]}
write('review.json',report)
write('attempts.json',{'version':'review-attempts/1','attempts':[
 {'kind':'author-initial-test-setup-failure','evidence':'frozen/evidence/00-umf-native-disclosure-child-tests-r1-20261016.log','description':'Mixed-vector name typo; retained separately from corrected successful tests.'},
 {'kind':'author-earlier-epochs','evidence':'frozen/evidence/06-receipt.json through 12-umf-native-disclosure-python-native52-replay-r2-20261016.json','description':'Earlier CLI/bridge sources, logs and receipts retained verbatim; no retroactive qualification.'},
 {'kind':'reviewer-read-path-correction','description':'After successfully extracting and hashing R2, attempted to read overlay/tools/security/replay-held-native-disclosure.py. The ZIP member is tools/security/replay-held-native-disclosure.py. The first read failed FileNotFound before test execution; corrected path used thereafter. Tool trace was not separately saved.'},
 {'kind':'confirmed-initial-counterexamples','evidence':['cli-pipe-drift-execution.json','pycache-control.json'],'description':'Intentional R1 custody counterexamples; preserve successful-but-misqualified receipt and actual cache marker.'},
 {'kind':'expected-repaired-refusals','evidence':['cli-r2-pipe-drift-execution.json','cli-r2-manifest-drift-execution.json'],'description':'Intentional R2 drift after capture; both nonzero without receipt.'}]})
write('restoration.json',{'version':'independent-review-restoration/1','root':str(R),'source':'Extract reconstructed-source.zip into a new directory; it preserves all 2456 R1 reconstructed source files. The final R2 CLI is separately retained at frozen-r2/tools/security/replay-held-native-disclosure.py. Do not rewrite the R1 archive.','bundle':'frozen/bundle and rebuilt-bundle contain the original and byte-identical independently rebuilt executable, manifests and notices.','wheel':'frozen/evidence/14-weft_sql-0.4.37.dev0-cp39-abi3-macosx_11_0_arm64.whl restores excluded generated wheel extraction directories.','replay':'Scripts retain exact paths and commands. For reruns use a fresh relocated copy/output, preserve source epochs, and adjust paths consistently. Do not overwrite these original evidence directories.','externalRuntime':['/opt/homebrew/bin/bun 1.4.2','/private/tmp/truss-practical-performance-env/bin/python 3.11.17'],'retainedExceptionalBytecode':['pycache-control/__pycache__/pipe.cpython-311.pyc','r2-poisoned-cache-inputs/__pycache__/pipe.cpython-311.pyc'],'exclusions':'Reconstructed/build scratch, base-source.tar, generated installed-wheel trees and incidental bytecode are reconstructible; intentional adversarial bytecode is retained.'})
(R/'README.md').write_text('Independent held native disclosure 0.2 review\n\nR1 source plus the separate R2 replay-CLI custody repair has no remaining actionable findings. HELD-001 and its actual initial counterexamples remain in initial-review.json; review.json records the repair and qualified results.\n\nIndependent evidence: 143 process controls (all 72 vectors), 69 session/scanner controls, 19 held/0.1/legacy tests with 812 assertions, 10 build controls, eight CLI preflight negatives and 3,704 custody checks. Actual reviewed Python bridge replay covers 52 supplied native records; R2 ignores poisoned cache and refuses both closing drift controls. No new database execution or authority/acceptance promotion. The reused pipe remains 4 MiB; direct child inspection was tested at 16 MiB.\n\nmanifest.json pins the retained evidence. restoration.json explains reconstructible exclusions and external runtime dependencies. Original failed attempts and R1/R2 epochs are retained.\n')
files={};excluded=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R);s=str(rel);parts=rel.parts
 if s in ['manifest.json','manifest-verification.json']:continue
 if parts[0] in ['reconstructed','build-probe'] or s=='base-source.tar':excluded.append(s);continue
 if 'wheel' in parts:excluded.append(s);continue
 if '__pycache__' in parts and parts[0] not in ['pycache-control','r2-poisoned-cache-inputs']:excluded.append(s);continue
 b=p.read_bytes();files[s]={'sha256':sha(b),'bytes':len(b)}
for special in ['pycache-control/__pycache__/pipe.cpython-311.pyc','r2-poisoned-cache-inputs/__pycache__/pipe.cpython-311.pyc']:assert special in files
write('manifest.json',{'version':'independent-review-evidence-manifest/1','reviewSha256':sha((R/'review.json').read_bytes()),'files':files,'excludedReconstructibleScratch':{'prefixes':['reconstructed/','build-probe/','*/wheel/','incidental __pycache__/'],'files':['base-source.tar'],'count':len(excluded),'restoration':'restoration.json'}})
for n,v in files.items():
 b=(R/n).read_bytes();assert sha(b)==v['sha256'] and len(b)==v['bytes']
v={'status':'passed','files':len(files),'bytes':sum(v['bytes'] for v in files.values()),'reviewSha256':sha((R/'review.json').read_bytes()),'manifestSha256':sha((R/'manifest.json').read_bytes()),'intentionalBytecodeRetained':True}
write('manifest-verification.json',v);print(json.dumps(v,indent=2))
