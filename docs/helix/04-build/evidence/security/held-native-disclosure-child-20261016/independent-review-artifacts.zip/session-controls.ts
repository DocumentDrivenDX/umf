import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {CurrentNativeDisclosureChildSession,NATIVE_DISCLOSURE_CHILD_VERSION as version} from './reconstructed/tools/security/current-native-disclosure-child';
import {encodeDisclosureChildFrame as encode} from './reconstructed/tools/security/current-disclosure-child';
import {scanPlanJson} from './reconstructed/src/extensions/actions/plan-artifacts';
import {inspectSecurityDisclosureV2} from './reconstructed/src/extensions/security/protection/disclosure';
const R=import.meta.dir,v=JSON.parse(readFileSync(R+'/frozen/overlay/tests/security/protection/native-disclosure-child-vectors.json','utf8')),checks:any[]=[],observations:any[]=[];
const check=(id:string,ok:unknown)=>{if(!ok)throw Error(id);checks.push({id,passed:true});},sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex'),decode=(b:Uint8Array)=>JSON.parse(new TextDecoder().decode(b.subarray(4)));
function setup(id:string,alter?:(source:any,packet:any)=>void){const p=structuredClone(v.packets.find((x:any)=>x.id===id)),s=structuredClone(v.sources[p.sourceIndex]);alter?.(s,p);const initial={version,kind:'initialize',requestId:'init',sources:{policy:s.policy,catalog:s.catalog,closure:s.closure,ontology:s.ontology,associationBindings:[]},owner:s.owner,selection:p.selection},session:any=new CurrentNativeDisclosureChildSession(),a=encode(initial),receipt=sha(a);session.process(a);const b=encode({version,kind:'evaluate-disclosure',requestId:'eval',sourceReceipt:receipt,cut:p.cut}),result=decode(session.process(b)).result;return {session,result,source:s,packet:p,initial,evaluation:b,inspection:(batch:any)=>encode({version,kind:'inspect-native-disclosure',requestId:'inspect',sourceReceipt:receipt,batch})};}
function cleared(s:any,name:string){for(const field of ['handle','sources','owner','selection','originalBatch'])check(name+'-clears-'+field,s[field]===undefined);check(name+'-clears-evaluation-hash',s.evaluationFrameSha256===null);check(name+'-clears-ids',s.ids.size===0);check(name+'-terminal',s.phase==='terminal');}
for(const mode of ['success','wrong-batch','semantic-refusal','malformed-inspection']){
 const s=setup(mode==='semantic-refusal'?'allowed:unreported':'allowed:transformed-null');
 if(mode==='semantic-refusal'){check(mode,s.result.status==='refused');cleared(s.session,mode);continue;}
 check(mode+'-holds-original',s.session.handle&&s.session.sources&&s.session.owner&&s.session.selection&&s.session.originalBatch&&s.session.evaluationFrameSha256===sha(s.evaluation));
 let reply:any;
 if(mode==='malformed-inspection'){try{s.session.process(Uint8Array.from([0,0,0,1,255]));}catch{} }
 else {const batch=structuredClone(s.result.batch);if(mode==='wrong-batch')batch.rows=[];reply=decode(s.session.process(s.inspection(batch)));check(mode+'-reply',reply.kind===(mode==='success'?'native-disclosure-inspected':'refused'));}
 check(mode+'-inspection-completed',s.session.inspectionCompleted===(mode==='success'));cleared(s.session,mode);
}
// Same transform/value, but a different independently valid selected policy occurrence.
const d=setup('allowed:transformed-null',(s,p)=>{s.policy.revision+='-review-duplicate';s.policy.rules.push({...structuredClone(s.policy.rules[0]),id:'reader-duplicate'});p.cut.policy.revision=s.policy.revision;});
check('duplicate-occurrence-producer-rendered',d.result.status==='rendered');const changed=structuredClone(d.result.batch);changed.rows[0][0].selection.ruleIndex=4;
const whole=inspectSecurityDisclosureV2(changed,d.source.policy,d.source.catalog,d.source.closure);check('duplicate-occurrence-whole-v2-valid',whole.status==='validated-disclosure');const reply=decode(d.session.process(d.inspection(changed)));check('duplicate-occurrence-held-equality-refuses',reply.kind==='refused');cleared(d.session,'duplicate-occurrence');observations.push({id:'valid-alternate-occurrence',source:d.source,packet:d.packet,original:d.result,batch:changed,wholeInspection:whole,heldReply:reply});
// Scanner-specific resource endpoints; not full V2 semantic acceptance of these arrays.
for(const depth of [64,65]){let failed=false;try{scanPlanJson('['.repeat(depth)+'0'+']'.repeat(depth),16777216,100016);}catch{failed=true;}check('scanner-depth-'+depth,failed===(depth===65));}
for(const values of [100015,100016]){let failed=false;try{scanPlanJson('['+Array(values).fill('0').join(',')+']',16777216,100016);}catch{failed=true;}check('scanner-nodes-'+(values+1),failed===(values===100016));}
for(const [text,valid] of [['"\\ud83d\\ude42"',true],['"🙂"',true],['"\\ud800"',false],['"\\udfff"',false],['{"\\ud800":0}',false],['9007199254740991',true],['9007199254740992',false],['1.000e0',true],['0e9999',true],['-0.0e123',false],['1e-999',false],['0.10000000000000001',false],['{"x":0,"\\u0078":1}',false]] as const){let failed=false;try{scanPlanJson(text,16777216,100016);}catch{failed=true;}check('scanner-value-'+checks.length,failed!==valid);}
writeFileSync(R+'/session-controls.json',JSON.stringify({status:'passed',controls:checks.length,checks,observations,scope:'Exact held session source/handle lifecycle and canonical provenance equality; scanner boundary tests are separate from full V2 semantic validity. No native authority.'},null,2)+'\n');console.log(JSON.stringify({status:'passed',controls:checks.length}));
