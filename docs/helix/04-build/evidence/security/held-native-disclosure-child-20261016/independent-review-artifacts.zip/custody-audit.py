from pathlib import Path
import json,hashlib,subprocess,difflib,shutil,collections,zipfile
R=Path(__file__).parent;F=R/'frozen';O=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def check(name,ok,**kw):
 assert ok,name;checks.append({'id':name,'passed':True,**kw})
m=json.loads((F/'manifest.json').read_bytes());base=m['baseCommit']
for p,v in m['files'].items():check('frozen:'+p,sha((F/p).read_bytes())==v['sha256'] and (F/p).stat().st_size==v['bytes'])
check('r1-archive',sha((F/'review.zip').read_bytes())=='e1a29f77c0a3a486deeaeb5ef7b3b957a832889ea2d45c4a731af878cd59f82e')
check('r2-archive',sha((R/'frozen-r2/review.zip').read_bytes())=='0963b141ced25d7d37a29d04708251bd9d6ca96ec0ba2736829d221b4e3e2392')
final=R/'frozen-r2/tools/security/replay-held-native-disclosure.py';check('r2-script',sha(final.read_bytes())=='1994e9a6ec20e52b131a299928f7a1999e669c89aec0f123a31fe58316b2e933');check('owner-final-cli',final.read_bytes()==(O/'tools/security/replay-held-native-disclosure.py').read_bytes())
bm=json.loads((F/'bundle/manifest.json').read_bytes());meta=json.loads((F/'bundle/metafile.json').read_bytes());rebuild=json.loads((R/'rebuilt-bundle/manifest.json').read_bytes())
check('rebuilt-executable-byte-identical',(F/'bundle/current-native-disclosure-child.mjs').read_bytes()==(R/'rebuilt-bundle/current-native-disclosure-child.mjs').read_bytes())
check('rebuilt-pins-identical',bm['sourcePins']==rebuild['sourcePins']);check('exact-metadata-domain',set(bm['sourcePins'])==set(meta['inputs'])|{'tools/security/build-current-native-disclosure-child.ts','package.json','bun.lock','tsconfig.json','bunfig.toml'})
with zipfile.ZipFile(F/'selected-source-inputs.zip') as z:
 check('source-zip-exact-domain',set(z.namelist())==set(bm['sourcePins']))
 for p,h in bm['sourcePins'].items():check('source-zip:'+p,sha(z.read(p))==h)
for p,h in bm['sourcePins'].items():check('current-source-endpoint:'+p,sha((O/p).read_bytes())==h)
for p,h in json.loads((R/'source-before.json').read_bytes()).items():check('reconstructed-source-unchanged:'+p,sha((R/'reconstructed'/p).read_bytes())==h)
for p in ['tools/security/current-disclosure-child.ts','tools/security/current-disclosure-child-main.ts','tools/security/build-current-disclosure-child.ts','tests/security/current-disclosure-child.test.ts','tools/security/current-query-child.ts','tools/security/current-query-child-main.ts','tools/security/build-current-query-child.ts','tests/security/current-query-child.test.ts','src/index.ts','package.json','bun.lock']:
 b=subprocess.check_output(['git','show',base+':'+p],cwd=O);check('old-profile-base-identical:'+p,b==(O/p).read_bytes() and b==(R/'reconstructed'/p).read_bytes(),sha256=sha(b))
for p in ['docs/helix/02-design/technical-designs/TD-056-security-bindings.md','docs/helix/03-test/test-plans/STP-056-security-bindings.md','docs/helix/04-build/implementation-plan.md','tsconfig.tools.json']:
 original=subprocess.check_output(['git','show',base+':'+p],cwd=O);changed=(F/'overlay'/p).read_bytes();(R/(Path(p).name+'.diff')).write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),changed.decode().splitlines(True),fromfile=base+':'+p,tofile='R1:'+p)))
# Reproduce retained exact52 typed objects/results; source-module and resource/cell correspondence.
v=json.loads((F/'overlay/tests/security/protection/native-disclosure-child-vectors.json').read_bytes());packets={p['id']:p for p in v['packets']};native=json.loads((F/'evidence/16-receipt.json').read_bytes());r1=json.loads((R/'cli-normal/receipt.json').read_bytes());r2=json.loads((R/'cli-r2-poisoned-cache/receipt.json').read_bytes());supplied=json.loads((F/'evidence/04-receipt.json').read_bytes())
check('r1-r2-records-exact',r1['records']==r2['records']);check('supplied-r1-records-exact',r1['records']==supplied['records'])
for record,operation in zip(r2['records'],native['operations']):
 ident=operation['id'];p=packets['mixed:'+ident.removeprefix('review-') if ident.startswith('review-') else ident];s=v['sources'][p['sourceIndex']];q=json.loads(operation['requestJson']);documents={d['document']['id']:d for d in s['closure']['documents']};seen=set()
 for module in q['modules']:
  pin=module['pin'];d=documents[pin['documentId']];check('core-module:'+ident,sha(module['documentJson'].encode())==pin['sha256'] and json.loads(module['documentJson'])==d['document'] and pin['revision']==d['revision'] and pin['umfVersion']==d['document']['umf']);seen.add(pin['documentId']);check('selected-modules:'+ident,set(module['selectedModuleIds'])=={x['id'] for x in d['document']['modules']})
 check('closure-complete:'+ident,seen==set(documents))
 for role in ['policy','catalog','ontology','owner']:
  opaque=[x for x in q['opaqueSources'] if x['role']==role];check('opaque:'+ident+':'+role,len(opaque)==1 and json.loads(opaque[0]['utf8'])==s[role])
 check('exact-evaluation:'+ident,record['evaluationReply']['result']==p['result'])
 check('actual-driver-retained:'+ident,record['actualDriverRows']==operation['actualDriverRows'])
 check('native-parent-and-child-lifecycle:'+ident,record['parentHeldThroughInspection'] and record['childCleanupConfirmed'])
 if record['inspectionInvoked']:
  check('reconstructed-native-batch:'+ident,record['reconstructedBatch']==operation['nativeBatch'])
  if record['outcome']=='validated-data-only':
   check('native-equals-original:'+ident,record['reconstructedBatch']==p['result']['batch']);reply=record['inspectionReply'];check('no-authority:'+ident,reply['complete'] is False and reply['authority'] is False)
  else:check('source-invalid-is-cleared:'+ident,record['outcome']=='whole-v2-refusal' and record['inspectionReply']['kind']=='refused' and 'result' not in record['inspectionReply'])
 else:check('structural-refusal-not-inspected:'+ident,record['outcome']=='structural-refusal')
# Preserve later owner corrected normal replay separately, without overwriting original packet.
provided=Path('/private/tmp/umf-held-native-replay-cli-r3-20261016/receipt.json')
if provided.exists():
 dest=R/'supplemental-r2';dest.mkdir();shutil.copyfile(provided,dest/'owner-receipt.json');log=Path('/private/tmp/umf-held-native-replay-cli-r3-20261016.log')
 if log.exists():shutil.copyfile(log,dest/'owner.log')
 rr=json.loads(provided.read_bytes());check('later-owner-r2-records-exact',rr['records']==r2['records']);check('later-owner-r2-script-pin',rr['replayScriptSha256']==sha(final.read_bytes()))
result={'status':'passed','checks':len(checks),'items':checks,'sourcePins':len(bm['sourcePins']),'nativeRecordOutcomes':dict(collections.Counter(r['outcome'] for r in r2['records'])),'scope':'Exact file/archive/module/current-endpoint and original captured-record correspondence; no fresh SQL or native source/caller/current-cut/guarded release, no held-file/ABA or hermetic runtime claim.'}
(R/'custody-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'passed','checks':len(checks)}))
