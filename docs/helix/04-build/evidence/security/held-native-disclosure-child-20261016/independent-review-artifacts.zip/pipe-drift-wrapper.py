import importlib.machinery,sys,runpy
from pathlib import Path
original=importlib.machinery.SourceFileLoader.exec_module
def execute(self,module):
 result=original(self,module)
 if Path(getattr(module,'__file__','')).resolve()==Path('/private/tmp/umf-held-native-disclosure-astra-20261016/pipe-drift-source.py').resolve():
  p=Path(module.__file__);p.write_bytes(p.read_bytes()+b'\n# reviewer post-import drift\n')
 return result
importlib.machinery.SourceFileLoader.exec_module=execute
sys.argv=sys.argv[1:]
runpy.run_path(sys.argv[0],run_name='__main__')
