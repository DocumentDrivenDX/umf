from pathlib import Path
import subprocess,json,hashlib,shutil,sys
R=Path(__file__).parent;F=R/'frozen';mode=sys.argv[1];pipe=F/'evidence/15-_current_query_pipe.py';script=R/'reconstructed/tools/security/replay-held-native-disclosure.py';output=R/('cli-'+mode)
if mode=='pipe-drift':
 pipe=R/'pipe-drift-source.py';shutil.copyfile(F/'evidence/15-_current_query_pipe.py',pipe)
wrapper=R/'pipe-drift-wrapper.py'
if mode=='pipe-drift':
 wrapper.write_text("import importlib.machinery,sys,runpy\nfrom pathlib import Path\noriginal=importlib.machinery.SourceFileLoader.exec_module\ndef execute(self,module):\n result=original(self,module)\n if Path(getattr(module,'__file__','')).resolve()==Path("+repr(str(pipe))+ ").resolve():\n  p=Path(module.__file__);p.write_bytes(p.read_bytes()+b'\\n# reviewer post-import drift\\n')\n return result\nimportlib.machinery.SourceFileLoader.exec_module=execute\nsys.argv=sys.argv[1:]\nrunpy.run_path(sys.argv[0],run_name='__main__')\n")
args=['/private/tmp/truss-practical-performance-env/bin/python']+([str(wrapper)] if mode=='pipe-drift' else [])+[str(script),'--umf-root',str(R/'reconstructed'),'--bundle-root',str(R/'rebuilt-bundle'),'--wheel',str(F/'evidence/14-weft_sql-0.4.37.dev0-cp39-abi3-macosx_11_0_arm64.whl'),'--wheel-manifest',str(F/'evidence/13-presence-bridge-review-manifest-r1.json'),'--pipe-source',str(pipe),'--native-receipt',str(F/'evidence/16-receipt.json'),'--output',str(output),'--bun','/opt/homebrew/bin/bun']
with (R/('cli-'+mode+'.log')).open('wb') as log:
 run=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=180)
result={'mode':mode,'command':args,'exitCode':run.returncode,'pipeSourceSha256':hashlib.sha256(pipe.read_bytes()).hexdigest(),'receiptIssued':(output/'receipt.json').is_file()}
if result['receiptIssued']:
 r=json.loads((output/'receipt.json').read_bytes());result.update(status=r['status'],records=len(r['records']),reportedPipeSha256=r['trussPipeSha256'])
(R/('cli-'+mode+'-execution.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
