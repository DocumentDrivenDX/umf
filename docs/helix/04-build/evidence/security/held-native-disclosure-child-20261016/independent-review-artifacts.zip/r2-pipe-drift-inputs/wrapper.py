import builtins,sys,runpy
from pathlib import Path
original=builtins.compile
def changed(source,filename,mode,*args,**kwargs):
 result=original(source,filename,mode,*args,**kwargs)
 if str(filename)=='/private/tmp/umf-held-native-disclosure-astra-20261016/r2-pipe-drift-inputs/pipe.py':
  p=Path('/private/tmp/umf-held-native-disclosure-astra-20261016/r2-pipe-drift-inputs/pipe.py');p.write_bytes(p.read_bytes()+b'\n')
 return result
builtins.compile=changed
sys.argv=sys.argv[1:]
runpy.run_path(sys.argv[0],run_name='__main__')
