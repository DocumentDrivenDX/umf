from pathlib import Path
import json,hashlib,struct,subprocess,copy,time
R=Path(__file__).parent;F=R/'frozen';B=R/'rebuilt-bundle/current-native-disclosure-child.mjs';V='umf.security.private-disclosure-child/0.2-candidate';sha=lambda b:hashlib.sha256(b).hexdigest();D=R/'process-raw';D.mkdir()
vectors=json.loads((F/'overlay/tests/security/protection/native-disclosure-child-vectors.json').read_bytes());packets=vectors['packets'];sources=vectors['sources'];checks=[]
def frame(x):
 b=json.dumps(x,ensure_ascii=True,separators=(',',':')).encode();return rawframe(b)
def rawframe(b):return struct.pack('>I',len(b))+b
def decode(b):
 out=[]
 while b:
  assert len(b)>=4;n=struct.unpack('>I',b[:4])[0];assert 0<n<=16777216 and len(b)>=n+4;out.append(json.loads(b[4:n+4]));b=b[n+4:]
 return out
def messages(p):
 s=sources[p['sourceIndex']];i={'version':V,'kind':'initialize','requestId':'init','sources':{**{k:s[k] for k in ['policy','catalog','closure','ontology']},'associationBindings':[]},'owner':s['owner'],'selection':p['selection']};a=frame(i);h=sha(a);e={'version':V,'kind':'evaluate-disclosure','requestId':'eval','sourceReceipt':h,'cut':p['cut']};b=frame(e);n={'version':V,'kind':'inspect-native-disclosure','requestId':'inspect','sourceReceipt':h,'batch':p['result']['batch']};return a,b,n
byid={p['id']:p for p in packets}
def run(name,data,code,kinds,validate=None):
 st=time.monotonic();r=subprocess.run(['/opt/homebrew/bin/bun',str(B)],input=data,capture_output=True,timeout=25,cwd=R,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'});out=decode(r.stdout);prefix=D/name
 prefix.with_suffix('.stdin').write_bytes(data);prefix.with_suffix('.stdout').write_bytes(r.stdout);prefix.with_suffix('.stderr').write_bytes(r.stderr)
 assert r.returncode==code,(name,r.returncode,r.stderr);assert r.stderr==(b'UMF_NATIVE_DISCLOSURE_CHILD_REFUSED\n' if code else b''),(name,r.stderr);assert [x['kind'] for x in out]==kinds,(name,out)
 if validate:validate(out)
 checks.append({'id':name,'passed':True,'exitCode':r.returncode,'replyKinds':kinds,'inputSha256':sha(data),'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr),'seconds':time.monotonic()-st});return out
for index,p in enumerate(packets):
 a,b,n=messages(p);c=frame(n);rendered=p['result']['status']=='rendered'
 def validate(out):
  assert out[1]=={'version':V,'kind':'disclosure-evaluated','requestId':'eval','sourceReceipt':sha(a),'result':p['result']}
  if rendered:assert out[2]=={'version':V,'kind':'native-disclosure-inspected','requestId':'inspect','sourceReceipt':sha(a),'evaluationFrameSha256':sha(b),'inspectionFrameSha256':sha(c),'status':'validated-disclosure','complete':False,'authority':False}
 run('vector-'+str(index).zfill(3),a+b+(c if rendered else b''),0 if rendered else 2,['initialized','disclosure-evaluated']+(['native-disclosure-inspected'] if rendered else []),validate)
# Exact source traceability, including each repeated source value, cut, selection and full result.
original=json.loads((F/'evidence/17-inputs.json').read_bytes())['packets'];mixed=json.loads((F/'evidence/18-independent-controls.json').read_bytes())['observations'];originals={p['id']:p for p in original};originals.update({'mixed:'+x['id']:{**x['packet'],'result':x['result']} for x in mixed})
assert set(originals)==set(byid)
for p in packets:
 q=originals[p['id']];assert sources[p['sourceIndex']]==q['source'];assert all(p[k]==q[k] for k in ['cut','selection','result'])
# Initial/evaluation lifecycle and closed inspection envelope.
p=byid['allowed:transformed-null'];a,b,n=messages(p);c=frame(n)
for name,data,kinds in [('empty',b'',[]),('initial-only',a,['initialized']),('evaluation-only',a+b,['initialized','disclosure-evaluated']),('inspection-early',a+c,['initialized','refused']),('evaluation-twice',a+b+b,['initialized','disclosure-evaluated','refused']),('inspection-twice',a+b+c+c,['initialized','disclosure-evaluated','native-disclosure-inspected']),('inspection-before-initial',c,[])]:run('lifecycle-'+name,data,2,kinds)
for k in n:
 x=copy.deepcopy(n);del x[k];run('inspection-missing-'+k,a+b+frame(x),2,['initialized','disclosure-evaluated']+([] if k=='requestId' else ['refused']))
for k in ['owner','selection','cut','source','result','resources','complete','authority','extra']:
 x=copy.deepcopy(n);x[k]={'private':'must-not-leak'};run('inspection-extra-'+k,a+b+frame(x),2,['initialized','disclosure-evaluated','refused'])
for k,val in [('requestId','init'),('requestId','eval'),('requestId','bad id'),('requestId',''),('requestId','x'*65),('version','umf.security.private-disclosure-child/0.1-candidate'),('sourceReceipt','0'*64),('kind','evaluate-disclosure')]:
 x=copy.deepcopy(n);x[k]=val;parseable=k!='requestId' or val in ['init','eval'];run('inspection-mutant-'+str(len(checks)),a+b+frame(x),2,['initialized','disclosure-evaluated']+(['refused'] if parseable else []))
# Tagged cells/source metadata/whole batch identity.
for name,ident in [('value','allowed:string'),('present-to-absent','allowed:null'),('absent-to-null','allowed:absent'),('missing-row','allowed:string'),('duplicate-row','allowed:string'),('extra-denied-row','revoked:string'),('reordered-rows','mixed:mixed-string'),('withheld-to-absent','allowed:withheld')]:
 pp=byid[ident];aa,bb,nn=messages(pp);batch=nn['batch']=copy.deepcopy(nn['batch'])
 if name=='value':batch['rows'][0][0]['value']={'string':'changed'}
 elif name=='present-to-absent' or name=='withheld-to-absent':batch['rows'][0][0]={'disposition':'absent'}
 elif name=='absent-to-null':batch['rows'][0][0]={'disposition':'original','value':None}
 elif name=='missing-row':batch['rows']=[]
 elif name=='duplicate-row':batch['rows'].append(copy.deepcopy(batch['rows'][0]))
 elif name=='extra-denied-row':batch['rows']=[[{'disposition':'original','value':{'string':'invented'}}]]
 elif name=='reordered-rows':batch['rows'].reverse()
 run('held-substitution-'+name,aa+bb+frame(nn),2,['initialized','disclosure-evaluated','refused'])
for mode in ['source-policy','source-catalog','domains','column','storage','transform','domain','occurrence','payload','field-order','extra-cell']:
 x=copy.deepcopy(n);batch=x['batch'];cell=batch['rows'][0][0]
 if mode=='source-policy':batch['policy']['revision']='changed'
 elif mode=='source-catalog':batch['protection']['revision']='changed'
 elif mode=='domains':batch['domains']=[]
 elif mode=='column':batch['columns'][0]['field']['elementId']='salary'
 elif mode=='storage':batch['columns'][0]['storageEffect']='canonical'
 elif mode=='transform':cell['transform']['version']='changed'
 elif mode=='domain':cell['outputDomain']['elementId']='salary'
 elif mode=='occurrence':cell['selection']={'ruleIndex':999,'disclosureIndex':999}
 elif mode=='payload':del cell['value']
 elif mode=='field-order':batch['columns'].append(copy.deepcopy(batch['columns'][0]))
 elif mode=='extra-cell':cell['extra']=True
 run('metadata-'+mode,a+b+frame(x),2,['initialized','disclosure-evaluated','refused'])
# Scanner refuses duplicate decoded keys, invalid Unicode and non-interoperable numeric spelling.
raw=frame(n)[4:]
cases={'duplicate':raw.replace(b'"batch":',b'"batch":null,"batch":'),'escaped-duplicate':raw.replace(b'"batch":',b'"ba\\u0074ch":null,"batch":'),'surrogate-value':raw.replace(b'"requestId":"inspect"',b'"requestId":"\\ud800"'),'surrogate-key':raw.replace(b'"batch":',b'"\\udfff":0,"batch":'),'utf8-overlong':b'\xc0\xaf','utf8-surrogate':b'\xed\xa0\x80','utf8-too-high':b'\xf4\x90\x80\x80','bom':b'\xef\xbb\xbf'+raw,'trailing-json':raw+b'{}'}
for token in ['-0','-0e10','9007199254740993','1e309','1e-999','0.10000000000000001']:
 cases['number-'+str(len(cases))]=raw.replace(b'"ruleIndex":0',('"ruleIndex":'+token).encode())
for name,body in cases.items():run('parser-'+name,a+b+rawframe(body),2,['initialized','disclosure-evaluated'])
# Semantically equal JSON syntax/key ordering is allowed, while receipt hashes bind exact full frames.
def reverse_keys(x):
 if isinstance(x,dict):return {k:reverse_keys(x[k]) for k in reversed(x)}
 if isinstance(x,list):return [reverse_keys(v) for v in x]
 return x
for name,body in [('reversed-object-keys',json.dumps(reverse_keys(n),separators=(',',':')).encode()),('exact-exponents',raw.replace(b'"ruleIndex":0',b'"ruleIndex":0e123').replace(b'"disclosureIndex":1',b'"disclosureIndex":1.000e0'))]:
 cc=rawframe(body);out=run('canonical-'+name,a+b+cc,0,['initialized','disclosure-evaluated','native-disclosure-inspected']);assert out[-1]['inspectionFrameSha256']==sha(cc) and out[-1]['evaluationFrameSha256']==sha(b)
# Actual process 16MiB inspection endpoint, larger than the old standalone pipe's4MiB send limit.
for size in [16777216,16777217]:
 body=b' '*(size-len(raw))+raw;cc=rawframe(body);out=run('inspection-bytes-'+str(size),a+b+cc,0 if size==16777216 else 2,['initialized','disclosure-evaluated']+(['native-disclosure-inspected'] if size==16777216 else []))
 if size==16777216:assert out[-1]['inspectionFrameSha256']==sha(cc)
for name,tail in [('partial-header',c[:3]),('partial-body',c[:-1]),('zero-length',b'\0'*4),('maximum-u32',b'\xff'*4)]:run('inspection-framing-'+name,a+b+tail,2,['initialized','disclosure-evaluated'])
result={'status':'passed','controls':len(checks),'originalVectors':72,'checks':checks,'scope':'Actual rebuilt child processes, supplied logical facts and exact data inspection only; no SQL/native caller/current-cut/release. Inspection16MiB endpoint exercised directly, not through old4MiB CurrentQueryPipe.'};(R/'process-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'passed','controls':len(checks),'vectors':72}))
