from pathlib import Path
import json,hashlib,subprocess,tarfile,zipfile,shutil
R=Path(__file__).parent;F=R/'frozen';S=R/'reconstructed';S.mkdir();owner=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((F/'manifest.json').read_text())
for p,v in m['files'].items():assert sha((F/p).read_bytes())==v['sha256'] and (F/p).stat().st_size==v['bytes']
base=m['baseCommit'];roots=['src','spec','tests/security','tools/security','AGENTS.md','.helix.yml','docs/helix/README.md','package.json','bun.lock','tsconfig.json','bunfig.toml','tsconfig.tools.json']
with (R/'base-source.tar').open('wb') as f:subprocess.run(['git','archive',base,*roots],cwd=owner,stdout=f,check=True)
with tarfile.open(R/'base-source.tar') as a:
 for member in a.getmembers():assert not member.name.startswith('/') and '..' not in Path(member.name).parts and not member.issym() and not member.islnk()
 a.extractall(S)
with zipfile.ZipFile(F/'selected-source-inputs.zip') as z:
 for n in z.namelist():assert not n.startswith('/') and '..' not in Path(n).parts
 z.extractall(S)
for p in (F/'overlay').rglob('*'):
 if p.is_file():q=S/p.relative_to(F/'overlay');q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
bm=json.loads((F/'bundle/manifest.json').read_text())
for n in bm['notices']:
 for p in (F/'bundle/notices'/n['name']).iterdir():q=S/'node_modules'/n['name']/p.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for p,h in bm['sourcePins'].items():assert sha((S/p).read_bytes())==h and sha((owner/p).read_bytes())==h
source={str(p.relative_to(S)):sha(p.read_bytes()) for p in S.rglob('*') if p.is_file()}
(R/'source-before.json').write_text(json.dumps(source,indent=2)+'\n')
with zipfile.ZipFile(R/'reconstructed-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(source):z.write(S/p,p)
print(json.dumps({'files':len(source),'selectedPins':len(bm['sourcePins']),'base':base}))
