"""Captured original owner catalog staging on an isolated native transaction."""
import hashlib,json,os,re,select,subprocess,tempfile,time,uuid,importlib.metadata
from pathlib import Path
from urllib.parse import urlparse,parse_qs
import pg8000.native,pgserver
ROOT=Path(__file__).resolve().parents[2]
if Path.cwd()!=ROOT:raise SystemExit('Exact root invocation required')
T=Path('/private/tmp/truss-security-main-integration');O=Path('/private/tmp/truss-umf-runtime-LmpSsH')
IR=ROOT/'docs/helix/04-build/evidence/security/weft-handoff.json'
components=['operation-admission','operation-commit-barrier','catalog-generation-observer','catalog-document-batch','catalog-lineage-producer','catalog-source-integrity','catalog-type-match','catalog-type-stage','catalog-property-match','catalog-property-stage','catalog-key-match','catalog-key-stage','catalog-key-batch','catalog-relationship-match','catalog-relationship-stage','catalog-report-documents','catalog-new-inventory','catalog-observation-recheck','catalog-input-custody','catalog-prestate-capture','catalog-new-prestate-parity','catalog-new-counts','catalog-provisional-empty','catalog-report-immutability','catalog-original-context','operation-generation-observer','canonical-string-bytes','canonical-tree-bytes','object-key-stage']
layout=T/'docs/helix/04-build/evidence/qualified-property-layout-0.15.owner-export.sql'
paths=[Path(__file__),ROOT/'tools/security/truss-owner-catalog-stage.ts',IR,layout,O/'producer.js',O/'producer-manifest.json',ROOT/'docs/helix/02-design/contracts/CONTRACT-040-core-ideals.md',ROOT/'docs/helix/02-design/contracts/CONTRACT-063-security-enforcement.md']
paths += [T/f'packages/postgresql/native/{n}.sql' for n in components]
for directory in ['packages/umf-bun/src','packages/postgresql/src','docs/helix/02-design/contracts/bindings']:
 paths += [p for p in (T/directory).rglob('*') if p.is_file() and p.suffix in ['.ts','.json']]
paths += [T/'docs/helix/02-design/contracts/acceptance-input-v0.1.schema.json']
frozen={str(p):p.read_bytes() for p in paths};sha=lambda b:hashlib.sha256(b).hexdigest();pins={p:sha(b) for p,b in frozen.items()}
out=ROOT/'docs/helix/04-build/evidence/security/truss-owner-catalog-stage'/str(uuid.uuid4());out.mkdir(parents=True)
for p,b in frozen.items():
 dest=out/'preimages'/p.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
bridge=out/'frozen';bridge.mkdir()
for p,b in frozen.items():
 if p.startswith(str(T)+'/'):dest=bridge/'truss'/Path(p).relative_to(T)
 elif p.startswith(str(O)+'/'):dest=bridge/'owner'/Path(p).relative_to(O)
 elif p.endswith('truss-owner-catalog-stage.ts'):dest=bridge/'bridge.ts'
 else:continue
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
checks=[];server=None;temporary=None;c=None;child=None;phase='runtime';query_log=[]
def check(name,expected,observed):
 checks.append({'id':name,'expected':expected,'observed':observed})
 if expected!=observed:raise ValueError(name)
try:
 check('pgserver-version','0.1.4+truss.pg16.15',importlib.metadata.version('pgserver'));check('pg8000-version','1.31.5',importlib.metadata.version('pg8000'))
 temporary=tempfile.TemporaryDirectory(prefix='original-owner-catalog-');server=pgserver.get_server(Path(temporary.name)/'data',cleanup_mode='delete')
 uri=urlparse(server.get_uri());host=parse_qs(uri.query).get('host',[uri.hostname])[0];port=uri.port or 5432
 c=pg8000.native.Connection(user='postgres',database=uri.path.lstrip('/'),unix_sock=str(Path(host)/f'.s.PGSQL.{port}'),ssl_context=False,timeout=5)
 check('postgresql16.15',[['160015']],c.run('SHOW server_version_num'))
 phase='layout';c.run(frozen[str(layout)].decode())
 for name in components:phase='install:'+name;c.run(frozen[str(T/f'packages/postgresql/native/{name}.sql')].decode())
 phase='original-stage';c.run('BEGIN')
 artifact=next(a for a in json.loads(frozen[str(IR)])['artifacts'] if a['id']=='natural-count-self-join')
 child=subprocess.Popen(['bun',str(bridge/'bridge.ts')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 init={'artifact':artifact,'fixture':json.loads(frozen[str(T/'docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json')]),'ownerDirectory':str(bridge/'owner'),'dependenciesPackage':str(ROOT/'package.json')}
 child.stdin.write((json.dumps(init)+'\n').encode());child.stdin.flush();buffer=b'';deadline=time.monotonic()+45;packet=None
 while packet is None:
  if time.monotonic()>deadline:raise TimeoutError('Bounded stage deadline')
  ready,_,_=select.select([child.stdout,child.stderr],[],[],min(1,deadline-time.monotonic()))
  for stream in ready:
   data=os.read(stream.fileno(),65536)
   if stream is child.stderr:
    if data:raise ValueError('Unexpected bridge stderr')
    continue
   if not data:raise ValueError('Bridge terminated without result')
   buffer+=data
   if len(buffer)>1048576:raise ValueError('Bounded bridge output')
   while b'\n' in buffer:
    line,buffer=buffer.split(b'\n',1);message=json.loads(line)
    if message['kind']!='query':packet=message;break
    sql=message['sql'];params=message['parameters'];query_log.append({'sql':sql,'parametersSha256':sha(json.dumps(params,separators=(',',':')).encode())})
    if len(query_log)>64 or not isinstance(sql,str) or len(sql)>4096 or not all(isinstance(v,str) for v in params):raise ValueError('Bounded original query')
    try:
     converted=re.sub(r'\$(\d+)',lambda m:':p'+m[1],sql);rows=c.run(converted,**{'p'+str(i+1):v for i,v in enumerate(params)})
     cols=[column['name'] for column in c.columns] if c.columns else []
     response={'rows':[{name:str(v) for name,v in zip(cols,row)} for row in (rows or [])]}
    except pg8000.exceptions.DatabaseError as error:response={'error':error.args[0].get('C','unknown')}
    child.stdin.write((json.dumps(response)+'\n').encode());child.stdin.flush()
 if packet.get('kind')!='result':raise ValueError(packet.get('reason','Original staging unavailable'))
 child.stdin.close();check('bridge-exit',0,child.wait(timeout=5))
 check('original-archive-bridge',artifact['request']['modules'][0]['documentJson'],packet['originalText'])
 check('five-records',5,len(packet['staged']['types']));check('nine-owned-fields',9,len(packet['staged']['properties']));check('five-keys',5,len(packet['staged']['keys']));check('no-invented-core-relationships',0,len(packet['staged']['relationships']))
 check('native-non-primary-keys',[[5,0]],c.run('SELECT count(*),count(*) FILTER(WHERE is_primary) FROM truss.key_def'))
 check('native-original-archive',[[packet['originalText']]],c.run('SELECT document::text FROM truss.schema_doc WHERE doc_id=\'domain\''))
 c.run('ROLLBACK');check('rollback-catalog',[[0,0,0,0]],c.run('SELECT (SELECT count(*) FROM truss.type_def),(SELECT count(*) FROM truss.prop_def),(SELECT count(*) FROM truss.key_def),(SELECT count(*) FROM truss.schema_doc)'))
 phase='source-current';check('source-pins-current',True,all(Path(p).read_bytes()==b for p,b in frozen.items()))
 receipt={'status':'pass','observations':checks,'sourceSha256':pins,'queryLog':query_log,'result':packet,'scope':'Installer-only original owner preparation and provisional native catalog staging, rollback-only','acceptancePromoted':False,'limitations':['Synthetic operation admission artifacts; no authenticated owner/binding/current cut','No relationship binding or revision publication','RPC adapter, not whole installed public runtime/driver','Ajv dependency closure not yet captured; no dependency-complete preparation qualification']}
 (out/'native.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':'pass','receipt':str(out/'native.json'),'observations':len(checks)}))
except Exception as error:
 (out/'failure.json').write_text(json.dumps({'status':'fail','phase':phase,'reason':str(error),'observations':checks,'sourceSha256':pins,'queryLog':query_log},indent=2)+'\n');print(json.dumps({'status':'fail','receipt':str(out/'failure.json'),'phase':phase,'reason':str(error)}));raise
finally:
 if child and child.poll() is None:child.kill();child.wait(timeout=5)
 if c:
  try:c.close()
  except Exception:pass
 if server:server.cleanup()
 if temporary:temporary.cleanup()
