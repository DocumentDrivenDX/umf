from pathlib import Path
import hashlib,io,json,subprocess,tarfile,zipfile
p=Path(__file__).resolve().parent
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf')
run=Path('/private/tmp/truss-protected-query-ci-root-replay-20261015')
truss=Path('/private/tmp/truss-main-integration-20261010')
wheel=Path('/private/tmp/weft-release033-ci-arm/weft_sql-0.4.33-cp39-abi3-macosx_11_0_arm64.whl')
sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((run/'receipt.json').read_text());pins=r['trackedInputs'];checks=[]
def check(name,result,count=None):
 checks.append({'name':name,'passed':bool(result),'count':count});assert result,name
check('expected-exact-commit',r['sourceCommit']=='edebb67f5f56d6c54ac879246c0c035e0a39638a')
check('retained-receipt-four-tests-passed',r['status']=='passed' and r['tests']==4)
harness='tools/security/truss-protected-query-ci-replay.py'
check('harness-current-exact',sha((root/harness).read_bytes())==r['harnessSha256'])
check('input-zip-exact',sha((run/'original-inputs.zip').read_bytes())==r['archiveSha256'])
with zipfile.ZipFile(run/'original-inputs.zip') as z:
 check('exact-unique-archive-population',len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(pins),len(pins))
 check('archived-input-digests',all(sha(z.read(k))==v for k,v in pins.items()),len(pins))
check('extracted-input-digests',all(sha((run/'original'/k).read_bytes())==v for k,v in pins.items()),len(pins))
paths=['packages/python/src','packages/python/tests','packages/postgresql','docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json']
data=subprocess.run(['git','-C',str(truss),'archive',r['sourceCommit'],*paths],check=True,stdout=subprocess.PIPE).stdout
with tarfile.open(fileobj=io.BytesIO(data)) as t:
 actual={m.name:sha(t.extractfile(m).read()) for m in t.getmembers() if m.isfile()}
check('exact-fixed-commit-population-and-bytes',actual==pins,len(actual))
mods=r['loadedTrussModules']
check('every-loaded-truss-module-committed-and-exact',all(pins.get(v['path'])==v['sha256'] and (run/'original'/v['path']).resolve().is_relative_to((run/'original').resolve()) for v in mods.values()),len(mods))
check('exact-original-child',pins['packages/python/src/truss/_current_query_owner/current-query-child.mjs']==r['originalChildSha256']=='36e2c63fb0d942c9b94141f1753bcd9b56aad9e32dec5aa1a9ee27aabc674248')
check('exact-weft-wheel',sha(wheel.read_bytes())==r['weftWheelSha256']=='dfe0fa7f8286758c6e1f24e417e62e11f252dce9896ecf99800f5151b49c9fb3')
with zipfile.ZipFile(wheel) as z:
 selected={k:sha(z.read(k)) for k in z.namelist() if Path(k).suffix in ('.so','.py')}
check('exact-wheel-python-and-native-population',selected==r['weftLoadedFiles'],len(selected))
check('extracted-weft-files-exact',all(sha((run/'original-weft'/k).read_bytes())==v for k,v in selected.items()),len(selected))
check('selected-native-postgres-exact',sha(Path('/private/tmp/truss-clean-install-20261013/lib/python3.12/site-packages/pgserver/pginstall/bin/postgres').read_bytes())==r['postgresBinarySha256'])
check('native-profile-receipt',r['nativeObservation']['serverVersion']=='18.6' and r['pgserverDistribution']=='18.6.1' and r['libpqVersion']==180006)
check('retained-owned-cleanup',all(r[k] is True for k in ('originalRuntimeStopped','leaseReleased','testDirectoryAbsent')) and r['nativeObservation']['postmasterAbsent'] is True)
check('original-data-directory-still-absent',not Path(r['nativeObservation']['dataDirectory']).exists())
check('unittest-log-exact-success', (run/'unittest.log').read_text().count(' ... ok\n')==4 and 'Ran 4 tests in ' in (run/'unittest.log').read_text() and (run/'unittest.log').read_text().endswith('\nOK\n'))
check('no-acceptance-promotion',r['acceptanceCasesPromoted']==[])

old=(root/'tools/security/truss-protected-query-replay.py').read_text()
new=(root/harness).read_text()
expected=old.replace('Replay the committed public ordinary-caller query with original UMF/Weft.', 'Replay the committed public ordinary-caller query with original UMF and the selected standard-feature CI Weft wheel.').replace('3e9bd6f6ac42c944dd12e36ce3ea0481ca116a3ab639ef2c2ede933751ff17a8','dfe0fa7f8286758c6e1f24e417e62e11f252dce9896ecf99800f5151b49c9fb3').replace('6b8af80b8d6da4216b1338e79e869faee4f5cd25af8500034368ef709005f523','60b977a1c8b8a355b86be40375aab209ed894b172dbed972498721eab8bbddae').replace('Not all COUNT/graph/raw-table/concurrency/actor/backend cases or production release.', 'External runtime routine attachments are refused before activation. The CI Weft0.4.33 wheel is selected only for ABI2; aggregate APIs are not admitted. Not all COUNT/graph/raw-table/concurrency/actor/backend cases or production release.')
check('only-reviewed-cohort-and-scope-harness-delta',expected==new)
check('previous-reviewed-harness-unchanged',sha(old.encode())=='b9876f3692ef84640ddf77ebd6b5a2f395a0d8e30f05b055f36205420d2407bd')
check('strict-no-skip-no-expected-failure-completion-retained','and not result.skipped and not result.expectedFailures and not result.unexpectedSuccesses' in new)

selected_sources=['packages/python/src/truss/'+s for s in ['catalog_runtime.py','current_query.py','_current_query_runtime.py','_current_query_evaluation.py','_current_query_stage.py','_current_query_originals.py','_current_query_sources.py','_current_query_subjects.py','_current_query_facts.py','_current_query_computation.py','_current_query_pipe.py','local_runtime.py','_current_query_protection.py']]+['packages/python/tests/'+s for s in ['test_current_query_runtime_native.py','test_current_query_full_sources_native.py','test_current_query_subjects_native.py','test_catalog_runtime_native.py','fixtures/current-query-weft-request.json']]
additional=[run/'receipt.json',run/'unittest.log']
methods=['test_all_denied_population_returns_empty_rows','test_empty_population_returns_empty_rows','test_protected_activation_closes_legacy_data_facades','test_public_masked_projection_with_authorized_exact_raw_predicate']
check('exact-original-four-method-inventory',r['expectedTestMethods']==methods and all(n+' (test_current_query_runtime_native.CurrentQueryRuntimeNativeTests.'+n+') ... ok' in (run/'unittest.log').read_text() for n in methods))
casepath='docs/helix/03-test/security/cases.json';casebytes=(root/casepath).read_bytes();committed=subprocess.check_output(['git','-C',str(root),'show','HEAD:'+casepath]);check('original-case-inventory-unchanged',casebytes==committed)
cases=json.loads(casebytes)['cases'];check('all-original-truss-cases-retained',sum(c['id'].startswith('truss.') for c in cases)==30 and len(cases)==158)
record={'sourceCommit':r['sourceCommit'],'harness':{harness:r['harnessSha256']},'selectedOriginals':{k:pins[k] for k in selected_sources},'referencedEvidence':{str(f):sha(f.read_bytes()) for f in additional},'inputArchive':{'path':str(run/'original-inputs.zip'),'sha256':r['archiveSha256']},'wheel':{'path':str(wheel),'sha256':r['weftWheelSha256']},'extractedWeft':selected,'procedurePins':{k:sha((root/k).read_bytes()) for k in [casepath,'docs/helix/03-test/security/truss.md']}}
(p/'source-pins.json').write_text(json.dumps(record,indent=2)+'\n')
result={'status':'passed','checks':checks,'count':len(checks),'nativeExecutionPerformedByReviewer':False,'scope':'Read-only source/archive/wheel/selected-module correspondence and retained native evidence; no native DB, child or cloud execution.'}
(p/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'passed','checks':len(checks),'committedInputs':len(pins),'loadedTrussModules':len(mods),'weftPythonNativeFiles':len(selected)}))
