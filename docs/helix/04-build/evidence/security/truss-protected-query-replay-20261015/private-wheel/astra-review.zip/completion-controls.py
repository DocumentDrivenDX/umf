import ast,hashlib,io,json,pathlib,unittest
p=pathlib.Path(__file__).resolve().parent
src=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf/tools/security/truss-protected-query-replay.py').read_text()
(p/'completion-guard-source.py').write_text(src)
module=ast.parse(src)
completion=next(n for n in module.body if isinstance(n,ast.Assert) and 'result.wasSuccessful()' in ast.unparse(n))
code=compile(ast.fix_missing_locations(ast.Module(body=[completion],type_ignores=[])),'original-completion-assert','exec')
names=['test_all_denied_population_returns_empty_rows','test_empty_population_returns_empty_rows','test_protected_activation_closes_legacy_data_facades','test_public_masked_projection_with_authorized_exact_raw_predicate']
results=[]
for mode in ['all-pass','one-skip','one-expected-failure','one-failure']:
 def passed(self):pass
 methods={name:passed for name in names}
 if mode=='one-skip':methods[names[0]]=unittest.skip('diagnostic control')(lambda self:None)
 if mode=='one-expected-failure':methods[names[0]]=unittest.expectedFailure(lambda self:self.fail('diagnostic control'))
 if mode=='one-failure':methods[names[0]]=lambda self:self.fail('diagnostic control')
 selected=type('SelectedFourMethods',(unittest.TestCase,),methods)
 log=io.StringIO();result=unittest.TextTestRunner(stream=log).run(unittest.defaultTestLoader.loadTestsFromTestCase(selected))
 try:exec(code,{'result':result,'log':log});accepted=True
 except AssertionError:accepted=False
 results.append({'control':mode,'testsRun':result.testsRun,'skipped':len(result.skipped),'expectedFailures':len(result.expectedFailures),'originalCompletionAssertAccepted':accepted})
(p/'completion-controls.json').write_text(json.dumps({'sourceSha256':hashlib.sha256(src.encode()).hexdigest(),'scope':'Exact original completion assertion with finite unittest outcomes; no native database started or native workflow simulated.','controls':results},indent=2)+'\n')
print(json.dumps(results))
