import pathlib,json,hashlib,zipfile,subprocess,shutil
R=pathlib.Path('/private/tmp/umf-canonical-disclosure-selection-astra-20261016');F=R/'frozen';E=F/'docs/helix/04-build/evidence/security/disclosure-selection-20261016';S=R/'reconstructed';S.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def check(name,v):
 checks.append({'id':name,'passed':bool(v)});assert v,name
z=zipfile.ZipFile(E/'browser-inputs.zip');snap=json.loads(z.read([n for n in z.namelist() if n.endswith('snapshot.json')][0]));rec=json.loads((E/'browser.json').read_text());check('all104sourcepins',len(snap['sources'])==104 and set(snap['sources'])==set(rec['selectedSourceDigests']))
for n,t in snap['sources'].items():
 check('source:'+n,h(t.encode())==rec['selectedSourceDigests'][n]);p=S/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.encode())
 if (F/n).exists():check('outer:'+n,(F/n).read_bytes()==p.read_bytes())
check('bundle-sha',h(z.read([n for n in z.namelist() if n.endswith('.js')][0]))==rec['bundleSha256']);check('owner42pass',rec['controls']==42 and len(rec['observations'])==42 and all(x['passed'] for x in rec['observations']));check('owner-browser-clean',rec['sourcesUnchanged'] and not rec['pageErrors'] and not rec['externalRequests'])
repo='/Users/erik/.codex/worktrees/security-main-integration/umf';base=subprocess.check_output(['git','-C',repo,'rev-parse','80ca3635']);prior=subprocess.check_output(['git','-C',repo,'show','80ca3635:src/extensions/security/catalog-runtime-candidate.ts']);check('prior-exact-Git-base',prior==(E/'prior-kernel.ts').read_bytes())
changed=[]
for n,t in snap['sources'].items():
 if n.startswith('node_modules/'):continue
 p=subprocess.run(['git','-C',repo,'show','80ca3635:'+n],capture_output=True)
 if p.returncode or p.stdout!=t.encode():changed.append(n)
check('closure-only4intendedchanged',set(changed)=={'src/extensions/security/catalog-runtime-candidate.ts','tests/security/catalog-disclosure-selection-corpus.ts','tests/security/catalog-disclosure-selection.test.ts','tools/security/catalog-disclosure-selection-browser.ts'})
(S/'src/extensions/security/prior-kernel.ts').write_bytes(prior)
for name in ['ajv','yaml','fast-deep-equal','fast-uri','json-schema-traverse','require-from-string']:
 src=pathlib.Path('/private/tmp/umf-native-presence-astra-20261016/reconstructed-r3/node_modules')/name;dst=S/'node_modules'/name
 shutil.copytree(src,dst,dirs_exist_ok=True)
check('installedajvmetadata',h((S/'node_modules/ajv/package.json').read_bytes())==rec['selectedSourceDigests']['node_modules/ajv/package.json'])
z=zipfile.ZipFile(E/'owner-version-browser.zip');storage=json.loads((E/'owner-browser-storage.json').read_text());check('1803archiveexact',set(z.namelist())=={x['archive'] for x in storage['files'].values()} and len(z.namelist())==1803);check('all1803storagepins',all(h(z.read(v['archive']))==v['sha256'] for v in storage['files'].values()))
z=zipfile.ZipFile(E/'baseline-owner-sources.zip');bp=json.loads(z.read('source-pins.json'));print('baseline pins type',type(bp),str(bp)[:300]);print('storage keys',storage.keys())
(R/'custody.json').write_text(json.dumps({'status':'passed','base':base.decode().strip(),'sourceFiles':104,'changedClosureFiles':changed,'checks':checks},indent=2)+'\n')
print('audit',len(checks),'pass')
