import pathlib,json,hashlib,zipfile,subprocess
R=pathlib.Path('/private/tmp/umf-canonical-disclosure-selection-astra-20261016');S=R/'supplemental';F=R/'frozen';repo='/Users/erik/.codex/worktrees/security-main-integration/umf';base='80ca3635';h=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def ck(n,v):checks.append({'id':n,'passed':bool(v)});assert v,n
w=json.loads((S/'gate-witness.json').read_text());old=zipfile.ZipFile(S/'gate-preimages.zip');new=zipfile.ZipFile(S/'gate-current-receipts.zip')
ck('archive-pathsets',set(old.namelist())==set(new.namelist())==set(w['originalTrackedReceiptReplacements']) and len(old.namelist())==21)
for n,p in w['originalTrackedReceiptReplacements'].items():ck('old-receipt:'+n,h(old.read(n))==p['oldSha256']);ck('new-receipt:'+n,h(new.read(n))==p['currentSha256'])
for n,p in w['uncommittedSourceDigests'].items():ck('frozen-source:'+n,h((F/n).read_bytes())==p)
a=json.loads(new.read('docs/helix/04-build/evidence/security/acceptance.json'));ck('acceptance-sha',h(new.read('docs/helix/04-build/evidence/security/acceptance.json'))==w['gateSha256']);ck('45passing',len(a['execution'])==45 and all(x['accepted'] and x['exitCode']==0 and not x['timedOut'] and not x['outputExceeded'] for x in a['execution']));ck('158required34criteria113missing',a['requiredCases']==158 and a['allocatedAcceptanceCriteria']==34 and len(a['errors'])==113 and all('not implemented' in e for e in a['errors']) and a['status']=='failed')
plan=subprocess.check_output(['git','-C',repo,'show',base+':docs/helix/03-test/security/cases.json']);ck('unchanged-plan',h(plan)==a['planDigest']==a['finalPlanDigest']==w['planDigest']);ck('unchanged-gate',a['gateSourceDigests']==a['finalGateSourceDigests']);
for n,p in a['gateSourceDigests'].items():ck('base-gate:'+n,h(subprocess.check_output(['git','-C',repo,'show',base+':'+n]))==p)
fingerprints={}
for e in a['execution']:
 for n,p in e['fingerprints'].items():
  if n in fingerprints:ck('consistent-pin:'+e['id']+':'+n,fingerprints[n]==p)
  fingerprints[n]=p
for n,p in fingerprints.items():
 data=(F/n).read_bytes() if (F/n).is_file() else subprocess.check_output(['git','-C',repo,'show',base+':'+n]);ck('fingerprint:'+n,h(data)==p)
ck('S24S25P04-updated-kernel',all(e['fingerprints'].get('src/extensions/security/catalog-runtime-candidate.ts')==w['uncommittedSourceDigests']['src/extensions/security/catalog-runtime-candidate.ts'] for e in a['execution'] if e['id'] in ['S24','S25','pg-raw.P04']))
i=zipfile.ZipFile(S/'policy-regression-inputs.zip').read('inputs.json');p=json.loads((S/'policy-regression.json').read_text());ck('policy-input-sha',h(i)==p['inputSnapshotSha256']==w['policyRegressionInputSha256']);inputs=json.loads(i)
ck('policy-100pins',len(inputs['sources'])==100 and set(inputs['sources'])==set(inputs['sourcePins']) and all(h(v.encode())==inputs['sourcePins'][n] for n,v in inputs['sources'].items()));ck('policy-kernel-current',inputs['sourcePins']['src/extensions/security/catalog-runtime-candidate.ts']==w['uncommittedSourceDigests']['src/extensions/security/catalog-runtime-candidate.ts']);ck('policy44-188-pass',len(inputs['packets'])==44 and len(p['controls'])==188 and all(c['passed'] for c in p['controls']) and p['status']=='passed')
b=json.loads((S/'evidence-audit.log').read_text());print('audit summary',type(b['checks']),type(b['failed']),str(b['failed'])[:150]);
ck('broaderaudit-qualified',b['checks']==221 and len(b['failed'])==87)
(R/'supplemental-audit.json').write_text(json.dumps({'status':'passed','checks':checks,'distinctGateFingerprintFiles':len(fingerprints),'reviewScope':'Source/receipt custody and stated result correspondence only; no independent native gate rerun.'},indent=2)+'\n');print('supplemental audit passed',len(checks),'checks',len(fingerprints),'fingerprints')
