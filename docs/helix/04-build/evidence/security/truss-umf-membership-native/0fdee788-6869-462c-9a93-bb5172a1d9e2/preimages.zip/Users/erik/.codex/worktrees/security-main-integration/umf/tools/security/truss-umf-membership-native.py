"""Original native cohort joined membership evidence; no complete accepted report."""
import hashlib,json,os,pathlib,subprocess,uuid,zipfile
umf=pathlib.Path(__file__).resolve().parents[2];truss=pathlib.Path('/private/tmp/truss-security-main-integration');container='umf-membership-native-20261011-b64d';container_id='2d575cdd9dd9b23b1f129cd643c1857d20947264ebe82305f157ba63c4bbf4ac'
inspect=json.loads(subprocess.check_output(['docker','inspect',container]))[0];assert inspect['Id']==container_id and inspect['State']['Running'];assert inspect['Config']['Image']=='postgres:17.9'
owners={'TRUSS_UMF_PRODUCER':'/private/tmp/truss-umf-runtime-LmpSsH','TRUSS_UMF_DECLARATION_PRODUCER':'/private/tmp/truss-umf-runtime-vKoRzl','TRUSS_UMF_FIELD_ASSERTION_PRODUCER':'/private/tmp/truss-umf-runtime-xZQtaP'}
paths={pathlib.Path(__file__).resolve(),truss/'scripts/check-catalog-new-cohort.ts',truss/'scripts/build-configuration-context-admission.py'}
for directory,pattern in [('packages/umf-bun/src','*.ts'),('packages/postgresql/src','*.ts'),('packages/postgresql/native','*.sql'),('docs/helix/02-design/contracts','*.json'),('docs/helix/02-design/contracts/bindings','*.d.ts')]:paths.update((truss/directory).rglob(pattern))
paths.add(truss/'docs/helix/03-test/report-wire-untrusted.fixture.json')
for name in ['qualified-property-layout-0.15.owner-export.sql','source-epoch-storage.owner-export.sql','operation-configuration-storage.owner-export.sql']:paths.add(truss/'docs/helix/04-build/evidence'/name)
for directory in owners.values():paths.update(pathlib.Path(directory)/name for name in ['producer.js','producer-manifest.json'])
images={str(p):p.read_bytes() for p in sorted(paths)};sha=lambda b:hashlib.sha256(b).hexdigest()
out=umf/'docs/helix/04-build/evidence/security/truss-umf-membership-native'/str(uuid.uuid4());out.mkdir(parents=True)
env={**os.environ,**owners,'TRUSS_OPERATION_TEST_URL':'postgres://postgres@127.0.0.1:15437/umf_membership','TRUSS_COHORT_EVIDENCE':str(out/'native-cohort.json')}
command=['bun','scripts/check-catalog-new-cohort.ts'];result=None;cleanup=None
try:result=subprocess.run(command,cwd=truss,env=env,text=True,capture_output=True,timeout=180)
finally:
 cleanup=subprocess.run(['docker','rm','-f',container_id],text=True,capture_output=True,timeout=60)
receipt={'status':'pass' if result and result.returncode==0 and cleanup.returncode==0 else 'fail','scope':'native_original_new_cohort_execution_and_declared_umf_membership_candidate_only','container':{'id':container_id,'name':container,'image':inspect['Image'],'declaredImage':inspect['Config']['Image'],'ports':inspect['NetworkSettings']['Ports']},'execution':None if result is None else {'command':command,'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr},'cleanup':{'exitCode':cleanup.returncode,'stdout':cleanup.stdout,'stderr':cleanup.stderr},'sourceSha256':{p:sha(b) for p,b in images.items()},'owners':owners,'acceptedReportQualified':False,'supportSemanticsQualified':False,'acceptancePromoted':False,'limitations':['Actual PostgreSQL17.9 component cohort; installation/profile/semantic authority and complete acceptance remain unqualified.','Declared subset bytes are synthetic; original UMF bundles execute.','No full report persistence/head publication/finalizer or public acceptance is admitted.','Container image/local Bun/Ajv/Python/ambient runtime are observed dependencies, not hermetic closure.']}
for p,b in images.items():assert pathlib.Path(p).read_bytes()==b,p
with zipfile.ZipFile(out/'preimages.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p,b in images.items():z.writestr(p.lstrip('/'),b)
receipt['preimagesSha256']=sha((out/'preimages.zip').read_bytes());(out/'native.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'receipt':str(out/'native.json'),'sources':len(images),'execution':receipt['execution']}))
if receipt['status']!='pass':raise SystemExit(1)
