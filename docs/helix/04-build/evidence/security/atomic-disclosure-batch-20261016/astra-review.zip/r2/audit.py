import pathlib,json,hashlib,zipfile,subprocess,re,copy,posixpath,gzip
R=pathlib.Path('/private/tmp/umf-atomic-disclosure-astra-20261016');D=R/'r2';F=D/'frozen';E=F/'docs/helix/04-build/evidence/security/atomic-disclosure-batch-20261016';S=D/'supplemental';L=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf');BASE='109c77529aa9e32b355ccb06eb9731f1d145aad9';sha=lambda x:hashlib.sha256(x).hexdigest();checks=[]
def check(id,actual,expected):checks.append(dict(id=id,passed=actual==expected,actual=actual,expected=expected))
def git(path):return subprocess.check_output(['git','show',BASE+':'+path],cwd=L,stderr=subprocess.DEVNULL)
check('initial-zip',sha(pathlib.Path('/private/tmp/umf-atomic-disclosure-review-20261016.zip').read_bytes()),'5de354d08edecf416de2a051369ec83abcc50c425e8aea435aa60f358577e8eb')
check('r2-zip',sha(pathlib.Path('/private/tmp/umf-atomic-disclosure-r2-review-20261016.zip').read_bytes()),'07e2c338b85b5376dfaf3e471ae9cd7f97ddfb5ed09e787083944f81f645ec4d')
for prefix,packet in [('initial',R/'frozen'),('r2',F)]:
 e=packet/'docs/helix/04-build/evidence/security/atomic-disclosure-batch-20261016';b=json.loads((e/'browser.json').read_bytes())
 with zipfile.ZipFile(e/'browser-inputs.zip') as z:
  check(prefix+'-bundle',sha(z.read('browser.bundle.js')),b['bundleSha256']);sources=json.loads(z.read('browser.source-snapshot.json'))['sources']
  check(prefix+'-exact-source-set',sorted(sources),sorted(b['selectedSourceDigests']))
  for p,data in sources.items():
   check(prefix+'-source:'+p,sha(data.encode()),b['selectedSourceDigests'][p])
   if (packet/p).exists():check(prefix+'-outer:'+p,(packet/p).read_text(),data)
   if prefix=='r2':check('r2-replayed-unchanged:'+p,(D/'reconstructed'/p).read_text(),data)
check('prior-kernel', (E/'prior-kernel.ts').read_bytes()==git('src/extensions/security/catalog-runtime-candidate.ts'), True)
initial=R/'frozen/docs/helix/04-build/evidence/security/atomic-disclosure-batch-20261016'
for newer,older in [('first-browser.json','browser.json'),('first-browser-inputs.zip','browser-inputs.zip'),('first-security-regression.log','security-regression.log'),('first-typecheck.log','typecheck.log')]:check('retained-initial:'+newer,sha((E/newer).read_bytes()),sha((initial/older).read_bytes()))
check('retained-initial-patch',gzip.decompress((E/'first-candidate.patch.gz').read_bytes()),(initial/'candidate.patch').read_bytes() if (initial/'candidate.patch').exists() else gzip.decompress((initial/'candidate.patch.gz').read_bytes()))
with zipfile.ZipFile(E/'initial-budget-counterexample.zip') as z:
 for p in z.namelist():check('retained-counterexample:'+p,sha(z.read(p)),sha((R/p).read_bytes()))
planpath='docs/helix/03-test/security/cases.json';beforebytes=git(planpath);before=json.loads(beforebytes);afterbytes=(F/planpath).read_bytes();after=json.loads(afterbytes);rev=copy.deepcopy(after)
adds=['src/extensions/security/protection/disclosure.ts','src/extensions/security/protection/source.ts'];delta={}
for old,new,back in zip(before['cases'],after['cases'],rev['cases']):
 added=sorted(set(new.get('implementationSources',[]))-set(old.get('implementationSources',[])));removed=sorted(set(old.get('implementationSources',[]))-set(new.get('implementationSources',[])))
 if added or removed:delta[new['id']]={'added':added,'removed':removed};back['implementationSources']=[p for p in back['implementationSources'] if p not in added]
check('six-exact-inventory-additions',delta,{id:{'added':adds,'removed':[]} for id in ['S24','S25','pg-raw.P04']});check('all-other-plan-values-unchanged',rev,before)
check('before-plan-pin',sha(beforebytes),'6a42e29e7b41ceec23bd4d0fe77ba53c7faf575944fda955d043264800302f4b');check('after-plan-pin',sha(afterbytes),'2808e1b9ab5c615002061883376bed500b8f43eb0bde567ef0c16dfc78956a13');check('live-plan-exact',sha((L/planpath).read_bytes()),sha(afterbytes))
check('158-required',sum(bool(c['required']) for c in after['cases']),158);check('34-criteria',len({x for c in after['cases'] for x in c['covers']}),34)
# Capture current endpoint inputs; compare every repeated fingerprint rather than trusting witness booleans.
w=json.loads((S/'gate-witness.json').read_bytes());allbytes={}
with zipfile.ZipFile(S/'gate-current-receipts.zip') as z:
 final=json.loads(z.read('docs/helix/04-build/evidence/security/acceptance.json'))
 for n in z.namelist():check('current-archive:'+n,sha(z.read(n)),sha((L/n).read_bytes()))
 for e in final['execution']:
  for p,h in e['fingerprints'].items():
   if p not in allbytes:allbytes[p]=(L/p).read_bytes()
   check('fingerprint:'+e['id']+':'+p,sha(allbytes[p]),h)
 check('gate-pass-count',sum(bool(e['accepted']) for e in final['execution']),45);check('gate-executions',len(final['execution']),45);check('missing-errors-count',len(final['errors']),113);check('only-missing-errors',all('required reviewed runner/oracle/implementation binding not implemented' in x for x in final['errors']),True)
 check('gate-plan-before',final['planDigest'],sha(afterbytes));check('gate-plan-after',final['finalPlanDigest'],sha(afterbytes));check('gate-tool-endpoints',final['gateSourceDigests'],final['finalGateSourceDigests'])
 for p,h in final['gateSourceDigests'].items():check('gate-tool-base:'+p,h,sha(git(p)))
 with zipfile.ZipFile(E/'gate-preimages.zip') as old:
  for p,v in w['originalTrackedReceiptReplacements'].items():
   oldbytes=old.read(p) if p in old.namelist() else git(p)
   check('oldreceipt:'+p,sha(oldbytes),v['oldSha256']);check('newreceipt:'+p,sha(z.read(p)),v['newSha256'])
 first=json.loads((E/'first-gate.json').read_bytes());check('first44accepted',sum(bool(e['accepted']) for e in first['execution']),44);bad=[e for e in first['execution'] if not e['accepted']];check('first-only-p04', [e['id'] for e in bad],['pg-raw.P04']);check('first-p04-pre-SQL', 'line 36' in bad[0]['stderr'] and 'assert set(sources)==set' in bad[0]['stderr'] and not bad[0]['stdout'],True);check('first-plan-before',first['planDigest'],sha(beforebytes));check('first-plan-after',first['finalPlanDigest'],sha(beforebytes))
 with zipfile.ZipFile(E/'first-gate-receipts.zip') as original:check('first-receipt-exact',original.read('docs/helix/04-build/evidence/security/acceptance.json'),(E/'first-gate.json').read_bytes())
 phase=json.loads(z.read('docs/helix/04-build/evidence/security/phase-validation.json'));print('phasekeys',list(phase));
check('unique570',len(allbytes),570);check('repeated2184',sum(len(e['fingerprints']) for e in final['execution']),2184)
for p,h in w['sourceDigests'].items():check('witness-frozen:'+p,sha((F/p).read_bytes()),h)
# Independent conservative relative-import census; no runner or SQL execution.
def data(p):
 if p in allbytes:return allbytes[p]
 try:return (D/'reconstructed'/p).read_bytes()
 except FileNotFoundError:return git(p)
def exists(p):
 if p in allbytes or (D/'reconstructed'/p).is_file():return True
 if (D/'reconstructed'/p).is_dir():return False
 v=subprocess.run(['git','cat-file','-t',BASE+':'+p],cwd=L,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 return v.returncode==0 and v.stdout.strip()==b'blob'
edges=[]
def closure(p,seen=None):
 if seen is None:seen=set()
 if p in seen:return seen
 seen.add(p)
 if pathlib.Path(p).suffix in ['.ts','.js']:
  for rel in re.findall(r'(?:from\s*|import\s*)[\'"](\.[^\'"]+)[\'"]',data(p).decode()):
   base=posixpath.normpath(posixpath.join(posixpath.dirname(p),rel));found=next((v for v in [base,base+'.ts',base+'.json',base+'/index.ts'] if exists(v)),None)
   if found is None:raise ValueError(base)
   edges.append([p,found]);closure(found,seen)
 return seen
p04=closure('tests/security/native/pg18-mask-write-declarations.ts')|set(['tests/security/native/pg18-mask-write.py','tests/security/native/pg18-mask-write.sql','tests/security/native/pg18-mask-write-oracle.py','package.json','bun.lock'])
c=next(c for c in after['cases'] if c['id']=='pg-raw.P04');check('p04-exact-closure',sorted(p04),sorted(set([c['testSource'],c['oracleSource'],*c['implementationSources']])))
write=closure('tests/security/protection/write-oracle.ts')
for id in ['S24','S25']:
 c=next(c for c in after['cases'] if c['id']==id);check(id+'-closure-covered',sorted(write-set([c['testSource'],c['oracleSource'],*c['implementationSources']])),[])
check('direct-type-import-real', ['src/extensions/security/catalog-runtime-candidate.ts','src/extensions/security/protection/disclosure.ts'] in edges,True);check('transitive-source-import-real',['src/extensions/security/protection/disclosure.ts','src/extensions/security/protection/source.ts'] in edges,True)
for p in ['tests/security/native/pg18-mask-write.py','tests/security/native/pg18-mask-write-oracle.py','tests/security/protection/write-acceptance.ts','tests/security/protection/write-oracle.ts','tests/security/protection/write-oracle.py']:check('runner-unchanged:'+p,sha(data(p)),sha(git(p)))
with zipfile.ZipFile(D/'gate-endpoint-source-snapshot.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p,b in sorted(allbytes.items()):z.writestr(p,b)
# Avoid duplicating megabyte-valued successful observations in the human-facing audit.
compact=[{k:v for k,v in c.items() if k not in ['actual','expected']}|({} if c['passed'] else {'actual':str(c['actual'])[:2000],'expected':str(c['expected'])[:2000]}) for c in checks]
report={'status':'passed' if all(c['passed'] for c in checks) else 'failed','count':len(checks),'checks':compact,'sourcePins':{p:sha(b) for p,b in sorted(allbytes.items())},'closures':{'P04':sorted(p04),'write':sorted(write),'edges':sorted(set(tuple(e) for e in edges))},'auditReceipt':phase,'scope':'Read-only source/receipt endpoint and exact frozen input correspondence. No native campaign, held-file/ABA provenance or broad acceptance claimed.'}
(D/'evidence-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'count':len(checks),'failures':[c for c in compact if not c['passed']]}))
