/** Fresh Weft-owned read requirements -> supplied-complete-cut logical scan oracle. */
import {createHash} from 'node:crypto';
import source from '/Users/erik/.codex/worktrees/security-main-integration/umf/tests/security/protection/current-query-source.json';
import scenarios from '/Users/erik/.codex/worktrees/security-main-integration/umf/tests/security/protection/current-query-read-scenarios.json';
import {compileCandidateCatalogProgram} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-program-candidate';
import {inspectCandidateStoredQueryProperties} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/stored-query-candidate';
import {evaluateCandidateCatalogScan} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-runtime-candidate';
const [binary,expectedSha,output]=process.argv.slice(2);if(!binary||!/^[a-f0-9]{64}$/.test(expectedSha??'')||!output)throw Error('Exact producer, SHA256 and output directory required');
const sha=(x:string|Uint8Array)=>createHash('sha256').update(x).digest('hex'),hashBinary=async()=>sha(new Uint8Array(await Bun.file(binary).arrayBuffer()));if(await hashBinary()!==expectedSha)throw Error('Producer mismatch');
const observations:any[]=[],check=(id:string,ok:boolean)=>{if(!ok)throw Error(id);observations.push({id,passed:true});},id=(r:any)=>JSON.stringify([r.documentId,r.moduleId,r.elementId]);
const queryCases:[string,string,string[],string[][]][]=[
 ['projection-read','SELECT r.token FROM Resource r',['s0'],[['s0','outputs/0/expression','token','projection']]],
 ['hidden-read-false-zero',"SELECT r.resourceId FROM Resource r WHERE FALSE AND r.token='opaque-token' ORDER BY r.token LIMIT 0",['s0'],[['s0','outputs/0/expression','resourceId','projection'],['s0','filters/1/left','token','predicate'],['s0','order/0','token','order']]],
 ['distinct-selfjoin-false-zero',"SELECT COUNT(DISTINCT s.token) FROM Resource r JOIN Resource s ON r.token=s.token WHERE FALSE AND r.token='opaque-token' LIMIT 0",['s0','s1'],[['s0','joins/0/on/0/left','token','join'],['s1','joins/0/on/0/right','token','join'],['s0','filters/1/left','token','predicate'],['s1','outputs/0/argument','token','aggregate']]],
 ['field-free-false-zero','SELECT COUNT(*) FROM Resource r WHERE TRUE AND FALSE LIMIT 0',['s0'],[]],
 ['distinct-required','SELECT COUNT(DISTINCT r.token) AS unique_tokens FROM Resource r',['s0'],[['s0','outputs/0/argument','token','aggregate']]],
 ['sum-unsupported','SELECT SUM(r.salary) FROM Resource r LIMIT 0',['s0'],[['s0','outputs/0/argument','salary','aggregate']]],
];
const sourceFiles=['tools/security/current-query-readsets.ts','src/extensions/security/catalog-runtime-candidate.ts','src/extensions/security/catalog-program-candidate.ts','src/extensions/security/stored-query-candidate.ts','src/extensions/security/catalog-storage-candidate.ts','tests/security/protection/current-query-source.json','tests/security/protection/current-query-read-scenarios.json','bun.lock','package.json'];
const pins=async()=>Object.fromEntries(await Promise.all(sourceFiles.map(async path=>[path,sha(new Uint8Array(await Bun.file(path).arrayBuffer()))]))),before=await pins();
const results:any[]=[];
for(const variant of ['r1-undisclosed','r2-allowed','r2-revoked']){
 const policy:any=structuredClone(variant==='r1-undisclosed'?source.policy:scenarios.policy),owner:any=structuredClone(source.owner),cut:any=structuredClone(scenarios.cut);owner.revision='named-scan-owner-r1';owner.disclosure={readAction:'read'};cut.owner.revision=owner.revision;cut.policy.revision=policy.revision;
 if(variant==='r2-revoked'){cut.generation=cut.expectedGeneration='logical-revoked-cut-r1';cut.facts.find((r:any)=>r.type.elementId==='Assignment').fields.find((f:any)=>f.field.elementId==='active').value={boolean:false};}
 const program=compileCandidateCatalogProgram(policy,source.catalog,source.closure,source.ontology),documentJson=JSON.stringify(source.closure.documents[0]!.document);
 const opaqueSources=[['policy',policy,policy.id,policy.revision],['catalog',source.catalog,source.catalog.id,source.catalog.revision],['ontology',source.ontology,source.ontology.documentId,source.ontology.revision],['owner',owner,owner.id,owner.revision],['logical-cut',cut,'logical-cut-fixture',cut.generation]].map(([role,value,documentId,revision])=>{const utf8=JSON.stringify(value);return {role,identity:{documentId,revision},mediaType:'application/json',utf8,sha256:sha(utf8)};});
 for(const [name,sql,scanIds,expectedFields]of queryCases){
  const label=variant+':'+name,request={interfaceVersion:'weft-application-lineage/0.2-candidate',modules:[{documentJson,pin:{documentId:'domain',revision:source.closure.pins[0]!.revision,umfVersion:'0.8.0',sha256:sha(documentJson)},selectedModuleIds:['m']}],sql,parameters:{},opaqueSources},raw=JSON.stringify(request);
  const proc=Bun.spawn([binary],{stdin:'pipe',stdout:'pipe',stderr:'pipe'});proc.stdin.write(raw);proc.stdin.end();const [stdout,stderr,exit]=await Promise.all([new Response(proc.stdout).text(),new Response(proc.stderr).text(),proc.exited]);check(label+':actual-issuer',exit===0&&stderr==='');const report=JSON.parse(stdout);report.uses=[];
  check(label+':exact-source',report.sourceRequestJson===raw&&report.sourceRequestSha256===sha(raw)&&report.sqlSha256===sha(sql));check(label+':no-native-authority',report.version==='weft.application.lineage/0.2-candidate'&&report.authority===false&&report.securityReady===false);
  check(label+':original-plan',report.applicationPlanSha256===sha(report.applicationPlanJson));
  check(label+':opaque-source-custody',report.unresolvedSources.length===opaqueSources.length&&report.unresolvedSources.every((x:any)=>opaqueSources.some(s=>s.role===x.role&&s.identity.documentId===x.identity.documentId&&s.identity.revision===x.identity.revision&&s.sha256===x.sha256&&x.status==='uninterpreted')));
  const reads=report.readRequirements;check(label+':all-occurrence-scans',JSON.stringify(reads.scans.map((x:any)=>x.scan))===JSON.stringify(scanIds)&&reads.scans.every((x:any)=>x.kind==='rowRead'&&x.target.elementId==='Resource'&&x.recordIdentity.revision===source.closure.pins[0]!.revision));
  check(label+':all-projected-hidden-fields',JSON.stringify(reads.fields.map((x:any)=>[x.scan,x.path,x.field.elementId,x.role]))===JSON.stringify(expectedFields));
  check(label+':actual-required-descriptors',reads.fields.every((x:any)=>x.descriptor.availability==='required'&&x.fieldIdentity.revision===source.closure.pins[0]!.revision&&x.descriptor.identity.element===x.field.elementId&&!Object.hasOwn(x,'mode')&&!Object.hasOwn(x,'action')));
  check(label+':no-unhandled-relationship',reads.relationships.length===0);check(label+':unsupported-sum-retained',reads.unsupportedSources.length===(name==='sum-unsupported'?1:0)&&(name!=='sum-unsupported'||reads.unsupportedSources[0].kind==='numericAggregateProperties'));
  const properties=[];
  for(const use of report.uses){if(use.field.elementId!=='token')continue;
   const property=inspectCandidateStoredQueryProperties(program,owner,{type:use.type,field:use.field,operator:use.operator,required:use.required});
   check(label+':'+use.path+':separate-stored-property-check',property.status==='selected'&&property.report?.status===(use.operator==='order'?'refused':'compatible-properties')&&!property.complete&&!property.authority);properties.push({path:use.path,scan:use.scan,report:property.report});
  }
  const scans=[];
  for(const scan of reads.scans){const fields:any[]=[],seen=new Set<string>();for(const f of reads.fields.filter((x:any)=>x.scan===scan.scan))if(!seen.has(id(f.field))){seen.add(id(f.field));fields.push(f.field);}
   const selection={type:scan.target,fields},logical=evaluateCandidateCatalogScan(program,owner,cut,selection),hasToken=fields.some(f=>f.elementId==='token'),expected=variant==='r1-undisclosed'&&hasToken?'refused':'rendered';
   check(label+':'+scan.scan+':read-decision',logical.status===expected&&!logical.complete&&!logical.authority);
   // Core literal families/values are authored expectations, independent of the emitter.
   const expectedRows=expected==='refused'||variant==='r2-revoked'?[]:[fields.map(field=>({field,disposition:'original',value:field.elementId==='salary'?{integerToken:'100'}:{string:field.elementId==='resourceId'?'r1':'opaque-token'}}))];
   const canonical=(x:any):string=>x&&typeof x==='object'?Array.isArray(x)?'['+x.map(canonical).join(',')+']':'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x);
   check(label+':'+scan.scan+':complete-source-rows',canonical(logical.rows)===canonical(expectedRows));scans.push({scan:scan.scan,selection,logical});
  }
  await Bun.write(output+'/'+variant+'-'+name+'.request.json',raw);await Bun.write(output+'/'+variant+'-'+name+'.report.json',stdout);results.push({variant,query:name,scans,properties,unsupportedSources:reads.unsupportedSources});
 }
}
const after=await pins();check('producer-and-selected-sources-unchanged',await hashBinary()===expectedSha&&JSON.stringify(before)===JSON.stringify(after));
await Bun.write(output+'/receipt.json',JSON.stringify({status:'correspondence-passed',acceptanceReceipt:false,casePromoted:null,producerSha256:expectedSha,selectedSourceDigests:after,controls:observations.length,observations,results,scope:'Fresh actual compiler-issued readsets matched to complete supplied logical scans under separately authored r1/r2/changed-assignment source packets. False/zero-limit syntax does not erase pre-query row/Field read duties. This does not execute queries, apply aggregate semantics, infer query-use mode/action grants, authenticate cut completeness or qualify native/backend/P03/B08 authority.'},null,2)+'\n');console.log(JSON.stringify({status:'correspondence-passed',controls:observations.length}));
