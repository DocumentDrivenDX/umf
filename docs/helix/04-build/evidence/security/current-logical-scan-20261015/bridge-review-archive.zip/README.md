Focused readset bridge review

No remaining blocker in the fixed six-query candidate bridge scope. Fresh actual producer/bridge replay: 262 controls; independent exact audit: 18 reports; three repaired verifier tamper controls detected. Historical surviving controls are retained, with exact before/after source pins. No native, general query compiler, receiver, P03/B08 or authority qualification. Final Weft main provenance remains pending.

Reproduce the final bridge from the UMF checkout with Bun and the pinned producer path recorded in bridge-review.json. Run independent-report-audit.py against the resulting report directory. The three repaired-*.ts files are self-contained private harness copies with absolute imports into the selected checkout; they must fail at the named assertions in repaired-negative-controls.json.
