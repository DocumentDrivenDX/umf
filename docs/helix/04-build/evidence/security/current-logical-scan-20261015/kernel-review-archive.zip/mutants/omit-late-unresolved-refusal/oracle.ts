import base from './base-fixture.json';
import {compileCandidateCatalogProgram as compile} from '/private/tmp/current-logical-scan-astra-20261015/mutants/omit-late-unresolved-refusal/src/extensions/security/catalog-program-candidate';
import {evaluateCandidateCatalogScan as scan,evaluateCandidateCatalogCollection as collection} from '/private/tmp/current-logical-scan-astra-20261015/mutants/omit-late-unresolved-refusal/src/extensions/security/catalog-runtime-candidate';
const cp=(x:any)=>structuredClone(x), ref=(elementId:string,moduleId='entities')=>({documentId:'review-domain',moduleId,elementId});
const A=ref('Asset'),AM=ref('amount'),AK=ref('asset-key'),R={documentId:'review-domain',moduleId:'entities',relationshipId:'DirectLink'};
const frozen=(v:any):boolean=>v===null||typeof v!=='object'||Object.isFrozen(v)&&Object.values(v).every(frozen);
const same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b);
const fact=(f:any,name:string)=>f.cut.facts.find((x:any)=>x.type.elementId===name), cov=(f:any,name='Asset')=>f.cut.coverage.find((x:any)=>x.type.elementId===name);
const field=(f:any,name='amount')=>f.closure.documents[0].document.modules[0].elements.find((x:any)=>x.id===name);
const cell=(field:any,value:any)=>({field,disposition:'original',value});
const eq=(v:any)=>({op:'eq',left:{kind:'resource',field:AM},right:{kind:'constant',field:ref('dto-number','domains'),value:v}});
function add(f:any,key:string,value:any){const a=cp(fact(f,'Asset'));a.key=[{string:key}];a.fields=[{field:AK,value:{string:key}},{field:AM,value}];a.absent=[];f.cut.facts.push(a);return a;}
function fixture(){const f:any=cp(base);f.owner.disclosure={readAction:'read'};f.ontology.actionPurposes=[{action:'read',purposes:['read']}];f.policy.rules[0].disclosure[0].disposition={kind:'original'};fact(f,'Asset').fields[1].value={integerToken:'1'};add(f,'a2',{integerToken:'2'});add(f,'a3',{integerToken:'1'});f.selection={type:A,fields:[AK,AM]};return f;}
function membership(f:any,graph=false,opaque=false){
 const ep=(endpoint:string)=>({kind:'variable',name:'g',endpoint});
 f.policy.rules[0].condition={op:'exists',association:graph?R:ref('Link'),as:'g',where:{op:'and',args:[{op:'eq',left:ep('person'),right:{kind:'subject',identity:true}},{op:'eq',left:ep('asset'),right:{kind:'resource',identity:true}}]}};
 if(graph){f.closure.documents[0].document.modules[0].relationships=[{id:'DirectLink',name:'DirectLink',directed:true,sourceMultiplicity:{min:0,max:1},targetMultiplicity:{min:0,max:2},targetLifecycle:'independent',source:[{module:'entities',element:'Person'}],target:[{module:'entities',element:'Asset',key:'pk'}],...(!opaque?{associationRecord:{module:'entities',element:'Link'}}:{})}];f.ontology.associations=[{kind:'core-relationship',relationship:R,witness:opaque?{kind:'opaque-existential'}:{kind:'record-key',type:ref('Link'),keyId:'pk'},endpoints:[{role:'person',side:'source',target:ref('Person'),keyId:'pk'},{role:'asset',side:'target',target:A,keyId:'pk'}]}];f.cut.graphs=[{relationship:R,witness:opaque?{kind:'opaque-existential',id:'w1'}:{kind:'record-key',type:ref('Link'),key:[{string:'l1'}]},endpoints:[{role:'person',key:[{string:'p1'}]},{role:'asset',key:[{string:'a1'}]}]}];f.cut.graphCoverage=[{relationship:R,complete:true,roles:['person','asset'],fields:[]}];}
}
function dropAmount(f:any,absent=false){for(const a of f.cut.facts.filter((x:any)=>x.type.elementId==='Asset')){a.fields=a.fields.filter((p:any)=>p.field.elementId!=='amount');if(absent)a.absent=[AM];}if(!absent)cov(f).fields=cov(f).fields.filter((r:any)=>r.elementId!=='amount');}
function empty(f:any){f.cut.facts=f.cut.facts.filter((x:any)=>x.type.elementId!=='Asset');}
const refused={status:'refused',complete:false,authority:false,rows:[],valueProfiles:[]};
function exec(f:any){return scan(compile(f.policy,f.catalog??null,f.closure,f.ontology),f.owner,f.cut,f.selection);}
export function runOracle(){const rows:any[]=[];
 const test=(id:string,fn:()=>boolean)=>{let passed=false,error=null;try{passed=fn();}catch(e){error=String(e);}rows.push({id,passed,error});};
 const output=(id:string,edit:(f:any)=>void,expected:any)=>test(id,()=>{const f=fixture();edit(f);const before=JSON.stringify(f),r=exec(f);return r.status==='rendered'&&same(r.rows,expected)&&r.complete===false&&r.authority===false&&frozen(r)&&JSON.stringify(f)===before;});
 const reject=(id:string,edit:(f:any)=>void)=>test(id,()=>{const f=fixture();edit(f);const h=compile(f.policy,f.catalog??null,f.closure,f.ontology),before=JSON.stringify(f),r=scan(h,f.owner,f.cut,f.selection);return same(r,refused)&&frozen(r)&&JSON.stringify(f)===before;});
 output('every-target-once-original-fact-order',()=>{},[['a1','1'],['a2','2'],['a3','1']].map(([key,n])=>[cell(AK,{string:key}),cell(AM,{integerToken:n})]));
 output('reverse-fact-order-preserved',f=>f.cut.facts.reverse(),[['a3','1'],['a2','2'],['a1','1']].map(([key,n])=>[cell(AK,{string:key}),cell(AM,{integerToken:n})]));
 output('selected-field-order-preserved',f=>f.selection.fields=[AM,AK],[['a1','1'],['a2','2'],['a3','1']].map(([key,n])=>[cell(AM,{integerToken:n}),cell(AK,{string:key})]));
 output('denial-filters-only-matching-rows',f=>f.policy.rules[0].condition=eq({integerToken:'1'}),['a1','a3'].map(key=>[cell(AK,{string:key}),cell(AM,{integerToken:'1'})]));
 output('fieldfree-keeps-row-read-filter',f=>{f.selection.fields=[];f.policy.rules[0].condition=eq({integerToken:'1'});},[[],[]]);
 output('fieldfree-no-field-disclosure-demand',f=>{f.selection.fields=[];delete f.policy.rules[0].disclosure;dropAmount(f);},[[],[],[]]);
 output('fieldfree-without-grants-is-empty',f=>{f.selection.fields=[];f.policy.rules=[];},[]);
 output('no-grants-is-empty',f=>f.policy.rules=[],[]);
 output('actual-owner-read-action-is-derived',f=>{f.owner.disclosure.readAction='view-assets';f.ontology.actions=['view-assets'];f.ontology.actionPurposes=[{action:'view-assets',purposes:['read']}];f.policy.rules[0].actions=['view-assets'];f.selection.fields=[];},[[],[],[]]);
 output('original-null',f=>{f.selection.fields=[AM];for(const r of f.cut.facts.filter((x:any)=>x.type.elementId==='Asset'))r.fields[1].value=null;},Array.from({length:3},()=>[cell(AM,null)]));
 output('original-known-absence',f=>{f.selection.fields=[AM];dropAmount(f,true);},Array.from({length:3},()=>[{field:AM,disposition:'absent'}]));
 output('withheld-no-input-dependency',f=>{f.selection.fields=[AM];dropAmount(f);f.policy.rules[0].disclosure[0].disposition={kind:'withheld'};},Array.from({length:3},()=>[{field:AM,disposition:'withheld'}]));
 output('inline-no-input-dependency',f=>{f.selection.fields=[AM];dropAmount(f);f.policy.rules[0].disclosure[0].disposition={kind:'transformed',transform:'constant',version:'0.1.0',field:ref('dto-text','domains'),value:{string:'mask'}};},Array.from({length:3},()=>[{field:AM,disposition:'transformed',outputType:ref('dto-text','domains'),value:{string:'mask'}}]));
 output('empty-full-preflight-positive',empty,[]);
 output('empty-fieldfree-positive',f=>{empty(f);f.selection.fields=[];},[]);
 output('empty-inline-no-input',f=>{empty(f);f.selection.fields=[AM];cov(f).fields=[];f.policy.rules[0].disclosure[0].disposition={kind:'transformed',transform:'constant',version:'0.1.0',field:ref('dto-text','domains'),value:{string:'mask'}};},[]);
 output('empty-withheld-no-input',f=>{empty(f);f.selection.fields=[AM];cov(f).fields=[];f.policy.rules[0].disclosure[0].disposition={kind:'withheld'};},[]);
 for(const [id,edit]of [
 ['caller-resources',(f:any)=>f.selection.resources=[]],['caller-action',(f:any)=>f.selection.action='read'],['caller-limit',(f:any)=>f.selection.limit=1],['caller-predicate',(f:any)=>f.selection.predicate={op:'literal',value:true}],['caller-native-binding',(f:any)=>f.selection.binding={}],
 ['duplicate-selected-field',(f:any)=>f.selection.fields.push(AM)],['foreign-field',(f:any)=>f.selection.fields=[ref('person-label')]],['domain-only-field',(f:any)=>f.selection.fields=[ref('dto-number','domains')]],['unknown-type',(f:any)=>f.selection.type=ref('Missing')],['type-extra',(f:any)=>f.selection.type={...A,revision:'x'}],
 ['missing-owner-read',(f:any)=>delete f.owner.disclosure],['unknown-owner-read',(f:any)=>f.owner.disclosure.readAction='unknown'],['source-no-read-purpose',(f:any)=>f.ontology.actionPurposes[0].purposes=['field']],['missing-owner-storage',(f:any)=>f.owner.storage.pop()],
 ['incomplete-target',(f:any)=>cov(f).complete=false],['missing-target-coverage',(f:any)=>f.cut.coverage=f.cut.coverage.filter((x:any)=>x.type.elementId!=='Asset')],['missing-original-field-coverage',(f:any)=>cov(f).fields=[AK]],['stale-generation',(f:any)=>f.cut.expectedGeneration='stale'],['stale-policy',(f:any)=>f.cut.policy.revision='stale'],['stale-core',(f:any)=>f.cut.domains[0].revision='stale'],
 ['duplicate-validated-fact',(f:any)=>f.cut.facts.push(cp(fact(f,'Asset')))],['invalid-unselected-typed-fact',(f:any)=>fact(f,'Person').fields[1].value={integerToken:'4'}],['unselected-unknown-fact-member',(f:any)=>fact(f,'Link').surprise=true],['malformed-later-target',(f:any)=>f.cut.facts.at(-1).fields[1].value={string:'wrong'}],['covered-unselected-projection-missing',(f:any)=>fact(f,'Person').fields.pop()],
 ['aggregate-derived-population-bound',(f:any)=>f.cut.maxFacts=f.cut.facts.length],['steps-exhausted',(f:any)=>f.cut.maxSteps=1],['fractional-steps',(f:any)=>f.cut.maxSteps=100000.1],['string-facts-limit',(f:any)=>f.cut.maxFacts='100'],
 ['empty-missing-original-coverage',(f:any)=>{empty(f);cov(f).fields=[];}],['empty-incomplete-target',(f:any)=>{empty(f);cov(f).complete=false;}],
 ['late-unknown-atomic',(f:any)=>{f.policy.rules[0].condition=eq({integerToken:'1'});const r=f.cut.facts.at(-1);r.fields.pop();r.absent=[AM];}],
 ['fieldfree-late-unknown-atomic',(f:any)=>{f.selection.fields=[];f.policy.rules[0].condition=eq({integerToken:'1'});const r=f.cut.facts.at(-1);r.fields.pop();r.absent=[AM];}],
 ['late-conflict-atomic',(f:any)=>{f.policy.rules[0].disclosure[0].disposition={kind:'transformed',transform:'constant',version:'0.1.0',field:ref('dto-text','domains'),value:{string:'one'}};const q=cp(f.policy.rules[0]);q.id='conflict';q.condition=eq({integerToken:'2'});q.disclosure[0].disposition.value={string:'two'};f.policy.rules.push(q);}]
 ]as [string,(f:any)=>void][])reject(id,edit);
 output('aggregate-bound-inclusive',f=>f.cut.maxFacts=f.cut.facts.length+3,[['a1','1'],['a2','2'],['a3','1']].map(([key,n])=>[cell(AK,{string:key}),cell(AM,{integerToken:n})]));
 for(const [tag,graph,opaque]of [['flat',false,false],['record-graph',true,false],['opaque-graph',true,true]]as [string,boolean,boolean][]){
  output(tag+'-membership-selects-all-and-only-linked',f=>membership(f,graph,opaque),[[cell(AK,{string:'a1'}),cell(AM,{integerToken:'1'})]]);
  output(tag+'-fieldfree-still-membership',f=>{membership(f,graph,opaque);f.selection.fields=[];},[[]]);
  reject(tag+'-missing-association-coverage',f=>{membership(f,graph,opaque);if(graph)f.cut.graphCoverage=[];else cov(f,'Link').complete=false;});
  reject(tag+'-empty-still-association-preflight',f=>{membership(f,graph,opaque);empty(f);f.cut.graphs=[];if(graph)f.cut.graphCoverage=[];else cov(f,'Link').complete=false;});
 }
 test('legacy-subset-is-still-subset',()=>{const f=fixture(),h=compile(f.policy,null,f.closure,f.ontology);const r=collection(h,f.owner,f.cut,{action:'read',targets:[A],fields:[AK],resources:[{type:A,key:[{string:'a2'}]}]});return r.status==='rendered'&&same(r.rows,[[cell(AK,{string:'a2'})]])&&scan(h,f.owner,f.cut,{type:A,fields:[AK]}).rows.length===3;});
 test('copied-program-refused',()=>{const f=fixture();return same(scan(cp(compile(f.policy,null,f.closure,f.ontology)),f.owner,f.cut,f.selection),refused);});
 for(const place of ['selection','owner','cut'])test(place+'-getter-never-executed',()=>{const f=fixture(),h=compile(f.policy,null,f.closure,f.ontology);let calls=0;if(place==='selection')Object.defineProperty(f.selection,'fields',{enumerable:true,get(){calls++;return[];}});if(place==='owner')Object.defineProperty(f.owner,'disclosure',{enumerable:true,get(){calls++;return{readAction:'read'};}});if(place==='cut')Object.defineProperty(f.cut,'facts',{enumerable:true,get(){calls++;return[];}});return same(scan(h,f.owner,f.cut,f.selection),refused)&&calls===0;});
 return rows;
}
