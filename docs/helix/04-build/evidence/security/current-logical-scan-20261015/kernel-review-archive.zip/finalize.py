import pathlib,json,hashlib,zipfile,datetime
base=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((base/'source-pins-final.json').read_text());drift=[p for p,s in pins.items() if sha(repo/p)!=s];assert not drift,drift
actual=json.loads((base/'results.json').read_text());browser=json.loads((base/'browser-results.json').read_text());mutants=json.loads((base/'mutation-results.json').read_text());formal=json.loads((base/'formal-replay/receipt.json').read_text())
assert len(actual['rows'])==69 and all(r['passed'] for r in actual['rows'])
assert browser['rows']==actual['rows'] and browser['parity'] and browser['hostGlobalsAbsent'] and browser['pageErrors']==[] and browser['externalRequests']==0
assert len(mutants)==9 and all(r['detected'] for r in mutants) and mutants[0]['failedRows']==[]
review={
 'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'no-blocking-finding-within-reviewed-scope','acceptanceReceipt':False,
 'scope':'Private evaluateCandidateCatalogScan over an originally issued program and the entire validated supplied target-type fact population; trusted complete-cut premise. No query parser/compiler, native authority, backend qualification, or public root API.',
 'sourcePins':'source-pins-final.json','sourceCount':len(pins),'sourceUnchangedAtFinalCheck':True,
 'primarySourceSha256':pins['src/extensions/security/catalog-runtime-candidate.ts'],
 'independentExecution':{'bun':{'version':browser['versions']['bun'],'controls':69,'passed':69,'result':'results.json'},'chromium':{'version':browser['versions']['chromium'],'controls':69,'passed':69,'exactParity':True,'hostGlobalsAbsent':True,'externalRequests':0,'pageErrors':[],'result':'browser-results.json'},'focusedOriginalTests':{'command':'bun test tests/security/catalog-scan.test.ts tests/security/catalog-collection.test.ts tests/security/catalog-runtime.test.ts','tests':27,'assertions':198,'failed':0,'log':'focused-regression.log'},'actualSourceWeakenings':{'originalBaselineControls':69,'mutants':8,'detected':8,'file':'mutation-results.json','qualification':'Each mutant runs in a separate private source copy; intended semantic assertion failures are required, while thrown/import/setup errors are rejected. Eight diffs and focused mutated module copies are retained.'},'conditionalFormalReplay':{'queries':10,'unsat':6,'sat':4,'freshContextReplays':10,'solverVersion':formal['solverVersion'],'receipt':'formal-replay/receipt.json'}},
 'reviewConclusions':[
  'The new operation is an explicit separate entry point. Existing subset action/collection semantics remain unchanged; the independent corpus directly compares a legal one-row subset with a three-row scan.',
  'The one packet snapshot precedes owner/read-action derivation. Selection is exactly {type,fields}; caller resources/action/limit/predicate/native binding members refuse. Accessor controls refuse without invoking selection, owner or cut getters.',
  'Every supplied Record fact is typed and its normalized Key/projections validated before scan target enumeration. The target population comes from the validated byType index exactly once in source fact order. Unknown or malformed unselected facts still refuse.',
  'Derived selector count is charged before map allocation and added to existing facts+graphs aggregate maxFacts. It stays inside the original operation and literal/output ledgers; the new entry does not reset evaluation or rendering budgets.',
  'The actual detached owner read action is used, with the existing source read-purpose and policy checks. A custom action-name positive detects a hardcoded read-action substitution.',
  'Field-free scans still evaluate each row read. Denials filter; late unknown/conflict clears all rows. Empty target populations retain existing source condition/output preflight. Original null, known absence, withheld and inline transformation retain separate cell meanings.',
  'Flat association, Record-backed graph and opaque graph examples all scan the full population while filtering by actual supplied membership. These are logical-cut controls, not native fact custody evidence.',
  'No new root export exists. Weft remains responsible for per-occurrence query read requirements and the native consumer for current authority/cut/dispatch binding.'
 ],
 'designAssessment':{'contract':'CONTRACT-062 private complete logical scan candidate','design':'TD-079 Complete typed scan reference for query read admission','testPlan':'STP-079 Complete typed scan reference for query read admission','verdict':'Consistent in the explicitly supplied-complete-cut scope. The operation prevents selector omission inside its own interface; it cannot authenticate the caller-supplied inventory completeness.'},
 'formalAssessment':{'acceptedMeaning':'Conditional unbounded prefix invariant: final release has every and only permitted row index, any U/conflict prevents release, field-free denied rows are not emitted, empty populations still require source preflight. Four SAT controls establish nonvacuity and expose subset/native-auth gaps.','assumptions':['Exact source-to-index population enumeration and unique normalized Keys','Faithful row decision/disposition kernel','Trustworthy supplied complete-cut/source preflight assertions'],'notProved':['Actual TypeScript traversal/refinement','Row ordering/multiplicity physical interpretation beyond unique modeled indices','Runtime budgets, value rendering or native release coordination','Native authentication or Weft readset completeness']},
 'limitations':['Finite controls plus separate conditional model, not a universal security theorem.','Supplied completeness/trust remains a host premise; a caller can fabricate an incomplete cut outside this API guarantee.','No P03/B08 or other backend case promotion. No native jobs were run.','Parent whole 158-case gate was running at review finalization; its result is not independently claimed by this packet.','Captured files are a selected recursive relative-import closure plus relevant source/docs/tests; Bun/Chromium/runtime dependency closure is not proved exhaustive.','Private shared dependency symlinks in mutant staging are not a hermetic build claim.'],
 'findings':[],
 'historicalAndSetupNotes':['The first 68-control browser run passed; the final 69-control oracle adds a custom owner read-action positive without changing earlier expectations.','The first sandbox browser server startup failed with EADDRINUSE at port 0 before browser execution; the authorized loopback/Chromium replay then passed. This setup failure is not counted as negative semantic evidence.'],
 'artifactPackaging':'Archive includes selected sources, oracle/fixture, runtime receipts, proof formulas/models, mutation diffs/logs/results/focused module copies. It excludes full copied mutant source trees and node_modules.'
}
(base/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(base/'review.md').write_text('No blocking finding within the private complete supplied-population scan scope.\n\n69 independently authored controls pass in Bun and Chromium with exact parity. Eight actual source weakenings are detected. Original focused scan/collection/action tests pass 27/27 with 198 assertions. Ten conditional formal queries replay: 6 UNSAT and 4 SAT. All 77 selected pins remain unchanged.\n\nThe cut completeness and trust flags remain external premises. The operation supplies no query/compiler/native credential or P03/B08 promotion. The parent whole gate was still running when this review was finalized.\n')
files=[]
for p in sorted(base.rglob('*')):
 if not p.is_file() or p.is_symlink() or 'node_modules' in p.parts or p.name in ['review-archive.zip','archive.json','artifact-manifest.json']:continue
 rel=p.relative_to(base)
 if rel.parts[0]=='mutants':
  # Preserve the entire observed failure/result plus the single modified module and exact patch.
  if str(pathlib.Path(*rel.parts[2:])) not in ['src/extensions/security/catalog-runtime-candidate.ts','change.patch','run.log','results.json','run.ts','oracle.ts']:continue
 files.append(p)
manifest=[dict(path=str(p.relative_to(base)),sha256=sha(p),bytes=p.stat().st_size) for p in files]
(base/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(base/'artifact-manifest.json')
archive=base/'review-archive.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(base)))
result=dict(review=str(base/'review.json'),reviewSha256=sha(base/'review.json'),archive=str(archive),archiveSha256=sha(archive),archiveBytes=archive.stat().st_size,files=len(files),sourceCount=len(pins))
(base/'archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
