import pathlib,subprocess,shutil,hashlib,json,difflib
root=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=pathlib.Path(__file__).parent
rel='src/extensions/security/catalog-runtime-candidate.ts';original=(root/rel).read_text();baseline_sha=hashlib.sha256((root/rel).read_bytes()).hexdigest()
variants=[
 ('original',None,None,[]),
 ('truncate-population','candidates.map((row:any)=>({type:row.type,key:row.key}))','candidates.slice(0,1).map((row:any)=>({type:row.type,key:row.key}))',['every-target-once-original-fact-order','fieldfree-no-field-disclosure-demand','late-unknown-atomic']),
 ('duplicate-population','candidates.map((row:any)=>({type:row.type,key:row.key}))','candidates.concat(candidates.slice(0,1)).map((row:any)=>({type:row.type,key:row.key}))',['every-target-once-original-fact-order']),
 ('hardcode-read-action','action:owner?.disclosure?.readAction','action:"read"',['actual-owner-read-action-is-derived']),
 ('admit-caller-resource-member',"shape(request,['type','fields']);","shape(request,['type','fields'],['resources']);",['caller-resources']),
 ('omit-derived-aggregate-charge',"if(cut.facts.length+cut.graphs.length+candidates.length>cut.maxFacts)fail('Aggregate scan facts exhausted');",'', ['aggregate-derived-population-bound']),
 ('omit-late-unresolved-refusal',"if(rows.some(r=>r.decision==='indeterminate'||r.decision==='conflict'))fail('Collection decision is unresolved');",'', ['late-unknown-atomic','fieldfree-late-unknown-atomic','late-conflict-atomic']),
 ('omit-empty-target-preflight','if(!resourceTypes.has(id(target)))','if(false)',['empty-missing-original-coverage']),
 ('fieldfree-bypasses-permission','const rows:any[]=[];for(const resource of resources)',"if(scanPopulation&&request.fields.length===0)return freeze({status:'rendered',complete:false,authority:false,rows:resources.map(()=>[]),valueProfiles:[]});const rows:any[]=[];for(const resource of resources)",['fieldfree-keeps-row-read-filter','fieldfree-without-grants-is-empty','fieldfree-late-unknown-atomic'])
]
results=[]
for name,old,new,expected in variants:
 d=out/'mutants'/name;d.mkdir(parents=True,exist_ok=True);shutil.copytree(root/'src',d/'src',dirs_exist_ok=True)
 for folder in ['spec','native','node_modules']:
  (d/folder).symlink_to(root/folder,target_is_directory=True)
 s=original
 if old is not None:
  assert s.count(old)==1,(name,s.count(old));s=s.replace(old,new)
  (d/rel).write_text(s)
  (d/'change.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile=rel,tofile=rel)))
 shutil.copy2(out/'base-fixture.json',d/'base-fixture.json')
 (d/'oracle.ts').write_text((out/'oracle.ts').read_text().replace(str(root),str(d)))
 (d/'run.ts').write_text((out/'run.ts').read_text())
 p=subprocess.run(['/opt/homebrew/bin/bun',str(d/'run.ts')],capture_output=True,text=True,timeout=30,cwd=d);(d/'run.log').write_text(p.stdout+p.stderr)
 assert (d/'results.json').exists(),(name,p.returncode,p.stderr)
 rows=json.loads((d/'results.json').read_text())['rows'];failed=[r['id'] for r in rows if not r['passed']]
 assert len(rows)==69 and all(r['error'] is None for r in rows),(name,'setup or unexpected thrown error')
 assert (p.returncode==0 and failed==[]) if name=='original' else (p.returncode==1 and set(expected).issubset(failed)),(name,failed,expected)
 results.append(dict(name=name,observations=len(rows),expectedFailedRows=expected,failedRows=failed,detected=(name=='original' or set(expected).issubset(failed)),returncode=p.returncode,sourceSha256=hashlib.sha256((d/rel).read_bytes()).hexdigest(),baselineSha256=baseline_sha))
 (out/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results[-1]),flush=True)
assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==baseline_sha
