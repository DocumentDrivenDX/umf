import pathlib,re,hashlib,json,shutil,sys
root=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=pathlib.Path(__file__).parent
queue=['src/extensions/security/catalog-runtime-candidate.ts'];files=set()
while queue:
 rel=queue.pop()
 if rel in files:continue
 files.add(rel);p=root/rel
 if p.suffix!='.ts':continue
 for spec in re.findall(r'(?:from\s*|import\s*)[\'\"]([^\'\"]+)[\'\"]',p.read_text()):
  if not spec.startswith('.'):continue
  q=p.parent/spec
  found=next((x for x in [q,pathlib.Path(str(q)+'.ts'),pathlib.Path(str(q)+'.json'),q/'index.ts'] if x.is_file()),None)
  if found:queue.append(str(found.resolve().relative_to(root.resolve())))
files.update(['src/index.ts','bun.lock','tests/security/catalog-scan.test.ts','tests/security/catalog-scan-corpus.ts','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md','docs/helix/02-design/technical-designs/TD-079-security-semantics.md','docs/helix/03-test/test-plans/STP-079-security-semantics.md'])
pins={rel:hashlib.sha256((root/rel).read_bytes()).hexdigest() for rel in sorted(files)}
label=sys.argv[1] if len(sys.argv)>1 else 'before'
(out/('source-pins-'+label+'.json')).write_text(json.dumps(pins,indent=2)+'\n')
if label=='before':
 for rel in pins:
  p=out/'captured-sources'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/rel,p)
else:
 old=json.loads((out/'source-pins-before.json').read_text());assert pins==old,{rel for rel in pins if old.get(rel)!=pins[rel]}
print(json.dumps({'sourceCount':len(pins),'label':label}))
