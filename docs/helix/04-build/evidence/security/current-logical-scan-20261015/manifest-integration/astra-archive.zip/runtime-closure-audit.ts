import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
const root='/Users/erik/.codex/worktrees/security-main-integration/umf',out='/private/tmp/logical-scan-manifest-integration-astra-20261015';
const cases=JSON.parse(fs.readFileSync(root+'/docs/helix/03-test/security/cases.json','utf8'));
const results=[];
for(const [id,prefix]of [['pg-raw.P04','pg18-mask-write'],['pg-raw.P08','pg18-stored-token']]){
 const seen=new Set<string>(),edges:any[]=[],external=new Set<string>();
 const transpiler=new Bun.Transpiler({loader:'ts'});
 function walk(file:string){file=path.resolve(file);if(!file.startsWith(root+'/'))throw Error('outside');if(seen.has(file))return;seen.add(file);if(!/\.[jt]s$/.test(file))return;
  const imports=transpiler.scan(fs.readFileSync(file,'utf8')).imports;
  for(const imp of imports){if(!imp.path.startsWith('.')){external.add(imp.path);continue;}const base=path.resolve(path.dirname(file),imp.path);const f=[base,base+'.ts',base+'.json',path.join(base,'index.ts')].find(p=>fs.existsSync(p)&&fs.statSync(p).isFile());if(!f)throw Error('unresolved '+file+' '+imp.path);edges.push({from:path.relative(root,file),to:path.relative(root,f),kind:imp.kind});walk(f);}
 }
 walk(root+'/tests/security/native/'+prefix+'-declarations.ts');
 const c=cases.cases.find((x:any)=>x.id===id),bound=new Set([c.testSource,c.oracleSource,...c.implementationSources]);
 const sources=[...seen].map(p=>path.relative(root,p)).sort(),missing=sources.filter(p=>!bound.has(p));if(missing.length)throw Error(JSON.stringify({id,missing}));
 results.push({id,runtimeStaticSources:sources.length,missing,external:[...external].sort(),edges,sourceDigests:Object.fromEntries(sources.map(p=>[p,createHash('sha256').update(fs.readFileSync(root+'/'+p)).digest('hex')]))});
}
fs.writeFileSync(out+'/runtime-closure-audit.json',JSON.stringify({method:'Independent Bun compiler import scan traverses actual static/runtime literal imports; erased type-only imports and explicit Python/SQL roots are checked separately against runner inventory.',results},null,2)+'\n');console.log(JSON.stringify(results.map(x=>({id:x.id,runtimeStaticSources:x.runtimeStaticSources,missing:x.missing}))));
