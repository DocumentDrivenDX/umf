const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root='/Users/erik/.codex/worktrees/security-main-integration/umf';
const ts=require(root+'/node_modules/typescript/lib/typescript.js');
const out='/private/tmp/logical-scan-manifest-integration-astra-20261015';
const cases=JSON.parse(fs.readFileSync(root+'/docs/helix/03-test/security/cases.json'));
const changes=JSON.parse(fs.readFileSync(out+'/case-comparison.json')).changes;
const inputs=[['pg-raw.P04','pg18-mask-write',['tests/security/native/pg18-mask-write.py','tests/security/native/pg18-mask-write.sql','tests/security/native/pg18-mask-write-oracle.py','package.json','bun.lock']],['pg-raw.P08','pg18-stored-token',['tests/security/native/pg18-stored-token.py','tests/security/native/pg18-stored-token.sql','tests/security/native/pg18-stored-token-oracle.py','tests/security/native/pg-raw-membership.sql','package.json','bun.lock']]];
const results=[];
for(const [id,prefix,extra] of inputs){
 const seen=new Set(),edges=[],outside=new Set(),unsupported=[];
 function walk(p){p=path.resolve(p);if(!p.startsWith(root+'/'))throw Error('outside root');if(seen.has(p))return;seen.add(p);if(!/\.[jt]s$/.test(p))return;
  const source=ts.createSourceFile(p,fs.readFileSync(p,'utf8'),ts.ScriptTarget.Latest,true);
  function visit(n){let spec;
   if(ts.isImportDeclaration(n)||ts.isExportDeclaration(n)){spec=n.moduleSpecifier;}
   else if(ts.isImportEqualsDeclaration(n)&&ts.isExternalModuleReference(n.moduleReference))spec=n.moduleReference.expression;
   else if(ts.isCallExpression(n)&&(n.expression.kind===ts.SyntaxKind.ImportKeyword||ts.isIdentifier(n.expression)&&n.expression.text==='require')){if(n.arguments.length===1&&ts.isStringLiteral(n.arguments[0]))spec=n.arguments[0];else unsupported.push({file:p,offset:n.pos});}
   if(spec&&ts.isStringLiteral(spec)){const s=spec.text;if(!s.startsWith('.'))outside.add(s);else {const base=path.resolve(path.dirname(p),s),found=[base,base+'.ts',base+'.json',path.join(base,'index.ts')].find(f=>fs.existsSync(f)&&fs.statSync(f).isFile());if(!found)throw Error('unresolved '+s+' in '+p);edges.push({from:path.relative(root,p),to:path.relative(root,found)});walk(found);}}
   ts.forEachChild(n,visit);
  }visit(source);
 }
 walk(root+'/tests/security/native/'+prefix+'-declarations.ts');
 const all=[...new Set([...seen].map(p=>path.relative(root,p)).concat(extra))].sort(),c=cases.cases.find(x=>x.id===id),bound=[...new Set([c.testSource,c.oracleSource,...c.implementationSources])].sort();
 const missing=all.filter(p=>!bound.includes(p)),extraBindings=bound.filter(p=>!all.includes(p));
 if(missing.length||extraBindings.length||unsupported.length)throw Error(JSON.stringify({id,missing,extraBindings,unsupported}));
 const added=changes.find(x=>x.case===id).added;
 results.push({id,status:'exact-selected-static-closure',totalSources:all.length,missing,extraBindings,unsupported,externalModuleSpecifiers:[...outside].sort(),addedEdges:edges.filter(e=>added.includes(e.to)),sourceDigests:Object.fromEntries(all.map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(root+'/'+p)).digest('hex')]))});
}
fs.writeFileSync(out+'/closure-audit.json',JSON.stringify({method:'Independent TypeScript AST import/export/require/dynamic-literal traversal, including type-only imports, plus explicit native Python/SQL/package roots. External runtime dependency closure remains the native runner responsibility.',results},null,2)+'\n');console.log(JSON.stringify(results.map(x=>({id:x.id,status:x.status,totalSources:x.totalSources,missing:x.missing,extraBindings:x.extraBindings,unsupported:x.unsupported}))));
