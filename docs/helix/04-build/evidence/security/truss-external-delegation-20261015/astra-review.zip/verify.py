from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent;run=Path('/private/tmp/truss-external-protection-facade-20261015');root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((run/'receipt.json').read_text());pins=json.loads((run/'snapshot-pins.json').read_text());checks=[]
def check(name,result):checks.append({'name':name,'passed':bool(result)});assert result,name
check('retained-test-passed',r['passed'] is True and 'Ran 1 test in 12.029s\n\nOK' in (run/'unittest.log').read_text())
check('all-retained-snapshot-pins-match',len(pins)==1142 and all(sha((run/'original'/k).read_bytes())==v for k,v in pins.items()))
check('activation-returned-original-success',r['activationOutcome'].startswith('Ok(value=CurrentQueryProtection('))
check('ordinary-direct-object-select-false',r['ordinaryRawTableSelect'] is False)
rows=r['externalWrapperRows'];check('six-raw-property-bags',len(rows)==6 and all(type(x) is dict for x in rows))
r2=[x for x in rows if x.get('9')=={'kind':'string','text':'r2'}]
check('denied-r2-exact-salary-observed',len(r2)==1 and r2[0].get('10')=={'kind':'integer','text':'9007199254740993'} and r2[0].get('11')=={'kind':'string','text':'opaque-two'})
assignment=[x for x in rows if x.get('2')=={'kind':'string','text':'a1'}]
check('private-assignment-properties-observed',len(assignment)==1 and assignment[0].get('1')=={'kind':'boolean','value':True} and assignment[0].get('3')=={'kind':'string','text':'p1'} and assignment[0].get('4')=={'kind':'string','text':'alice'})
check('retained-runtime-lease-directory-cleanup',all(r[k] is True for k in ('originalRuntimeStopped','leaseReleased','testDirectoryAbsent')))
fixture='docs/helix/02-design/contracts/bindings/acceptance-input-capacity-v0.1.fixture.json';check('binding-fixture-not-covered-by-original-pinmap',fixture not in pins and (run/'original'/fixture).exists())
selected=['packages/python/src/truss/_current_query_protection.py','packages/python/tests/test_current_query_runtime_native.py','packages/python/tests/test_current_query_full_sources_native.py','packages/python/tests/test_current_query_subjects_native.py','packages/python/tests/test_catalog_runtime_native.py']
record={'snapshot':'Uncommitted working snapshot; not a fixed release or main commit','snapshotPinCount':len(pins),'snapshotPinFileSha256':sha((run/'snapshot-pins.json').read_bytes()),'selectedSnapshotPins':{k:pins[k] for k in selected},'separatelyCopiedBindingFixtureObservedNow':{fixture:sha((run/'original'/fixture).read_bytes())},'retainedArtifacts':{str(f):sha(f.read_bytes()) for f in [Path('/private/tmp/probe-external-protection-facade.py'),run/'receipt.json',run/'unittest.log']},'governingArtifacts':{k:sha((root/k).read_bytes()) for k in ['docs/helix/02-design/contracts/CONTRACT-063-security-enforcement.md','docs/helix/01-frame/user-stories/US-056-security-bindings.md']}}
(p/'source-pins.json').write_text(json.dumps(record,indent=2)+'\n');(p/'verification.json').write_text(json.dumps({'status':'passed','checks':checks,'count':len(checks),'nativeReplayPerformed':False,'scope':'Independent inspection of retained native observations and source snapshot; no retrospective before-run pin or executable attestation is claimed.'},indent=2)+'\n')
for source,target in [(Path('/private/tmp/probe-external-protection-facade.py'),'probe.py'),(run/'receipt.json','parent-receipt.json'),(run/'unittest.log','parent-unittest.log')]: (p/target).write_bytes(source.read_bytes())
print(json.dumps({'checks':len(checks),'snapshotPinsMatched':len(pins),'nativeReplay':False}))
