-- Administrative connected staging + complete typed effect verification.
-- Caller-owned transaction; no public acceptance or committed publication.
CREATE FUNCTION truss.runtime_stage_catalog_records_checked_candidate(
 issued_ordinal bigint,definition_bytes bytea,input_bytes bytea,candidate_bytes bytea,
 obligation_bytes bytea,group_bytes bytea,documents_bytes bytea,declarations_bytes bytea,
 origin_bytes bytea,original_prestate bytea,original_context bytea,configuration_profile bytea)
RETURNS TABLE(writer_xid text,ordinal text,context_hex text,provisional_result_hex text)
LANGUAGE plpgsql VOLATILE SECURITY INVOKER SET search_path=pg_catalog,pg_temp AS $$
DECLARE relation record; stores oid[]; identities text[]; captured jsonb:='{}'; actual jsonb;
 wire_rows jsonb; raw_bytes bigint:=0; stage_result record; index_value int; final_graph record; result jsonb; before_topology jsonb; after_topology jsonb; before_op bytea; before_config bytea;
BEGIN
 IF current_user IS DISTINCT FROM session_user OR NOT EXISTS(SELECT 1 FROM pg_roles WHERE rolname=current_user AND rolsuper) THEN
  RAISE EXCEPTION 'administrative checked staging only' USING ERRCODE='42501'; END IF;
SELECT jsonb_agg(jsonb_build_array(c.oid::text,c.relname,c.relkind::text,c.relispartition,c.relrowsecurity,coalesce(pg_get_partkeydef(c.oid),''),coalesce((SELECT jsonb_agg(jsonb_build_array(i.inhparent::text,i.inhseqno::text) ORDER BY i.inhseqno) FROM pg_inherits i WHERE i.inhrelid=c.oid),'[]'::jsonb)) ORDER BY c.oid) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='truss' AND c.relkind IN ('r','p','f','v','m') INTO before_topology;
 IF EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE n.nspname='truss' AND ((c.relname IN
   ('schema_rev','schema_doc','type_def','prop_def','key_def','rel_def','relationship_lineage','rel_endpoint') AND c.relkind<>'r')
   OR (c.relkind='r' AND (c.relrowsecurity OR EXISTS(
   SELECT 1 FROM pg_inherits i WHERE i.inhparent=c.oid OR i.inhrelid=c.oid))))) THEN
  RAISE EXCEPTION 'selected flat non-RLS catalog and complement relations required' USING ERRCODE='0A000'; END IF;
 -- Capture the complete unchanged complement before any catalog effects.
 -- The operation registry has a separately checked, planned generation change.
 FOR relation IN SELECT c.oid,c.relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE n.nspname='truss' AND c.relkind='r' AND c.relname NOT IN
   ('schema_rev','schema_doc','type_def','prop_def','key_def','rel_def','relationship_lineage','rel_endpoint','row_home_operation')
  ORDER BY c.relname COLLATE "C" LOOP
  IF coalesce(cardinality(stores),0)>=128 THEN RAISE EXCEPTION 'complement relation capacity' USING ERRCODE='54000'; END IF;
  EXECUTE format('LOCK TABLE ONLY truss.%I IN SHARE MODE NOWAIT',relation.relname);
  EXECUTE format('SELECT coalesce(jsonb_agg(encode(record_send(r),''hex'') ORDER BY encode(record_send(r),''hex'') COLLATE "C"),''[]''::jsonb) FROM (SELECT * FROM ONLY truss.%I LIMIT 4097) r',relation.relname) INTO wire_rows;
  IF jsonb_array_length(wire_rows)>4096 THEN RAISE EXCEPTION 'complement row capacity' USING ERRCODE='54000'; END IF;
  raw_bytes:=raw_bytes+octet_length(wire_rows::text);
  IF raw_bytes>33554432 THEN RAISE EXCEPTION 'complement carrier capacity' USING ERRCODE='54000'; END IF;
  stores:=array_append(stores,relation.oid); identities:=array_append(identities,relation.relname);
  captured:=jsonb_set(captured,ARRAY[relation.relname],wire_rows);
 END LOOP;
 SELECT * INTO STRICT stage_result FROM truss.runtime_stage_catalog_with_release(
  issued_ordinal,definition_bytes,input_bytes,candidate_bytes,obligation_bytes,group_bytes,
  documents_bytes,declarations_bytes,origin_bytes,original_prestate,original_context,configuration_profile);
 SELECT record_send(o) INTO STRICT before_op FROM truss.row_home_operation o WHERE o.original_writer_xid=pg_current_xact_id_if_assigned() AND o.operation_ordinal=issued_ordinal;
 SELECT record_send(c) INTO STRICT before_config FROM truss.operation_configuration c WHERE c.original_writer_xid=pg_current_xact_id_if_assigned() AND c.operation_ordinal=issued_ordinal;
 PERFORM truss.runtime_verify_fresh_catalog_records_candidate(declarations_bytes,documents_bytes,origin_bytes);
 FOR index_value IN 1..cardinality(stores) LOOP
  IF to_regclass(format('truss.%I',identities[index_value])) IS DISTINCT FROM stores[index_value] THEN
   RAISE EXCEPTION 'original complement relation identity required' USING ERRCODE='55000'; END IF;
  EXECUTE format('SELECT coalesce(jsonb_agg(encode(record_send(r),''hex'') ORDER BY encode(record_send(r),''hex'') COLLATE "C"),''[]''::jsonb) FROM (SELECT * FROM ONLY truss.%I LIMIT 4097) r',identities[index_value]) INTO actual;
  IF actual IS DISTINCT FROM captured->identities[index_value] THEN
   RAISE EXCEPTION 'unchanged catalog complement % required',identities[index_value] USING ERRCODE='55000'; END IF;
 END LOOP;
 result:=convert_from(decode(stage_result.provisional_result_hex,'hex'),'UTF8')::jsonb;
 SELECT * INTO STRICT final_graph FROM truss.runtime_collect_configured_catalog_graph();
 SELECT jsonb_agg(jsonb_build_array(c.oid::text,c.relname,c.relkind::text,c.relispartition,c.relrowsecurity,coalesce(pg_get_partkeydef(c.oid),''),coalesce((SELECT jsonb_agg(jsonb_build_array(i.inhparent::text,i.inhseqno::text) ORDER BY i.inhseqno) FROM pg_inherits i WHERE i.inhrelid=c.oid),'[]'::jsonb)) ORDER BY c.oid) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='truss' AND c.relkind IN ('r','p','f','v','m') INTO after_topology;
 IF EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE n.nspname='truss' AND ((c.relname IN
   ('schema_rev','schema_doc','type_def','prop_def','key_def','rel_def','relationship_lineage','rel_endpoint') AND c.relkind<>'r')
   OR (c.relkind='r' AND (c.relrowsecurity OR EXISTS(
   SELECT 1 FROM pg_inherits i WHERE i.inhparent=c.oid OR i.inhrelid=c.oid))))) THEN
  RAISE EXCEPTION 'selected flat non-RLS catalog and complement relations required' USING ERRCODE='0A000'; END IF;
 IF before_topology IS DISTINCT FROM after_topology OR to_jsonb(final_graph) IS DISTINCT FROM result->'reportSources'->'end'
  OR (SELECT record_send(o) FROM truss.row_home_operation o WHERE o.original_writer_xid=pg_current_xact_id_if_assigned() AND o.operation_ordinal=issued_ordinal) IS DISTINCT FROM before_op
  OR (SELECT record_send(c) FROM truss.operation_configuration c WHERE c.original_writer_xid=pg_current_xact_id_if_assigned() AND c.operation_ordinal=issued_ordinal) IS DISTINCT FROM before_config THEN
  RAISE EXCEPTION 'original checked staging final cut required' USING ERRCODE='55000'; END IF;
 RETURN QUERY SELECT stage_result.writer_xid,stage_result.ordinal,stage_result.context_hex,stage_result.provisional_result_hex;
END;
$$;
REVOKE ALL ON FUNCTION truss.runtime_stage_catalog_records_checked_candidate(bigint,bytea,bytea,bytea,bytea,bytea,bytea,bytea,bytea,bytea,bytea,bytea) FROM PUBLIC;
