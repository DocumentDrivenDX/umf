"""Installation-wide lockdown for the initial protected read-only query profile.

The host quiesces ordinary sessions and new connections until activation commits.
Legacy data interfaces stay unavailable until they have equivalent policy checks.
"""
import json
from psycopg import sql
from .execution import Error, ExecutionFailure
from .psycopg_host import PsycopgHost
from ._installation_privileges import installation_administrator_with_cursor
from ._current_query_sources import capture_current_query_sources_with_cursor
from ._current_query_subjects import _verify_helper
from .catalog_runtime import _pin_cursor
from .current_query import CurrentQueryProtection

_MARKER='truss.current_query_protection_marker()'
_METADATA=('truss.reader_catalog(integer,integer,text,text)',
           'truss.accepted_document(text,integer,text,text)')
_SUBJECT='truss.current_query_subject_current()'


def require_unprotected_configuration(cursor):
    """Serialize every supported regrant path with protection activation."""
    cursor.execute('LOCK TABLE ONLY truss.catalog_runtime_installation IN SHARE ROW EXCLUSIVE MODE NOWAIT',prepare=False)
    cursor.execute('SELECT pg_catalog.to_regprocedure(%s)',(_MARKER,),prepare=False)
    if cursor.fetchone()!=(None,):
        raise ValueError('Protected query installation requires an explicit protection migration')


def _body(sources):
    return 'SELECT '+sql.Literal(json.dumps({'profile':'truss-current-query-protection/0.1-candidate',
        'installation':sources.installation_id,'inventory':sources.inventory_digest},sort_keys=True,separators=(',',':'))).as_string()+'::pg_catalog.text'


def _owner(cursor):
    cursor.execute('''SELECT i.owner_oid,r.rolname::text FROM ONLY truss.catalog_runtime_installation i
        JOIN pg_catalog.pg_roles r ON r.oid=i.owner_oid JOIN pg_catalog.pg_namespace n ON n.nspname='truss' AND n.nspowner=r.oid
        WHERE i.singleton AND NOT r.rolcanlogin AND NOT r.rolsuper AND NOT r.rolcreaterole
        AND NOT r.rolcreatedb AND NOT r.rolreplication AND NOT r.rolbypassrls AND NOT r.rolinherit''',prepare=False)
    rows=cursor.fetchmany(2)
    if len(rows)!=1:raise ValueError('Unprivileged original runtime owner required')
    return rows[0]


def _private_homes(cursor,owner):
    cursor.execute('''SELECT EXISTS(SELECT 1 FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace
        WHERE n.nspname='truss' AND (c.relowner<>%s OR EXISTS(
        SELECT 1 FROM pg_catalog.aclexplode(coalesce(c.relacl,pg_catalog.acldefault(CASE WHEN c.relkind='S' THEN 's'::"char" ELSE 'r'::"char" END,c.relowner))) a
        WHERE a.grantee<>c.relowner OR a.grantor<>c.relowner OR a.is_grantable)
        OR EXISTS(SELECT 1 FROM pg_catalog.pg_attribute a WHERE a.attrelid=c.oid AND a.attacl IS NOT NULL)))''',(owner,),prepare=False)
    if cursor.fetchone()!=(False,):raise ValueError('Owner-only complete runtime relations and columns required')


def _allowed_oids(cursor,owner):
    allowed=[]
    for signature in (*_METADATA,_SUBJECT):
        cursor.execute('SELECT oid,proowner FROM pg_catalog.pg_proc WHERE oid=pg_catalog.to_regprocedure(%s)',(signature,),prepare=False)
        row=cursor.fetchone()
        if row is None or row[1]!=owner:raise ValueError('Complete exact protected metadata/Subject signatures required')
        allowed.append(row[0])
    if len(set(allowed))!=3:raise ValueError('Distinct protected facade signatures required')
    return allowed


def _ordinary_roles(cursor,registration):
    # Same effective role-state closure as native runtime_person, applied by the
    # trusted installer to enrolled LOGINs without impersonating SESSION_USER.
    for role,_ in registration.bindings:
        cursor.execute('''SELECT r.rolcanlogin AND NOT r.rolsuper AND NOT r.rolcreaterole AND NOT r.rolcreatedb
            AND NOT r.rolreplication AND NOT r.rolbypassrls AND NOT EXISTS(
            SELECT 1 FROM pg_catalog.pg_roles forbidden WHERE
            (forbidden.oid=(SELECT owner_oid FROM truss.catalog_runtime_installation WHERE singleton)
             OR forbidden.rolname IN ('pg_read_server_files','pg_write_server_files','pg_execute_server_program'))
            AND pg_catalog.pg_has_role(r.oid,forbidden.oid,'MEMBER')) FROM pg_catalog.pg_roles r WHERE r.oid=%s::oid''',(role,),prepare=False)
        if cursor.fetchone()!=(True,):raise ValueError('Original ordinary protected LOGIN required')
        cursor.execute('''WITH RECURSIVE role_states(active_oid,privilege_oid) AS (
            SELECT %s::oid,%s::oid UNION
            SELECT CASE WHEN m.admin_option OR (m.set_option AND s.active_oid=s.privilege_oid)
                THEN m.roleid ELSE s.active_oid END,m.roleid
            FROM pg_catalog.pg_auth_members m JOIN role_states s ON m.member=s.privilege_oid
            WHERE m.inherit_option OR m.admin_option OR (m.set_option AND s.active_oid=s.privilege_oid))
            SELECT EXISTS(SELECT 1 FROM (SELECT DISTINCT active_oid FROM role_states) s JOIN pg_catalog.pg_roles r ON r.oid=s.active_oid
                WHERE r.rolsuper OR r.rolcreaterole OR r.rolcreatedb OR r.rolreplication OR r.rolbypassrls
                OR pg_catalog.has_schema_privilege(r.oid,'truss','CREATE')
                OR EXISTS(SELECT 1 FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='truss'
                    AND ((c.relkind IN ('r','p','v','m','f') AND (pg_catalog.has_table_privilege(r.oid,c.oid,'SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER,MAINTAIN')
                        OR pg_catalog.has_any_column_privilege(r.oid,c.oid,'SELECT,INSERT,UPDATE,REFERENCES')))
                        OR (c.relkind='S' AND pg_catalog.has_sequence_privilege(r.oid,c.oid,'USAGE,SELECT,UPDATE')))))''',(role,role),prepare=False)
        if cursor.fetchone()!=(False,):raise ValueError('Ordinary protected roles cannot reach raw runtime authority')


def verify_current_query_protection(cursor,sources,registration):
    owner,_=_owner(cursor)
    if registration.owner_oid!=owner:raise ValueError('Same protected Subject/runtime owner required')
    _verify_helper(cursor,registration)
    cursor.execute('''SELECT p.prosrc,p.proowner,p.prosecdef,p.provolatile,p.proretset,p.prorettype::int,p.pronargs,l.lanname::text,p.proconfig
        FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_language l ON l.oid=p.prolang WHERE p.oid=pg_catalog.to_regprocedure(%s)''',(_MARKER,),prepare=False)
    if cursor.fetchone()!=(_body(sources),owner,False,'v',False,25,0,'sql',['search_path=pg_catalog, pg_temp']):
        raise ValueError('Committed original protected-query activation required')
    allowed=_allowed_oids(cursor,owner)
    cursor.execute('''SELECT EXISTS(SELECT 1 FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
        WHERE n.nspname='truss' AND (p.proowner<>%s OR EXISTS(
        SELECT 1 FROM pg_catalog.aclexplode(coalesce(p.proacl,pg_catalog.acldefault('f',p.proowner))) a
        WHERE a.grantor<>p.proowner OR a.is_grantable OR (a.grantee<>p.proowner
        AND (p.oid<>ALL(%s::oid[]) OR a.grantee=0)))))''',(owner,allowed),prepare=False)
    if cursor.fetchone()!=(False,):raise ValueError('Protected query requires closed ordinary routine grants')
    _private_homes(cursor,owner)
    _ordinary_roles(cursor,registration)


def activate_current_query_protection_in_transaction(host,transaction,*,subject_registration):
    """Quiesced trusted bootstrap; commit before opening protected callers.

    No commit, disconnection, implicit upgrade or regrant is performed here.
    """
    from .current_query import CurrentQuerySubjectRegistration
    if type(host) is not PsycopgHost or type(subject_registration) is not CurrentQuerySubjectRegistration:
        return Error(ExecutionFailure('execution_obligation','Original protection host and Subject registration required'))
    def activate(cursor,observed):
        _pin_cursor(cursor)
        cursor.execute("SELECT pg_catalog.current_setting('search_path')",prepare=False)
        prior=cursor.fetchone()[0]
        cursor.execute("SELECT pg_catalog.set_config('search_path','pg_catalog, pg_temp',true)",prepare=False)
        installation_administrator_with_cursor(cursor)
        require_unprotected_configuration(cursor)
        cursor.execute('''SELECT EXISTS(SELECT 1 FROM pg_catalog.pg_stat_activity WHERE datid=(SELECT oid FROM pg_catalog.pg_database WHERE datname=pg_catalog.current_database())
            AND pid<>pg_catalog.pg_backend_pid() AND backend_type='client backend')''',prepare=False)
        if cursor.fetchone()!=(False,):raise ValueError('Quiesce all ordinary sessions and new connections before activation')
        cursor.execute('LOCK TABLE pg_catalog.pg_authid,pg_catalog.pg_auth_members IN SHARE MODE NOWAIT',prepare=False)
        sources=capture_current_query_sources_with_cursor(cursor)
        if sources.query_originals is None:raise ValueError('Complete protected query originals required')
        owner,owner_name=_owner(cursor)
        installation_administrator_with_cursor(cursor,owner)
        _verify_helper(cursor,subject_registration)
        if (subject_registration.owner_oid,subject_registration.installation_id,subject_registration.source_receipt)!=(owner,sources.installation_id,sources.source_receipt):
            raise ValueError('Original protected Subject/source correspondence required')
        _private_homes(cursor,owner)
        allowed=_allowed_oids(cursor,owner)
        cursor.execute(sql.SQL('CREATE FUNCTION truss.current_query_protection_marker() RETURNS text LANGUAGE sql VOLATILE SECURITY INVOKER SET search_path=pg_catalog,pg_temp AS {}').format(sql.Literal(_body(sources))),prepare=False)
        cursor.execute(sql.SQL('ALTER FUNCTION truss.current_query_protection_marker() OWNER TO {}').format(sql.Identifier(owner_name)),prepare=False)
        cursor.execute('REVOKE ALL ON FUNCTION truss.current_query_protection_marker() FROM PUBLIC',prepare=False)
        cursor.execute('''SELECT p.proname::text,pg_catalog.pg_get_function_identity_arguments(p.oid),a.grantee,r.rolname::text
            FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
            CROSS JOIN LATERAL pg_catalog.aclexplode(coalesce(p.proacl,pg_catalog.acldefault('f',p.proowner))) a
            LEFT JOIN pg_catalog.pg_roles r ON r.oid=a.grantee WHERE n.nspname='truss' AND a.grantee<>p.proowner
            AND p.oid<>ALL(%s::oid[])
            ORDER BY p.oid,a.grantee''',(allowed,),prepare=False)
        grants=cursor.fetchmany(4097)
        if len(grants)>4096:raise ValueError('Bounded runtime grant inventory required')
        for name,args,grantee,role in grants:
            recipient=sql.SQL('PUBLIC') if grantee==0 else sql.Identifier(role)
            cursor.execute(sql.SQL('REVOKE ALL PRIVILEGES ON ROUTINE truss.{}({}) FROM {} CASCADE').format(sql.Identifier(name),sql.SQL(args),recipient),prepare=False)
        verify_current_query_protection(cursor,sources,subject_registration)
        cursor.execute("SELECT pg_catalog.set_config('search_path',%s,true)",(prior,),prepare=False)
        if cursor.fetchone()!=(prior,):raise ValueError('Protection installation search path restoration required')
        return CurrentQueryProtection(sources.installation_id,sources.inventory_digest)
    return host._run_operation(transaction,activate)
