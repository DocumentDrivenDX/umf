import {createHash} from 'node:crypto';
import {compileCandidateCatalogProgram} from './reconstructed-umf/src/extensions/security/catalog-program-candidate';
import {evaluateCandidateCatalogReadDisclosureBatchWithinOperation as produce} from './reconstructed-umf/src/extensions/security/catalog-runtime-candidate';
import {CandidateSecurityOperationBudget} from './reconstructed-umf/src/extensions/security/operation-budget-candidate';
import {inspectSecurityDisclosureV2,encodeSecurityDisclosureV2,decodeSecurityDisclosureV2} from './reconstructed-umf/src/extensions/security/protection/disclosure';
const root=import.meta.dir;
const inputs=await Bun.file(root+'/replay-inputs.json').json();
const canonical=(x:any):string=>x&&typeof x==='object'?Array.isArray(x)?'['+x.map(canonical).join(',')+']':'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x);
const hash=(x:any)=>createHash('sha256').update(canonical(x)).digest('hex');
const checks:any[]=[];const output:any[]=[];
const ck=(id:string,actual:any,expected:any)=>checks.push({id,passed:canonical(actual)===canonical(expected),actualSha256:hash(actual),expectedSha256:hash(expected)});
for(const x of inputs){
 const p=x.packet,s=p.source,o=x.record,tag=`${x.operationIndex}:${x.id}:${x.negative}`;
 const fresh=produce(compileCandidateCatalogProgram(s.policy,s.catalog,s.closure,s.ontology),s.owner,p.cut,p.selection,new CandidateSecurityOperationBudget(100000));
 ck(tag+':fresh-actual-atomic-producer',fresh,p.result);
 const original=inspectSecurityDisclosureV2(fresh.batch,s.policy,s.catalog,s.closure);
 ck(tag+':fresh-producer-whole-v2',original.status,'validated-disclosure');
 const rec:any={operationIndex:x.operationIndex,id:x.id,negative:x.negative,freshProducerSha256:hash(fresh),codecs:[]};
 if(o.nativeBatch){
  const inspected=inspectSecurityDisclosureV2(o.nativeBatch,s.policy,s.catalog,s.closure);
  ck(tag+':exact-recorded-whole-v2-inspection',inspected,o.publicInspection);
  ck(tag+':whole-v2-false-authority',[inspected.authority,inspected.complete],[false,false]);
  for(const format of ['json','yaml'] as const){
   if(x.negative==='invalid-selected-occurrence'){
    let encodedRefused=false;try{encodeSecurityDisclosureV2(o.nativeBatch,s.policy,s.catalog,s.closure,format);}catch{encodedRefused=true;}
    ck(tag+':'+format+':encoding-refuses-invalid-selection',encodedRefused,true);
    let decodedRefused=false;
    // JSON is a legal YAML subset; both decoder channels must still reject the invalid selected occurrence.
    try{decodeSecurityDisclosureV2(JSON.stringify(o.nativeBatch),s.policy,s.catalog,s.closure,format);}catch{decodedRefused=true;}
    ck(tag+':'+format+':decoding-refuses-invalid-selection',decodedRefused,true);
    rec.codecs.push({format,encodedRefused,decodedRefused});
   }else{
    const text=encodeSecurityDisclosureV2(o.nativeBatch,s.policy,s.catalog,s.closure,format);
    const decoded=decodeSecurityDisclosureV2(text,s.policy,s.catalog,s.closure,format);
    ck(tag+':'+format+':exact-native-batch-roundtrip',decoded,o.nativeBatch);
    ck(tag+':'+format+':exact-original-producer-batch',decoded,p.result.batch);
    rec.codecs.push({format,text,decodedSha256:hash(decoded)});
   }
  }
 }
 output.push(rec);
}
const report={status:checks.every(c=>c.passed)?'passed':'failed',count:checks.length,checks,observations:output,nativeDatabaseExecuted:false,scope:'Fresh actual atomic producer plus whole V2/JSON/YAML non-database replay from archived source bytes against the supplied native receipt; external Bun/Ajv/YAML runtime is recorded separately and not hermetic.'};
await Bun.write(root+'/v2-codec-replay.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,checks:checks.length,operations:output.length,failures:checks.filter(c=>!c.passed).map(c=>c.id)}));
if(report.status!=='passed')process.exit(1);
