from pathlib import Path
import json,hashlib,subprocess,zipfile
R=Path(__file__).resolve().parent
inputs=json.loads((R/'replay-inputs.json').read_text());checks=[]
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(b):return hashlib.sha256(b).hexdigest()
def ck(id,a,e):checks.append({'id':id,'passed':type(a)==type(e)and a==e,'actualSha256':sha(canonical(a).encode()),'expectedSha256':sha(canonical(e).encode())})
for x in inputs:
 i=str(x['operationIndex']);p=x['packet'];s=p['source'];o=x['record'];q=json.loads(o['requestJson']);prep=json.loads(o['preparationJson']);opaque={v['role']:v for v in q['opaqueSources']};profile=json.loads(opaque['presence-designation']['utf8'])
 ck(i+':exact-six-opaque-roles',sorted(opaque),['catalog','native-binding','ontology','owner','policy','presence-designation'])
 for role,entry in opaque.items():
  ck(i+':opaque-digest:'+role,sha(entry['utf8'].encode()),entry['sha256']);ck(i+':opaque-media:'+role,entry['mediaType'],'application/json')
 for role in ['policy','catalog','ontology','owner']:
  e=opaque[role];ck(i+':exact-original-opaque-bytes:'+role,e['utf8'],p['sourceBytes'][role]['utf8']);ck(i+':original-opaque-digest:'+role,e['sha256'],p['sourceBytes'][role]['sha256']);ck(i+':actual-source-object:'+role,json.loads(e['utf8']),s[role])
  identity={'documentId':s[role].get('id',s[role].get('documentId')),'revision':s[role]['revision']};ck(i+':identity:'+role,e['identity'],identity)
 ck(i+':exact-profile-source-pins',profile['sources'],[{k:opaque[role][k]for k in ['role','identity','sha256']}for role in ['policy','catalog','ontology','owner']])
 ck(i+':profile-issued-exact',prep['sourceProfileJson'],opaque['presence-designation']['utf8']);ck(i+':profile-binding-issued',prep['binding'],profile['binding']);ck(i+':profile-native-source-sha',profile['binding']['sha256'],opaque['native-binding']['sha256'])
 ck(i+':fixture-explicitly-unadmitted',profile['binding']['targetProfile'],'unadmitted-fixture')
 ck(i+':exact-producer-profile',profile['producer'],{'protocol':'umf.security.logical-disclosure-batch/0.1-candidate','entrypoint':'evaluateCandidateCatalogReadDisclosureBatchWithinOperation'})
 ck(i+':primary-action-read',profile['primaryAction'],'read');ck(i+':request-read-projection',q['sql'],'SELECT r.token FROM Resource r');ck(i+':request-no-parameters',q['parameters'],{})
 ck(i+':model-count',len(q['modules']),1)
 mod=q['modules'][0];ck(i+':model-source-bytes-digest',sha(mod['documentJson'].encode()),mod['pin']['sha256']);ck(i+':exact-source-model',json.loads(mod['documentJson']),s['closure']['documents'][0]['document']);ck(i+':model-revision',mod['pin']['revision'],s['closure']['documents'][0]['revision']);ck(i+':profile-model-pin',profile['modelPins'],[mod['pin']])
 decisions=p['result']['decisions'];permitted=[d for d in decisions if d['decision']=='permit'];ck(i+':canonical-permit-resource-order',[d['resource']for d in permitted],p['result']['resources'])
 ck(i+':result-source-identities',p['result']['sources'],{'policy':{'id':s['policy']['id'],'revision':s['policy']['revision']},'ontology':{'documentId':s['ontology']['documentId'],'revision':s['ontology']['revision']},'protection':{'id':s['catalog']['id'],'revision':s['catalog']['revision']},'domains':s['closure']['pins'],'owner':{'id':s['owner']['id'],'revision':s['owner']['revision']},'generation':p['cut']['generation'],'readAction':'read'})
 for j,(d,cells)in enumerate(zip(permitted,p['result']['batch']['rows'])):
  disposition=d['dispositions'][0];cell=cells[0];occurrences=disposition['sourceOccurrences'];ck(i+':'+str(j)+':single-original-occurrence',occurrences,[{'ruleIndex':0,'disclosureIndex':1}])
  declaration=s['policy']['rules'][0]['disclosure'][1]
  ck(i+':'+str(j)+':original-field',declaration['field'],disposition['field'])
  fact=next(f for f in p['cut']['facts']if {'type':f['type'],'key':f['key']}==d['resource'])
  wire_disposition='absent'if declaration['disposition']['kind']=='original'and declaration['field']in fact['absent']else declaration['disposition']['kind']
  ck(i+':'+str(j)+':cell-disposition-from-original-policy-and-known-presence',cell['disposition'],wire_disposition)
  if cell['disposition']=='transformed':
   ck(i+':'+str(j)+':exact-selected-occurrence',cell['selection'],disposition['selectedOccurrence']);ck(i+':'+str(j)+':actual-selection',cell['selection'],{'ruleIndex':0,'disclosureIndex':1});ck(i+':'+str(j)+':pure-null-out',cell['value'],None)
  else:ck(i+':'+str(j)+':no-transform-selection',disposition['selectedOccurrence'],None)
 ck(i+':stored-token-header',p['result']['batch']['columns'],[{'field':{'documentId':'domain','moduleId':'m','elementId':'token'},'storageEffect':'stored-transformed','storageTransform':{'id':'vault','version':'1'}}])
 if x['id'].startswith('review-mixed'):
  ck(i+':mixed-full-census-order',[d['resource']['key'][0]['string']for d in decisions],['r3','r2','r5','r1','r4']);ck(i+':mixed-denied-native-absent',[d['resource']['key'][0]['string']for d in decisions if d['decision']=='deny'],['r2']);ck(i+':mixed-native-private-keys',{json.loads(k)['key'][0]['string']:True for k,c in o['expectedCapture']},{k:True for k in ['r3','r5','r1','r4']})
 if x['id'].startswith('review-empty'):ck(i+':empty-complete-census',decisions,[])
# Source endpoints and the reconstruction still match the captured bytes after all non-DB executions.
with zipfile.ZipFile(R/'supplied/source-inputs.zip')as z:
 m=json.loads(z.read('manifest.json'))
 for p,v in m.items():ck('post-replay-current:'+p,sha(Path(p).read_bytes()),v['sha256'])
 producer=json.loads(z.read(m['/private/tmp/umf-atomic-presence-handoff-r3-20261016/inputs.json']['entry']))
 for rel,h in producer['sourcePins'].items():ck('post-replay-reconstructed:'+rel,sha((R/'reconstructed-umf'/rel).read_bytes()),h)
for rel,h in json.loads((R/'external-runtime-files.json').read_text()).items():ck('external-runtime-post:'+rel,sha((R/'reconstructed-umf/node_modules'/rel).read_bytes()),h)
ck('executed-binary-post',sha((R/'sources/weft-presence-native-probe').read_bytes()),'fa9874ec3a25ed3662eee49fc45320c653f31e4042fbe3536f8faa9d8652e6a4')
r={'status':'passed'if all(c['passed']for c in checks)else'failed','count':len(checks),'failures':[c for c in checks if not c['passed']],'checks':checks,'scope':'Independent source/profile/census/occurrence correspondence, plus post-replay source and external runtime endpoints. Supplied logical trust flags are not native authentication.'}
(R/'provenance-audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='checks'}));raise SystemExit(0 if r['status']=='passed'else 1)
