from pathlib import Path
import ast,subprocess,sys,selectors,threading,time,json,os,signal
R=Path(__file__).parent;tree=ast.parse((R/'r4/frozen/runner.py').read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['encoded','send','receive','finish']];checks=[]
def check(label,e,a):
 if type(e)is not type(a) or e!=a:raise AssertionError(label)
ns={'selectors':selectors,'json':json,'time':time,'os':os,'check':check};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<exact-r4-io>','exec'),ns)
def child(code):return subprocess.Popen([sys.executable,'-c',code],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
def cleanup(p):
 if p.poll() is None:p.kill()
 p.wait()
 for f in [p.stdin,p.stdout,p.stderr]:
  try:f.close()
  except BrokenPipeError:pass

def case(name,code,fn,expected,seconds=1.0):
 p=child(code);start=time.monotonic();actual=None;value=None
 try:value=fn(p);actual='success'
 except Exception as e:actual=type(e).__name__
 elapsed=time.monotonic()-start;cleanup(p);ok=actual==expected and elapsed<seconds;checks.append({'id':name,'passed':ok,'actual':actual,'expected':expected,'elapsedSeconds':elapsed,'value':value})
recv=lambda p:ns['receive'](p,.2)
case('complete-fragmented','import sys,time;sys.stdout.write(\'{"ok":\');sys.stdout.flush();time.sleep(.03);print("true}",flush=True)',recv,'success')
case('no-first-byte','import time;time.sleep(30)',recv,'TimeoutError')
case('partial-first-byte','import sys,time;sys.stdout.write("{");sys.stdout.flush();time.sleep(30)',recv,'TimeoutError')
case('trickle-does-not-reset-deadline','import sys,time\nfor c in "{          ":\n sys.stdout.write(c);sys.stdout.flush();time.sleep(.06)',recv,'TimeoutError')
case('two-lines-same-write','import os;os.write(1,b"{}\\n{}\\n")',recv,'ValueError')
case('invalid-utf8','import os;os.write(1,b"\\xff\\n")',recv,'UnicodeDecodeError')
case('EOF-before-line','import sys;sys.stdout.write("{")',recv,'ValueError')
case('empty-EOF','pass',recv,'ValueError')
case('response-byte-limit','import sys;sys.stdout.buffer.write(b"x"*64000001+b"\\n");sys.stdout.flush()',lambda p:ns['receive'](p,5),'ValueError',6)
case('stalled-write','import time;time.sleep(30)',lambda p:ns['send'](p,{'payload':'x'*2000000},.2),'TimeoutError')
def roundtrip(p):
 ns['send'](p,{'payload':'é'*100000},2);v=ns['receive'](p,2);ns['finish'](p,0,2);assert v=={'length':100000};return v
case('complete-large-write','import sys,json;s=json.loads(sys.stdin.readline());print(json.dumps({"length":len(s["payload"])}),flush=True)',roundtrip,'success',5)
from types import SimpleNamespace
import io
r1,w1=os.pipe();r2,w2=os.pipe();held=SimpleNamespace(stdin=io.BytesIO(),stderr=os.fdopen(r1,'rb'),stdout=os.fdopen(r2,'rb'),wait=lambda timeout:0);start=time.monotonic();actual='success'
try:ns['finish'](held,0,.2)
except Exception as e:actual=type(e).__name__
finally:held.stderr.close();held.stdout.close();os.close(w1);os.close(w2)
checks.append({'id':'terminal-retained-pipe-writer','passed':actual=='TimeoutError' and time.monotonic()-start<1,'actual':actual,'scope':'Parent-owned open write ends model inherited pipes after process exit; no descendant process created.'})
case('terminal-nonempty-stderr','import sys;sys.stderr.write("unexpected")',lambda p:ns['finish'](p,0,.2),'AssertionError')
case('terminal-extra-stdout','print("unexpected")',lambda p:ns['finish'](p,0,.2),'AssertionError')
case('terminal-exit-mismatch','import sys;sys.exit(1)',lambda p:ns['finish'](p,0,.2),'AssertionError')
case('terminal-exit-timeout','import time;time.sleep(30)',lambda p:ns['finish'](p,0,.2),'TimeoutExpired')
report={'status':'passed' if all(c['passed'] for c in checks) else 'failed','count':len(checks),'checks':checks,'nativeExecuted':False};(R/'r4/io-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'],len(checks));print([c for c in checks if not c['passed']]);assert report['status']=='passed'
