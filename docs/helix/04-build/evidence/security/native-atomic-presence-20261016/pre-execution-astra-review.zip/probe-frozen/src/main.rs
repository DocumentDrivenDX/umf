//! Fixture-only line protocol. Holds the actual Core borrow across native I/O.
use std::io::{self,BufRead,Read,Write};
use serde::Deserialize;
use serde_json::{json,Value};
use weft_core::json::checked_json;
#[derive(Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
struct Start{request_json:String}
#[derive(Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
struct Binding{binding_json:String}
#[derive(Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
struct Check{frame_json:String}
fn line(input:&mut impl BufRead,maximum:usize)->Result<String,()>{
 let mut bytes=Vec::new();input.take(maximum as u64+1).read_until(b'\n',&mut bytes).map_err(|_|())?;
 if bytes.len()>maximum||bytes.pop()!=Some(b'\n'){return Err(())}String::from_utf8(bytes).map_err(|_|())
}
fn emit(value:Value)->Result<(),()>{let mut out=io::stdout().lock();serde_json::to_writer(&mut out,&value).map_err(|_|())?;out.write_all(b"\n").map_err(|_|())?;out.flush().map_err(|_|())}
fn run()->Result<(),()>{
 let stdin=io::stdin();let mut input=stdin.lock();
 let raw=line(&mut input,8_000_000)?;let start:Start=serde_json::from_value(checked_json(&raw).map_err(|_|())?).map_err(|_|())?;
 if start.request_json.len()>4_000_000{return Err(())}
 let original=weft_core::application_lineage::prepare(&start.request_json).map_err(|_|())?;
 let context=weft_core::current_presence::prepare(&original).map_err(|_|())?;
 emit(json!({"phase":"prepared","preparationJson":context.json(),"qualification":"source data only; native host authority required"}))?;
 let raw=line(&mut input,8_000_000)?;let binding:Binding=serde_json::from_value(checked_json(&raw).map_err(|_|())?).map_err(|_|())?;
 let artifact=weft_postgresql::current_presence::lower(&context,&binding.binding_json).map_err(|_|())?;
 emit(json!({"phase":"compiled","artifactJson":artifact.json()}))?;
 // These live lexical borrows and the exact supplied binding remain in this
 // same process while the native host executes and captures the complete rows.
 let raw=line(&mut input,32_000_000)?;let check:Check=serde_json::from_value(checked_json(&raw).map_err(|_|())?).map_err(|_|())?;
 let report=weft_postgresql::current_presence::check(&context,&binding.binding_json,&check.frame_json).map_err(|_|())?;
 emit(json!({"phase":"checked","reportJson":report}))
}
fn main(){if run().is_err(){let _=emit(json!({"phase":"refused","authority":false}));std::process::exit(1)}}
