# Fixture-only held-context presence probe

This is a private native-test harness, not a runtime SDK or admission service.
Run one process per original operation. Send exactly three newline-delimited JSON
commands: `{requestJson}`, `{bindingJson}`, `{frameJson}`. JSON string values retain
complete original UTF8; separator newlines are outside those strings. The process
emits prepared/preparationJson, compiled/artifactJson, then checked/reportJson.
The original typed ApplicationLineage, borrowed CurrentPresencePreparation and
compiled object remain alive across the host SQL execution and result capture.
The last command cannot replace the original request/context/binding. Any error
emits only a generic refusal, exits nonzero and grants no release permission.

Hosts own actual UMF batch validation, caller/source/Subject/current cut,
private native population completeness, source/statement/result custody, closing
checks, guarded release, cleanup and cancellation. Prepared/compiled/checked data
alone supplies none of those. No native query has yet executed through this probe.
Only disposable owned PostgreSQL18.6 fixtures may be used after source review and
serialized campaign coordination. Raw denied census is private host data.
