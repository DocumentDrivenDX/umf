from pathlib import Path
import ast,subprocess,sys,selectors,threading,time,json
R=Path(__file__).parent;tree=ast.parse((R/'frozen/runner.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='receive');ns={'selectors':selectors,'json':json};exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact-r2-receive>','exec'),ns)
child=subprocess.Popen([sys.executable,'-c',"import sys,time;sys.stdout.write('{');sys.stdout.flush();time.sleep(90)"],stdout=subprocess.PIPE);result={}
def reader():
 try:ns['receive'](child)
 except Exception as e:result['exception']=type(e).__name__
thread=threading.Thread(target=reader,daemon=True);start=time.monotonic();thread.start();thread.join(32);still_blocked=thread.is_alive();elapsed=time.monotonic()-start;child.kill();child.wait();thread.join(3);report={'configuredSelectTimeoutSeconds':30,'watchdogElapsedSeconds':elapsed,'stillBlockedAfterDeadline':still_blocked,'childBehavior':'Wrote one byte then withheld remaining line; no native DB/probe touched.','outcomeAfterReviewerKilledChild':result,'scope':'Exact frozen receive() extracted by AST. Modeled partial pipe response demonstrates deadline does not cover readline.'};(R/'partial-response-timeout.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert still_blocked
