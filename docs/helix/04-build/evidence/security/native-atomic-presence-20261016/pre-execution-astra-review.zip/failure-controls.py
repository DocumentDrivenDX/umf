from pathlib import Path
from types import SimpleNamespace
import ast,json,subprocess,uuid,zipfile,io,copy
R=Path(__file__).parent;source=(R/'frozen/runner.py').read_text();tree=ast.parse(source);last=tree.body[-1];assert isinstance(last,ast.Try);cleanup={};exec((R/'cleanup-frozen.py').read_text(),cleanup);results=[]
def simulate(case):
 name='umf-pg18-atomic-presence-'+str(uuid.uuid4());rid=name.split('presence-')[1];calls=[];out=R/'failure-models'/case;out.mkdir(parents=True,exist_ok=False);phase={'removed':False,'created':False};obs=[]
 def response(code=0,out='',err=''):return SimpleNamespace(returncode=code,stdout=out,stderr=err)
 def cmd(args,**kw):
  calls.append(args)
  if args[:4]==['docker','container','ls','-a']:return response(out=name+'\n' if case=='preexisting-name' else '')
  if args[:2]==['docker','run']:
   phase['created']=True
   if case=='create-timeout':raise subprocess.TimeoutExpired(args,30)
   return response(out='container-id\n')
  if args[:2]==['docker','exec']:return response()
  if args[:3]==['docker','image','inspect']:return response(out='sha256:image\n')
  if args[:2]==['docker','rm']:
   if case=='remove-fails':return response(1,'','daemon failed')
   phase['removed']=True;return response(out=name+'\n')
  if args[:2]==['docker','inspect']:
   if len(args)==3:
    if case=='post-remove-unknown':return response(1,'','daemon unavailable')
    return response(1,'[]\n','Error: No such object: '+name+'\n')
   fmt=args[-1]
   if fmt=='{{json .Mounts}}':return response(out=json.dumps([{'Type':'volume' if case=='unexpected-volume' else 'tmpfs','Destination':'/var/lib/postgresql'}]))
   if fmt=='{{.Image}}':return response(out='wrong' if case=='wrong-image' else 'sha256:image\n')
   if 'Config.Labels' in fmt:
    if case=='ownership-mismatch':return response(out='foreign\n')
    if case=='label-inspect-unknown':return response(1,'','daemon unavailable')
    return response(out=rid+'\n')
  raise AssertionError(args)
 def require(r):
  if r.returncode:raise RuntimeError(r.stderr)
  return r.stdout
 def check(label,expected,actual):
  obs.append({'id':label,'passed':type(expected) is type(actual) and expected==actual})
  if not obs[-1]['passed']:raise AssertionError(label)
 class T:
  def monotonic(self):return 0
  def sleep(self,x):raise AssertionError('Unexpected mock sleep')
 def execute(row,negative=None):
  if case=='operation-fails':raise ValueError('modeled native operation failure')
  operations.append({'id':row['id'],'negative':negative})
 operations=[];ns={'name':name,'run_id':rid,'attempted':False,'command':cmd,'require':require,'image':'pinned-image','os':__import__('os'),'password':'fixture','time':T(),'json':json,'result':{'status':'incomplete'},'check':check,'scalar':lambda _: {'number':'bad' if case=='wrong-engine' else '180006'},'sql':lambda _:None,'emitted':[{'id':'allowed:string'},{'id':'allowed:transformed-null'}],'execute':execute,'frozen':{},'pathlib':__import__('pathlib'),'sha':lambda _:None,'statements':[],'cleanup_ns':cleanup,'out':out,'zipfile':zipfile,'encoded':lambda x:json.dumps(x),'operations':operations,'observations':obs,'print':lambda *a:None}
 thrown=None
 try:exec(compile(ast.Module(body=[last],type_ignores=[]),'<frozen-native-try>','exec'),ns)
 except Exception as e:thrown=type(e).__name__
 receipt=json.loads((out/'receipt.json').read_text());removed=any(c[:2]==['docker','rm'] for c in calls);expected_status='native-atomic-presence-component-passed' if case=='success' else 'native-passed-cleanup-unverified' if case in ['remove-fails','post-remove-unknown','ownership-mismatch','label-inspect-unknown'] else 'failed';ok=receipt['status']==expected_status and removed==(case not in ['preexisting-name','ownership-mismatch','label-inspect-unknown'])
 if case in ['create-timeout','unexpected-volume','wrong-image','wrong-engine','operation-fails']:ok=ok and receipt['cleanup']['verified'] and thrown is not None
 if case=='preexisting-name':ok=ok and not receipt['cleanup']['attempted']
 if case in ['ownership-mismatch','label-inspect-unknown']:ok=ok and not receipt['cleanup']['verified']
 results.append({'id':case,'passed':ok,'thrown':thrown,'status':receipt['status'],'cleanup':receipt['cleanup'],'commands':calls,'nativeExecuted':False})
for case in ['success','create-timeout','preexisting-name','unexpected-volume','wrong-image','wrong-engine','operation-fails','ownership-mismatch','label-inspect-unknown','remove-fails','post-remove-unknown']:simulate(case)
(R/'failure-controls.json').write_text(json.dumps({'status':'passed' if all(x['passed'] for x in results) else 'failed','count':len(results),'observations':results,'qualification':'Exact frozen top-level native try/finally and cleanup helper executed with modeled command/SQL/probe behavior; no Docker or SQL execution.'},indent=2)+'\n');print(len(results),all(x['passed'] for x in results));print([x for x in results if not x['passed']]);assert all(x['passed'] for x in results)
