"""Actual compiled fixture probe, logical packets only: no database is executed."""
from pathlib import Path
import subprocess,json,hashlib,selectors,copy
ROOT=Path('/private/tmp/umf-native-atomic-presence-runner-astra-20261016')
BINARY=Path('/private/tmp/weft-presence-native-probe-target-20261016/debug/weft-presence-native-probe')
CASES=json.loads(Path('/private/tmp/weft-presence-lowering-r3-owner-20261016/tests/current-query-presence/fixtures/actual-atomic-transport.json').read_text())['cases']
EMITTED=json.loads(Path('/private/tmp/weft-presence-actual-emitted-r3-20261016.json').read_text())
REQUESTS={x['id']:x['request'] for x in CASES}
def encode(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def digest(text):return hashlib.sha256(text.encode()).hexdigest()
def send(p,value):p.stdin.write((encode(value)+'\n').encode());p.stdin.flush()
def read(p):
 s=selectors.DefaultSelector();s.register(p.stdout,selectors.EVENT_READ)
 try:
  if not s.select(30):raise AssertionError('Probe response timeout')
 finally:s.close()
 raw=p.stdout.readline(64_000_001);assert raw.endswith(b'\n') and len(raw)<=64_000_000
 return json.loads(raw)
def launch():return subprocess.Popen([str(BINARY)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def finish(p,code):
 p.stdin.close();assert p.wait(timeout=30)==code;assert p.stderr.read()==b'';assert p.stdout.read()==b''
import ast,os,time
runner=ast.parse((ROOT/'r5/frozen/runner.py').read_text())
def check(label,expected,actual):
 if type(expected) is not type(actual) or expected!=actual:raise AssertionError(label)
functions=[node for node in runner.body if isinstance(node,ast.FunctionDef) and node.name in ['encoded','send','receive','finish']]
exec(compile(ast.Module(body=functions,type_ignores=[]),'<exact-r5-io>', 'exec'),globals())
read=receive
observations=[]
for row in EMITTED:
 p=launch()
 try:
  request=encode(REQUESTS[row['id']]);send(p,{'requestJson':request});prepared=read(p);assert prepared['phase']=='prepared';assert digest(prepared['preparationJson'])==row['binding']['preparationSha256']
  binding=encode(row['binding']);send(p,{'bindingJson':binding});compiled=read(p);assert compiled['phase']=='compiled';assert json.loads(compiled['artifactJson'])==row['compiled'];assert digest(compiled['artifactJson'])==row['frame']['compiledArtifactSha256']
  frame=encode(row['frame']);send(p,{'frameJson':frame});checked=read(p);assert checked['phase']=='checked';actual=json.loads(checked['reportJson']);assert actual==row['report'];assert actual['authority'] is False;finish(p,0);observations.append({'id':row['id'],'matched':True,'nativeExecuted':False})
 finally:
  if p.poll() is None:p.kill();p.wait()
for name in ['import-report','wrong-binding','scalar-collapse','late-context-replacement']:
 row=EMITTED[0];p=launch()
 try:
  if name=='import-report':send(p,{'preparationJson':row['binding']['preparationSha256']})
  else:
   send(p,{'requestJson':encode(REQUESTS[row['id']])});assert read(p)['phase']=='prepared'
   binding=copy.deepcopy(row['binding'])
   if name=='wrong-binding':binding['preparationSha256']='0'*64
   send(p,{'bindingJson':encode(binding)})
   if name!='wrong-binding':
    assert read(p)['phase']=='compiled';frame=copy.deepcopy(row['frame'])
    if name=='scalar-collapse':frame['resultRows'][0][0]='null';send(p,{'frameJson':encode(frame)})
    else:send(p,{'frameJson':encode(frame),'requestJson':encode(REQUESTS[row['id']])})
  refusal=read(p);assert refusal=={'phase':'refused','authority':False};finish(p,1);observations.append({'id':name,'refused':True,'nativeExecuted':False})
 finally:
  if p.poll() is None:p.kill();p.wait()
receipt={'scope':'Live borrowed Rust probe protocol over actual supplied logical producer outputs; no database or native authority','binarySha256':hashlib.sha256(BINARY.read_bytes()).hexdigest(),'renderedPackets':41,'negativeControls':4,'observations':observations}
(ROOT/'r5/protocol-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'renderedPackets':41,'negativeControls':4,'passed':True,'nativeExecuted':False}))
