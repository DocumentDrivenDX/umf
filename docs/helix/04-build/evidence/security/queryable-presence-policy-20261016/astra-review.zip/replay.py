from pathlib import Path
import json,zipfile,hashlib,shutil,subprocess
r=Path(__file__).resolve().parent;e=r/'frozen/docs/helix/04-build/evidence/security/queryable-presence-policy-20261016';raw=zipfile.ZipFile(e/'inputs.zip').read('inputs.json');snap=json.loads(raw);receipt=json.loads((e/'receipt.json').read_text());h=lambda b:hashlib.sha256(b).hexdigest();assert h(raw)==receipt['inputSnapshotSha256'];assert len(snap['sources'])==len(snap['sourcePins'])==100 and len(snap['packets'])==44
repo=r/'reconstructed'
for p,s in snap['sources'].items():
 path=Path(p);assert not path.is_absolute()and'..'not in path.parts;assert h(s.encode())==snap['sourcePins'][p];d=repo/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(s)
assert (repo/'tools/security/query-presence-policy-oracle.ts').read_bytes()==(r/'frozen/tools/security/query-presence-policy-oracle.ts').read_bytes()
assert len(receipt['results'])==44 and len(receipt['controls'])==188 and all(v['passed']is True for v in receipt['controls'])
assert len({v['id']for v in receipt['controls']})==188
assert all(v['expected']==v['scan']and v['scan']['complete']is False and v['scan']['authority']is False for v in receipt['results'])
base=Path('/private/tmp/umf-native-presence-astra-20261016/reconstructed-r3/node_modules')
packages=['ajv','yaml','fast-deep-equal','fast-uri','json-schema-traverse','require-from-string']
for name in packages:
 dst=repo/'node_modules'/name
 if dst.exists():shutil.rmtree(dst)
 shutil.copytree(base/name,dst,symlinks=False)
assert all((repo/p).read_text()==s for p,s in snap['sources'].items())
extpins={str(p.relative_to(repo)):h(p.read_bytes())for name in packages for p in(repo/'node_modules'/name).rglob('*')if p.is_file()}
cmd=['/opt/homebrew/bin/bun','tools/security/query-presence-policy-oracle.ts',str(r/'independent-replay')]
p=subprocess.run(cmd,cwd=repo,capture_output=True,text=True);(r/'replay.stdout').write_text(p.stdout);(r/'replay.stderr').write_text(p.stderr);assert p.returncode==0,p.stderr
for name,expected in [('inputs.json',raw),('receipt.json',(e/'receipt.json').read_bytes())]:assert(r/'independent-replay'/name).read_bytes()==expected,name
assert all((repo/p).read_text()==s for p,s in snap['sources'].items())
assert extpins=={str(p.relative_to(repo)):h(p.read_bytes())for name in packages for p in(repo/'node_modules'/name).rglob('*')if p.is_file()}
(r/'external-executable-pins.json').write_text(json.dumps(extpins,indent=2)+'\n')
report={'status':'passed','command':cmd,'exitCode':p.returncode,'sourceCount':100,'scenarioCount':44,'controlCount':188,'allSnapshotPinsMatch':True,'exactByteReplayInputsAndReceipt':True,'sourcesBeforeAfterUnchanged':True,'externalCopiedFileCount':len(extpins),'externalAssumptions':snap['externalDependencyAssumptions'],'scope':'Independent actual logical evaluator replay from frozen source and authored packets; no database/compiled-query/host authority.'}
(r/'replay-execution.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
