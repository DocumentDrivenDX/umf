import {compileCandidateCatalogProgram} from './reconstructed/src/extensions/security/catalog-program-candidate';
import {evaluateCandidateCatalogScan} from './reconstructed/src/extensions/security/catalog-runtime-candidate';
const snap=await Bun.file(import.meta.dir+'/independent-replay/inputs.json').json();const source=JSON.parse(snap.sources['tests/security/protection/current-query-presence-source.json']);const ref=(elementId:string)=>({documentId:'domain',moduleId:'m',elementId});
const results:any[]=[];const c=(x:any):string=>x&&typeof x==='object'?Array.isArray(x)?'['+x.map(c).join(',')+']':'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+c(x[k])).join(',')+'}':JSON.stringify(x);
const fact=(p:any,type:string)=>p.cut.facts.find((f:any)=>f.type.elementId===type);const set=(f:any,name:string,value:any)=>f.fields.find((v:any)=>v.field.elementId===name).value=value;
function addId(p:any,type:string,idField:string,value:string){const f=structuredClone(fact(p,type));f.key=[{string:value}];f.fields=[{field:ref(idField),value:{string:value}}];p.cut.facts.push(f);}
function witness(p:any,type:string,idField:string,value:string){const f=structuredClone(fact(p,type));f.key=[{string:value}];set(f,idField,{string:value});p.cut.facts.push(f);}
function check(id:string,p:any,status:string,rows:any[],forged=false){let handle=compileCandidateCatalogProgram(p.policy,source.catalog,source.closure,source.ontology);if(forged)handle=JSON.parse(JSON.stringify(handle));const actual=evaluateCandidateCatalogScan(handle,p.owner,p.cut,{type:ref('Resource'),fields:[ref('token')]});const expected={status,complete:false,authority:false,rows,valueProfiles:[]};if(c(actual)!==c(expected))throw Error(id+': '+JSON.stringify(actual));results.push({id,actual});}
for(const state of['string','null','absent']){
 const original=snap.packets.find((p:any)=>p.variant==='allowed'&&p.state===state);const rows=[[{field:ref('token'),disposition:state==='absent'?'absent':'original',...(state==='absent'?{}:{value:state==='null'?null:{string:'opaque-token'}})}]];
 for(const label of['baseline','restore-staff-equality','restore-project-equality','restore-both-equalities','duplicate-ownership-witness','duplicate-assignment-witness','second-unowned-resource']){
  const p=structuredClone(original);
  if(['restore-staff-equality','restore-both-equalities'].includes(label)){addId(p,'Staff','staffId','bob');p.cut.subject.key=[{string:'bob'}];set(fact(p,'Assignment'),'assignmentStaff',{string:'bob'});}
  if(['restore-project-equality','restore-both-equalities'].includes(label)){addId(p,'Project','projectId','p2');set(fact(p,'Assignment'),'assignmentProject',{string:'p2'});set(fact(p,'Ownership'),'ownerProject',{string:'p2'});}
  if(label==='duplicate-ownership-witness')witness(p,'Ownership','ownerId','o2');if(label==='duplicate-assignment-witness')witness(p,'Assignment','assignmentId','a2');
  if(label==='second-unowned-resource'){const f=structuredClone(fact(p,'Resource'));f.key=[{string:'r2'}];set(f,'resourceId',{string:'r2'});p.cut.facts.push(f);}
  check(state+':'+label,p,'rendered',rows);
 }
}
const base=snap.packets.find((p:any)=>p.variant==='allowed'&&p.state==='string');
for(const label of['incomplete-ownership','incomplete-assignment','stale-owner','stale-policy','untrusted-cut','tiny-step-budget','tiny-fact-budget','unreported-denied-resource','forged-program']){
 const p=structuredClone(base);
 if(label==='incomplete-ownership')p.cut.coverage.find((c:any)=>c.type.elementId==='Ownership').complete=false;
 if(label==='incomplete-assignment')p.cut.coverage.find((c:any)=>c.type.elementId==='Assignment').complete=false;
 if(label==='stale-owner')p.cut.owner.revision='foreign';if(label==='stale-policy')p.cut.policy.revision='foreign';if(label==='untrusted-cut')p.cut.trusted=false;if(label==='tiny-step-budget')p.cut.maxSteps=1;if(label==='tiny-fact-budget')p.cut.maxFacts=1;
 if(label==='unreported-denied-resource'){const f=structuredClone(fact(p,'Resource'));f.key=[{string:'r2'}];set(f,'resourceId',{string:'r2'});f.fields=f.fields.filter((x:any)=>x.field.elementId!=='token');p.cut.facts.push(f);}
 check(label,p,'refused',[],label==='forged-program');
}
await Bun.write(import.meta.dir+'/additional-controls.json',JSON.stringify({status:'passed',controls:results.length,results,scope:'Actual unchanged logical evaluator against independently authored equality-restoration, distinct duplicate-witness, population and fail-closed controls. All supplied logical cuts, not native authenticated facts.'},null,2)+'\n');console.log(JSON.stringify({status:'passed',controls:results.length}));
