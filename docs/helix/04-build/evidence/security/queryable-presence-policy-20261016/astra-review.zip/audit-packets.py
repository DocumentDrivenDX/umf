from pathlib import Path
import json,zipfile,hashlib,copy
r=Path(__file__).resolve().parent;e=r/'frozen/docs/helix/04-build/evidence/security/queryable-presence-policy-20261016';s=json.loads(zipfile.ZipFile(e/'inputs.zip').read('inputs.json'));src=json.loads(s['sources']['tests/security/protection/current-query-presence-source.json']);receipt=json.loads((e/'receipt.json').read_text());out=[]
ref=lambda name:dict(documentId='domain',moduleId='m',elementId=name)
for p,row in zip(s['packets'],receipt['results']):
 assert(p['variant'],p['state'])==(row['variant'],row['state'])
 policy=copy.deepcopy(src['policy'])
 if p['variant']!='undisclosed':policy['revision']='query-presence-token-read-policy-r2';policy['rules'][0]['disclosure'].append({'field':ref('token'),'disposition':{'kind':'original'}})
 assert policy==p['policy']
 owner=copy.deepcopy(src['owner']);owner['revision']='query-presence-read-owner-r2';owner['disclosure']={'readAction':'read'};assert owner==p['owner']
 cut=p['cut'];assert cut['domains']==src['closure']['pins'] and cut['policy']=={'id':policy['id'],'revision':policy['revision']}
 facts=cut['facts'];identities=[(f['type']['elementId'],json.dumps(f['key'],sort_keys=True))for f in facts];assert len(set(identities))==len(identities)
 def get(f,k):return next((x['value']for x in f['fields']if x['field']['elementId']==k),None)
 def keyExists(t,v):return any(f['type']['elementId']==t and f['key']==[v]for f in facts)
 for f in facts:
  t=f['type']['elementId']
  if t=='Ownership':assert keyExists('Resource',get(f,'ownerResource'))and keyExists('Project',get(f,'ownerProject'))
  if t=='Assignment':assert keyExists('Staff',get(f,'assignmentStaff'))and keyExists('Project',get(f,'assignmentProject'))
 resource=next(f for f in facts if f['type']['elementId']=='Resource')
 eligible=any(o['type']['elementId']=='Ownership'and get(o,'ownerResource')==resource['key'][0]and any(a['type']['elementId']=='Assignment'and get(a,'assignmentStaff')==cut['subject']['key'][0]and get(a,'assignmentProject')==get(o,'ownerProject')and get(a,'active')=={'boolean':True}for a in facts)for o in facts)
 assert eligible==(p['variant']not in ['revoked','foreign-subject','foreign-assignment-staff','foreign-assignment-project','foreign-ownership-project','no-ownership','no-assignment'])
 if p['variant']in ['no-ownership','no-assignment']:assert all(c['complete']is True for c in cut['coverage'])
 out.append({'variant':p['variant'],'state':p['state'],'independentMembershipResult':eligible,'allEndpointsPresent':True,'policyDeltaExact':True,'ownerDeltaExact':True})
# Original 20-case packet is preserved verbatim.
original=Path('/private/tmp/umf-queryable-presence-policy-review-20261016.zip');z=zipfile.ZipFile(original)
assert hashlib.sha256(original.read_bytes()).hexdigest()=='0e18d31e22282f424f6c706fc28834e5f8b30942140c07325d38ceb6b5b77914'
for f in ['README.md','inputs.zip','receipt.json']:assert z.read('docs/helix/04-build/evidence/security/queryable-presence-policy-20261016/'+f)==(e/'r1'/f).read_bytes()
(r/'packet-audit.json').write_text(json.dumps({'status':'passed','packets':44,'allPolicyAndOwnerDeltasExact':True,'allIndependentMembershipResultsMatch':True,'allForeignEndpointsResolveToCompleteFacts':True,'originalR1RetainedByteIdentically':True,'results':out},indent=2)+'\n');print('44 packets audited; R1 byte-identical')
