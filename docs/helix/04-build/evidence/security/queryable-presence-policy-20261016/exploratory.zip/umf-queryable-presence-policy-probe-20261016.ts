import {compileCandidateCatalogProgram} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-program-candidate';
import {evaluateCandidateCatalogScan} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-runtime-candidate';
const root='/Users/erik/.codex/worktrees/security-main-integration/umf/';
const source=await Bun.file(root+'tests/security/protection/current-query-presence-source.json').json();
const scenarios=await Bun.file(root+'tests/security/protection/current-query-read-scenarios.json').json();
const ref=(elementId:string)=>({documentId:'domain',moduleId:'m',elementId});
const results=[];
for(const variant of ['allowed','undisclosed','revoked','incomplete-coverage','stale-generation'])for(const state of ['string','null','absent','unreported']){
 const policy=structuredClone(source.policy);if(variant!=='undisclosed'){policy.revision='query-presence-token-read-policy-r2';policy.rules[0].disclosure.push({field:ref('token'),disposition:{kind:'original'}});}
 const owner=structuredClone(source.owner);owner.revision='query-presence-read-owner-r2';owner.disclosure={readAction:'read'};
 const cut=structuredClone(scenarios.cut);cut.generation=cut.expectedGeneration='query-presence-supplied-cut-r2';cut.policy={id:policy.id,revision:policy.revision};cut.ontology={documentId:source.ontology.documentId,revision:source.ontology.revision};cut.protection={id:source.catalog.id,revision:source.catalog.revision};cut.domains=source.closure.pins;cut.owner={id:owner.id,revision:owner.revision};
 const fact=cut.facts.find((f:any)=>f.type.elementId==='Resource');fact.fields=fact.fields.filter((f:any)=>f.field.elementId!=='token');fact.absent=[];
 if(state==='absent')fact.absent.push(ref('token'));else if(state!=='unreported')fact.fields.push({field:ref('token'),value:state==='null'?null:{string:'opaque-token'}});
 if(variant==='revoked')cut.facts.find((f:any)=>f.type.elementId==='Assignment').fields.find((f:any)=>f.field.elementId==='active').value={boolean:false};
 if(variant==='incomplete-coverage')cut.coverage.find((f:any)=>f.type.elementId==='Resource').fields=cut.coverage.find((f:any)=>f.type.elementId==='Resource').fields.filter((f:any)=>f.elementId!=='token');
 if(variant==='stale-generation')cut.expectedGeneration='other';
 try{const program=compileCandidateCatalogProgram(policy,source.catalog,source.closure,source.ontology);const scan=evaluateCandidateCatalogScan(program,owner,cut,{type:ref('Resource'),fields:[ref('token')]});results.push({variant,state,scan});}catch(error){results.push({variant,state,error:String(error)});}
}
await Bun.write('/private/tmp/umf-queryable-presence-policy-probe-20261016.json',JSON.stringify({scope:'Exploratory actual logical evaluator observations; supplied completeness is not native authority',results},null,2)+'\n');
for(const r of results)console.log(JSON.stringify(r));
