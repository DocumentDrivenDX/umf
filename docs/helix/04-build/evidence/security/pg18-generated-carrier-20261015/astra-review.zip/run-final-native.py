import pathlib,subprocess,time,json
out=pathlib.Path(__file__).parent;runs=[]
for name,wd,needle in [('current-68',out/'final-source',None),('final-truncated-results',out/'final-mutants/truncated-results','all-request-results-present'),('final-altered-statements',out/'final-mutants/altered-statements','exact-ordered-install-plan')]:
 start=time.monotonic();r=subprocess.run(['python3','tests/security/native/pg18-generated-carrier.py','--output',str(out/(name+'-native.json'))],cwd=wd,capture_output=True,text=True,timeout=60);elapsed=time.monotonic()-start
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 item={'name':name,'exit':r.returncode,'seconds':elapsed,'expectedFailure':needle,'matched':r.returncode==0 if needle is None else r.returncode!=0 and needle in r.stderr,'stdout':r.stdout,'stderrTail':r.stderr[-400:]};runs.append(item);(out/'final-native-runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(item),flush=True)
assert all(r['matched'] for r in runs)
