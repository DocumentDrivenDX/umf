import {readFileSync} from 'node:fs';
const {compilePg18ProtectionCarrier: compile}=await import(process.argv[2]!);
const fixture=JSON.parse(readFileSync(process.argv[3]!,'utf8'));
const rows:any[]=[];
const clone=(v:any)=>JSON.parse(JSON.stringify(v));
const canonical=(v:any):string=>JSON.stringify(v,(k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
function check(id:string,expected:any,observed:any){rows.push({id,pass:canonical(expected)===canonical(observed),expected,observed});}
function fresh(){return {carrier:'barrier-view',...clone(fixture)};}
function refused(id:string,input:any,preserve=true){let result:any;try{result=compile(input);}catch(e){check(id,'returned refusal','throw');return;}
 check(id+':atomic',{status:'refused',carrier:null,projection:null,statements:[],complete:false,authority:false},{status:result.status,carrier:result.carrier,projection:result.projection,statements:result.statements,complete:result.complete,authority:result.authority});
 check(id+':reason',true,typeof result.reason==='string'&&result.reason.length>0);
 if(preserve)check(id+':source',input,result.request);
}
const original=fresh(); const admitted=compile(original);
check('barrier:admitted','compiled',admitted.status);check('barrier:flags',{complete:false,authority:false,carrier:'barrier-view'},{complete:admitted.complete,authority:admitted.authority,carrier:admitted.carrier});
check('barrier:ordered-plan',[admitted.projection?.sourceDDL,admitted.projection?.viewSQL],admitted.statements);
check('barrier:source',original,admitted.request);
check('barrier:security-barrier',true,admitted.statements?.[1]?.includes('security_barrier=true'));
function frozen(v:any):boolean{return v===null||typeof v!=='object'||(Object.isFrozen(v)&&Object.values(v).every(frozen));}
check('barrier:deep-freeze',true,frozen(admitted));
const saved=canonical(admitted);original.catalog.transforms[0].id='mutated';original.profile.source.view='changed';check('barrier:detached',saved,canonical(admitted));
const opaque=fresh();opaque.catalog.native={future:['payload',null,{carrier:'virtual-generated'}]};let r=compile(opaque);check('opaque:compiled','compiled',r.status);check('opaque:preserved',opaque,r.request);
for(const value of ['virtual-generated','stored-generated','barrier-View','BARRIER-VIEW','',null,true,false,0,1,{},[],['barrier-view']])refused('carrier:'+canonical(value),{...fresh(),carrier:value});
for(const key of ['carrier','catalog','closure','profile']){const v=fresh();delete v[key];refused('missing:'+key,v);}
for(const value of [null,[],false,{},'barrier-view'])refused('envelope:'+canonical(value),value);
refused('extra-envelope',{...fresh(),fallback:'barrier-view'});
for(const key of ['profile','catalog','closure']){const v=fresh();v[key].unknown=true;refused('unknown:'+key,v);}
const mutations:any[]=[
 ['stale-catalog-pin',(x:any)=>x.profile.catalog.revision='stale'],
 ['stale-domain-pin',(x:any)=>x.closure.pins[0].revision='stale'],
 ['wrong-version',(x:any)=>x.profile.version='future'],
 ['wrong-transform',(x:any)=>x.profile.bindings[0].transform.id='missing'],
 ['missing-transform',(x:any)=>x.catalog.transforms.pop()],
 ['unsupported-recipe',(x:any)=>x.catalog.transforms[0].function='future'],
 ['unsafe-native-column',(x:any)=>x.profile.bindings[0].column='ctid'],
 ['unknown-param',(x:any)=>x.catalog.transforms[0].parameters[0].name='other'],
 ['unknown-source',(x:any)=>x.profile.source.extra=true],
];
for(const [id,change]of mutations){const v=fresh();change(v);refused(id,v);}
let getters=0;const getter=fresh();Object.defineProperty(getter,'carrier',{enumerable:true,get(){getters++;return 'barrier-view'}});refused('accessor',getter,false);check('accessor:no-invocation',0,getters);
const cyclic=fresh();cyclic.loop=cyclic;refused('cycle',cyclic,false);
const custom=Object.assign(Object.create({carrier:'barrier-view'}),fixture);refused('prototype',custom,false);
const symbol=fresh();symbol[Symbol('hidden')]=1;refused('symbol',symbol,false);
const hidden=fresh();Object.defineProperty(hidden,'hidden',{value:1,enumerable:false});refused('hidden',hidden,false);
const undefinedValue=fresh();undefinedValue.catalog.native=undefined;refused('undefined',undefinedValue,false);
process.stdout.write(JSON.stringify({count:rows.length,failed:rows.filter(x=>!x.pass),rows})+'\n');
