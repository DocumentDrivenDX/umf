import pathlib,json,subprocess,shutil,hashlib,difflib
out=pathlib.Path(__file__).parent;final=out/'final-source';relative=pathlib.Path('tools/security/protection-pg18-carrier.ts');original=(final/relative).read_text();cases=[
 ('virtual-admission',"if(request.carrier!=='barrier-view')","if(!['barrier-view','virtual-generated'].includes(request.carrier))",'carrier:"virtual-generated":atomic'),
 ('hidden-fallback',"carrier:null,projection:null,statements:[]","carrier:null,projection:null,statements:['SELECT 1;']",'carrier:"virtual-generated":atomic'),
 ('unknown-profile-ignored',"const projection=compilePg18ProtectionCatalog", "delete request.profile.unknown; const projection=compilePg18ProtectionCatalog",'unknown:profile:atomic'),
 ('extra-envelope-ignored',"Object.keys(request).length!==4||",'', 'extra-envelope:atomic'),
 ('plan-omits-view',"statements:[projection.sourceDDL,projection.viewSQL]","statements:[projection.sourceDDL]",'barrier:ordered-plan'),
 ('shallow-result-freeze',"for(const x of Object.values(v))freeze(x);",'', 'barrier:deep-freeze'),
 ('opaque-source-stripped',"const projection=compilePg18ProtectionCatalog","delete request.catalog.native; const projection=compilePg18ProtectionCatalog",'opaque:preserved'),
]
runs=[]
for name,old,new,expected in [('original','','',''),*cases]:
 if name=='original':wd=final;changed=None
 else:
  assert original.count(old)==1,(name,original.count(old));changed=original.replace(old,new)
  wd=out/'compiler-mutants'/name;shutil.copytree(final,wd,symlinks=True);(wd/relative).write_text(changed)
  (out/(name+'.diff')).write_text(''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile=str(relative),tofile=str(relative))))
 r=subprocess.run(['/opt/homebrew/bin/bun',str(out/'compiler-controls.ts'),str(wd/relative),str(out/'fixture.json')],capture_output=True,text=True,timeout=30)
 (out/('compiler-'+name+'.stderr')).write_text(r.stderr)
 payload=json.loads(r.stdout);(out/('compiler-'+name+'.json')).write_text(json.dumps(payload,indent=2)+'\n')
 ids=[x['id'] for x in payload['failed']];matched=r.returncode==0 and (not ids if name=='original' else expected in ids)
 item=dict(name=name,exit=r.returncode,count=payload['count'],failedIds=ids,expectedFailure=expected,detected=matched,originalSha256=hashlib.sha256(original.encode()).hexdigest(),mutantSha256=hashlib.sha256(changed.encode()).hexdigest() if changed else None);runs.append(item)
 print(json.dumps({k:item[k] for k in ['name','count','failedIds','detected']}),flush=True)
 (out/'compiler-mutations.json').write_text(json.dumps(runs,indent=2)+'\n')
assert all(r['detected'] for r in runs)
