import pathlib,shutil,hashlib,json,subprocess
out=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/erik/.codex/worktrees/security-main-integration/umf');final=out/'final-source'
shutil.copytree(out/'source',final,symlinks=True)
rel='tests/security/native/pg18-generated-carrier.py';shutil.copy2(repo/rel,final/rel)
pins={p:hashlib.sha256((final/p).read_bytes()).hexdigest() for p in json.loads((out/'initial-pins.json').read_text())['files']}
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in pins.items())
(out/'final-pins.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':pins},indent=2)+'\n')
for name in ['truncated-results','altered-statements']:
 dst=out/'final-mutants'/name;shutil.copytree(final,dst,symlinks=True);shutil.copy2(out/'mutants'/name/'tests/security/native/pg18-carrier-compile.ts',dst/'tests/security/native/pg18-carrier-compile.ts')
