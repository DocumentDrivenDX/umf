import {compilePg18ProtectionCarrier} from '../../../tools/security/protection-pg18-carrier';
const requests=JSON.parse(await Bun.stdin.text());
const results=requests.map((r:unknown)=>compilePg18ProtectionCarrier(r)); results[0]={...results[0],statements:[results[0].statements[0],results[0].statements[1].replace('security_barrier=true','security_barrier=false')]}; console.log(JSON.stringify(results));
