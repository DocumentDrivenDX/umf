# P05 independent review

No remaining blocker within the original refusal branch. Final current-source native replay: **68 observations, 5.898 seconds**, PostgreSQL 18.6, original 60-second budget, owned container and volume absent. The 127 compiler checks pass; seven source weakenings and two output-plan faults are detected.

The historical truncated-response mutant actually passed only 53 observations by dropping seven requests. The corrected runner rejects it before Docker. An altered positive SQL plan is also rejected before Docker; the installer consumes exactly the checked returned plan.

The excluded virtual probe is evidence for its actual grants, expression and observed plan only. The deliberate owner expression change is not an ordinary-role exploit or a universal virtual-column failure. The admitted carrier remains the original barrier view under the fixed native membership profile. P05 case binding/full-gate status is parent-owned. See review.json for precise pins and exclusions.

Reproduce compiler controls with Bun using compiler-controls.ts, a source module path, and fixture.json. run-compiler-mutations.py records exact source replacements and expected named failed observations. run-final-native.py records the bounded disposable native replay plus compiler-response controls. Compact evidence contains selected original source files and changed mutant modules/diffs, not copied dependency trees. The copied source needs the original installed node_modules (not included); runtime dependency bytes are pinned in native receipts.
