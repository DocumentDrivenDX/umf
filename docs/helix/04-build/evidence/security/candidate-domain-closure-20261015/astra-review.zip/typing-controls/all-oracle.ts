import {runOracle as runTyping} from './oracle';
import {runCompactOracle} from './compact-oracle';
export function runOracle(){return [...runTyping(),...runCompactOracle()];}
