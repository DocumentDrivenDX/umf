import {createCandidateEntityTermScope} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/entity-terms-candidate';
import {resolveCandidateSecurityOntology} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/ontology-checks-candidate';
import {normalizeCandidateAssociationExpression as normalize,serializeCandidateAssociationExpression as serialize,compileCandidateAssociationCondition as compile,requireIssuedCandidateCompactCondition as check,inspectCandidateAssociationExpressionTransport as inspect} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/association-expression';
import fixtures from './fixtures.json';
const ref=(elementId:string)=>({documentId:'review-domain',moduleId:'entities',elementId});
const edge={documentId:'review-domain',moduleId:'entities',relationshipId:'DirectLink'};
function fixture(recordWitness=false){
 const f:any=structuredClone(fixtures.cases[0]!.input);
 f.documents[0].document.modules[0].relationships=[{id:'DirectLink',name:'DirectLink',sourceMultiplicity:{min:0,max:1},targetMultiplicity:{min:0,max:2},targetLifecycle:'independent',directed:true,source:[{module:'entities',element:'Person'}],target:[{module:'entities',element:'Asset',key:'pk'}],...(recordWitness?{associationRecord:{module:'entities',element:'Link'}}:{})}];
 f.ontology.associations.push({kind:'core-relationship',relationship:edge,witness:recordWitness?{kind:'record-key',type:ref('Link'),keyId:'pk'}:{kind:'opaque-existential'},endpoints:[{role:'person',side:'source',target:ref('Person'),keyId:'pk'},{role:'asset',side:'target',target:ref('Asset'),keyId:'pk'}]});return f;
}
const eq=(left:any,right:any)=>({op:'eq',left,right});
const exists=(association:any,as:string,where:any)=>({op:'exists',association,as,where});
const ep=(name:string,endpoint:string)=>({kind:'variable',name,endpoint});
const subject={kind:'subject',identity:true};
function truth(f:any){const checked=resolveCandidateSecurityOntology(f.ontology,f.documents),scope=createCandidateEntityTermScope(f.ontology,f.documents,f.target);return{checked,scope};}
const frozen=(a:any):boolean=>a===null||typeof a!=='object'||Object.isFrozen(a)&&Object.values(a).every(frozen);
export function runCompactOracle(){
 const rows:any[]=[];function test(id:string,expected:boolean,fn:()=>boolean){let actual=false,error=null;try{actual=fn();}catch(e){error=String(e);}rows.push({id,expected,actual,error,passed:actual===expected});}
 const f=fixture(),{checked,scope}=truth(f),table=checked.associations;
 const expression={op:'and',args:[exists(ref('Link'),'same',eq(ep('same','person'),subject)),exists(edge,'same',eq(ep('same','asset'),{kind:'resource',identity:true}))]};
 const n=normalize(expression,table,undefined,scope),c:any=compile(n,table),old:any=serialize(n);
 test('compact-full-source-transport-expression-correspondence',true,()=>JSON.stringify(c.expression)===JSON.stringify(old.expression));
 test('compact-no-enumerable-source-archives',true,()=>JSON.stringify(Object.keys(c))==='["kind","expression"]');
 test('compact-recursively-immutable',true,()=>frozen(c));
 test('compact-two-scoped-sibling-occurrences',true,()=>c.expression.args[0].occurrence===0&&c.expression.args[1].occurrence===1&&c.expression.args[0].where.left.occurrence===0&&c.expression.args[1].where.left.occurrence===1);
 test('compact-original-ordered-table',true,()=>{check(c,table,scope);return true;});
 test('compact-new-array-same-ordered-handles',true,()=>{check(c,[...table],scope);return true;});
 test('compact-reordered-table-refuses',false,()=>{check(c,[...table].reverse(),scope);return true;});
 test('compact-copied-handles-refuse',false,()=>{check(c,structuredClone(table),scope);return true;});
 test('compact-copied-condition-refuses',false,()=>{check(structuredClone(c),table,scope);return true;});
 test('compact-omitted-intrinsic-scope-refuses',false,()=>{check(c,table);return true;});
 test('compact-equal-source-new-scope-refuses',false,()=>{check(c,table,truth(fixture()).scope);return true;});
 test('compact-table-truncation-refuses',false,()=>{check(c,[table[0]!],scope);return true;});
 test('compact-extra-table-entry-refuses',false,()=>{check(c,[...table,table[0]!],scope);return true;});
 test('compact-compiler-copied-normalization-refuses',false,()=>{compile(structuredClone(n),table);return true;});
 test('compact-compiler-duplicate-handle-refuses',false,()=>{compile(n,[table[0]!,table[0]!]);return true;});
 test('compact-compiler-unrelated-issued-handle-refuses',false,()=>{compile(n,truth(fixture()).checked.associations);return true;});
 test('compact-compiler-empty-table-refuses',false,()=>{compile(n,[]);return true;});
 test('compact-compiler-missing-unused-table-refuses',false,()=>{const literal=normalize({op:'literal',value:true},table,undefined,scope);compile(literal,[table[0]!]);return true;});
 test('compact-compiler-oversize-table-refuses',false,()=>{compile(n,Array.from({length:257},()=>table[0]!));return true;});
 test('compact-compiler-getter-no-invocation',true,()=>{let calls=0;const a=new Array(2);Object.defineProperty(a,'0',{get(){calls++;return table[0];}});a[1]=table[1];let refused=false;try{compile(n,a);}catch{refused=true;}return refused&&calls===0;});
 test('compact-reader-getter-no-invocation',true,()=>{let calls=0;const a=new Array(2);Object.defineProperty(a,'0',{get(){calls++;return table[0];}});a[1]=table[1];let refused=false;try{check(c,a,scope);}catch{refused=true;}return refused&&calls===0;});
 test('compact-reordered-emission-binds-own-indices',true,()=>{const reversed=[...table].reverse(),r:any=compile(n,reversed);check(r,reversed,scope);return r.expression.args[0].association===1&&r.expression.args[1].association===0;});
 test('compact-reordered-emission-rejects-original-table',false,()=>{const r=compile(n,[...table].reverse());check(r,table,scope);return true;});
 test('compact-native-endpoint-not-synthetic-field',true,()=>{const term=c.expression.args[1].where.left.term;return JSON.stringify(term.relationship)===JSON.stringify(edge)&&term.side==='target'&&term.fields===undefined;});
 test('compact-original-transport-still-roundtrips',true,()=>JSON.stringify(inspect(old))===JSON.stringify(old));
 const changed=fixture();changed.documents[0].document.modules[1].elements[0].name='Changed valid source name';const changedScope=truth(changed).scope;
 test('compact-changed-source-valid-scope',true,()=>!!changedScope);
 test('compact-source-document-substitution-refuses',false,()=>{normalize(expression,table,undefined,changedScope);return true;});
 test('compact-unresolved-intrinsic-terms-refuse',false,()=>{compile(normalize(expression,table),table);return true;});
 test('compact-no-intrinsic-scope-positive',true,()=>{const literal=normalize({op:'literal',value:true},table);const cc=compile(literal,table);check(cc,table);return true;});
 test('compact-no-intrinsic-scope-rejects-injected-scope',false,()=>{const cc=compile(normalize({op:'literal',value:true},table),table);check(cc,table,scope);return true;});
 for(const opaque of [true,false])test('compact-graph-'+(opaque?'opaque-endpoint':'record-nullable-attribute'),true,()=>{
  const z=fixture(!opaque),{checked:q,scope:s}=truth(z),condition=opaque?eq(ep('g','person'),subject):eq({kind:'variable',name:'g',field:ref('note')},{kind:'constant',field:{documentId:'review-domain',moduleId:'domains',elementId:'dto-text'},value:null});
  const normalized=normalize(exists(edge,'g',condition),q.associations,undefined,s),cc:any=compile(normalized,q.associations);check(cc,q.associations,s);return JSON.stringify(cc.expression)===JSON.stringify((serialize(normalized) as any).expression);
 });
 test('compact-opaque-witness-attribute-refuses',false,()=>{const condition=exists(edge,'g',eq({kind:'variable',name:'g',field:ref('note')},{kind:'constant',field:{documentId:'review-domain',moduleId:'domains',elementId:'dto-text'},value:null}));compile(normalize(condition,table,undefined,scope),table);return true;});
 return rows;
}
