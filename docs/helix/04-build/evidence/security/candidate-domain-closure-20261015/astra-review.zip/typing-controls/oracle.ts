import {createCandidateEntityTermScope,resolveCandidateEntityTerm,candidateEntityTermsCompatible} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/entity-terms-candidate';
import {resolveCandidateSecurityOntology} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/ontology-checks-candidate';
import {normalizeCandidateAssociationExpression,serializeCandidateAssociationExpression} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/association-expression';
import {resolveCandidateSecurityPolicy} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/policy-checks-candidate';
import packet from './fixtures.json';
function equal(a:unknown,b:unknown){return JSON.stringify(a)===JSON.stringify(b);}
function frozen(a:any):boolean{return a===null||typeof a!=='object'||Object.isFrozen(a)&&Object.values(a).every(frozen);}
export function runOracle(){return(packet.cases as any[]).map(c=>{
 const f=structuredClone(c.input),before=JSON.stringify(f);let accepted=false,detailCorrect=true,outputFrozen=true,error:null|string=null;
 try{
  let result:any;
  if(c.operation==='policy'){
   result=resolveCandidateSecurityPolicy(f.policy,f.ontology,f.documents);
   detailCorrect=equal(result.residuals,[])&&equal(result.policy,f.policy);
  }else{
   const scope=createCandidateEntityTermScope(f.ontology,f.documents,f.target);
   if(c.operation==='scope') result=scope;
   else if(c.operation==='term'){
    result=resolveCandidateEntityTerm(scope,f.term);
    detailCorrect=f.expectedTerm===undefined||equal(result.term,f.expectedTerm);
    if(f.term.kind==='constant')detailCorrect=detailCorrect&&equal(result.term.value,f.term.value)&&equal(result.term.field,f.term.field);
   }else if(['compatible','crossScope','copiedTerm'].includes(c.operation)){
    let l=resolveCandidateEntityTerm(scope,f.left);
    const rightScope=c.operation==='crossScope'?createCandidateEntityTermScope(f.ontology,f.documents,f.target):scope;
    const r=resolveCandidateEntityTerm(rightScope,f.right);
    if(c.operation==='copiedTerm')l=structuredClone(l);
    result=candidateEntityTermsCompatible(l,r);
    detailCorrect=result===f.expectedCompatible;
   }else if(c.operation==='snapshot'){
    const mutated=structuredClone(f);
    const captured=createCandidateEntityTermScope(mutated.ontology,mutated.documents,mutated.target);
    mutated.documents[0].document.modules[1].elements[0].nullability='required';
    mutated.ontology.context.push({documentId:'review-domain',moduleId:'domains',elementId:'dto-number'});
    result=resolveCandidateEntityTerm(captured,{kind:'constant',field:{documentId:'review-domain',moduleId:'domains',elementId:'dto-number'},value:null});
    let contextRefused=false;try{resolveCandidateEntityTerm(captured,{kind:'context',field:{documentId:'review-domain',moduleId:'domains',elementId:'dto-number'}});}catch{contextRefused=true;}
    detailCorrect=result.term.value===null&&contextRefused;
   }else if(c.operation==='expression'){
    const checked=resolveCandidateSecurityOntology(f.ontology,f.documents),n=normalizeCandidateAssociationExpression(f.expression,checked.associations,undefined,scope);
    result=serializeCandidateAssociationExpression(n);
    detailCorrect=equal(n.residuals,[])&&equal(result.sourceExpression.input,f.expression);
   }else throw Error('unknown oracle operation');
  }
  outputFrozen=frozen(result);accepted=true;
 }catch(e){error=String(e);}
 const sourceUnchanged=before===JSON.stringify(f);
 return {id:c.id,expectedAccepted:c.expected,accepted,detailCorrect,outputFrozen,sourceUnchanged,error,passed:accepted===c.expected&&(!accepted||detailCorrect&&outputFrozen)&&sourceUnchanged};
});}
