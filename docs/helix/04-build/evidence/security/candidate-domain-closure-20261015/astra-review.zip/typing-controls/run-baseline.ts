import {runOracle} from './baseline-oracle';
const rows=runOracle();await Bun.write(import.meta.dir+'/baseline-results.json',JSON.stringify({baseline:'6afddd95',scope:'Actual prior typing behavior; mismatches expected for corrected positive domains, not acceptance qualification',rows},null,2)+'\n');console.log(JSON.stringify({count:rows.length,changed:rows.filter(r=>!r.passed)},null,2));
