import {runOracle} from './oracle';
const rows=runOracle();await Bun.write(import.meta.dir+'/current-results.json',JSON.stringify({runtime:'Bun '+Bun.version,rows},null,2)+'\n');console.log(JSON.stringify({count:rows.length,failed:rows.filter(r=>!r.passed)},null,2));if(rows.some(r=>!r.passed))process.exitCode=1;
