"""Independently authored candidate typing prerequisites; no runtime/authority oracle."""
import json
from copy import deepcopy
from pathlib import Path
OUT=Path(__file__).parent
D='review-domain'; M='entities'; T='domains'
def ref(n,m=M,d=D):return dict(documentId=d,moduleId=m,elementId=n)
def field(n,t='string',nullable=False,**kw):return dict(id=n,kind='field',scalarType=t,cardinality='one',nullability='absent-allowed' if nullable else 'required',extensions={},**kw)
def record(n,fs):return dict(id=n,kind='record',members=[dict(module=M,element=f) for f in fs],keys=[dict(id='pk',name='Primary',fields=[dict(module=M,element=fs[0])])],extensions={})
def base():
 groups={'Person':['person-key','person-label'],'Asset':['asset-key','amount'],'Link':['link-key','link-person','link-asset','note']}
 elems=[]
 for n,fs in groups.items():
  elems.append(record(n,fs))
  elems += [field(f,'integer' if f=='amount' else 'string',f in ['amount','note','person-label']) for f in fs]
 doc=dict(umf='0.8.0',id=D,vocabularies={},modules=[dict(id=M,namespace='',elements=elems),dict(id=T,namespace='',elements=[field('dto-number','integer',True),field('dto-text','string',True),field('dto-required'),field('dto-bool','boolean',True),field('dto-binary','binary',True),field('dto-decimal','decimal',True,facets=dict(precision=12,scale=2))])])
 entities=[dict(type=ref(n),keyId='pk',fields=[dict(ref=ref(f),protection='protected' if f=='amount' else 'unprotected') for f in fs]) for n,fs in groups.items()]
 ont=dict(version='0.2.0',documentId='review-ontology',revision='ontology-r1',documents=[dict(documentId=D,revision='model-r1')],subject=ref('Person'),entities=entities,associations=[dict(kind='record-members',type=ref('Link'),keyId='pk',endpoints=[dict(role='person',target=ref('Person'),fields=[ref('link-person')]),dict(role='asset',target=ref('Asset'),fields=[ref('link-asset')])])],context=[],actions=['read'])
 policy=dict(vocabulary='umf.security',version='0.2.0',id='review-policy',revision='policy-r1',ontology=dict(documentId='review-ontology',revision='ontology-r1'),rules=[dict(id='read-rule',effect='permit',actions=['read'],target=[ref('Asset')],condition=dict(op='literal',value=True),disclosure=[dict(field=ref('amount'),disposition=dict(kind='transformed',transform='constant',version='0.1.0',field=ref('dto-number',T),value=None))])])
 return dict(ontology=ont,documents=[dict(revision='model-r1',document=doc)],target=ref('Asset'),policy=policy)
def fdef(f,n,m=M):return next(x for a in f['documents'][0]['document']['modules'] if a['id']==m for x in a['elements'] if x['id']==n)
def const(n,val,m=T):return dict(kind='constant',field=ref(n,m),value=val)
def attr(n,kind='resource',m=M):return dict(kind=kind,field=ref(n,m))
cases=[]
def add(id,op,expected,modify=lambda x:None,**a):
 f=base();modify(f);f.update(a);cases.append(dict(id=id,operation=op,expected=expected,input=f))
def context(f):f['ontology']['context']=[ref('dto-number',T)]
add('nullable-resource','term',True,term=attr('amount'),expectedTerm=dict(kind='record-attribute',context='resource',type=ref('Asset'),field=ref('amount')))
add('nullable-subject','term',True,term=attr('person-label','subject'))
add('nullable-field-null','term',True,term=const('amount',None,M))
add('dto-null','term',True,term=const('dto-number',None))
for name,value in [('dto-text',{'string':'λ\u0000z'}),('dto-bool',{'boolean':False}),('dto-binary',{'binaryHex':'0001ff'}),('dto-decimal',{'decimalToken':'-1.20'}),('dto-number',{'integerToken':'9007199254740993'})]:add('dto-family-'+name,'term',True,term=const(name,value))
add('dto-required-null','term',False,term=const('dto-required',None))
add('dto-live-resource','term',False,term=attr('dto-number',m=T))
add('dto-live-subject','term',False,term=attr('dto-number','subject',T))
add('dto-unlisted-context','term',False,term=attr('dto-number','context',T))
add('dto-listed-context','term',True,context,term=attr('dto-number','context',T),expectedTerm=dict(kind='context-attribute',field=ref('dto-number',T)))
add('other-entity-field-live','term',False,term=attr('person-label'))
add('record-as-constant','term',False,term=const('Asset',None,M))
add('missing-domain','term',False,term=const('absent',None))
add('foreign-domain','term',False,term=dict(kind='constant',field=ref('dto-number',T,'other'),value=None))
add('wrong-same-name-module','term',False,term=const('dto-number',None,M))
add('required-null-key-constant','term',False,term=const('asset-key',None,M))
add('required-resource-identity','term',True,term=dict(kind='resource',identity=True))
add('required-subject-identity','term',True,term=dict(kind='subject',identity=True))
add('nullable-key','scope',False,lambda f:fdef(f,'asset-key').update(nullability='absent-allowed'))
add('nullable-endpoint','scope',False,lambda f:fdef(f,'link-person').update(nullability='absent-allowed'))
add('wrong-revision','scope',False,lambda f:f['documents'][0].update(revision='model-r2'))
add('unknown-core-member','scope',False,lambda f:fdef(f,'amount').update(futureMeaning=True))
add('unknown-ontology-member','scope',False,lambda f:f['ontology'].update(futureMeaning=True))
add('duplicate-context','scope',False,lambda f:f['ontology'].update(context=[ref('dto-number',T)]*2))
for n,r in [('record',ref('Asset')),('missing',ref('no-field')),('foreign',ref('dto-number',T,'other'))]:add('context-'+n,'scope',False,lambda f,r=r:f['ontology'].update(context=[r]))
add('compatible-dto-live','compatible',True,left=attr('amount'),right=const('dto-number',None),expectedCompatible=True)
add('different-nullability-domains','compatible',True,lambda f:fdef(f,'dto-number',T).update(nullability='required'),left=attr('amount'),right=const('dto-number',{'integerToken':'1'}),expectedCompatible=False)
add('different-scalar-domains','compatible',True,left=attr('amount'),right=const('dto-text',None),expectedCompatible=False)
add('different-captured-scopes','crossScope',False,left=attr('amount'),right=const('dto-number',None))
add('copied-term-not-issued','copiedTerm',False,left=attr('amount'),right=const('dto-number',None))
add('snapshot-independent-domain','snapshot',True)
add('nullable-inline-dto-output','policy',True)
add('required-inline-output-null','policy',False,lambda f:fdef(f,'dto-number',T).update(nullability='required'))
add('dto-disclosed-input-not-owned','policy',False,lambda f:f['policy']['rules'][0]['disclosure'][0].update(field=ref('dto-number',T)))
add('policy-stale-ontology','policy',False,lambda f:f['policy']['ontology'].update(revision='other'))
add('dto-context-whole-policy','policy',True,lambda f:(context(f),f['policy']['rules'][0].update(condition=dict(op='eq',left=attr('dto-number','context',T),right=const('dto-number',None)))))
add('nullable-live-whole-policy','policy',True,lambda f:f['policy']['rules'][0].update(condition=dict(op='eq',left=attr('amount'),right=const('dto-number',None))))
add('nullable-witness','expression',True,expression=dict(op='exists',association=ref('Link'),**{'as':'r'},where=dict(op='eq',left=dict(kind='variable',name='r',field=ref('note')),right=const('dto-text',None))))
add('witness-cannot-read-dto','expression',False,expression=dict(op='exists',association=ref('Link'),**{'as':'r'},where=dict(op='eq',left=dict(kind='variable',name='r',field=ref('dto-text',T)),right=const('dto-text',None))))
add('endpoint-identity-to-subject','expression',True,expression=dict(op='exists',association=ref('Link'),**{'as':'r'},where=dict(op='eq',left=dict(kind='variable',name='r',endpoint='person'),right=dict(kind='subject',identity=True))))
add('endpoint-wrong-record-type','expression',False,expression=dict(op='exists',association=ref('Link'),**{'as':'r'},where=dict(op='eq',left=dict(kind='variable',name='r',endpoint='person'),right=dict(kind='resource',identity=True))))
for family in ['float','date','time','timestamp']:
 add('unsupported-'+family,'term',False,lambda f,family=family:fdef(f,'dto-number',T).update(scalarType=family),term=const('dto-number',None))
add('decimal-missing-facets','term',False,lambda f:fdef(f,'dto-decimal',T).pop('facets'),term=const('dto-decimal',None))
add('collection-domain','term',False,lambda f:fdef(f,'dto-number',T).update(cardinality='many'),term=const('dto-number',None))
add('unspecified-nullability','term',False,lambda f:fdef(f,'dto-number',T).update(nullability='unspecified'),term=const('dto-number',None))
add('domain-refinement','term',False,lambda f:fdef(f,'dto-number',T).update(allowedValues=[{'integerToken':'1'}]),term=const('dto-number',{'integerToken':'2'}))
add('domain-extension','term',False,lambda f:fdef(f,'dto-number',T).update(extensions={'unknown':{'meaning':True}}),term=const('dto-number',None))
OUT.joinpath('fixtures.json').write_text(json.dumps(dict(scope='Candidate typing prerequisite; not action execution, general .2 policy admission, or S24/S25 qualification',cases=cases),ensure_ascii=False,indent=2)+'\n')
print(len(cases))
