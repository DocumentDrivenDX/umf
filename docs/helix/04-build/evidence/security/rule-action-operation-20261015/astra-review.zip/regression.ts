import {runOracle as activation} from '/private/tmp/query-route-activation-astra-20261015/oracle';
import {runOracle as mixed} from '/private/tmp/catalog-operation-batch-astra-20261015/oracle';
const results=[{name:'prior-activation',rows:activation()},{name:'prior-mixed-operation',rows:mixed()}];await Bun.write(import.meta.dir+'/regression.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results.map(x=>({name:x.name,controls:x.rows.length,failures:x.rows.filter(y=>!y.passed)}))));if(results.some(x=>x.rows.some(y=>!y.passed)))process.exitCode=1;
