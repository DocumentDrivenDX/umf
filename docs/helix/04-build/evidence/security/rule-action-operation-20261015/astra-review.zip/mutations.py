from pathlib import Path
import re,json,subprocess,hashlib
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/catalog-rule-duty-batch-astra-20261015');B=R/'src/extensions/security/catalog-operation-batch-candidate.ts';K=R/'src/extensions/security/catalog-runtime-candidate.ts';source=B.read_text();kernel=K.read_text();oracle=(O/'oracle.ts').read_text()
def relocate(t,p):return re.sub(r"(from\s+['\"])(\.[^'\"]+)(['\"])",lambda m:m[1]+str((p.parent/m[2]).resolve())+m[3],t)
def change(t,a,b):
 assert t.count(a)==1,(t.count(a),a)
 return t.replace(a,b)
resultsDecl="const results:CandidateCatalogOperationBatchResult['operations'][number][]=[];"
prefix=change(source,resultsDecl,'').replace(' const refused='," const results:CandidateCatalogOperationBatchResult['operations'][number][]=[];\n const refused=",1).replace(' }catch{return refused();}'," }catch{return results.length?freeze({status:'completed',complete:false,authority:false,operations:results}):refused();}")
variants={
 'late-prefix-escape':('batch',prefix),
 'per-leaf-work-reset':('batch',change(source,'  for(const op of operations){\n   if(op.kind',"  for(const op of operations){\n   (ledger as any).work=0;\n   if(op.kind")),
 'per-leaf-text-reset':('batch',change(source,'  for(const op of operations){\n   if(op.kind',"  for(const op of operations){\n   (ledger as any).text=0;\n   if(op.kind")),
 'per-leaf-literal-reset':('batch',change(source,'  for(const op of operations){\n   if(op.kind',"  for(const op of operations){\n   (ledger as any).literal=new CandidateSecurityOperationBudget(cut.maxSteps).literal;\n   if(op.kind")),
 'omit-trace-visits':('batch',change(source,'if(ref(fact.type)===type)population++;',"if(ref(fact.type)===type&&op.kind==='scan')population++;")),
 'omit-action-visits':('batch',change(source,'population+=op.request.resources.length;','population+=0;')),
 'omit-graph-population':('batch',change(source,'let population=cut.facts.length+cut.graphs.length;','let population=cut.facts.length;')),
 'force-action-permit':('batch',change(source,"results.push({id:op.id,kind:'action',outcome});","results.push({id:op.id,kind:'action',outcome:{...outcome,rows:outcome.rows.map(row=>({...row,decision:'permit' as const}))}});")),
 'trace-operation-ledger-disconnected':('kernel',change(kernel,' return readRuleScan(handle,owner,cut,selection,operation);',' return readRuleScan(handle,owner,cut,selection);')),
 'trace-selection-extras-ignored':('batch',change(source,"shape(op.selection,op.kind==='scan'?['type','fields']:['type']);", "if(op.kind==='scan')shape(op.selection,['type','fields']);"))
}
rows=[]
for name,(target,t) in variants.items():
 d=O/'mutants'/name;d.mkdir(parents=True,exist_ok=True)
 b=relocate(t if target=='batch' else source,B)
 if target=='kernel':
  (d/'kernel.ts').write_text(relocate(t,K));b=b.replace(str(K.with_suffix('')),str(d/'kernel'))
 (d/'batch.ts').write_text(b)
 s=oracle.replace("'./base-fixture.json'",repr(str(O/'base-fixture.json'))).replace(str(B.with_suffix('')),str(d/'batch'))
 if target=='kernel':s=s.replace(str(K.with_suffix('')),str(d/'kernel'))
 (d/'oracle.ts').write_text(s);(d/'run.ts').write_text("import {runOracle} from './oracle';const rows=runOracle();await Bun.write(import.meta.dir+'/result.json',JSON.stringify({rows},null,2)+'\\n');console.log(JSON.stringify({controls:rows.length,failures:rows.filter(x=>!x.passed)}));")
 p=subprocess.run(['/opt/homebrew/bin/bun',str(d/'run.ts')],cwd=R,text=True,capture_output=True,timeout=60);(d/'run.log').write_text(p.stdout+p.stderr);j=json.loads((d/'result.json').read_text()) if p.returncode==0 and (d/'result.json').exists() else None;fs=[x for x in j['rows'] if not x['passed']] if j else []
 row={'name':name,'target':target,'exit':p.returncode,'sourceSha256':hashlib.sha256(t.encode()).hexdigest(),'controls':len(j['rows']) if j else 0,'failures':[x['id'] for x in fs],'errors':[x for x in fs if x['error']],'detected':p.returncode==0 and bool(fs) and not any(x['error'] for x in fs)};rows.append(row);print(json.dumps(row),flush=True)
(O/'mutation-results.json').write_text(json.dumps({'batchSha256':hashlib.sha256(B.read_bytes()).hexdigest(),'kernelSha256':hashlib.sha256(K.read_bytes()).hexdigest(),'variants':rows},indent=2)+'\n')
if not all(x['detected'] or x['name']=='trace-selection-extras-ignored' and not x['failures'] and x['exit']==0 for x in rows):raise SystemExit(1)
