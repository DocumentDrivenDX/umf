import {fixture,h,traceOp,actionOp} from './oracle';
import {evaluateCandidateCatalogOperationBatch as batch} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-operation-batch-candidate';
import {evaluateCandidateCatalogReadRuleScan as trace,evaluateCandidateCatalogAction as action} from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-runtime-candidate';
const f=fixture(),p=h(f),checks:any[]=[];let lo=1,hi=100000;while(lo<hi){const m=Math.floor((lo+hi)/2);f.cut.maxSteps=m;const status=batch(p,f.owner,f.cut,[traceOp(),actionOp()]).status;checks.push({m,status});if(status==='completed')hi=m;else lo=m+1;}
const outputs=[];for(const n of [lo-1,lo]){f.cut.maxSteps=n;outputs.push({maxSteps:n,batch:batch(p,f.owner,f.cut,[traceOp(),actionOp()]).status,trace:trace(p,f.owner,f.cut,traceOp().selection).status,action:action(p,f.owner,f.cut,actionOp().request).status});}
await Bun.write(import.meta.dir+'/work-calibration.json',JSON.stringify({minimum:lo,checks,outputs},null,2)+'\n');console.log(JSON.stringify({minimum:lo,outputs}));
