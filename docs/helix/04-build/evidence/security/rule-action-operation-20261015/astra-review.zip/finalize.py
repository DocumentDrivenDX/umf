from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil
R=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');O=Path('/private/tmp/catalog-rule-duty-batch-astra-20261015');sha=lambda b:hashlib.sha256(b).hexdigest()
pins=json.loads((O/'source-pins-before.json').read_text());assert all(sha((R/p).read_bytes())==h for p,h in pins.items());(O/'final-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
b=json.loads((O/'browser-result.json').read_text());m=json.loads((O/'mutation-results.json').read_text());f=json.loads((O/'formal/receipt.json').read_text());reg=json.loads((O/'regression.json').read_text());cal=json.loads((O/'work-calibration.json').read_text())
assert b['parity'] and not b['externalRequests'] and not b['pageErrors'] and len(b['results'])==12
assert len(b['results'][0]['rows'])==52 and all(x['passed'] for x in b['results'][0]['rows'])
assert len(m['variants'])==11 and sum(x['detected'] for x in m['variants'])==10
for v in b['results']:
 assert all(x=='undefined' for x in v['globals'].values())
 if v['name']!='original':
  mut=next(x for x in m['variants'] if x['name']==v['name']);assert mut['exit']==0 and not mut['errors'];assert [x['id'] for x in v['rows'] if not x['passed']]==mut['failures']
assert m['batchSha256']==pins['src/extensions/security/catalog-operation-batch-candidate.ts'] and m['kernelSha256']==pins['src/extensions/security/catalog-runtime-candidate.ts']
assert cal['minimum']==1756 and cal['outputs']==[{'maxSteps':1755,'batch':'refused','trace':'evaluated','action':'evaluated'},{'maxSteps':1756,'batch':'completed','trace':'evaluated','action':'evaluated'}]
assert all(pins[p]==h for p,h in cal['originalSourcePins'].items())
assert len(f['checks'])==12 and sum(x['observed']=='unsat' for x in f['checks'])==6 and all(x['expected']==x['observed']==x['freshContextReplay'] for x in f['checks']) and f['sourcesUnchanged']
assert all(pins[p]==h for p,h in f['selectedSourceDigests'].items())
assert [len(x['rows']) for x in reg]==[121,49] and all(y['passed'] for x in reg for y in x['rows'])
assert '47 expect() calls' in (O/'root-focused.log').read_text()
assert subprocess.check_output(['git','show','40ef0b48:docs/helix/03-test/security/cases.json'],cwd=R)==(R/'docs/helix/03-test/security/cases.json').read_bytes()
assert 'evaluateCandidateCatalogReadRuleScanWithinOperation' not in (R/'src/index.ts').read_text()
P=R/'docs/helix/04-build/evidence/security/rule-action-operation-20261015'
for p in ['browser.json','README.md','original-work-calibration.ts','original-work-calibration.json','verification-commands.json','formal/receipt.json']:
 q=O/'parent-evidence'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/p,q)
review={
 'kind':'independent-astra-security-review','date':'2026-10-15','base':'40ef0b484515acd2ee3322947aaed31d8bcdb986',
 'scope':'Private atomic composition of original complete-population read-rule evidence, explicit action duties and existing read rendering on one detached supplied logical cut and cumulative operation ledger.',
 'disposition':'No blocking correctness finding in this increment. The original shared kernel receives the existing ledger for read-rule leaves; diagnostic decisions and late atomic refusals are preserved in independently exercised cases.',
 'findings':[],
 'sourceAssessment':{
  'sameCut':'The batch snapshots owner/cut/operations before dispatch. Each trace/read/action leaf consumes values from that same detached packet; the read-rule leaf reuses the original kernel, full source/cut/typed inventory/coverage checks and exact original owner read action. No independently supplied per-leaf cut or caller read-action override is accepted.',
  'budget':'Inventory is counted once plus every target population visit and explicit action target. The trace composition entry passes the exact same CandidateSecurityOperationBudget into run; original work, snapshot text and literal ledgers therefore accumulate across trace and neighboring leaves. Standalone trace delegates through the same function with its own operation, preserving its previous result semantics. Trace retention remains charged by the original kernel.',
  'atomicity':'Structural/preflight/retention/budget failure in any leaf returns refused with an empty operation list. Successful earlier traces/actions are buffered. Completed retains each ordered tagged outcome, including deny/indeterminate/conflict; it is not a grant.',
  'separation':'Field-free read evidence need not require public disclosure of a hidden original-use Field. Missing protected disclosure still refuses the actual renderer while original rule evidence and a separately supplied granted action can complete. No masked value becomes original, no branch is selected, and no scalar is returned by the trace.',
  'privateData':'Read-rule outcomes include canonical selectors and original truth for denied rows. They remain private host diagnostics, not safe public output or a native credential.',
  'scope':'No public root export, canonical compiler designation, occurrence/duty completeness attestation, native call or acceptance promotion was added. Source-plan reconstruction/route activation is a separate consumer; this increment supplies same-cut evidence and explicit duty outcomes.'
 },
 'independentExecution':{
  'oracle':{'controls':52,'bun':'1.4.2','chromium':b['browser'],'exactParity':True,'hostGlobals':'Bun/process undefined','pageErrors':0,'externalRequests':0,'receipt':'browser-result.json','provenance':'Independent Person/Asset/Link fixture and expectations reused from earlier reviewer-authored sources, with new exact trace/action outcomes. No repository fixture helper is imported.','coverage':'Complete ordered truth/resource rows and nonzero rule indices; action deny/U; missing public disclosure versus private hidden duty; separate rendered scan; flat/Record/opaque graph membership and valid endpoint revocation; empty preflight; atomic late trace/action/render failure; closed shapes, forged/copy/getter refusal, stale pins; frozen detached results; whole fact/work/text/literal budgets.'},
  'sourceMutations':{'attemptedVariants':11,'detectedVariants':10,'bothRuntimes':True,'importOrRuntimeErrorsCounted':False,'receipt':'mutation-results.json','detected':[x['name'] for x in m['variants'] if x['detected']],'survivingRedundantGuard':{'name':'trace-selection-extras-ignored','reason':'The original read-rule leaf independently enforces exact selection shape. Removing the outer batch check alone remains refused by that leaf; not counted as a detection.','pairedControl':'paired-trace-selection-guards-omitted removes both shape checks and is detected by five unchanged expected refusal controls.'}},
  'fixedWorkCalibration':{'positive':1756,'negative':1755,'bothStandaloneLeavesPassAtNegative':True,'sourceBound':True,'calibration':'work-calibration.json','scope':'Threshold frozen from the original independently authored fixture before mutation. The oracle contains literal1755/1756 and does not search or recalibrate against mutants. Parent fixture1780/1781 is a different source and retained separately.'},
  'repositoryFocusedTest':{'tests':1,'assertions':47,'receipt':'root-focused.log'},
  'existingBehaviorRegression':{'priorActivation':121,'priorMixedOperations':49,'runtime':'Bun1.4.2','allPassed':True,'receipt':'regression.json'},
  'formal':{'queries':12,'unsat':6,'sat':6,'solver':'4.15.4','distinctContextReplays':True,'receipt':'formal/receipt.json','scope':'Fresh replay of the existing conditional mixed-operation cost/cut/atomic-release model against current selected source/docs. Faithful leaf semantics/cost accounting, complete supplied duty enumeration and real detached-cut provenance are premises. No TypeScript/kernel/native refinement or newly proved general integration law.'}
 },
 'evidenceNotes':[
  'The initial independently authored50 semantic controls passed. Two fixed original work-boundary controls were added after source-pinned calibration, yielding52. Expectations were not derived from mutant behavior.',
  'The first ten-mutation run deliberately failed its all-detected assertion because the outer shape-only removal survived. Original result/log are retained as mutation-results-before-paired-control.json and mutations-before-paired-control.log. Review identified the redundant inner guard and added an explicitly paired weakening, retaining the single survivor honestly.',
  'All final Bun/Chromium and mutation checks ran after parent build regenerated action plan identity.910 captured selected/static-relative hashes remain unchanged through review finalization.',
  'Parent47 browser,347test/build/type/action-browser results are retained separately as parent evidence. Reviewer independently executed52 both-runtime controls, all11 mutation variants in both runtimes,47 focused assertions,170 prior controls and12 proof queries.',
  'The parent original158case gate is running separately and is pending at this receipt. The reviewer did not run native jobs or the full gate.'
 ],
 'qualificationLimits':[
  'Supplied cut/source authenticity, completeness/currentness and exhaustive correct duty enumeration remain external premises. Identical labels are not credentials.',
  'Completed read/action evidence may contain denied/unknown/conflicting outcomes. Consumer enforcement, actual Weft-issued original-use/action correspondence and route interpretation remain required.',
  'No scalar availability/domain/paired key scope, cryptographic behavior, query execution, authenticated native authority or held-through-release claim.',
  'Finite flat/graph and boundary controls plus a conditional arithmetic model do not prove arbitrary policy/kernel execution or complete resource accounting.',
  'All158 original acceptance definitions are byte-identical to base40ef0b48, with no assertion/criteria/timeout/binding/status change.',
  'Static selected source hashes include root barrel reach and generated identity, not a hermetic dynamic/package provenance theorem. Compact archive copies125 focused sources and retains all910 endpoint hashes.'
 ],
 'selectedSources':{'count':len(pins),'copiedFocusedSources':len(json.loads((O/'copied-source-selection.json').read_text())),'endpointStable':True,'pins':'final-source-pins.json','batchSha256':pins['src/extensions/security/catalog-operation-batch-candidate.ts'],'kernelSha256':pins['src/extensions/security/catalog-runtime-candidate.ts'],'generatedIdentitySha256':pins['src/extensions/actions/plan-identity.ts']},
 'acceptanceCasesPromoted':[],'rootSourcesEditedByReviewer':False
}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(O/'review.md').write_text('''# Independent same-cut rule/action review\n\nNo blocking finding. Original read-rule evidence now shares the batch cut and cumulative operation/text/literal budgets with explicit action duties. Late failure erases all operations; completed retains actual denied/unknown/conflicting outcomes. Traces remain private and do not imply public disclosure, branch selection, scalar or native permission.\n\n52 independent controls pass with exact Bun/Chromium parity.10 deliberate weakenings are detected in both runtimes; one outer shape-only removal remains protected by the inner check, with paired removal detected separately.47 focused assertions and170 prior regression controls pass.12 conditional proof queries replay6UNSAT/6SAT. The independent work boundary is frozen at1756positive/1755negative.\n\nAll158 original case definitions are unchanged. Final source/generated identity pins are stable; parent full gate is pending. Exact source hashes, outcomes, scope and the redundant-guard survivor are in review.json.\n''')
assert all(sha((R/p).read_bytes())==h for p,h in pins.items())
files=[]
for p in sorted(O.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(O)
 if any(v in ['node_modules','__pycache__'] for v in rel.parts) or rel.name in ['archive.zip','manifest.json','archive-summary.json']:continue
 files.append(p)
manifest={'reviewSha256':sha((O/'review.json').read_bytes()),'files':[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in files],'scope':'Selected sources, original independent fixture/oracle, exact focused mutant modules, calibration/receipts/logs and all endpoint hashes. No full mutated repositories or dependency trees.'};(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(O/'manifest.json')
with zipfile.ZipFile(O/'archive.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in files:z.write(p,str(p.relative_to(O)))
with zipfile.ZipFile(O/'archive.zip')as z:
 assert z.testzip() is None
 for f in manifest['files']:assert sha(z.read(f['path']))==f['sha256']
s={'review':str(O/'review.json'),'reviewSha256':sha((O/'review.json').read_bytes()),'archive':str(O/'archive.zip'),'archiveSha256':sha((O/'archive.zip').read_bytes()),'bytes':(O/'archive.zip').stat().st_size,'files':len(files),'sourcePins':len(pins)};(O/'archive-summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
