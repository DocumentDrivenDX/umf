import json,hashlib,re,sys,shutil,subprocess
from pathlib import Path
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent
paths={'src/extensions/security/write.ts','src/extensions/security/evaluate.ts','src/extensions/security/policy-v2-legacy-access.ts','src/extensions/security/protection/obligations.ts','src/extensions/security/protection/disclosure.ts','src/extensions/security/action-purposes.ts'}
queue=list(paths)
while queue:
 p=queue.pop()
 for imp in re.findall(r"(?:from|import)\s*['\"]([^'\"]+)['\"]",(root/p).read_text()):
  if not imp.startswith('.'):continue
  b=(root/p).parent/imp
  candidates=[b,b.with_suffix('.ts'),b/'index.ts']
  f=next((q.resolve() for q in candidates if q.is_file()),None)
  if f is None:continue
  rel=str(f.relative_to(root))
  if rel not in paths:paths.add(rel);queue.append(rel) if rel.endswith('.ts') else None
paths.update(['src/index.ts','bun.lock','package.json','tests/security/write-read-protection.test.ts','tests/security/write-fixture.ts','tests/security/write.test.ts','docs/helix/02-design/contracts/CONTRACT-062-security-semantics.md','docs/helix/02-design/technical-designs/TD-079-security-semantics.md','docs/helix/03-test/test-plans/STP-079-security-semantics.md','tools/security/prove-write-read-guard.py'])
for f in root.glob('spec/extensions/security*/**/*.json'):paths.add(str(f.relative_to(root)))
result={'scope':'Selected direct library dependency closure plus governing sources; not full root bundle/runtime provenance.','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sources':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}}
for p in paths:
 dest=out/'sources'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,dest)
(out/('source-pins-'+sys.argv[1]+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print(len(paths))
