import {evaluateSecurityWrite} from '/private/tmp/security-write-protection-review-20261015/head-323f4a04/src/extensions/security/write';
import {evaluateSecurityAccess} from '/private/tmp/security-write-protection-review-20261015/head-323f4a04/src/extensions/security/evaluate';
import fixtures from './fixtures.json';
import {createHash} from 'node:crypto';
const root='/private/tmp/security-write-protection-review-20261015/head-323f4a04';
const files=['src/extensions/security/write.ts','src/extensions/security/evaluate.ts','src/extensions/security/policy.ts'];
const pins=async()=>Object.fromEntries(await Promise.all(files.map(async p=>[p,createHash('sha256').update(new Uint8Array(await Bun.file(root+'/'+p).arrayBuffer())).digest('hex')])));
const before=await pins(),rows:any[]=[];
for(const name of ['original-visible-update','withheld-no-blind','transformed-no-blind','mask-output-write-back-no-blind','transformed-null-no-blind','read-denied-no-blind','missing-protected-read-disposition','conflicting-read-transform','original-null','original-absence','proposed-absence','equal-canonical-value-is-not-mutation','original-only-old-state-insufficient','create-withheld-refuses','delete-withheld-refuses']){
 const c=(fixtures.cases as any[]).find(c=>c.id===name),f=structuredClone(c.input);delete f.profile.readProtection;
 const before=f.request.original,after=f.request.proposed;
 const read=(s:any)=>evaluateSecurityAccess(f.policy,f.resolution,s.cut,{action:'read-own',output:[{documentId:'write-oracle',moduleId:'types',elementId:'amount'}]},s.resource);
 const write=evaluateSecurityWrite(f.policy,f.resolution,f.profile,f.request);
 rows.push({id:name,expectedNewAdmission:c.expectedAdmission,observedOldWrite:write,oldRead:before?read(before):null,newRead:after?read(after):null});
}
const after=await pins();if(JSON.stringify(before)!==JSON.stringify(after))throw Error('Source changed during baseline');
await Bun.write('/private/tmp/security-write-protection-review-20261015/baseline-results.json',JSON.stringify({scope:'Actual current .1 implementation under its original profile shape; no native effects or future-profile qualification.',sourceDigests:after,rows},null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({id:r.id,write:r.observedOldWrite.decision,read:[r.oldRead?.decision,r.oldRead?.output[0]?.disposition,r.newRead?.decision,r.newRead?.output[0]?.disposition]}))));
