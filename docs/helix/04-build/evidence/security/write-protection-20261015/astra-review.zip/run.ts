import {runOracle} from './oracle';
const rows=runOracle();await Bun.write('/private/tmp/security-write-protection-review-20261015/current-results.json',JSON.stringify({scope:'Independent finite .1 correction only; no full S24/S25 or .2 qualification',rows},null,2)+'\n');console.log(JSON.stringify({rows:rows.length,failed:rows.filter(r=>!r.passed)}));
