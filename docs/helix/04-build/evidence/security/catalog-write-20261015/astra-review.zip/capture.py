from pathlib import Path
import json,hashlib,subprocess,shutil
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent
plan=json.loads((root/'docs/helix/03-test/security/cases.json').read_text());cases={r['id']:r for r in plan['cases']}
paths=set()
for id in ['S24','S25']:
 c=cases[id];paths.update([c['testSource'],c['oracleSource'],*c['implementationSources']])
paths.update(['docs/helix/03-test/security/cases.json','tests/security/catalog-write.test.ts','tests/security/catalog-write-fixture.ts','tests/security/operation-budget-candidate.test.ts','docs/helix/02-design/technical-designs/TD-079-security-semantics.md','docs/helix/03-test/test-plans/STP-079-security-semantics.md','docs/helix/04-build/security-field-protection-plan.md'])
pins={p:hashlib.sha256((root/p).read_bytes()).hexdigest()for p in sorted(paths)}
if not (out/'source-pins.json').exists():
 for p in paths:
  dst=out/'sources'/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/p,dst)
 (out/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
else:
 before=json.loads((out/'source-pins.json').read_text());(out/'source-custody.json').write_text(json.dumps({'unchanged':before==pins,'before':before,'after':pins},indent=2)+'\n');assert before==pins
base=json.loads(subprocess.check_output(['git','show','HEAD:docs/helix/03-test/security/cases.json'],cwd=root))
allowed={'status','command','evidence','testSource','oracleSource','implementationSources'}
deltas=[]
assert len(base['cases'])==len(plan['cases'])==158
for b,a in zip(base['cases'],plan['cases']):
 assert a['id']==b['id']
 keys=[k for k in set(a)|set(b)if a.get(k)!=b.get(k)]
 if keys:assert a['id']in ['S24','S25']and set(keys)<=allowed
 deltas.append({'id':a['id'],'changedFields':sorted(keys)})
py=(root/'tests/security/protection/write-oracle.py').read_text();original=(out/'independent-fixtures.py').read_text()
ts=(root/'tests/security/protection/write-oracle.ts').read_text();expected=(out/'acceptance-oracle.ts').read_text().replace("'./fixtures.json'","'./write-fixtures.json'").replace(str(root)+'/src/extensions/security', '../../../src/extensions/security/').replace('data.fixtures.filter','(data.fixtures as any[]).filter')
assert py.startswith(original) and py[len(original):].strip()=='''print(json.dumps(dict(version="independent-catalog-write-fixtures/0.1",counts={k:sum(f["case"]==k for f in generate()["fixtures"]) for k in ["S24","S25"]})))'''
assert ts==expected
assert (root/'tests/security/protection/write-fixtures.json').read_bytes()==(out/'fixtures.json').read_bytes()
(out/'adoption-review.json').write_text(json.dumps({'pythonOriginalPrefixExact':True,'pythonAppend':'stdout fixture version/count metadata only; independent generation/expectations unchanged','jsonByteExact':True,'typescriptRelocationsAndTypeOnlyCastExact':True,'caseCount':158,'onlyBindingsChanged':[r for r in deltas if r['changedFields']],'sourceCount':len(pins),'fullAssertionsCoversTimeoutsUnchanged':True,'selectedProvenance':'Declared source subset, not complete toolchain/runtime/browser closure'},indent=2)+'\n')
print(json.dumps({'sourceCount':len(pins),'adoption':True,'onlyBindingsChanged':[r['id']for r in deltas if r['changedFields']]}))
