from pathlib import Path
import re
r=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');p=Path(__file__).parent
s=(r/'src/extensions/security/catalog-write-candidate.ts').read_text();s=re.sub(r"from '([^']+)'",lambda m:"from '"+str((r/'src/extensions/security'/m[1]).resolve())+"'" if m[1].startswith('.')else m[0],s);s=s.replace("catch{return freeze({decision:'indeterminate',complete:false,authority:false});}","catch(error){console.error(error);return freeze({decision:'indeterminate',complete:false,authority:false});}")
(p/'diagnostic-module.ts').write_text(s)
