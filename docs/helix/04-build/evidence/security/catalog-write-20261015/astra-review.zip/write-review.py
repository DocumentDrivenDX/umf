from pathlib import Path
import json,hashlib,zipfile
p=Path(__file__).parent
h=lambda f:hashlib.sha256((p/f).read_bytes()).hexdigest()
b=json.loads((p/'browser-results.json').read_text());rows=json.loads((p/'all-results.json').read_text())['rows'];mut=json.loads((p/'mutation-results.json').read_text());pins=json.loads((p/'source-pins.json').read_text());formal=json.loads((p/'formal-replay.json').read_text());custody=json.loads((p/'source-custody.json').read_text())
assert len(rows)==1947 and all(r['passed']for r in rows) and b['parity'] and len(b['rows'])==1947 and not b['externalRequests'] and not b['pageErrors'] and b['hostGlobalsAbsent']
assert len(mut)==20 and all(m['selectedFailuresObserved']for m in mut) and not mut[0]['failed'] and all(m['failed']for m in mut[1:])
assert len(formal['queries'])==16 and custody['unchanged']
review={
 'status':'No remaining actionable defect found in the reviewed finite logical component scope.',
 'date':'2026-10-15','reviewer':'Astra independent review subagent','authoritativeRoot':'/Users/erik/.codex/worktrees/security-main-integration/umf',
 'baseline':'aa997a81fa44cbb9b90ada2c4f2d9e8a53e7a293',
 'scope':'Canonical source-closed multi-target logical write guard; complete typed before/after Record and association comparison; all-state ordinary/read-or-blind/vault requirements; shared operation ledgers; governed S24/S25 adoption. No authoritative repository edits, native processes or source-owner authentication performed.',
 'currentFindings':[],
 'resolvedFindings':[
  {'issue':'Changed stored carrier could omit vaultWriteAction and still permit.','evidence':'vault-before.json / vault-after.json; genuine preimage and mechanically relocated module retained.','result':'Independent well-typed missing-action fixture: preimage permit, corrected indeterminate.'},
  {'issue':'Ordinary nullable scalar comparison called the core allowed-value identity operation on null.','evidence':'null-witness.json / pre-null-write.ts / pre-null-module.ts','result':'Independent unchanged nullable Subject/witness fields: preimage indeterminate, corrected permit; null vs absence remains distinct.'},
  {'issue':'Blind-action aliases checked only against the same type profile.','evidence':'S24/cross-type-alias; omit-global-blind-separation mutant','result':'Complete-profile ordinary/read action separation now enforced.'},
  {'issue':'Create/delete needed conservative ownership checks for declared owned associations even when the inventory was empty.','evidence':'create/delete-empty-owned-inventory-still-needs-owner; omit-empty-owned-create-delete mutant','result':'Corrected to require ownership and source-dependent policy actions.'}
 ],
 'independentExecution':{'bun':b['versions']['bun'],'chromium':b['versions']['chromium'],'sameRowsEachRuntime':1947,'S24':144,'S25':58,'additionalWriteControls':132,'priorActionControls':1088,'priorCollectionControls':525,'parity':True,'externalRequests':0,'pageErrors':[],'hostGlobalsAbsent':True,'result':'All exact expectations passed; no native lifecycle independently run.'},
 'sourceWeakening':{'variants':19,'originalControls':334,'allSelectedFailuresObserved':True,'scope':'Bun isolated copies; expected concrete failed rows, no import/crash accepted as discrimination. Full original source copies excluded from archive; changed modules and exact edit selectors retained.'},
 'formal':{'queries':16,'unsat':10,'sat':6,'z3':formal['z3'],'scope':'Conditional quantified logical obligations, multiset arithmetic and budget judgments; assumes faithful typed comparison, complete mappings/cuts and all-state grants. The monotone bound is an assumed accounting law, not implementation extraction or total CPU/heap proof.'},
 'adoption':{'jsonByteExact':True,'pythonOriginalPrefixExact':True,'pythonAppend':'stdout count/version metadata only','typescriptChanges':'Two module-import relocations, fixture filename relocation, type-only any[] boundary cast. No expected outcomes changed.','bindingsChangedOnly':['S24','S25'],'requiredCases':158,'assertionsCoversLayersTimeoutsUnchanged':True,'independentlyReplayedGovernedObservations':{'S24':296,'S25':124},'sourcePinsPerGovernedWrapper':68},
 'qualification':'The unchanged S24/S25 contract/browser assertions are supported by these actual guard executions, including mask-equal changed values and exact token/encrypt vault actions. This is not qualification of native cases or the whole goal. Logical no-op updates still need object permission but do not prove absence of physical SET/trigger intent. Equal opaque endpoint multisets do not prove absence of physical replacement.',
 'limits':['Trusted issued compiler/source and owner mapping/cut attestation remain premises; no native credentials, permit/seal, current-authority or backend admission.','No crypto, key, vault, reverse or storage side effect is executed or proven.','Opaque witness handles have per-cut dedup meaning only; cross-cut comparison preserves role-labelled endpoint multiplicity.','Private resource ledgers bound declared operations/retained text, not total pre-snapshot allocation, CPU or heap.','Selected 75-source provenance plus Bun/browser tool versions is not a hermetic toolchain or dependency-authenticity proof.'],
 'developmentEvidence':['Malformed empty-actions no-op fixture corrected to a valid nonmatching grant; exact deny unchanged.','Encrypt keyed custody fixture initially omitted keyRef; corrected to the published keyed wire contract, no expected decisions changed.','True forbid was initially mislabelled conflict; corrected to deny under original strong-Kleene evaluator and a separate genuine transform conflict added.','New-anchor mutation first survived because the independent fixture accidentally changed the new anchor Record; corrected to a true no-op anchor; all three flat/Record/opaque anchor failures now observed.','One isolated dependency-guard deletion caused a syntactic empty-loop error; retained separately, corrected with a no-op body, and not counted as discrimination.','Initial missing-vault probe was masked by the separate null defect; null-witness.json records it and isolated nonnull before/after proves the vault defect.'],
 'sourceCount':len(pins),'sourceCustodyUnchanged':True,
 'artifacts':{f:h(f)for f in ['source-pins.json','source-custody.json','adoption-review.json','oracle-freeze.json','all-results.json','browser-results.json','mutation-results.json','formal.py','formal-replay.json','governed-S24.json','governed-S25.json','vault-before.json','vault-after.json','null-witness.json','independent-fixtures.py','fixtures.json','acceptance-oracle.ts']}
}
(p/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(p/'README.md').write_text('''# Independent canonical graph write review

Current source review found no remaining actionable defect within the stated logical component scope. `review.json` contains exact counts, fixed findings, qualification limits, and artifact hashes; `source-pins.json` identifies 75 reviewed source/test/governance files.

Independent S24/S25 expectations are authored in `independent-fixtures.py`; run it to regenerate `fixtures.json`. `acceptance-oracle.ts` evaluates those fixtures through the actual issued compiler and write guard. `run-all.ts` and `run-browser.ts` add independent component controls and preserved action/collection regressions. Import roots are explicit local review paths and can be mechanically relocated without altering expectations.

The archive retains source snapshots, original defect preimages, developmental failures, exact mutation replacement selectors, changed mutant modules and all observed rows. It intentionally excludes complete mutant source trees, node_modules, native binaries and unrelated media. Recreating mutations requires a checkout matching the selected source pins plus the original Bun dependencies; scripts do not claim hermetic dependency closure. Native tests/full-gate qualification are owned by the parent task and were not independently rerun here.

The frozen S24/S25 oracle files are unchanged after handoff. The governed adoption adds only relative imports, a type-only boundary annotation, and Python stdout metadata; fixture bytes and every expected decision remain exact. S24/S25 are logical contract/browser cases. Source authenticity, native effects, current authority, vault execution and whole-backend admission remain separate requirements.
''')
# Bounded archive: top-level review files, selected source snapshots, original independent regressions,
# and only changed mutant modules/runners/results/logs (not full source clones or symlinks).
paths=[f for f in p.iterdir()if f.is_file()and f.suffix not in ['.zip']and f.name not in ['archive-manifest.json']]
paths += [f for d in ['sources','regressions'] for f in (p/d).rglob('*')if f.is_file()and not f.is_symlink()]
for m in mut:
 d=p/'mutants'/m['variant'];paths += [d/n for n in ['run.ts','results.json','run.log'] if(d/n).is_file()]
 paths += [d/x['path']for x in m['changedSources']]
paths=sorted(set(paths));manifest={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest()for f in paths}
(p/'archive-manifest.json').write_text(json.dumps({'files':manifest,'excluded':['full mutant source copies','node_modules','native binaries','unrelated spec/media'],'reviewSha256':h('review.json')},indent=2)+'\n')
with zipfile.ZipFile(p/'review-archive.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in paths+[p/'archive-manifest.json']:z.write(f,str(f.relative_to(p)))
print(json.dumps({'review':str(p/'review.json'),'reviewSha256':h('review.json'),'archive':str(p/'review-archive.zip'),'archiveSha256':h('review-archive.zip'),'archiveBytes':(p/'review-archive.zip').stat().st_size,'files':len(paths)+1,'observations':len(rows),'mutants':len(mut)-1,'sources':len(pins)}))
