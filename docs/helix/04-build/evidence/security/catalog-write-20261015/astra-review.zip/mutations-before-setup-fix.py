import json,shutil,subprocess,hashlib
from pathlib import Path
root=Path('/Users/erik/.codex/worktrees/security-main-integration/umf');out=Path(__file__).parent;dest=out/'mutants';dest.mkdir(exist_ok=True)
w='src/extensions/security/catalog-write-candidate.ts';r='src/extensions/security/catalog-runtime-candidate.ts'
variants=[('original',[],[]),
 ('omit-read-or-blind',[(w,'if(needs.length){const read=','if(false){const read=')],['S24/two-state-original-read0-blind0']),
 ('treat-transform-as-original',[(w,"d.disposition.kind==='original'",'true')],['S24/mask-equal-distinct-inline-0','S24/mask-equal-distinct-catalog-0']),
 ('first-blind-mapping-for-every-field',[(w,'m.p.blind.get(f)','[...m.p.blind.values()][0]',3)],['S24/wrong-field-blind-map']),
 ('omit-vault-presence',[(w,"if(!t.custody?.vaultWriteAction)fail();const kind=purposes.get(t.custody.vaultWriteAction);if(!kind||kind.length!==1||kind[0]!=='vault-write')fail();actions.add(t.custody.vaultWriteAction);","if(t.custody?.vaultWriteAction){const kind=purposes.get(t.custody.vaultWriteAction);if(!kind||kind.length!==1||kind[0]!=='vault-write')fail();actions.add(t.custody.vaultWriteAction);}")],['S25/tokenize-missing','S25/encrypt-missing']),
 ('omit-vault-grant',[(w,'actions.add(t.custody.vaultWriteAction);','')],['S25/tokenize-update-vaultFalse-blindTrue','S25/encrypt-no-vault-substitute-reverse-token']),
 ('update-checks-original-only',[(w,"m.source.operation==='delete'?[before]:states","m.source.operation==='delete'?[before]:[before]")],['S24/two-state-original-read1-blind0','S25/tokenize-vault-states1']),
 ('omit-field-permission',[(w,'...m.changed.map((f:any)=>m.p.actions.get(f)),','')],['S24/field-grant-required-before','S24/field-grant-required-after']),
 ('omit-unlisted-record-refusal',[(w,"if((!a||!b||!equalProjection(a.projection,b.projection))&&!mutations.has(key))fail();",'')],['extra/unlisted-unassociated-record']),
 ('omit-global-blind-separation',[(w,'if(ordinaryIds.has(action))fail();','')],['S24/cross-type-alias']),
 ('omit-null-comparison',[(w,"if(value===null){literal.check(f.document,f.field,null);return 'null';}",'')],['S24/flat-positive','S24/original-null-absence-94']),
 ('omit-empty-owned-create-delete',[(w,"for(const m of mutations.values())if(m.source.operation!=='update')for(const [i,binding] of bindings)","for(const m of mutations.values())if(false)for(const [i,binding] of bindings)")],['S24/create-empty-owned-inventory-still-needs-owner','S24/delete-empty-owned-inventory-still-needs-owner']),
 ('collapse-opaque-multiplicity',[(w,'if(group)group.count++;','if(group)group.count=1;')],['component/opaque-multiplicity-not-set']),
 ('omit-new-incidence-anchor',[(w,'if(delta<=0)continue;','if(delta<=0||state===after)continue;')],['component/flat-missing-new-anchor','component/record-missing-new-anchor','component/opaque-missing-new-anchor']),
 ('omit-subject-projection-comparison',[(w,'||!equalProjection(subjectBefore.projection,subjectAfter.projection)','')],['S24/subject']),
 ('reset-all-ledgers-per-action',[(r,'run(handle,owner,cut,request,false,operation)','run(handle,owner,cut,request,false)')],['S24/whole-operation-literal-ledger-8000','S24/whole-operation-step-ledger']),
 ('omit-source-policy-dependencies',[(w,'if(!p.policyFields.has(field))fail();','')],['extra/false-branch-source-dependency-not-omittable']),
 ('omit-policy-change-action',[(w,'...(m.policy?[p.policyAction]:[])','...[]')],['extra/policy-field-change-needs-policy-action']),
 ('omit-context-immutability',[(w,"if(!equalProjection(context(request.before),context(request.after)))fail();",'')],['extra/context-immutable']),
 ('omit-value-profile-immutability',[(w,"if(canonicalSchemaJson(profilesOf(request.before))!==canonicalSchemaJson(profilesOf(request.after)))fail();",'')],['extra/value-profiles-immutable'])]
results=[]
for name,edits,expected in variants:
 d=dest/name;shutil.copytree(root/'src',d/'src',dirs_exist_ok=True)
 for dirname in ['spec','node_modules','native']:
  if not (d/dirname).exists():(d/dirname).symlink_to(root/dirname)
 for edit in edits:
  path,old,new,*count=edit;p=d/path;s=p.read_text();assert s.count(old)==(count[0]if count else 1),(name,s.count(old));p.write_text(s.replace(old,new))
 for f in ['base-fixture.json','fixtures.json']:shutil.copyfile(out/f,d/f)
 for f in ['fixture.ts','oracle.ts','acceptance-oracle.ts','extra-oracle.ts']:(d/f).write_text((out/f).read_text().replace(str(root),str(d)))
 (d/'run.ts').write_text("import{runOracle as c}from './oracle';import{runOracle as a}from './acceptance-oracle';import{runOracle as e}from './extra-oracle';const rows=[...a('S24').map(x=>({...x,id:'S24/'+x.id})),...a('S25').map(x=>({...x,id:'S25/'+x.id})),...c().map(x=>({...x,id:'component/'+x.id})),...e().map(x=>({...x,id:'extra/'+x.id}))];await Bun.write(import.meta.dir+'/results.json',JSON.stringify({rows},null,2)+'\\n');console.log(JSON.stringify({count:rows.length,failed:rows.filter(r=>!r.passed).map(r=>r.id)}));")
 p=subprocess.run(['/opt/homebrew/bin/bun',str(d/'run.ts')],cwd=d,text=True,capture_output=True,timeout=45);(d/'run.log').write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError((name,p.returncode,p.stdout,p.stderr))
 rows=json.loads((d/'results.json').read_text())['rows'];failed=[x['id']for x in rows if not x['passed']]
 result=dict(variant=name,count=len(rows),failed=failed,expectedSelectedFailures=expected,selectedFailuresObserved=set(expected).issubset(failed),changedSources=[dict(path=path,sha256=hashlib.sha256((d/path).read_bytes()).hexdigest())for path in dict.fromkeys(e[0]for e in edits)])
 results.append(result);print(json.dumps(result),flush=True);(out/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
 assert bool(failed)==(name!='original'),(name,failed)
 assert set(expected).issubset(failed),(name,expected,failed)
