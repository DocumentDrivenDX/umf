# Independent canonical graph write review

Current source review found no remaining actionable defect within the stated logical component scope. `review.json` contains exact counts, fixed findings, qualification limits, and artifact hashes; `source-pins.json` identifies 75 reviewed source/test/governance files.

Independent S24/S25 expectations are authored in `independent-fixtures.py`; run it to regenerate `fixtures.json`. `acceptance-oracle.ts` evaluates those fixtures through the actual issued compiler and write guard. `run-all.ts` and `run-browser.ts` add independent component controls and preserved action/collection regressions. Import roots are explicit local review paths and can be mechanically relocated without altering expectations.

The archive retains source snapshots, original defect preimages, developmental failures, exact mutation replacement selectors, changed mutant modules and all observed rows. It intentionally excludes complete mutant source trees, node_modules, native binaries and unrelated media. Recreating mutations requires a checkout matching the selected source pins plus the original Bun dependencies; scripts do not claim hermetic dependency closure. Native tests/full-gate qualification are owned by the parent task and were not independently rerun here.

The frozen S24/S25 oracle files are unchanged after handoff. The governed adoption adds only relative imports, a type-only boundary annotation, and Python stdout metadata; fixture bytes and every expected decision remain exact. S24/S25 are logical contract/browser cases. Source authenticity, native effects, current authority, vault execution and whole-backend admission remain separate requirements.
