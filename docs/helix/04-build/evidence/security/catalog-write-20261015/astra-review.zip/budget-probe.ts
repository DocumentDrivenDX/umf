import{fixture,run,set}from './fixture';
for(const n of[1000,2000,3000,4000,5000,6000,7000,8000]){const f=fixture();for(const s of['before','after'])set(f.request[s],'Person','person-label',{string:'x'.repeat(n)});console.log(n,run(f).decision);}
for(const n of[1000,1500,2000,2500,3000,4000,5000,6000]){const f=fixture();f.request.maxSteps=n;console.log('steps',n,run(f).decision);}
