import {chromium} from '/Users/erik/.codex/worktrees/security-main-integration/umf/node_modules/playwright/index.mjs';
import {createHash} from 'node:crypto';
const out='/private/tmp/security-v2-write-review-20261015';
const build=await Bun.build({entrypoints:[out+'/all-oracle.ts'],target:'browser',format:'esm'});
if(!build.success||build.outputs.length!==1)throw Error('Browser build refused');
const js=await build.outputs[0]!.text();if(js.length>16_000_000)throw Error('Bundle bound');
const server=Bun.serve({hostname:'127.0.0.1',port:0,fetch:r=>new URL(r.url).pathname==='/oracle.js'?new Response(js,{headers:{'content-type':'text/javascript'}}):new Response('<!doctype html><title>Independent canonical logical runtime oracle</title>')});
let browser;
try{
 browser=await chromium.launch({headless:true});const page=await browser.newPage();
 const pageErrors:string[]=[];let externalRequests=0;page.on('pageerror',e=>pageErrors.push(String(e)));
 await page.route('**/*',r=>new URL(r.request().url()).origin===`http://127.0.0.1:${server.port}`?r.continue():(externalRequests++,r.abort()));
 await page.goto(`http://127.0.0.1:${server.port}`);
 const observed=await page.evaluate(async()=>{const path='/oracle.js',m=await import(path);const rows=await m.runOracle();return{rows,hostGlobalsAbsent:['Bun','process','Buffer','Deno'].every(k=>!(k in globalThis))};});
 const bun=await Bun.file(out+'/all-results.json').json();
 const receipt={versions:{bun:Bun.version,chromium:browser.version()},...observed,externalRequests,pageErrors,parity:JSON.stringify(observed.rows)===JSON.stringify(bun.rows),bundle:{sha256:createHash('sha256').update(js).digest('hex'),utf16Units:js.length},scope:'Actual multi-target logical write guard and prior action/collection regression. S24/S25 contract/browser observations only; no source authentication, native authority/effects, crypto/custody execution, query admission or total CPU/heap theorem.'};
 await Bun.write(out+'/browser-results.json',JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({rows:observed.rows.length,failed:observed.rows.filter((r:any)=>!r.passed),parity:receipt.parity,externalRequests,pageErrors,hostGlobalsAbsent:observed.hostGlobalsAbsent,versions:receipt.versions}));
 if(observed.rows.some((r:any)=>!r.passed)||!receipt.parity||externalRequests||pageErrors.length||!observed.hostGlobalsAbsent)process.exitCode=1;
}finally{await browser?.close();server.stop(true);}
