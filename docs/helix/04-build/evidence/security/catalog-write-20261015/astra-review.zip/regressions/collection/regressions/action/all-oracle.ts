import{runTruthOracle}from './truth-oracle';import{runRuntimeOracle}from './runtime-oracle';
export function runOracle(){return [...runTruthOracle().map(r=>({...r,id:'truth/'+r.id})),...runRuntimeOracle().map(r=>({...r,id:'boundary/'+r.id}))];}
