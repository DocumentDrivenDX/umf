import base from './base-fixture.json';import corpus from './logic-vectors.json';
import{compileCandidateCatalogProgram as compile}from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-program-candidate';
import{evaluateCandidateCatalogAction as evaluate}from '/Users/erik/.codex/worktrees/security-main-integration/umf/src/extensions/security/catalog-runtime-candidate';
const clone=(v:any)=>structuredClone(v),ref=(elementId:string,moduleId='entities')=>({documentId:'review-domain',moduleId,elementId});
export const fixture=()=>clone(base);
export const run=(f:any)=>evaluate(compile(f.policy,f.catalog,f.closure,f.ontology),f.owner,f.cut,f.request);
export function truthTerm(t:string):any{return t==='U'?{op:'eq',left:{kind:'resource',field:ref('amount')},right:{kind:'constant',field:ref('dto-number','domains'),value:null}}:{op:'literal',value:t==='T'};}
export function runTruthOracle(){const rows:any[]=[];for(const c of corpus.rows as any[]){const f=fixture(),resource=f.cut.facts.find((x:any)=>x.type.elementId==='Asset');resource.fields=resource.fields.filter((x:any)=>x.field.elementId!=='amount');resource.absent=[ref('amount')];let expected=c.expected,condition:any;
 if(c.operator==='decision'){let index=0;f.policy.rules=['permit','require','forbid'].flatMap(effect=>c[effect].map((t:string)=>({id:'r'+index++,effect,actions:['read'],target:[ref('Asset')],condition:truthTerm(t)})));}
 else{expected={T:'permit',F:'deny',U:'indeterminate'}[expected as 'T'|'F'|'U'];
  if(c.operator==='exists'){f.cut.facts=f.cut.facts.filter((x:any)=>x.type.elementId!=='Link');for(const [i,t]of c.input.entries()){const record=clone(base.cut.facts[2]);record.key=[{string:'l'+i}];record.fields.find((x:any)=>x.field.elementId==='link-key').value={string:'l'+i};const field=record.fields.find((x:any)=>x.field.elementId==='note');if(t==='U'){record.fields=record.fields.filter((x:any)=>x.field.elementId!=='note');record.absent=[ref('note')];}else field.value=t==='T'?null:{string:'not-null'};f.cut.facts.push(record);}condition={op:'exists',association:ref('Link'),as:'l',where:{op:'eq',left:{kind:'variable',name:'l',field:ref('note')},right:{kind:'constant',field:ref('dto-text','domains'),value:null}}};}
  else condition=c.operator==='not'?{op:'not',arg:truthTerm(c.input[0])}:{op:c.operator,args:c.input.map(truthTerm)};
  f.policy.rules=[{id:'truth',effect:'permit',actions:['read'],target:[ref('Asset')],condition}];
 }
 let actual:any=null,error:any=null;try{actual=run(f);}catch(e){error=String(e);}const pass=actual?.status==='evaluated'&&actual.complete===false&&actual.authority===false&&actual.rows.length===1&&actual.rows[0].decision===expected&&actual.rows[0].dispositions.length===0;rows.push({id:c.id,expected,actual,error,passed:pass});}
 return rows;}
