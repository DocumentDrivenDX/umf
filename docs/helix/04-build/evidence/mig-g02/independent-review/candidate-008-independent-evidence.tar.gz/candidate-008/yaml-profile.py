import copy, gzip, hashlib, io, json
from pathlib import Path
from ruamel.yaml import YAML
from umf_codegen import compile_table_deployment, compile_table_migration

base=Path('/private/tmp/umf-g02-independent-008')
plan=json.loads(next((base/'plans').glob('*.json')).read_text())
cfg=plan['next']['configuration']
def bundle(source, fmt):
 text=source['utf8']
 if fmt=='yaml':
  stream=io.StringIO();YAML().dump(json.loads(text),stream);text=stream.getvalue()
 result=compile_table_deployment(text,format=fmt,configuration=cfg)
 assert result['status']=='compiled',result
 return result['bundle']
bundles={}
for side in ('previous','next'):
 for fmt in ('json','yaml'):
  bundles[side,fmt]=bundle(plan[side]['source'],fmt)
results=[]
for oldfmt,newfmt in (('yaml','json'),('json','yaml'),('yaml','yaml')):
 result=compile_table_migration(migration_id=plan['id'],predecessor=plan['predecessor'],previous_bundle=bundles['previous',oldfmt],next_bundle=bundles['next',newfmt],options=plan['options'])
 assert result['status']=='blocked' and result.get('diagnostics'),result
 assert any(d.get('path') in ('/previous/source/format','/next/source/format') for d in result['diagnostics']),result
 results.append({'formats':[oldfmt,newfmt],'status':result['status'],'diagnostics':result['diagnostics']})
fixture=json.load(gzip.open(base/'evidence/g01/fixture.json.gz','rt'))['cases'][0]
old=bundle(fixture['initialSource'],'yaml');new=bundle(fixture['source'],'yaml')
legacy=compile_table_migration(migration_id=fixture['plan']['id'],predecessor=fixture['plan']['predecessor'],previous_bundle=old,next_bundle=new,options=fixture['plan']['options'])
assert legacy['status']=='compiled' and legacy['plan']['version']=='umf.table-migration/0.3',legacy
out={'scope':'compiler-only; no storage effects','runnerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'manifestSha256':hashlib.sha256((base/'owner-artifacts.json').read_bytes()).hexdigest(),'newProfile':results,'legacy03YamlStatus':legacy['status']}
(base/'yaml-profile.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'passed','newProfileRefusals':len(results),'legacy03YamlStatus':legacy['status']}))
