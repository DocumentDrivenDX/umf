import concurrent.futures
import json
import pathlib
import subprocess
import sys

base = pathlib.Path('/private/tmp/umf-g02-independent-008')
runner = base / 'evidence/g02/installed-text-oracle.py'
cases = [
 ('text', []),
 ('ne-null', ['--text-expression','ne-null','--case','valid']),
 ('not-eq-value', ['--text-expression','not-eq-value','--case','valid']),
 ('not-ne-null', ['--text-expression','not-ne-null','--case','valid']),
 ('coalesce-empty', ['--text-expression','coalesce','--empty-input','--case','valid']),
 ('enum', ['--domain','integer','--case','invalid','--enum-rejection']),
 ('unique', ['--shape','existing','--case','invalid','--native-constraint','unique']),
 ('foreign-key', ['--shape','existing','--case','invalid','--native-constraint','foreign-key']),
 ('varchar-loss', ['--case','invalid','--native-constraint','varchar-loss']),
 ('bound-excess', ['--case','invalid','--bound-excess']),
 ('empty-table', ['--case','valid','--empty-table']),
 ('all-populated', ['--case','valid','--shape','existing','--all-populated']),
]

def run(item):
 name, args = item
 report = base / (name+'.json')
 assert not report.exists(), report
 with (base/(name+'.log')).open('w') as log:
  result = subprocess.run([sys.executable,'-I',str(runner),'--dsn','dbname=postgres',*args,'--report',str(report)],stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:
  raise RuntimeError((name,result.returncode,(base/(name+'.log')).read_text()[-3500:]))
 data = json.loads(report.read_text())
 assert data['status']=='passed' and all(c['passed'] for c in data['cases'])
 print(json.dumps({'name':name,'cases':len(data['cases']),'status':'passed'}),flush=True)
 return {'name':name,'cases':len(data['cases']),'status':'passed'}

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results = list(pool.map(run,cases))
(base/'remaining-summary.json').write_text(json.dumps(results,indent=2)+'\n')
