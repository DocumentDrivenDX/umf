import {Registry,validateDocument,CURRENT_CORE_VERSION,compileTableMigration,verifyTableMigration} from '@umf/core';
import {createValidator} from '@umf/core/loader-contract';
import {readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const base='/private/tmp/umf-g02-independent-008';
const corpus=await Bun.file('/Users/erik/.codex/worktrees/eb69/umf/fixtures/metamodel/current-conformance.json').json();
if(corpus.currentVersion!==CURRENT_CORE_VERSION||typeof createValidator!=='function')throw Error('Installed entrypoint/core marker mismatch');
for(const item of corpus.cases){
 const registry=new Registry();
 if(item.registry)registry.register({id:item.registry.id,version:item.registry.version,coreVersion:CURRENT_CORE_VERSION,description:'Frozen callback probe',schema:true,semantics:'Trusted callback probe',scopes:[item.registry.scope],capabilities:{validation:'semantic',directions:[],evidence:[]}},(payload,context)=>[{code:'BASELINE_CALLBACK',path:context.path,message:context.document.id+':'+context.scope+':'+payload.kind,severity:'warning'}]);
 if(!Bun.deepEquals(validateDocument(item.document,registry),{valid:item.valid,complete:item.complete,diagnostics:item.diagnostics}))throw Error('Installed core conformance '+item.id);
}
const paths=(await readdir(base+'/plans')).filter(x=>x.endsWith('.json')).sort();
for(const path of paths){
 const plan=await Bun.file(base+'/plans/'+path).json();
 const compiled=compileTableMigration({id:plan.id,predecessor:plan.predecessor,previous:plan.previous,next:plan.next,options:plan.options});
 if(compiled.status!=='compiled'||!Bun.deepEquals(compiled.plan,plan))throw Error('SDK/Python plan mismatch '+path);
 if(!Bun.deepEquals(verifyTableMigration(plan),plan))throw Error('SDK plan verifier mismatch '+path);
}
const file=base+'/sdk-consumer/probe.ts';
const report={status:'passed',runtime:Bun.version,consumerPath:import.meta.dir,scriptSha256:createHash('sha256').update(await Bun.file(file).bytes()).digest('hex'),sdkSha256:'3f33611a51846a2af7eac3b50888c5844dd02d9570b9f2cc8f0886cc04e8335b',installation:'Bun offline cache; scripts disabled',coreConformanceCases:corpus.cases.length,exactPythonNativePlanParity:paths.length,sourceImports:false};
await Bun.write(base+'/sdk-installed.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
