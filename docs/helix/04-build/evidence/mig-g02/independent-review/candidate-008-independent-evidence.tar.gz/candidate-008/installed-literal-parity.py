"""Independent installed UMF/Weft CoreLiteral admission; no storage effects."""
import argparse
import copy
from decimal import Decimal
import gzip
import hashlib
import importlib.metadata
import importlib.util
import json
from pathlib import Path
import sys
from uuid import uuid4

from umf_access.lifecycle.seeds import _binding
from umf_codegen import compile_table_deployment
from weft import prepare_table_operation_module_json


parser = argparse.ArgumentParser()
parser.add_argument("--report", type=Path, required=True)
args = parser.parse_args()
fixture_path = Path(__file__).parent.parent / "g01/fixture.json.gz"
fixture = json.loads(gzip.open(fixture_path, "rt").read())
manifest_path = Path(sys.prefix).parent / "owner-artifacts.json"
provenance = {"runnerSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "fixtureSha256": hashlib.sha256(fixture_path.read_bytes()).hexdigest(), "artifactManifestSha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest() if manifest_path.exists() else None, "versions": {name: importlib.metadata.version(name) for name in ("umf-codegen", "weft-sql")}, "packageOrigins": {name: importlib.util.find_spec(name).origin for name in ("umf_codegen", "weft")}}
source = json.loads(fixture["cases"][0]["source"]["utf8"])
module = source["modules"][0]
target = next(field for field in module["elements"] if field["id"] == "summary")
target["scalarType"] = "integer"
module["elements"].insert(-1, {"id": "amount", "kind": "field", "scalarType": "integer", "cardinality": "one", "nullability": "required", "extensions": {}})
record = next(field for field in module["elements"] if field["id"] == "Note")
record["members"].insert(-1, {"module": "demo", "element": "amount"})
payload = module["extensions"]["umf.tables"]
table = payload["tables"][0]
next(column for column in table["columns"] if column["field"]["element"] == "summary")["nativeType"] = {"kind": "int2"}
table["columns"].insert(-1, {"field": {"module": "demo", "element": "amount"}, "name": "amount", "nativeType": {"kind": "int8"}})
command = payload["commands"][0]
command["version"] = "umf.table-operation/0.2"
command["body"]["values"][0]["value"] = {"kind": "rowExpression", "expression": {"op": "subtract", "left": {"op": "field", "field": {"module": "demo", "element": "amount"}}, "right": {"op": "literal", "value": {"integerToken": "99999"}}}}
prefix = "rv_g02_literals_" + uuid4().hex[:8]
config = {"module": "demo", "schema": prefix, "ownerRole": prefix + "_owner", "personRole": prefix + "_person", "batchRole": prefix + "_batch", "groupRoles": {}}
baseline = compile_table_deployment(json.dumps(source), configuration=config)
assert baseline["status"] == "compiled", baseline
base_binding = _binding(baseline["bundle"])
cases = [
    ("integerToken", "99999", True, "99999"),
    ("integerToken", "99999.0", True, "99999"),
    ("integerToken", "9.9999e4", True, "99999"),
    ("decimalToken", "99999.00", True, "99999"),
    ("decimalToken", "9.9999e4", True, "99999"),
    ("integerToken", "0e1000", True, "0"),
    ("integerToken", "0." + "0" * 2000 + "99999e2005", True, "99999"),
    ("decimalToken", "0." + "0" * 2000 + "99999e2005", True, "99999"),
    ("integerToken", "0e" + "9" * 64, True, "0"),
    ("decimalToken", "0e" + "9" * 64, True, "0"),
    ("integerToken", "99999.1", False, None),
    ("decimalToken", "99999.1", False, None),
    ("integerToken", "1e1001", False, None),
    ("decimalToken", "NaN", False, None),
    ("integerToken", "099999", False, None),
]
results = []
for wrapper, token, expected, mathematical in cases:
    document = copy.deepcopy(source)
    declaration = document["modules"][0]["extensions"]["umf.tables"]["commands"][0]
    declaration["body"]["values"][0]["value"]["expression"]["right"]["value"] = {wrapper: token}
    text = json.dumps(document)
    portable = compile_table_deployment(text, configuration=config)
    assert (portable["status"] == "compiled") == expected, (wrapper, token, portable)
    binding = copy.deepcopy(base_binding)
    binding["modelJson"] = text
    binding["modelSha256"] = hashlib.sha256(text.encode()).hexdigest()
    program, error_type = None, None
    try:
        prepared = prepare_table_operation_module_json(json.dumps({"version": "weft.table-operation-module/0.1", "target": "postgresql18", "binding": binding, "module": "demo"}))
        program = json.loads(prepared.prepare(command["id"]).bind_json(json.dumps({"call": {"kind": "single", "inputs": {}}, "idempotencyKey": "independent-literal-parity"})))
    except Exception as error:
        error_type = type(error).__name__
    accepted = program is not None and program.get("status") == "compiled"
    assert accepted == expected, (wrapper, token, accepted, error_type)
    if expected:
        assert program["version"] == "weft.table-operation/0.2"
        slots = [slot["source"] for slot in program["parameterSources"] if slot["source"]["kind"] == "literal"]
        assert slots
        assert all(slot["value"] == {wrapper: token} and Decimal(str(slot["nativeValue"])) == Decimal(mathematical) for slot in slots)
    results.append({"wrapper": wrapper, "token": token if len(token) < 200 else None, "tokenBytes": len(token.encode()), "tokenSha256": hashlib.sha256(token.encode()).hexdigest(), "expectedAdmitted": expected, "portableAdmitted": expected, "weftAdmitted": accepted, "weftRefusalType": error_type})
boundaries = []
for family, cases in (("decimal", [("1e-1000", True), ("1e-1001", False)]), ("text", [("\\" * 1_048_576, True), ("\\" * 1_048_577, False)])):
    template = copy.deepcopy(source)
    field = next(item for item in template["modules"][0]["elements"] if item["id"] == "summary")
    field["scalarType"] = "decimal" if family == "decimal" else "string"
    mapping = next(item for item in template["modules"][0]["extensions"]["umf.tables"]["tables"][0]["columns"] if item["field"]["element"] == "summary")
    mapping["nativeType"] = {"kind": "numeric", "precision": 1000, "scale": 1000} if family == "decimal" else {"kind": "text"}
    if family == "decimal":
        field["facets"] = {"precision": 1000, "scale": 1000}
    expression = template["modules"][0]["extensions"]["umf.tables"]["commands"][0]["body"]["values"][0]["value"]
    wrapper = "decimalToken" if family == "decimal" else "string"
    expression["expression"] = {"op": "literal", "value": {wrapper: "0" if family == "decimal" else "x"}}
    initial = compile_table_deployment(json.dumps(template), configuration=config)
    assert initial["status"] == "compiled", initial
    initial_binding = _binding(initial["bundle"])
    for token, expected in cases:
        document = copy.deepcopy(template)
        document["modules"][0]["extensions"]["umf.tables"]["commands"][0]["body"]["values"][0]["value"]["expression"]["value"] = {wrapper: token}
        text = json.dumps(document)
        portable = compile_table_deployment(text, configuration=config)
        assert (portable["status"] == "compiled") == expected, (family, len(token), portable.get("diagnostics"))
        binding = copy.deepcopy(initial_binding)
        binding["modelJson"] = text
        binding["modelSha256"] = hashlib.sha256(text.encode()).hexdigest()
        program, error_type = None, None
        try:
            prepared = prepare_table_operation_module_json(json.dumps({"version": "weft.table-operation-module/0.1", "target": "postgresql18", "binding": binding, "module": "demo"}))
            program = json.loads(prepared.prepare(command["id"]).bind_json(json.dumps({"call": {"kind": "single", "inputs": {}}, "idempotencyKey": "independent-literal-boundary"})))
        except Exception as error:
            error_type = type(error).__name__
        accepted = program is not None and program.get("status") == "compiled"
        assert accepted == expected, (family, len(token), accepted, error_type)
        if expected:
            slots = [slot["source"] for slot in program["parameterSources"] if slot["source"]["kind"] == "literal"]
            assert slots and all(slot["value"] == {wrapper: token} for slot in slots)
            if family == "text":
                assert all(slot["nativeValue"] == token for slot in slots)
            else:
                assert all(Decimal(str(slot["nativeValue"])) == Decimal("1e-1000") for slot in slots)
        boundaries.append({"family": family, "tokenBytes": len(token.encode()), "tokenSha256": hashlib.sha256(token.encode()).hexdigest(), "expectedAdmitted": expected, "portableAdmitted": expected, "weftAdmitted": accepted, "weftRefusalType": error_type})
intrinsics = []
for target_family, op, expected in (("integer", "concat", False), ("string", "add", False), ("integer", "add", True), ("string", "concat", True), ("boolean", "add", False), ("boolean", "concat", False)):
    document = copy.deepcopy(source)
    field = next(item for item in document["modules"][0]["elements"] if item["id"] == "summary")
    field["scalarType"] = target_family
    mapping = next(item for item in document["modules"][0]["extensions"]["umf.tables"]["tables"][0]["columns"] if item["field"]["element"] == "summary")
    mapping["nativeType"] = {"kind": {"integer": "int2", "string": "text", "boolean": "boolean"}[target_family]}
    selected = document["modules"][0]["extensions"]["umf.tables"]["commands"][0]["body"]["values"][0]["value"]
    selected["expression"] = {"op": "literal", "value": {"integerToken": "1"} if target_family == "integer" else {"string": "x"} if target_family == "string" else {"boolean": True}}
    initial = compile_table_deployment(json.dumps(document), configuration=config)
    assert initial["status"] == "compiled", initial
    binding = _binding(initial["bundle"])
    null = {"op": "literal", "value": None}
    selected["expression"] = {"op": "concat", "args": [null, null]} if op == "concat" else {"op": "add", "left": null, "right": null}
    text = json.dumps(document)
    portable = compile_table_deployment(text, configuration=config)
    assert (portable["status"] == "compiled") == expected, (target_family, op, portable.get("diagnostics"))
    binding.update(modelJson=text, modelSha256=hashlib.sha256(text.encode()).hexdigest())
    program, error_type = None, None
    try:
        prepared = prepare_table_operation_module_json(json.dumps({"version": "weft.table-operation-module/0.1", "target": "postgresql18", "binding": binding, "module": "demo"}))
        program = json.loads(prepared.prepare(command["id"]).bind_json(json.dumps({"call": {"kind": "single", "inputs": {}}, "idempotencyKey": "independent-null-intrinsic"})))
    except Exception as error:
        error_type = type(error).__name__
    accepted = program is not None and program.get("status") == "compiled"
    assert accepted == expected, (target_family, op, accepted, error_type)
    intrinsics.append({"target": target_family, "intrinsic": op, "allOperandsNull": True, "expectedAdmitted": expected, "portableAdmitted": expected, "weftAdmitted": accepted})
predicate_domains = []
for case, expected in (("required-null", False), ("enum-outside", False), ("enum-inside", True), ("range-outside", False), ("range-inside", True), ("length-outside", False), ("varchar-native-only", True), ("int2-native-only", True), ("in-required-null", False), ("in-enum-outside", False), ("in-enum-inside", True), ("decoded-predicate-byte-boundary", True)):
    document = copy.deepcopy(source)
    m = document["modules"][0]
    table = m["extensions"]["umf.tables"]["tables"][0]
    field_id = "owner" if "enum" in case else "amount" if "range" in case or case == "int2-native-only" else "id"
    field = next(item for item in m["elements"] if item["id"] == field_id)
    mapping = next(item for item in table["columns"] if item["field"]["element"] == field_id)
    if "enum" in case:
        field["allowedValues"] = [{"string": "a"}, {"string": "b"}]
    if "range" in case:
        field["facets"] = {"range": {"min": {"integerToken": "0"}, "max": {"integerToken": "10"}}}
    if case == "length-outside":
        field["facets"] = {"length": {"max": 3, "unit": "unicode-scalar"}}
    if case in ("varchar-native-only", "decoded-predicate-byte-boundary"):
        mapping["nativeType"] = {"kind": "varchar", "length": 3}
    if case == "int2-native-only":
        mapping["nativeType"] = {"kind": "int2"}
    selected = m["extensions"]["umf.tables"]["commands"][0]["body"]["values"][0]["value"]
    selected["expression"] = {"op": "literal", "value": {"integerToken": "1"}}
    initial = compile_table_deployment(json.dumps(document), configuration=config)
    assert initial["status"] == "compiled", (case, initial)
    binding = _binding(initial["bundle"])
    value = None if "required-null" in case else {"string": "outside" if "outside" in case else "a"} if "enum" in case else {"integerToken": "11" if case == "range-outside" else "10"} if "range" in case else {"integerToken": "200000"} if case == "int2-native-only" else {"string": "\\" * 1_048_576 if case == "decoded-predicate-byte-boundary" else "abcd"}
    predicate = {"op": "eq", "field": {"module": "demo", "element": field_id}, "value": {"kind": "literal", "value": value}}
    if case.startswith("in-"):
        predicate = {"op": "in", "field": predicate["field"], "values": [{"kind": "literal", "value": {"string": "a"}}, {"kind": "literal", "value": value}]}
        if case == "in-enum-inside":
            predicate["values"][1]["value"] = {"string": "b"}
    selected["expression"] = {"op": "conditional", "when": predicate, "then": {"op": "literal", "value": {"integerToken": "1"}}, "else": {"op": "literal", "value": {"integerToken": "2"}}}
    text = json.dumps(document)
    portable = compile_table_deployment(text, configuration=config)
    assert (portable["status"] == "compiled") == expected, (case, portable.get("diagnostics"))
    binding.update(modelJson=text, modelSha256=hashlib.sha256(text.encode()).hexdigest())
    program, error_type = None, None
    try:
        prepared = prepare_table_operation_module_json(json.dumps({"version": "weft.table-operation-module/0.1", "target": "postgresql18", "binding": binding, "module": "demo"}))
        program = json.loads(prepared.prepare(command["id"]).bind_json(json.dumps({"call": {"kind": "single", "inputs": {}}, "idempotencyKey": "independent-predicate-domain"})))
    except Exception as error:
        error_type = type(error).__name__
    accepted = program is not None and program.get("status") == "compiled"
    assert accepted == expected, (case, accepted, error_type)
    predicate_domains.append({"case": case, "expectedAdmitted": expected, "portableAdmitted": expected, "weftAdmitted": accepted, "weftRefusalType": error_type})
report = {"status": "passed", "scope": "independent installed compiler/lowering admission only; no storage effects or release approval", "provenance": provenance, "cases": results, "boundaries": boundaries, "intrinsicNullCarriers": intrinsics, "predicateDomains": predicate_domains}
args.report.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report))
