import {createHash} from 'node:crypto';
import {chromium} from 'playwright';
const server=Bun.serve({hostname:'127.0.0.1',port:0,fetch(request){return new URL(request.url).pathname==='/umf.js'?new Response(Bun.file('dist/umf.js'),{headers:{'content-type':'text/javascript'}}):new Response('<!doctype html><html><body>Core Cardinality</body></html>',{headers:{'content-type':'text/html'}});}});
let browser;
try{
 browser=await chromium.launch({headless:true,...(process.env.UMF_CHROMIUM_PATH?{executablePath:process.env.UMF_CHROMIUM_PATH}:{})});const page=await browser.newPage(),external:string[]=[];
 await page.route('**/*',route=>{if(!route.request().url().startsWith(`http://127.0.0.1:${server.port}/`)){external.push(route.request().url());return route.abort();}return route.continue();});await page.goto(`http://127.0.0.1:${server.port}/`);
 const checks=await page.evaluate(async()=>{
  const path='/umf.js',u=await import(path);let recoveries=0,transitions=0,refusals=0,authorRecoveries=0,authorRefusals=0;
  function source(cardinality:unknown,itemType?:unknown){return {umf:'0.4.0',id:'browser',vocabularies:{future:{version:'1.0.0'}},modules:[{id:'m',namespace:'',elements:[{id:'e',kind:'field',cardinality,extensions:{future:{native:{repeated:true,unknown:'9007199254740993'}}},...(itemType===undefined?{}:{itemType})},{id:'item',kind:'field',scalarType:'integer',nullability:'absent-allowed',extensions:{}}]}]};}
  const equal=(a:unknown,b:unknown)=>{if(JSON.stringify(a)!==JSON.stringify(b))throw Error('Recovery mismatch');};
  for(const label of ['one','array','map','unspecified','future-container']){const doc=source(label);if(!u.validateDocument(doc).valid)throw Error('Valid shape refused');for(const format of ['json','yaml']){equal(u.readDocument(u.writeDocument(doc,format),format),doc);recoveries++;}}
  for(const shape of ['array','map'])for(const target of ['item','e']){const doc=source(shape,{module:'m',element:target});for(const format of ['json','yaml']){equal(u.readDocument(u.writeDocument(doc,format),format),doc);recoveries++;}}
  for(const value of ['one','array','map','unspecified',null,42,[],{module:'m',element:'item'}]){const legacy={...source(value,value),umf:'0.3.0'},receipt=u.upgradeCardinalityEnvelope(legacy);if(receipt.residuals.length!==2)throw Error('Missing collision archive');for(const format of ['json','yaml']){const saved=u.readJsonValue(u.writeJsonValue(receipt,format),format),back=u.rollbackCardinalityEnvelope(saved,saved.target);equal(back.target,legacy);transitions++;}const forged=structuredClone(receipt);forged.residuals=[];let refused=false;try{u.rollbackCardinalityEnvelope(forged,receipt.target);}catch{refused=true;}if(!refused)throw Error('Forged transition');refusals++;}
  for(const shape of ['array','map']){const doc=source(shape);Object.assign(doc.modules[0]!.elements[0]!,{scalarType:'integer'});if(u.validateDocument(doc).valid)throw Error('Container is scalar');refusals++;}
  for(const ref of [{module:'m',element:'missing'},{module:'missing',element:'item'},{}]){if(u.validateDocument(source('array',ref)).valid)throw Error('Invalid item target');refusals++;}
  let getterCalls=0;const unsafe=source('array');Object.defineProperty(unsafe.modules[0]!.elements[0]!,'itemType',{enumerable:true,get(){getterCalls++;return {};}});if(u.validateDocument(unsafe).valid||getterCalls)throw Error('Getter invoked');refusals++;
  for(const cardinality of ['one','array','map','unspecified']){
   const doc=source('one'),identity={module:'m',element:'e'},request={cardinality,...(['array','map'].includes(cardinality)?{itemType:{module:'m',element:'item',future:{opaque:true}}}:{})};
   const receipt=u.declareCoreCardinality(doc,identity,request);const inspection=u.inspectCoreCardinality(receipt.target,identity);if(inspection.meaning.state!=='known'||inspection.meaning.cardinality!==cardinality||inspection.provenance!=='unverified')throw Error('Inspection meaning');
   for(const format of ['json','yaml']){const saved=u.readJsonValue(u.writeJsonValue(receipt,format),format);equal(u.verifyCoreCardinalityDeclaration(saved,saved.target),receipt);equal(saved.source,doc);authorRecoveries++;}
   const forged=structuredClone(receipt);forged.provenance.idealPath='/wrong';let refused=false;try{u.verifyCoreCardinalityDeclaration(forged,receipt.target);}catch{refused=true;}if(!refused)throw Error('Forged authorship');authorRefusals++;
  }
  const array=source('array',{module:'m',element:'item'}),cleared=u.declareCoreCardinality(array,{module:'m',element:'e'},{cardinality:'one',itemType:null});if(Object.hasOwn(cleared.target.modules[0].elements[0],'itemType'))throw Error('Explicit clear');equal(cleared.source,array);
  const scalar=source('one');Object.assign(scalar.modules[0]!.elements[0]!,{scalarType:'integer'});let conflict=false;try{u.declareCoreCardinality(scalar,{module:'m',element:'e'},{cardinality:'array'});}catch{conflict=true;}if(!conflict)throw Error('Implicit scalar movement');authorRefusals++;
  let original08Inspections=0;
  for(const label of ['one','array','map','unspecified','future-container']){
   const doc={...source(label,['array','map'].includes(label)?{module:'m',element:'item',future:{opaque:true}}:undefined),umf:'0.8.0'};
   const result=u.inspectCoreCardinality(doc,{module:'m',element:'e'});
   if(result.version!=='5.0.0'||result.meaning.state!==(label==='future-container'?'unknown':'known'))throw Error('Original0.8 cardinality');equal(result.source,doc);equal(result.meaning,label==='future-container'?{state:'unknown',value:label}:{state:'known',cardinality:label,...(['array','map'].includes(label)?{itemType:(doc.modules[0]!.elements[0]! as {itemType?:unknown}).itemType}:{})});original08Inspections++;
  }
  if('Bun'in globalThis||'process'in globalThis)throw Error('Host globals');return {original08Inspections,recoveries,transitions,refusals,getterCalls,authorRecoveries,authorRefusals};
 });
 if(external.length)throw Error('External request');const paths=['spec/core/cardinality-operation-v5.schema.json','spec/core/schema-properties-document.schema.json','scripts/core-cardinality-operations-browser.ts','spec/core/cardinality-document.schema.json','spec/core/cardinality-transition.schema.json','src/model/cardinality-transition.ts','src/model/cardinality.ts','spec/core/cardinality-operation.schema.json','src/model/types.ts','src/validation/document.ts','src/validation/schema.ts','src/index.ts','dist/umf.js'];const fingerprints=Object.fromEntries(await Promise.all(paths.map(async p=>[p,createHash('sha256').update(new Uint8Array(await Bun.file(p).arrayBuffer())).digest('hex')])));
 await Bun.write('fixtures/validation/core-cardinality-operations-browser.json',JSON.stringify({scope:'Read-only original0.8 Cardinality inspection plus historical core0.4 inspection, authoring, verified receipts and migration recovery; native bindings remain unfinished',browser:browser.version(),checks,externalRequests:external,fingerprints},null,2)+'\n');console.log(JSON.stringify(checks));
}finally{await browser?.close();server.stop(true);}
