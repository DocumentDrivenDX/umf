import {licenseModules,moduleNotice,dependencyLicenseBasename} from './protobuf-module-notices';
import {mkdir,rm,copyFile as copySource,chmod,readdir} from 'node:fs/promises';
// Go toolchain cache files can be read-only; repeated builds own their output copies.
async function copyFile(source:string,target:string){try{await chmod(target,0o644);}catch(error:any){if(error.code!=='ENOENT')throw error;}await copySource(source,target);}
// This profile is the pinned standalone module, never an ambient workspace.
process.env.GOWORK='off';
const goVersion=Bun.spawn(['go','env','GOVERSION'],{stdout:'pipe'});
if((await new Response(goVersion.stdout).text()).trim()!=='go1.27.1'||await goVersion.exited)throw new Error('Protobuf compiler build requires Go 1.27.1');
await mkdir('dist/protobuf',{recursive:true});
const build=Bun.spawn(['go','build','-trimpath','-buildvcs=false','-o','../../dist/protobuf/compiler.wasm','.'],{cwd:'native/protobuf',env:{...process.env,GOOS:'js',GOARCH:'wasm'},stdout:'inherit',stderr:'inherit'});
if(await build.exited)process.exit(1);
const root=Bun.spawn(['go','env','GOROOT'],{stdout:'pipe'});
const path=(await new Response(root.stdout).text()).trim();if(await root.exited)process.exit(1);
await copyFile(path+'/lib/wasm/wasm_exec.js','dist/protobuf/wasm_exec.js');
await copyFile('native/protobuf/worker.js','dist/protobuf/worker.js');
console.log('Protobuf WASM compiler built');
await rm('dist/protobuf/licenses',{recursive:true,force:true});
await mkdir('dist/protobuf/licenses',{recursive:true});
const goLicense=await Bun.file(path+'/LICENSE').exists()?path+'/LICENSE':path+'/../LICENSE';
await copyFile(goLicense,'dist/protobuf/licenses/Go-LICENSE');
// Populate the complete pinned module graph independently of a warm host cache.
const download=Bun.spawn(['go','mod','download','all'],{cwd:'native/protobuf',stdout:'inherit',stderr:'inherit'});
if(await download.exited)throw Error('Cannot download pinned Protobuf license inputs');
const modules=Bun.spawn(['go','list','-m','-f','{{.Path}}|{{.Version}}|{{.Dir}}|{{.Main}}|{{if .Replace}}true{{else}}false{{end}}','all'],{cwd:'native/protobuf',stdout:'pipe',stderr:'inherit'});
const dependencies=await new Response(modules.stdout).text();if(await modules.exited)process.exit(1);
const inventory=licenseModules(dependencies);
for(const {name,directory} of inventory){
 const basename=dependencyLicenseBasename(await readdir(directory));
 const file=Bun.file(directory+'/'+basename);
 if(!await file.exists())throw new Error('Missing dependency license: '+name);
 await Bun.write('dist/protobuf/licenses/'+name.replaceAll('/','-')+'-LICENSE',await file.text());
}
await Bun.write('dist/protobuf/NOTICE.txt',moduleNotice(inventory));
