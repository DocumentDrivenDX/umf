import asyncio,json,os
from pathlib import Path
import psycopg
retained=[]
with psycopg.connect(os.environ["CONTROL_DSN"],prepare_threshold=1) as connection:
 with connection.cursor() as cursor:
  for i in range(12):
   assert cursor.execute("SELECT %s::integer AS native_value",(i,)) is cursor
   assert cursor.fetchone()==(i,)
   retained.append(cursor._query is None)
  try: cursor.execute("SELECT 1/0")
  except psycopg.errors.DivisionByZero as error: assert error.sqlstate=="22012"
  else: raise AssertionError("original native error lost")
 connection.rollback()
async def run():
 connection=await psycopg.AsyncConnection.connect(os.environ["CONTROL_DSN"],prepare_threshold=1)
 try:
  async with connection.cursor() as cursor:
   for i in range(8):
    assert await cursor.execute("SELECT %s::integer AS native_value",(i,)) is cursor
    assert await cursor.fetchone()==(i,)
    retained.append(cursor._query is None)
 finally: await connection.close()
asyncio.run(run())
assert any(retained)
Path(os.environ["CONTROL_RESULT"]).write_text(json.dumps({"nativeCalls":21,"actualDriverDidNotRetainQuery":sum(retained),"sameCursorReturn":True,"original22012":True}))
