import {inspectBit128Binding} from './bit128';
export * from './bit128';
import stableManifest from '../../../spec/extensions/binding-stable/package.json';
import manifest from '../../../spec/extensions/binding/package.json';
import {Registry} from '../../registry/registry';
import {validateDocument} from '../../validation/document';
import {readDocument,writeDocument} from '../../model/document';
import {copyJson} from '../../model/json';
import {pointer,UmfError,type Diagnostic,type Document,type ExtensionPackage,type Json,type Validation} from '../../model/types';

export const BINDING_EXTENSION='umf.binding';
export const stableBindingPackage=stableManifest as unknown as ExtensionPackage;
export const bindingPackage=manifest as unknown as ExtensionPackage;

export interface BindingElementRef {module:string;element:string}
export interface BindingFieldRef extends BindingElementRef {field?:string}
export interface BindingRelationshipRef {module:string;name:string}
export interface BindingElement extends BindingElementRef {partition?:string|null;table?:string}
export interface BindingField extends BindingFieldRef {storage:'column'|'embedded';column?:string;documentColumn?:string;path?:string[]}
export interface StableBindingRelationshipRef {module:string;id:string}
export interface StableBindingRelationship extends StableBindingRelationshipRef {storage:'edge'|'foreign_key'|'junction'|'inline'}
export interface BindingRelationship extends BindingRelationshipRef {storage:'edge'|'foreign_key'|'junction'|'inline'}
export type BindingIndexTarget={field:BindingFieldRef}|{documentPath:{field:BindingFieldRef;path:string[]}};
export interface BindingIndex {name:string;kind:'btree'|'hash'|'gin'|'gist'|'expression'|'partial'|'unique'|'clustering';on:BindingIndexTarget[];predicate?:{language:string;version:string;expression:string};unique:boolean;include?:BindingFieldRef[]}
export interface BindingPayload {
  profile:'umf-binding-1'|'umf-binding-2';
  logical:{documentId:string;coreVersion:string};
  target:{system:string;version:string;subset:string};
  elements:BindingElement[];
  fields:BindingField[];
  relationships:(BindingRelationship|StableBindingRelationship)[];
  indexes:BindingIndex[];
  [key:string]:unknown;
}

const refKey=(ref:BindingElementRef)=>JSON.stringify([ref.module,ref.element]);
const fieldKey=(ref:BindingFieldRef)=>JSON.stringify([ref.module,ref.element,ref.field??null]);
const relationshipKey=(ref:BindingRelationshipRef|StableBindingRelationshipRef,profile:BindingPayload['profile'])=>JSON.stringify([ref.module,profile==='umf-binding-2'?(ref as StableBindingRelationshipRef).id:(ref as BindingRelationshipRef).name]);
function bindingSemantics(value:Json,context:{document:Document;path:string;scope:string}):Diagnostic[]{
  const out:Diagnostic[]=[];
  const path=context.path;
  const payload=value as unknown as BindingPayload;
  const add=(code:string,suffix:string,message:string,severity:'error'|'warning'='error')=>out.push({code,path:path+suffix,message,severity});
  if(context.scope!=='document')add('BINDING_SCOPE','','Binding payload belongs to its own document');
  if(context.document.modules.length)add('BINDING_SCOPE','/modules','A binding document does not contain logical modules');
  for(const key of Object.keys(payload))if(!['profile','logical','target','elements','fields','relationships','indexes'].includes(key))add('BINDING_UNKNOWN','/'+pointer(key),'Unknown binding content retained','warning');
  const unknown=(obj:Record<string,unknown>,known:string[],suffix:string)=>{
    for(const key of Object.keys(obj))if(!known.includes(key))add('BINDING_UNKNOWN',suffix+'/'+pointer(key),'Unknown binding content retained','warning');
  };
  unknown(payload.logical,['documentId','coreVersion'],'/logical');
  unknown(payload.target,['system','version','subset'],'/target');
  const unique=(rows:readonly unknown[],label:string,key:(item:any)=>string)=>{
    const seen=new Set<string>();
    rows.forEach((item,index)=>{const identity=key(item);if(seen.has(identity))add('BINDING_DUPLICATE',`/${label}/${index}`,'Duplicate '+label+' assignment');seen.add(identity);});
  };
  unique(payload.elements,'elements',refKey);
  payload.elements.forEach((item,index)=>unknown(item as unknown as Record<string,unknown>,['module','element','partition','table'],`/elements/${index}`));
  unique(payload.fields,'fields',fieldKey);
  payload.fields.forEach((item,index)=>unknown(item as unknown as Record<string,unknown>,['module','element','field','storage','column','documentColumn','path'],`/fields/${index}`));
  unique(payload.relationships,'relationships',row=>relationshipKey(row,payload.profile));
  payload.relationships.forEach((item,index)=>unknown(item as unknown as Record<string,unknown>,['module',payload.profile==='umf-binding-2'?'id':'name','storage'],`/relationships/${index}`));
  for(const[index,field]of payload.fields.entries()){
    if(field.storage==='column'&&!field.column)add('BINDING_COLUMN',`/fields/${index}/column`,'Column storage needs an explicit column name');
    if(field.storage==='column'&&(field.documentColumn!==undefined||field.path!==undefined))add('BINDING_PATH',`/fields/${index}`,'Column storage cannot also declare an embedded path');
    if(field.storage==='embedded'&&(field.documentColumn===undefined||!field.path?.length))add('BINDING_PATH',`/fields/${index}`,'Embedded storage needs a document column and nonempty path');
    if(field.storage==='embedded'&&field.column!==undefined)add('BINDING_COLUMN',`/fields/${index}/column`,'Embedded storage cannot also declare a standalone column');
  }
  const fields=new Map(payload.fields.map(field=>[fieldKey(field),field]));
  const names=new Set<string>();
  for(const[index,item]of payload.indexes.entries()){
    const base=`/indexes/${index}`;
    unknown(item as unknown as Record<string,unknown>,['name','kind','on','predicate','unique','include'],base);
    if(item.predicate)unknown(item.predicate as unknown as Record<string,unknown>,['language','version','expression'],base+'/predicate');
    if(item.kind==='unique'&&!item.unique)add('BINDING_INDEX',base+'/unique','Unique kind requires unique true');
    if(item.kind==='clustering'&&item.unique)add('BINDING_INDEX',base+'/unique','Clustering cannot be unique');
    if(item.kind==='partial'&&!item.predicate)add('BINDING_INDEX',base+'/predicate','Partial kind requires a predicate');
    if(item.kind!=='partial'&&item.predicate)add('BINDING_INDEX',base+'/predicate','Predicate requires partial kind');
    if(item.kind==='expression'&&!item.on.some(target=>'documentPath'in target))add('BINDING_INDEX',base+'/on','This expression profile needs a declared embedded document path');
    const owners=new Set<string>();
    const targets=new Set<string>();
    for(const[targetIndex,target]of item.on.entries()){
      const ref='field'in target?target.field:target.documentPath.field;
      const key=fieldKey(ref),field=fields.get(key);
      const targetPath=base+`/on/${targetIndex}`;
      unknown(target as unknown as Record<string,unknown>,['field','documentPath'],targetPath);
      if('documentPath'in target)unknown(target.documentPath as unknown as Record<string,unknown>,['field','path'],targetPath+'/documentPath');
      unknown(ref as unknown as Record<string,unknown>,['module','element','field'],targetPath+('field'in target?'/field':'/documentPath/field'));
      owners.add(refKey(ref));
      if(targets.has(JSON.stringify(target)))add('BINDING_INDEX',targetPath,'Duplicate ordered index target');
      targets.add(JSON.stringify(target));
      if(!field)add('BINDING_INDEX',targetPath,'Index target has no declared field binding');
      else if('documentPath'in target){
        if(field.storage!=='embedded'||JSON.stringify(field.path)!==JSON.stringify(target.documentPath.path))add('BINDING_INDEX',targetPath,'Document path differs from embedded field binding');
      }else if(field.storage!=='column')add('BINDING_INDEX',targetPath,'Field target requires column storage');
    }
    if(owners.size!==1)add('BINDING_INDEX',base+'/on','One index cannot span logical owner elements');
    const owner=[...owners][0]??'';
    const scoped=JSON.stringify([owner,item.name]);
    if(names.has(scoped))add('BINDING_DUPLICATE',base+'/name','Duplicate index name in table scope');
    names.add(scoped);
    const included=new Set<string>();
    for(const[includeIndex,ref]of (item.include??[]).entries()){
      const key=fieldKey(ref),field=fields.get(key),includePath=base+`/include/${includeIndex}`;
      unknown(ref as unknown as Record<string,unknown>,['module','element','field'],includePath);
      if(!field||field.storage!=='column')add('BINDING_INDEX',includePath,'Included field requires declared column storage');
      if(refKey(ref)!==owner)add('BINDING_INDEX',includePath,'Included field belongs to another table');
      if(included.has(key)||item.on.some(target=>'field'in target&&fieldKey(target.field)===key))add('BINDING_INDEX',includePath,'Duplicate or overlapping include field');
      included.add(key);
    }
  }
  return out;
}

export function bindingRegistry():Registry{return new Registry().register(bindingPackage,bindingSemantics).register(stableBindingPackage,bindingSemantics);}

/** Validate a separate binding document against an explicitly supplied logical model. */
export function inspectBinding(binding:Document,logical:Document):Validation{
  try {
    binding=copyJson(binding) as unknown as Document;
    logical=copyJson(logical) as unknown as Document;
  } catch(error) {
    if(!(error instanceof UmfError))throw error;
    return {valid:false,complete:false,diagnostics:[{code:error.code,path:error.path,message:error.message,severity:'error'}]};
  }
  if(binding.vocabularies?.['umf.binding']?.version==='0.3.0')return inspectBit128Binding(binding,logical);
  const base=validateDocument(binding,bindingRegistry());
  if(!base.valid)return base;
  const diagnostics=[...base.diagnostics];
  const add=(code:string,path:string,message:string)=>diagnostics.push({code,path,message,severity:'error' as const});
  const payload=binding.extensions?.[BINDING_EXTENSION] as unknown as BindingPayload|undefined;
  if(!['0.1.0','0.2.0'].includes(binding.vocabularies[BINDING_EXTENSION]?.version??'')||!payload){add('BINDING_PROFILE','/extensions','Expected a document-scoped umf.binding 0.1.0 or 0.2.0 payload');return {valid:false,complete:false,diagnostics};}
  if(payload&&base.valid){
    const logicalCheck=validateDocument(logical);
    if(!logicalCheck.valid){add('BINDING_MODEL','/extensions/umf.binding/logical','Supplied logical document is invalid');return {valid:false,complete:false,diagnostics};}
    if(payload.logical.documentId!==logical.id||payload.logical.coreVersion!==logical.umf)add('BINDING_MODEL','/extensions/umf.binding/logical','Logical document id/version mismatch');
    const elements=new Set(logical.modules.flatMap(m=>m.elements.map(e=>refKey({module:m.id,element:e.id}))));
    for(const [index,row]of payload.elements.entries())if(!elements.has(refKey(row)))add('BINDING_REFERENCE',`/extensions/umf.binding/elements/${index}`,'Missing logical element');
    for(const [index,row]of payload.fields.entries()){
      const owner=logical.modules.find(m=>m.id===row.module)?.elements.find(e=>e.id===row.element);
      const ddd=owner?.extensions?.['umf.ddd'] as {fields?:Record<string,unknown>}|undefined;
      const found=row.field===undefined ? owner?.kind==='field' : !!ddd?.fields && Object.hasOwn(ddd.fields,row.field);
      if(!found)add('BINDING_REFERENCE',`/extensions/umf.binding/fields/${index}`,'Missing exact logical Field or DDD owner/field');
    }
    for(const [index,row]of payload.relationships.entries()){
      const module=logical.modules.find(m=>m.id===row.module);
      const relationships=(module as {relationships?:{id?:string;name:string}[]}|undefined)?.relationships;
      const matches=Array.isArray(relationships)?relationships.filter(r=>payload.profile==='umf-binding-2'?'id'in row&&r.id===row.id:'name'in row&&r.name===row.name):[];
      if((payload.profile==='umf-binding-2'&&logical.umf!=='0.7.0')||matches.length!==1)add('BINDING_REFERENCE',`/extensions/umf.binding/relationships/${index}`,'Missing authored relationship');
    }
  }
  return {valid:!diagnostics.some(d=>d.severity==='error'),complete:diagnostics.length===0,diagnostics};
}

export function readBindingDocument(text:string,logical:Document,format:'json'|'yaml'='yaml'):Document{
  const binding=readDocument(text,format);
  const checked=inspectBinding(binding,logical);
  if(!checked.valid)throw new UmfError('BINDING_DOCUMENT',JSON.stringify(checked.diagnostics));
  return binding;
}

export function writeBindingDocument(binding:Document,logical:Document,format:'json'|'yaml'='yaml'):string{
  binding=copyJson(binding) as unknown as Document;logical=copyJson(logical) as unknown as Document;
  const checked=inspectBinding(binding,logical);
  if(!checked.valid)throw new UmfError('BINDING_DOCUMENT',JSON.stringify(checked.diagnostics));
  return writeDocument(binding,format);
}

export function getBinding(binding:Document,logical:Document):BindingPayload{
  binding=copyJson(binding) as unknown as Document;logical=copyJson(logical) as unknown as Document;
  const checked=inspectBinding(binding,logical);
  if(!checked.valid)throw new UmfError('BINDING_DOCUMENT',JSON.stringify(checked.diagnostics));
  if(binding.vocabularies[BINDING_EXTENSION]?.version==='0.3.0')throw new UmfError('BINDING_PROFILE','Legacy native generators do not admit scalar-carrier bindings');
  return copyJson(binding.extensions![BINDING_EXTENSION]) as unknown as BindingPayload;
}

export interface BindingIndexOutcome {name:string;path:string;outcome:'exact'|'approximated'|'not-expressible'|'unknown';reason?:string}
export interface BindingIndexProjection {status:'projected'|'reported'|'blocked';source:Document;logical:Document;target:BindingPayload['target'];outcomes:BindingIndexOutcome[];candidate?:BindingIndex[]}

/** Qualifies planned index carriers. Native DDL/catalog validation is a separate gate. */
export function projectBindingIndexes(binding:Document,logical:Document,lossPolicy:'strict'|'report'):BindingIndexProjection{
  const checked=inspectBinding(binding,logical);
  if(checked.diagnostics.some(d=>d.code==='BINDING_UNKNOWN'))throw new UmfError('BINDING_INCOMPLETE','Unknown binding content may affect index projection');
  const payload=getBinding(binding,logical);
  const outcomes:BindingIndexOutcome[]=payload.indexes.map((item,index)=>{
    const path=`/extensions/umf.binding/indexes/${index}`;
    const system=payload.target.system,version=payload.target.version;
    if(system==='postgresql'&&version.startsWith('17')){
      if(item.kind==='clustering')return {name:item.name,path,outcome:'not-expressible',reason:'PostgreSQL clustering is not a declared index kind'};
      if(item.predicate&&(item.predicate.language!=='postgresql'||!item.predicate.version.startsWith('17')))return {name:item.name,path,outcome:'unknown',reason:'Predicate language/version is not the selected PostgreSQL profile'};
      return {name:item.name,path,outcome:'exact'};
    }
    if(system==='sqlserver'){
      if(['btree','unique'].includes(item.kind))return {name:item.name,path,outcome:'exact'};
      if(item.kind==='partial'&&item.predicate?.language==='tsql')return {name:item.name,path,outcome:'exact'};
      return {name:item.name,path,outcome:'not-expressible',reason:'No supported SQL Server index carrier for this kind'};
    }
    if(system==='delta'){
      if(item.kind!=='clustering')return {name:item.name,path,outcome:'not-expressible',reason:'Delta profile only represents liquid clustering'};
      if(!/^3\.(?:2|[3-9])(?:\.|$)/.test(version))return {name:item.name,path,outcome:'unknown',reason:'Liquid-clustering profile requires pinned Delta 3.2 or later 3.x'};
      if(item.on.length>4||item.include?.length||item.on.some(target=>'documentPath'in target))return {name:item.name,path,outcome:'not-expressible',reason:'Liquid clustering requires at most four direct columns and no included or document-path targets'};
      return {name:item.name,path,outcome:'exact'};
    }
    if(system==='iceberg'){
      if(item.kind!=='clustering')return {name:item.name,path,outcome:'not-expressible',reason:'No Iceberg index carrier for this kind'};
      if(!/^[23](?:\.|$)/.test(version))return {name:item.name,path,outcome:'unknown',reason:'Sort-order analogue requires a pinned Iceberg v2 or v3 metadata profile'};
      if(item.include?.length||item.on.some(target=>'documentPath'in target))return {name:item.name,path,outcome:'not-expressible',reason:'This Iceberg profile maps direct columns only; includes and document paths are unsupported'};
      return {name:item.name,path,outcome:'approximated',reason:'Default sort order is a writer hint, not an enforced index or clustering guarantee'};
    }
    if(system==='parquet')return {name:item.name,path,outcome:'not-expressible',reason:'Parquet file schema does not enforce indexes'};
    return {name:item.name,path,outcome:'unknown',reason:'Target profile has no qualified index mapping'};
  });
  const nonExact=outcomes.some(row=>row.outcome!=='exact');
  const result:BindingIndexProjection={status:nonExact?(lossPolicy==='strict'?'blocked':'reported'):'projected',source:copyJson(binding) as unknown as Document,logical:copyJson(logical) as unknown as Document,target:copyJson(payload.target) as BindingPayload['target'],outcomes};
  if(result.status!=='blocked')result.candidate=payload.indexes.filter((_,index)=>outcomes[index]!.outcome==='exact');
  return result;
}

export interface BindingMigrationReceipt {
  profile:'umf-binding-migration-1';
  original:Document;
  logical:Document;
  migrated:Document;
  mappings:{path:string;original:BindingRelationship;stable:StableBindingRelationship}[];
}
export interface BindingMigrationResult {document:Document;receipt:BindingMigrationReceipt}

/** Explicit, atomic name-to-ID migration against the caller's exact paired model. */
export function migrateBindingRelationships(binding:Document,logical:Document):BindingMigrationResult {
  const original=copyJson(binding) as unknown as Document;
  const model=copyJson(logical) as unknown as Document;
  const payload=getBinding(original,model);
  if(payload.profile!=='umf-binding-1'||original.vocabularies[BINDING_EXTENSION]?.version!=='0.1.0'||model.umf!=='0.7.0')throw new UmfError('BINDING_MIGRATION','Migration requires binding 0.1.0 and the paired relationship core 0.7.0 model');
  const mappings:BindingMigrationReceipt['mappings']=[];
  const document=copyJson(original) as unknown as Document;
  const next=document.extensions![BINDING_EXTENSION] as unknown as BindingPayload;
  next.relationships=payload.relationships.map((entry,index)=>{
    const path=`/extensions/umf.binding/relationships/${index}`;
    if(!('name'in entry)||Object.hasOwn(entry,'id'))throw new UmfError('BINDING_MIGRATION_COLLISION','Existing ID-shaped unknown content cannot be overwritten',path);
    const rows=model.modules.find(m=>m.id===entry.module)?.relationships as {id:string;name:string}[]|undefined;
    const matches=rows?.filter(r=>r.name===entry.name)??[];
    if(matches.length!==1)throw new UmfError('BINDING_MIGRATION_REFERENCE','Exactly one authored relationship name must match',path);
    const stable=copyJson(entry) as unknown as StableBindingRelationship & {name?:string};
    delete stable.name;stable.id=matches[0]!.id;
    mappings.push({path,original:copyJson(entry) as unknown as BindingRelationship,stable:copyJson(stable) as unknown as StableBindingRelationship});
    return stable;
  });
  next.profile='umf-binding-2';document.vocabularies[BINDING_EXTENSION]!.version='0.2.0';
  const checked=inspectBinding(document,model);
  if(!checked.valid)throw new UmfError('BINDING_MIGRATION',JSON.stringify(checked.diagnostics));
  return {document,receipt:copyJson({profile:'umf-binding-migration-1',original,logical:model,migrated:document,mappings}) as unknown as BindingMigrationReceipt};
}

function equalBindingJson(a:unknown,b:unknown):boolean {
  if(a===b)return true;
  if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
  const left=Object.keys(a),right=Object.keys(b);
  return left.length===right.length&&left.every(key=>Object.hasOwn(b,key)&&equalBindingJson((a as Record<string,unknown>)[key],(b as Record<string,unknown>)[key]));
}
export interface BindingRollbackResult {
  document:Document;
  residuals:{path:string;reason:string;value:Json}[];
}
/** Restore the exact original; retain every later edit explicitly, without name reassociation. */
export function rollbackBindingRelationships(current:Document,logical:Document,receipt:BindingMigrationReceipt):BindingRollbackResult {
  const retained=copyJson(receipt) as unknown as BindingMigrationReceipt;
  if(retained.profile!=='umf-binding-migration-1')throw new UmfError('BINDING_RECEIPT','Unsupported migration receipt');
  const expected=migrateBindingRelationships(retained.original,retained.logical).receipt;
  if(!equalBindingJson(expected,retained))throw new UmfError('BINDING_RECEIPT','Receipt does not reproduce its retained migration');
  const now=copyJson(current) as unknown as Document;
  const payload=getBinding(now,logical);
  if(payload.profile!=='umf-binding-2'||now.id!==retained.migrated.id||now.umf!==retained.migrated.umf||logical.id!==retained.logical.id||logical.umf!==retained.logical.umf)throw new UmfError('BINDING_ROLLBACK','Current binding/model identities differ from migration');
  const residuals:BindingRollbackResult['residuals']=[];
  payload.relationships.forEach((row,index)=>{
    if(!retained.mappings.some(mapping=>equalBindingJson(mapping.stable,row)))residuals.push({path:`/extensions/umf.binding/relationships/${index}`,reason:'ID-only or edited relationship choice is not representable in the restored name-based binding',value:copyJson(row)});
  });
  if(!equalBindingJson(now,retained.migrated))residuals.push({path:'',reason:'Complete current binding retained: rollback restores original content and does not discard later edits',value:copyJson(now)});
  return {document:copyJson(retained.original) as unknown as Document,residuals};
}
