select * from {{ ref('broken') }}
