# Generated from pinned UMF inputs. Regenerate; do not edit.
from __future__ import annotations
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, ClassVar, TYPE_CHECKING, TypeVar, final
from pydantic import BeforeValidator, MISSING, TypeAdapter
from umf_access.dsl import FieldRef, GeneratedSource
from umf_access.types import StrictModel, Vector
from umf_access.values import validate_integer, validate_decimal, validate_string, validate_date, validate_instant, validate_local, validate_boolean, validate_binary, validate_length, validate_range, validate_allowed, validate_vector, validate_float32, FieldValidator
_AliasTag = TypeVar("_AliasTag")
UMF_GENERATED_SOURCE = GeneratedSource(document_id="typed-search-e2e", core_version="0.8.0", document_sha256="62dac138cfb2b9bbf2dab72ff965b4aff4844a9d71b7b953a9874ca6c2301d18", input_digest="52003978e8a6626aac4a8488103c94add980072c5e8425a3ee0b9708f74e076c", runtime_abi="umf-access-runtime/0.1")
if TYPE_CHECKING:
    from .fields import DocColumns, DocQuery, DocAlias, DocSearch

validate_field__modules_0_extensions_umf_access_views_0_fields_0 = FieldValidator(kind="string")

validate_field__modules_0_extensions_umf_access_views_0_fields_1 = FieldValidator(kind="string")

validate_field__modules_0_extensions_umf_access_views_0_fields_4 = FieldValidator(kind="float32")

validate_field__modules_0_extensions_umf_access_views_0_fields_2_row = FieldValidator(kind="vector", dimensions=3, minimum=3, maximum=3)

validate_field__modules_0_extensions_umf_access_views_0_fields_2_create = FieldValidator(kind="vector", dimensions=3, minimum=3, maximum=3)

validate_field__modules_0_extensions_umf_access_views_0_fields_3 = FieldValidator(kind="string")

@final
class Doc(StrictModel):
    UMF_SOURCE: ClassVar[GeneratedSource] = UMF_GENERATED_SOURCE
    c: ClassVar[DocColumns]
    objects: ClassVar[DocQuery]
    @classmethod
    def alias(cls, tag: type[_AliasTag]) -> DocAlias[_AliasTag]:
        from .fields import DocAlias
        return DocAlias(tag)
    s: ClassVar[DocSearch]
    id: Annotated[str, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_0)]
    body: Annotated[str, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_1)]
    embedding: Annotated[Vector, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_2_row)]
    owner: Annotated[str, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_3)]
    UMF_FIELDS: ClassVar[tuple[tuple[str, str, str], ...]] = (("search", "id", "id"), ("search", "body", "body"), ("search", "embedding", "embedding"), ("search", "owner", "owner"),)
    UMF_BUNDLE_INPUT_DIGEST: ClassVar[str] = "52003978e8a6626aac4a8488103c94add980072c5e8425a3ee0b9708f74e076c"
    UMF_RUNTIME_ABI: ClassVar[tuple[str, str, str]] = ("umf_access", "0.1.0.dev0", "umf-access-runtime/0.1")
    UMF_FINAL: ClassVar[bool] = True

@final
class DocCreate(StrictModel):
    UMF_SOURCE: ClassVar[GeneratedSource] = UMF_GENERATED_SOURCE
    id: Annotated[str, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_0)]
    body: Annotated[str, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_1)]
    embedding: Annotated[Vector, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_2_create)]
    owner: Annotated[str, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_3)]
    UMF_FIELDS: ClassVar[tuple[tuple[str, str, str], ...]] = (("search", "id", "id"), ("search", "body", "body"), ("search", "embedding", "embedding"), ("search", "owner", "owner"),)
    UMF_BUNDLE_INPUT_DIGEST: ClassVar[str] = "52003978e8a6626aac4a8488103c94add980072c5e8425a3ee0b9708f74e076c"
    UMF_RUNTIME_ABI: ClassVar[tuple[str, str, str]] = ("umf_access", "0.1.0.dev0", "umf-access-runtime/0.1")
    UMF_FINAL: ClassVar[bool] = True

@final
class DocPatch(StrictModel):
    UMF_SOURCE: ClassVar[GeneratedSource] = UMF_GENERATED_SOURCE
    body: Annotated[str, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_1)] | MISSING = MISSING
    embedding: Annotated[Vector, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_2_create)] | MISSING = MISSING
    UMF_FIELDS: ClassVar[tuple[tuple[str, str, str], ...]] = (("search", "body", "body"), ("search", "embedding", "embedding"),)
    UMF_BUNDLE_INPUT_DIGEST: ClassVar[str] = "52003978e8a6626aac4a8488103c94add980072c5e8425a3ee0b9708f74e076c"
    UMF_RUNTIME_ABI: ClassVar[tuple[str, str, str]] = ("umf_access", "0.1.0.dev0", "umf-access-runtime/0.1")
    UMF_FINAL: ClassVar[bool] = True

@final
class DocSummary(StrictModel):
    UMF_SOURCE: ClassVar[GeneratedSource] = UMF_GENERATED_SOURCE
    UMF_PROJECTION_OWNER: ClassVar[type[Doc]] = Doc
    @classmethod
    def _umf_projection_model(cls) -> type[DocSummary]:
        return cls
    UMF_PROJECTION_FIELDS: ClassVar[tuple[FieldRef, ...]] = (FieldRef(source=UMF_GENERATED_SOURCE, module="search", element="Doc", field="id", field_module="search", logical_name="id"), FieldRef(source=UMF_GENERATED_SOURCE, module="search", element="Doc", field="body", field_module="search", logical_name="body"),)
    id: Annotated[str, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_0)]
    body: Annotated[str, BeforeValidator(validate_field__modules_0_extensions_umf_access_views_0_fields_1)]
    UMF_FIELDS: ClassVar[tuple[tuple[str, str, str], ...]] = (("search", "id", "id"), ("search", "body", "body"),)
    UMF_BUNDLE_INPUT_DIGEST: ClassVar[str] = "52003978e8a6626aac4a8488103c94add980072c5e8425a3ee0b9708f74e076c"
    UMF_RUNTIME_ABI: ClassVar[tuple[str, str, str]] = ("umf_access", "0.1.0.dev0", "umf-access-runtime/0.1")
    UMF_FINAL: ClassVar[bool] = True

DocSummary.model_rebuild()
__all__ = ["Doc", "DocCreate", "DocPatch", "DocSummary"]
