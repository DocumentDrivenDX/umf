"""Shared generated-model ABI. Imports perform no host operations."""
from typing import TypeAlias

from pydantic import BaseModel, ConfigDict, MISSING as MISSING

Vector: TypeAlias = tuple[float, ...]


class ValueRuleError(ValueError):
    """A carrier or authored constraint refused; messages contain no values."""


class CodecError(ValueError):
    """A codec boundary refused its value graph or column inventory."""


class StrictModel(BaseModel):
    """Generated classes inherit directly, then seal their own subclass hook.

    Literal defaults belong to the engine, never to this base. Codecs must
    revalidate raw attributes even though assignment is frozen.
    """

    model_config = ConfigDict(
        strict=True, extra="forbid", frozen=True,
        revalidate_instances="always", hide_input_in_errors=True,
    )
