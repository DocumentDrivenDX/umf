from __future__ import annotations
"""Pure in-memory capture of explicitly supplied declarations, never module scanning."""
from dataclasses import dataclass, fields, is_dataclass
from datetime import date, datetime
from decimal import Decimal
import inspect
from itertools import combinations
from types import UnionType
from typing import Any, Callable, Union, cast, get_args, get_origin, get_type_hints
from pydantic import BaseModel, MISSING

from .dsl import Param, Terminal
from .types import ActionRef
from .dsl._context import CURRENT, CaptureContext, CaptureError as CaptureError
from .dsl._nodes import FieldRef, Node, RecordRef


@dataclass(frozen=True)
class CapturedParameter:
    name: str
    carrier: object
    optional: bool
    key_components: tuple[str, ...] = ()


@dataclass(frozen=True)
class CapturedVariant:
    presence: tuple[str, ...]
    node: Node
    parameters: tuple[CapturedParameter, ...]


@dataclass(frozen=True)
class CapturedDeclaration:
    name: str
    kind: str
    parameters: tuple[CapturedParameter, ...]
    variants: tuple[CapturedVariant, ...]
    action: tuple[str, str] | None = None


def _members(annotation: object) -> tuple[object, ...]:
    return get_args(annotation) if get_origin(annotation) in (Union, UnionType) else (annotation,)


def _supported(annotation: object) -> bool:
    if annotation is MISSING or annotation is type(None):
        return True
    if any(annotation is carrier for carrier in (str, bool, int, Decimal, bytes, date, datetime)):
        return True
    origin = get_origin(annotation)
    args = get_args(annotation)
    if origin in (Union, UnionType):
        return all(_supported(arg) for arg in args)
    if origin in (list, tuple):
        return bool(args) and all(arg is Ellipsis or _supported(arg) for arg in args)
    if origin is dict:
        return len(args) == 2 and args[0] is str and _supported(args[1])
    return isinstance(annotation, type) and issubclass(annotation, BaseModel)


def _parameters(function: Callable[..., Any]) -> tuple[CapturedParameter, ...]:
    original = inspect.unwrap(function)
    try:
        hints = get_type_hints(original)
        signature = inspect.signature(original)
    except (NameError, TypeError, ValueError) as error:
        raise CaptureError("CAPTURE_SIGNATURE", "unresolved declaration annotations") from error
    if len(signature.parameters) > 64:
        raise CaptureError("CAPTURE_SIGNATURE", "more than 64 declaration parameters")
    result: list[CapturedParameter] = []
    for name, parameter in signature.parameters.items():
        annotation = hints.get(name)
        if parameter.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            raise CaptureError("CAPTURE_SIGNATURE", "variadic declarations are unsupported")
        if get_origin(annotation) is not Param or len(get_args(annotation)) != 1:
            raise CaptureError("CAPTURE_SIGNATURE", "every parameter must be Param with supported carrier")
        carrier = get_args(annotation)[0]
        if not _supported(carrier):
            raise CaptureError("CAPTURE_SIGNATURE", "unsupported parameter carrier")
        members = _members(carrier)
        key_models = [m for m in members if isinstance(m, type) and issubclass(m, BaseModel)]
        components = tuple(key_models[0].model_fields) if len(key_models) == 1 else ()
        result.append(CapturedParameter(name, carrier, any(m is MISSING for m in members), components))
    names = {p.name for p in result}
    expanded = [f"{p.name}__{c}" for p in result for c in p.key_components]
    if len(set(expanded)) != len(expanded) or names.intersection(expanded):
        raise CaptureError("CAPTURE_SIGNATURE", "key component parameter names collide")
    return tuple(result)


def _canonical(value: object) -> object:
    if isinstance(value, tuple):
        return tuple(_canonical(item) for item in cast(tuple[object, ...], value))
    if is_dataclass(value) and not isinstance(value, type):
        return (type(value).__module__, type(value).__qualname__, tuple((f.name, _canonical(getattr(value, f.name))) for f in fields(value)))
    if isinstance(value, type):
        return (value.__module__, value.__qualname__)
    return value


def _validate_node(node: Node, parameters: tuple[CapturedParameter, ...]) -> None:
    if node.op not in {"all", "first", "one", "count", "exists", "get", "page", "group_count", "update"}:
        raise CaptureError("CAPTURE_UNSUPPORTED", "unsupported terminal form")
    if not node.args or not isinstance(node.args[0], RecordRef):
        raise CaptureError("CAPTURE_UNSUPPORTED", "terminal has no record identity")
    record = node.args[0]
    parameter_map = {p.name: p for p in parameters}
    temporal_parameters: dict[str, str] = {}

    def has_omitted(value: object) -> bool:
        if isinstance(value, Node):
            return value.op == "omitted" or any(has_omitted(child) for child in value.args)
        return isinstance(value, tuple) and any(has_omitted(child) for child in cast(tuple[object, ...], value))

    def visit(value: object) -> None:
        if isinstance(value, FieldRef):
            if (value.module, value.element) != (record.module, record.element):
                raise TypeError("expression column belongs to another Record")
        elif isinstance(value, Node):
            if value.op in ("param", "key_param"):
                name = cast(str, value.args[0])
                if name not in parameter_map:
                    raise CaptureError("CAPTURE_SIGNATURE", "expression references an undeclared parameter")
                components = value.args[1] if value.op == "key_param" else ()
                if components != parameter_map[name].key_components:
                    raise CaptureError("CAPTURE_SIGNATURE", "Key component parameters differ from declared carrier")
            if value.op in ("=", "<>", "<", "<=", ">", ">=", "BETWEEN", "IN", "NOT IN"):
                left = value.args[0]
                if isinstance(left, Node) and left.op == "column":
                    field = cast(FieldRef, left.args[0])
                    if field.temporal is not None:
                        for right in value.args[1:]:
                            if isinstance(right, Node) and right.op == "param":
                                name = cast(str, right.args[0])
                                if name in temporal_parameters and temporal_parameters[name] != field.temporal:
                                    raise CaptureError("CAPTURE_UNSUPPORTED", "parameter spans incompatible temporal profiles")
                                temporal_parameters[name] = field.temporal
            if value.op in ("and", "or", "not") and has_omitted(value):
                raise CaptureError("CAPTURE_UNSUPPORTED", "optional filters must be top-level filter arguments")
            for child in value.args:
                visit(child)
        elif isinstance(value, tuple):
            for child in cast(tuple[object, ...], value):
                visit(child)
    visit(node)


def _invoke(function: Callable[..., Any], parameters: tuple[CapturedParameter, ...], presence: frozenset[str]) -> tuple[Node, frozenset[str]]:
    context = CaptureContext(frozenset(p.name for p in parameters if p.optional), presence)
    token = CURRENT.set(context)
    try:
        signature = inspect.signature(function)
        positional: list[Param[Any]] = []
        keywords: dict[str, Param[Any]] = {}
        for parameter in parameters:
            symbolic = Param[Any](parameter.name, parameter.key_components)
            if signature.parameters[parameter.name].kind is inspect.Parameter.POSITIONAL_ONLY:
                positional.append(symbolic)
            else:
                keywords[parameter.name] = symbolic
        try:
            result = function(*positional, **keywords)
        except AttributeError as error:
            raise CaptureError("CAPTURE_UNSUPPORTED", "declaration uses an unsupported form") from error
        if not isinstance(result, Terminal):
            raise CaptureError("CAPTURE_UNSUPPORTED", "declaration must return a DSL terminal")
        _validate_node(result.node, parameters)
        return result.node, frozenset(context.used_optional)
    finally:
        CURRENT.reset(token)


def capture(function: Callable[..., Any]) -> CapturedDeclaration:
    kind = getattr(function, "__umf_kind__", None)
    if kind not in ("query", "command"):
        raise CaptureError("CAPTURE_UNSUPPORTED", "explicit query/command decorator required")
    parameters = _parameters(function)
    optional = frozenset(p.name for p in parameters if p.optional)

    def twice(presence: frozenset[str]) -> tuple[Node, frozenset[str]]:
        first = _invoke(function, parameters, presence)
        second = _invoke(function, parameters, presence)
        if _canonical(first) != _canonical(second):
            raise CaptureError("CAPTURE_NONDETERMINISTIC", "two captures differ")
        return first

    _, used = twice(optional)
    if len(used) > 4:
        raise CaptureError("VARIANT_LIMIT", "optional filters exceed 16 variants")
    # Declaration order, not set iteration, controls deterministic variant bytes.
    names = tuple(p.name for p in parameters if p.name in used)
    variants: list[CapturedVariant] = []
    for size in range(len(names) + 1):
        for selected in combinations(names, size):
            node, variant_used = twice(frozenset(selected))
            if variant_used != used:
                raise CaptureError("CAPTURE_UNSUPPORTED", "optional-filter topology changes across variants")
            if (node.op == "update") != (kind == "command"):
                raise CaptureError("CAPTURE_UNSUPPORTED", "writes require command and reads require query")
            variants.append(CapturedVariant(selected, node, parameters))
    action = None
    if kind == "command":
        reference = getattr(function, "__umf_action__", None)
        if not isinstance(reference, ActionRef):
            raise CaptureError("CAPTURE_UNSUPPORTED", "command requires generated action identity")
        action = (reference.module, reference.action)
    return CapturedDeclaration(function.__name__, kind, parameters, tuple(variants), action)
